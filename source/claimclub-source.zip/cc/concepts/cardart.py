# Settlement card tops, option A (Henry, Nov 15): every offer gets the same recipe. A gradient made from one
# brand color, a faint oversized copy of the mark in the corner, and the mark centered. Three kinds:
#   mark: a vector logo from Simple Icons (CC0). Current package, or an older version for brands it later dropped.
#   word: the brand name set in Manrope on its brand color, for well-known brands with no free vector logo.
#   cat:  the settlement's Lucide category icon on that category's color, for everyone else.
# Writes cc/marks/<id>.svg (registered in /tmp/blobmap.json) and the cardArt() table in src/landing.js.
# Run: python3 cardart.py   (needs node_modules from `npm i simple-icons` in /tmp/si and old versions in /tmp/siold)
import json, os, re, math, hashlib, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__)); CC = os.path.dirname(HERE)
SETS = [x for x in json.load(open(os.path.join(HERE, 'sets.json'))) if not x.get('st')]
LANDING = os.path.join(CC, 'src', 'landing.js')
BLOBMAP = '/tmp/blobmap.json'

# id -> (simple-icons slug, package dir or None for current, base color override, mark color override)
MARK = {
    'apple': ('apple', None, '#1D1D1F', None), 'google': ('google', None, None, None), 'youtube': ('youtube', None, None, None),
    'netflix': ('netflix', None, None, None), 'googleplay': ('googleplay', None, '#01875F', None), 'ubereats': ('ubereats', None, None, None),
    'starbucks': ('starbucks', None, None, None), 'ups': ('ups', None, '#351C15', '#FFB500'), 'upsfair': ('ups', None, '#351C15', '#FFB500'),
    'visa': ('visa', None, None, None), 'toyota': ('toyota', None, None, None), 'kia': ('kia', None, '#05141F', None),
    'hyundaikia': ('hyundai', None, None, None), 'hk_theft': ('hyundai', None, None, None), 'sonataphev': ('hyundai', None, None, None),
    'bofa': ('bankofamerica', None, None, None), 'westernunion': ('westernunion', None, '#FFDD00', '#0A0A0A'), 'seatgeek': ('seatgeek', None, None, None),
    'deere': ('johndeere', None, None, '#FFDE00'), 'netflix2': None, 'ubisoft': ('ubisoft', None, '#0070FF', None), 'datadog': ('datadog', None, None, None),
    'fujifilm': ('fujifilm', None, None, None), 'webtoon': ('webtoon', None, None, None), 'fordtransit': ('ford', None, None, None),
    'cashapp_mla': ('cashapp', None, None, None),
    'amazon': ('amazon', 'v4.25.0', '#232F3E', '#FFFFFF'), 'openai': ('openai', 'v4.25.0', '#10A37F', None), 'twitter': ('twitter', 'v4.25.0', None, None),
    'yahoo': ('yahoo', 'v4.25.0', None, None),
}
MARK = {k: v for k, v in MARK.items() if v}
# Well-known brands without a free vector logo: brand color plus the name.
WORD = {
    'disney': ('#0B1C4D', 'Disney+', '#FFFFFF'), 'cvs': ('#CC0000', 'CVS', '#FFFFFF'), 'walgreens': ('#E31837', 'Walgreens', '#FFFFFF'),
    'bestbuy': ('#0046BE', 'Best Buy', '#FFE000'), 'kroger': ('#134B97', 'Kroger', '#FFFFFF'), 'capone': ('#004977', 'Capital One', '#FFFFFF'),
    'equifax': ('#9E1B32', 'Equifax', '#FFFFFF'), 'equifax_inq': ('#9E1B32', 'Equifax', '#FFFFFF'), 'transunion': ('#00A6CA', 'TransUnion', '#FFFFFF'),
    'myfitnesspal': ('#0066EE', 'MyFitnessPal', '#FFFFFF'), 'bn': ('#2A5934', 'Barnes & Noble', '#FFFFFF'), 'fanatics': ('#D50A0A', 'Fanatics', '#FFFFFF'),
    'hertz': ('#FFD100', 'Hertz', '#0A0A0A'), 'geico_clue': ('#0E3A8C', 'GEICO', '#FFFFFF'), 'keurig': ('#1A1A1A', 'Keurig', '#FFFFFF'),
    'whirlpool_fz': ('#003C71', 'Whirlpool', '#FFFFFF'), 'whirlpool_frost': ('#003C71', 'Whirlpool', '#FFFFFF'), 'warnermusic': ('#111111', 'Warner Music', '#FFFFFF'),
    'goodrx': ('#FDDB00', 'GoodRx', '#0A0A0A'), 'knotts': ('#0055A5', 'Six Flags', '#FFFFFF'), 'navy': ('#003A70', 'Navy Federal', '#FFFFFF'),
    'squatch': ('#1E3A2B', 'Dr. Squatch', '#FFFFFF'), 'merrill': ('#012169', 'Merrill', '#FFFFFF'), 'ey': ('#2E2E38', 'EY', '#FFE600'),
    'dexcom': ('#58A618', 'Dexcom', '#FFFFFF'), 'davita': ('#00A3E0', 'DaVita', '#FFFFFF'), 'tyson': ('#C8102E', 'Tyson', '#FFFFFF'),
    'fleatick': ('#0073CF', 'Petco · PetSmart · Chewy', '#FFFFFF'), 'onemain': ('#14544B', 'OneMain', '#FFFFFF'), 'lemonade': ('#FF0083', 'Lemonade', '#FFFFFF'),
    'equinox': ('#111111', 'Equinox', '#FFFFFF'), 'sandoz': ('#0460A9', 'Sandoz', '#FFFFFF'), 'mdlive': ('#00857C', 'MDLIVE', '#FFFFFF'),
    'flo': ('#FF4F7B', 'Flo', '#FFFFFF'), 'goodyear': None,
    'sanyo': ('#0B4DA2', 'Sanyo', '#FFFFFF'), 'ncaatennis': ('#0067B1', 'NCAA', '#FFFFFF'), 'frontier401k': ('#D7282F', 'Frontier', '#FFFFFF'),
    'jci': ('#007DB8', 'Johnson Controls', '#FFFFFF'), 'firstcash': ('#00843D', 'FirstCash', '#FFFFFF'), 'teleflora': ('#C8102E', 'Teleflora', '#FFFFFF'),
    'realpage': ('#E2231A', 'RealPage', '#FFFFFF'), 'marqeta': ('#1A1A1A', 'Marqeta', '#FFFFFF'), 'columbia': ('#1D4F91', 'Columbia', '#FFFFFF'),
    'harvard': ('#A51C30', 'Harvard', '#FFFFFF'), 'duke': ('#012169', 'Duke Health', '#FFFFFF'), 'fordham': ('#860038', 'Fordham', '#FFFFFF'),
}
WORD = {k: v for k, v in WORD.items() if v}
CATC = {'privacy': '#3B4BD8', 'health': '#C9375F', 'products': '#D9681A', 'apps': '#7340E0', 'bank': '#0E6B5C', 'auto': '#1F64B0', 'invest': '#12805C', 'arb': '#475166'}

def rgb(h): h = h.lstrip('#'); return [int(h[i:i + 2], 16) for i in (0, 2, 4)]
def hexs(c): return '#' + ''.join(f'{max(0, min(255, round(v))):02X}' for v in c)
def mix(a, b, t): A, B = rgb(a), rgb(b); return hexs([A[i] + (B[i] - A[i]) * t for i in range(3)])
def lum(h):
    c = [v / 255 for v in rgb(h)]; c = [v / 12.92 if v <= .03928 else ((v + .055) / 1.055) ** 2.4 for v in c]
    return .2126 * c[0] + .7152 * c[1] + .0722 * c[2]
def grad(base): return f'radial-gradient(130% 100% at 15% 0%, {mix(base, "#FFFFFF", .18)} 0%, {base} 52%, {mix(base, "#000000", .28)} 100%)'
def fit(w, h, area=3400, maxw=150, maxh=66):
    a = w / h; H = math.sqrt(area / a); W = a * H; sc = min(1, maxw / W, maxh / H); return round(W * sc), round(H * sc)

# Simple Icons data (current and old versions)
cur = json.loads(subprocess.check_output(['node', '-e', "const s=require('simple-icons');const o={};for(const k in s){const i=s[k];if(i&&i.slug)o[i.slug]={t:i.title,h:i.hex,p:i.path}};console.log(JSON.stringify(o))"], cwd='/tmp/si'))
def icon(slug, ver):
    if not ver: return cur[slug]
    base = f'/tmp/siold/{ver}/package'
    data = json.load(open(f'{base}/_data/simple-icons.json'))['icons']
    svg = open(f'{base}/icons/{slug}.svg').read(); p = re.search(r' d="([^"]+)"', svg).group(1)
    for i in data:
        if re.sub(r'[^a-z0-9]', '', i['title'].lower().replace('+', 'plus').replace('.', 'dot').replace('&', 'and')) == slug or i.get('slug') == slug:
            return {'t': i['title'], 'h': i['hex'], 'p': p}
    raise KeyError(slug)
GOOGLE = [('#EA4335', 'M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z'),
          ('#4285F4', 'M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z'),
          ('#FBBC05', 'M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z'),
          ('#34A853', 'M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z')]

# measure path bounds in Chrome
need = {k: icon(*v[:2]) for k, v in MARK.items() if k != 'google'}
from playwright.sync_api import sync_playwright
with sync_playwright() as pw:
    b = pw.chromium.launch(executable_path='/usr/bin/google-chrome'); pg = b.new_page()
    pg.set_content('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">' + ''.join(f'<path id="p_{k}" d="{v["p"]}"/>' for k, v in need.items()) + '</svg>')
    BB = {k: pg.evaluate(f"(()=>{{const r=document.getElementById('p_{k}').getBBox();return [r.x,r.y,r.width,r.height]}})()") for k in need}
    b.close()

bm = json.load(open(BLOBMAP))
os.makedirs(os.path.join(CC, 'marks'), exist_ok=True)
ART = {}
for d in SETS:
    k = d['id']
    if k in MARK:
        slug, ver, bo, fo = MARK[k]
        if k == 'google':
            base, fg = '#FFFFFF', None; vb = [0, 0, 48, 48]
            body = ''.join(f'<path fill="{c}" d="{p}"/>' for c, p in GOOGLE)
            bg = 'radial-gradient(130% 100% at 15% 0%, #FFFFFF 0%, #F3F6FD 55%, #DCE6FB 100%)'; gop = .08
        else:
            ic = need[k]; base = bo or '#' + ic['h']; fg = fo or ('#FFFFFF' if lum(base) < .45 else '#0A0F0D'); vb = BB[k]
            body = f'<path fill="{fg}" d="{ic["p"]}"/>'; bg = grad(base); gop = .1
        x, y, w, h = vb; pad = max(w, h) * .02
        svg = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{x - pad:.3f} {y - pad:.3f} {w + 2 * pad:.3f} {h + 2 * pad:.3f}">{body}</svg>'
        fn = f'marks/{k}.svg'; open(os.path.join(CC, fn), 'w').write(svg)
        hsh = hashlib.md5(svg.encode()).hexdigest()
        for old in [b_ for b_, f in bm.items() if f == fn]: del bm[old]
        bm[hsh] = fn
        W, H = fit(w, h)
        ART[k] = {'k': 'm', 'bg': bg, 'u': '/_blob/' + hsh, 'w': W, 'h': H, 'g': gop}
    elif k in WORD:
        base, text, tc = WORD[k]
        size = 30 if len(text) <= 8 else 26 if len(text) <= 12 else 21 if len(text) <= 16 else 17
        ART[k] = {'k': 't', 'bg': grad(base), 't': text, 'c': tc, 's': size}
    else:
        ART[k] = {'k': 'c', 'bg': grad(CATC.get(d.get('cat'), '#475166'))}
json.dump(bm, open(BLOBMAP, 'w'))

s = open(LANDING).read()
fn = '  cardArt() { return ' + json.dumps(ART, separators=(',', ':')) + '; }\n'
if '  cardArt() {' in s: s = re.sub(r'  cardArt\(\) \{ return .*?; \}\n', lambda m: fn, s, count=1, flags=re.S)
else: s = s.replace('  logoMeta() {', fn + '  logoMeta() {', 1)
open(LANDING, 'w').write(s)
from collections import Counter
print(Counter(v['k'] for v in ART.values()), len(ART))
