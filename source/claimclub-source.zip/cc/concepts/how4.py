# Four "How Claimclub works" section designs as canvas boards: HowV1..HowV4.dc.html (desktop 1440 + mobile 390).
import json, os
OUT = os.path.join(os.path.dirname(__file__), '..', 'project')
LOGO = '<svg width="{s}" height="{s}" viewBox="0 0 100 100" aria-hidden="true"><path fill="{c}" d="M81.4 83.6A46 46 0 0 1 51.6 96.0L51.2 83.0A33 33 0 0 0 72.5 74.1Z"></path><path fill="{c}" d="M48.4 96.0A46 46 0 0 1 18.6 83.6L27.5 74.1A33 33 0 0 0 48.8 83.0Z"></path><path fill="{c}" d="M16.4 81.4A46 46 0 0 1 4.0 51.6L17.0 51.2A33 33 0 0 0 25.9 72.5Z"></path><path fill="{c}" d="M4.0 48.4A46 46 0 0 1 16.4 18.6L25.9 27.5A33 33 0 0 0 17.0 48.8Z"></path><path fill="{c}" d="M18.6 16.4A46 46 0 0 1 48.4 4.0L48.8 17.0A33 33 0 0 0 27.5 25.9Z"></path><path fill="#3DDC97" d="M51.6 4.0A46 46 0 0 1 81.4 16.4L72.5 25.9A33 33 0 0 0 51.2 17.0Z"></path></svg>'
# Lucide icon paths (ISC license)
IC = {
    'search': '<circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.3-4.3"></path>',
    'pen': '<path d="M12 20h9"></path><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"></path>',
    'wallet': '<path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"></path><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"></path>',
    'check': '<path d="M20 6 9 17l-5-5"></path>',
    'x': '<path d="M18 6 6 18"></path><path d="m6 6 12 12"></path>',
    'clock': '<circle cx="12" cy="12" r="10"></circle><path d="M12 6v6l4 2"></path>',
    'bell': '<path d="M10.27 21a2 2 0 0 0 3.46 0"></path><path d="M3.26 15.33A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.67C19.41 13.96 18 12.5 18 8A6 6 0 0 0 6 8c0 4.5-1.41 5.96-2.74 7.33"></path>',
    'file': '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"></path><path d="M14 2v4a2 2 0 0 0 2 2h4"></path><path d="m9 15 2 2 4-4"></path>',
    'shield': '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path><path d="m9 12 2 2 4-4"></path>',
    'arrow': '<path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path>',
}
def ic(k, s=20, w=2, c='currentColor'):
    return f'<svg width="{s}" height="{s}" viewBox="0 0 24 24" fill="none" stroke="{c}" stroke-width="{w}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex: none">{IC[k]}</svg>'
APPLE = '<svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true"><path fill="#0A0F0D" d="M12.152 6.896c-.948 0-2.415-1.078-3.96-1.04-2.04.027-3.91 1.183-4.961 3.014-2.117 3.675-.546 9.103 1.519 12.09 1.013 1.454 2.208 3.09 3.792 3.039 1.52-.065 2.09-.987 3.935-.987 1.831 0 2.35.987 3.96.948 1.637-.026 2.676-1.48 3.676-2.948 1.156-1.688 1.636-3.325 1.662-3.415-.039-.013-3.182-1.221-3.22-4.857-.026-3.04 2.48-4.494 2.597-4.559-1.429-2.09-3.623-2.324-4.39-2.376-2-.156-3.675 1.09-4.61 1.09zM15.53 3.83c.843-1.012 1.4-2.427 1.245-3.83-1.207.052-2.662.805-3.532 1.818-.78.896-1.454 2.338-1.273 3.714 1.338.104 2.715-.688 3.559-1.701"></path></svg>'

STEPS = [
    ('search', 'Answer a few yes or no questions', 'Tap the brands you have used. We check every answer against open, court-approved settlements and show what you could be owed. Free, about a minute.', 'About 1 minute'),
    ('pen', 'Sign once, we file the forms', 'We pre-fill each official claim form with your details. Review it, sign with a tap, and we submit it to the settlement administrator for you.', 'One signature'),
    ('wallet', 'Get paid when the settlement pays out', 'Settlements pay after the court gives final approval, usually 2 to 6 months after the claim deadline. We track every claim and tell you the moment your money is sent, straight to you by PayPal, Venmo, Zelle or check.', 'Paid when the settlement pays'),
]

# ---------- mini UI pieces ----------
def ui_quiz(m=False, compact=False):
    if compact:
        return ('<div style="background: #FFFFFF; border-radius: 14px; padding: 10px; box-shadow: inset 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; gap: 8px; text-align: left">'
                f'<span style="width: 30px; height: 30px; border-radius: 8px; box-shadow: inset 0 0 0 1px #E3EAE6; display: flex; align-items: center; justify-content: center">{APPLE}</span><span style="font-size: 13px; font-weight: 800; line-height: 1.3">Did you buy an iPhone 15 Pro or iPhone 16?</span>'
                '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 6px"><span class="tapY" style="height: 34px; border-radius: 9px; background: #0F3B2E; color: #FFFFFF; font-size: 13px; font-weight: 800; display: flex; align-items: center; justify-content: center">Yes</span><span style="height: 34px; border-radius: 9px; box-shadow: inset 0 0 0 1.5px #DDE5E0; font-size: 13px; font-weight: 800; display: flex; align-items: center; justify-content: center; color: #43504A">No</span></div>'
                '<span style="font-size: 11.5px; font-weight: 800; color: #12805C">Matched · up to $95</span></div>')
    return ('<div style="background: #FFFFFF; border-radius: 16px; padding: 14px; box-shadow: 0 10px 30px rgba(10,15,13,.08), inset 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; gap: 10px; text-align: left">'
            f'<div style="display: flex; align-items: center; gap: 10px"><span style="width: 34px; height: 34px; border-radius: 9px; box-shadow: inset 0 0 0 1px #E3EAE6; display: flex; align-items: center; justify-content: center">{APPLE}</span><span style="font-size: 14px; font-weight: 800; line-height: 1.3">Did you buy an iPhone 15 Pro or iPhone 16?</span></div>'
            '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px"><span class="tapY" style="height: 38px; border-radius: 10px; background: #0F3B2E; color: #FFFFFF; font-size: 14px; font-weight: 800; display: flex; align-items: center; justify-content: center">Yes</span><span style="height: 38px; border-radius: 10px; box-shadow: inset 0 0 0 1.5px #DDE5E0; font-size: 14px; font-weight: 800; display: flex; align-items: center; justify-content: center; color: #43504A">No</span></div>'
            '<div style="display: flex; justify-content: space-between; font-size: 12px; font-weight: 800"><span style="color: #5B6862">Up to $95 · no proof needed</span><span style="color: #12805C">Matched</span></div></div>')
def ui_sign(m=False, compact=False):
    rows = [('Name', 'Maria Lopez'), ('Address', '88 Pine St, Seattle'), ('Payout', 'PayPal')]
    if compact:
        return ('<div style="background: #FFFFFF; border-radius: 14px; padding: 10px; box-shadow: inset 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; gap: 6px; text-align: left">'
                + ''.join(f'<div style="display: flex; flex-direction: column; gap: 1px; padding-bottom: 5px; border-bottom: 1px solid #EEF2F0"><span style="font-size: 10.5px; color: #8A968F; font-weight: 800">{k.upper()}</span><span style="font-size: 13px; font-weight: 800">{v}</span></div>' for k, v in rows)
                + '<span class="sig" style="font-family: \'Mrs Saint Delafield\', cursive; font-size: 30px; line-height: 1.1; color: #0F3B2E; border-bottom: 1.5px solid #0A0F0D; white-space: nowrap">Maria Lopez</span>'
                f'<span style="display: inline-flex; align-items: center; gap: 5px; font-size: 12px; font-weight: 800; color: #12805C">{ic("check", 13, 3)}Submitted</span></div>')
    return ('<div style="background: #FFFFFF; border-radius: 16px; padding: 14px; box-shadow: 0 10px 30px rgba(10,15,13,.08), inset 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; gap: 8px; text-align: left">'
            '<div style="font-size: 11px; font-weight: 800; letter-spacing: 1px; color: #8A968F">OFFICIAL CLAIM FORM · PRE-FILLED</div>'
            + ''.join(f'<div style="display: flex; justify-content: space-between; gap: 10px; font-size: 13px; padding: 4px 0; border-bottom: 1px solid #EEF2F0"><span style="color: #5B6862; font-weight: 700">{k}</span><span style="font-weight: 800">{v}</span></div>' for k, v in rows)
            + '<div style="display: flex; align-items: flex-end; justify-content: space-between; gap: 10px; padding-top: 4px"><span class="sig" style="font-family: \'Mrs Saint Delafield\', cursive; font-size: 34px; line-height: 1; color: #0F3B2E; border-bottom: 1.5px solid #0A0F0D; padding: 0 6px">Maria Lopez</span>'
            f'<span style="display: inline-flex; align-items: center; gap: 5px; font-size: 12px; font-weight: 800; color: #12805C">{ic("check", 14, 3)}Submitted</span></div></div>')
def ui_paid(m=False):
    return ('<div style="display: flex; flex-direction: column; gap: 8px">'
            '<div class="pop" style="display: flex; align-items: center; gap: 10px; background: #FFFFFF; border-radius: 16px; padding: 12px; box-shadow: 0 14px 34px rgba(10,15,13,.14); text-align: left">'
            f'<span style="width: 38px; height: 38px; border-radius: 10px; background: #0F3B2E; display: flex; align-items: center; justify-content: center">{LOGO.format(s=24, c="#FFFFFF")}</span>'
            '<span style="display: flex; flex-direction: column; gap: 1px; min-width: 0"><span style="font-size: 14px; font-weight: 800">Payout received</span><span style="font-size: 12.5px; color: #43504A">$95 from the Apple settlement, sent to PayPal</span></span></div>'
            '<div style="display: flex; gap: 4px">' + ''.join(f'<span style="flex: 1; height: 6px; border-radius: 99px; background: {c}"></span>' for c in ['#12805C', '#12805C', '#12805C', '#3DDC97']) + '</div>'
            '<div style="display: grid; grid-template-columns: repeat(4, 1fr); font-size: 11px; font-weight: 800; color: #5B6862; text-align: center"><span>Filed</span><span>In review</span><span>Approved</span><span style="color: #12805C">Paid</span></div></div>')
def ui_track():
    st = lambda t, c, b: f'<span style="flex: 1; display: flex; flex-direction: column; align-items: center; gap: 4px; font-size: 10px; font-weight: 800; color: {c}"><span style="width: 100%; height: 5px; border-radius: 99px; background: {b}"></span>{t}</span>'
    return ('<div style="background: #FFFFFF; border-radius: 14px; padding: 10px; box-shadow: inset 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; gap: 8px">'
            f'<div style="display: flex; align-items: center; gap: 8px"><span style="width: 30px; height: 30px; border-radius: 8px; box-shadow: inset 0 0 0 1px #E3EAE6; display: flex; align-items: center; justify-content: center">{APPLE}</span><span style="display: flex; flex-direction: column; min-width: 0"><span style="font-size: 13px; font-weight: 800">Apple Siri settlement</span><span style="font-size: 11px; font-weight: 700; color: #5B6862">Up to $95 · filed Nov 14</span></span></div>'
            '<div style="display: flex; gap: 4px">' + st('Filed', '#12805C', '#12805C') + st('Review', '#12805C', '#3DDC97') + st('Approved', '#9AA8A0', '#E3EAE6') + st('Paid', '#9AA8A0', '#E3EAE6') + '</div>'
            f'<div style="display: flex; align-items: center; gap: 6px; padding: 7px 8px; border-radius: 9px; background: #EAF2EE; font-size: 11.5px; font-weight: 800; color: #0F3B2E">{ic("clock", 13, 2.4)}Expected payout Feb to Jun 2027</div></div>'
            '<div style="background: #FFFFFF; border-radius: 14px; padding: 9px 10px; box-shadow: inset 0 0 0 1px #E3EAE6; display: flex; justify-content: space-between; font-size: 12px; font-weight: 800"><span>Google Play</span><span style="color: #12805C">Filed</span></div>'
            '<div style="background: #FFFFFF; border-radius: 14px; padding: 9px 10px; box-shadow: inset 0 0 0 1px #E3EAE6; display: flex; justify-content: space-between; font-size: 12px; font-weight: 800"><span>ATM fees (Visa)</span><span style="color: #12805C">Filed</span></div>'
            f'<div class="pop" style="margin-top: auto; display: flex; align-items: center; gap: 8px; background: #0F3B2E; color: #FFFFFF; border-radius: 14px; padding: 9px 10px; font-size: 11.5px; font-weight: 700; line-height: 1.35">{ic("bell", 15, 2.2, "#3DDC97")}<span>We will notify you the moment each payout is sent.</span></div>')
UIS = [ui_quiz, ui_sign, ui_paid]

def eyebrow(t='HOW CLAIMCLUB WORKS', c='#12805C'):
    return f'<div style="font-size: 13px; font-weight: 800; letter-spacing: 1.6px; color: {c}">{t}</div>'

# ---------- V1: zig-zag timeline ----------
def v1(m):
    rows = ''
    for i, (k, t, d, tag) in enumerate(STEPS):
        flip = (i % 2 == 1) and not m
        txt = (f'<div style="flex: 1 1 0; min-width: 0; display: flex; flex-direction: column; gap: 10px; text-align: left">'
               f'<span style="display: inline-flex; align-self: flex-start; align-items: center; gap: 6px; padding: 5px 10px; border-radius: 99px; background: #E9F6EF; color: #17603F; font-size: 12px; font-weight: 800">{ic("clock", 13, 2.4)}{tag}</span>'
               f'<h3 style="margin: 0; font-size: {24 if m else 30}px; line-height: 1.15; letter-spacing: -0.6px; color: #0F3B2E">{t}</h3><p style="margin: 0; font-size: {15 if m else 17}px; line-height: 1.6; color: #43504A">{d}</p></div>')
        vis = f'<div style="flex: 1 1 0; min-width: 0; max-width: {"100%" if m else "420px"}">{UIS[i](m)}</div>'
        node = (f'<div style="flex: none; width: {48 if m else 64}px; display: flex; flex-direction: column; align-items: center; align-self: stretch">'
                f'<span style="width: {48 if m else 64}px; height: {48 if m else 64}px; border-radius: 50%; background: #0F3B2E; color: #3DDC97; display: flex; align-items: center; justify-content: center; font-size: {18 if m else 22}px; font-weight: 800; box-shadow: 0 0 0 8px #E9F6EF">0{i+1}</span>'
                + ('<span style="flex: 1; width: 2px; margin-top: 8px; background: repeating-linear-gradient(#B7E4CC 0 6px, transparent 6px 12px)"></span>' if i < 2 else '') + '</div>')
        if m:
            rows += f'<div style="display: flex; gap: 16px"><div style="flex: none; display: flex; flex-direction: column; align-items: center">{node}</div><div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 14px; padding-bottom: 28px">{txt}{vis}</div></div>'
        else:
            left, right = (vis, txt) if flip else (txt, vis)
            rows += f'<div style="display: flex; align-items: stretch; gap: 40px"><div style="flex: 1; display: flex; align-items: center; justify-content: flex-end; padding-bottom: 56px">{left}</div>{node}<div style="flex: 1; display: flex; align-items: center; padding-bottom: 56px">{right}</div></div>'
    head = (f'<div style="display: flex; flex-direction: column; align-items: {"flex-start" if m else "center"}; gap: 10px; text-align: {"left" if m else "center"}; margin-bottom: {28 if m else 56}px">{eyebrow()}'
            f'<h2 style="margin: 0; font-size: {32 if m else 50}px; line-height: 1.05; letter-spacing: -1.6px; color: #0F3B2E; max-width: 760px">Three steps from &ldquo;did I qualify?&rdquo; to paid.</h2></div>')
    return f'<section style="min-height: 100%; box-sizing: border-box; background: #F3F6F4; padding: {48 if m else 96}px {20 if m else 80}px">{head}{rows}</section>'

# ---------- V2: dark band with three phones ----------
SIGNAL = '<svg width="{a}" height="{b}" viewBox="0 0 17 11" aria-hidden="true"><rect x="0" y="7" width="3" height="4" rx="1" fill="#0A0F0D"></rect><rect x="4.5" y="5" width="3" height="6" rx="1" fill="#0A0F0D"></rect><rect x="9" y="2.5" width="3" height="8.5" rx="1" fill="#0A0F0D"></rect><rect x="13.5" y="0" width="3" height="11" rx="1" fill="#0A0F0D"></rect></svg>'
WIFI = '<svg width="{a}" height="{b}" viewBox="0 0 15 11" aria-hidden="true"><path fill="#0A0F0D" d="M7.5 2.3c2.1 0 4 .8 5.5 2.1l1.1-1.1A9.4 9.4 0 0 0 7.5.7 9.4 9.4 0 0 0 .9 3.3L2 4.4a7.8 7.8 0 0 1 5.5-2.1Zm0 3.2c1.2 0 2.4.5 3.2 1.3l1.1-1.1a6.2 6.2 0 0 0-8.6 0l1.1 1.1c.8-.8 2-1.3 3.2-1.3Zm0 3.2c-.4 0-.8.2-1.1.4l1.1 1.2 1.1-1.2c-.3-.2-.7-.4-1.1-.4Z"></path></svg>'
BATT = '<svg width="{a}" height="{b}" viewBox="0 0 25 12" aria-hidden="true"><rect x=".5" y=".5" width="21" height="11" rx="3.5" fill="none" stroke="#0A0F0D" stroke-opacity=".4"></rect><rect x="2" y="2" width="18" height="8" rx="2" fill="#0A0F0D"></rect><path d="M23 4v4c.8-.3 1.3-1.1 1.3-2S23.8 4.3 23 4Z" fill="#0A0F0D" fill-opacity=".45"></path></svg>'
def iphone(screen, w=250, bg='#F3F6F4', cls=''):
    """Realistic iPhone (Dynamic Island, titanium rim, side buttons, antenna lines), proportions from devices.css (MIT) iPhone 14 Pro, scalable to any width."""
    k = w / 428
    p = lambda v: f'{round(v * k, 2)}px'
    rim, rim2, glow = '#3A3A3C', '#4A4A4D', '#B4B4B8'
    btn = lambda side, top, h: f'<span style="position: absolute; {side}: -{p(2.4)}; top: {p(top)}; width: {p(3.4)}; height: {p(h)}; border-radius: {p(2)}; background: linear-gradient(90deg, #2A2A2C, #5A5A5E, #2A2A2C)"></span>'
    stripe = lambda pos: f'<span style="position: absolute; left: 0; {pos}: {p(85)}; width: 100%; height: {p(7)}; box-sizing: border-box; border: solid rgba(120,120,125,.35); border-width: 0 {p(7)}; z-index: 2"></span>'
    return (f'<div class="iph{(" " + cls) if cls else ""}" style="position: relative; flex: none; width: {w}px; height: {round(868 * k)}px">'
            + btn('left', 115, 32) + btn('left', 175, 62) + btn('left', 255, 62) + btn('right', 200, 100) +
            f'<div style="position: relative; width: 100%; height: 100%; box-sizing: border-box; padding: {p(19)}; border-radius: {p(68)}; background: #010101; border: 1px solid {rim}; box-shadow: inset 0 0 {p(4)} {p(2)} {glow}, inset 0 0 0 {p(6)} {rim2}, 0 {p(40)} {p(80)} rgba(0,0,0,.38), 0 {p(10)} {p(24)} rgba(0,0,0,.25)">'
            + stripe('top') + stripe('bottom') +
            f'<div style="position: relative; width: 100%; height: 100%; border-radius: {p(49)}; overflow: hidden; background: {bg}; color: #0A0F0D">'
            f'<div style="position: absolute; left: 0; right: 0; top: 0; height: {p(54)}; display: flex; align-items: center; justify-content: space-between; padding: {p(4)} {p(30)} 0 {p(38)}; box-sizing: border-box; font-size: {p(16)}; font-weight: 700; letter-spacing: -0.2px; z-index: 3"><span>9:41</span><span style="display: flex; align-items: center; gap: {p(6)}">'
            + SIGNAL.format(a=p(18), b=p(12)) + WIFI.format(a=p(16), b=p(12)) + BATT.format(a=p(26), b=p(12)) + '</span></div>'
            f'<div style="position: absolute; left: 50%; top: {p(10)}; width: {p(120)}; height: {p(35)}; margin-left: -{p(60)}; border-radius: {p(20)}; background: #010101; z-index: 4"><span style="position: absolute; right: {p(16)}; top: {p(12)}; width: {p(10)}; height: {p(10)}; border-radius: 50%; background: radial-gradient(farthest-corner at 30% 30%, #4A5A8F 0, transparent 45%), radial-gradient(farthest-corner at 70% 70%, #3A2F66 0, #1C3A42 30%, #0A0A0C 60%)"></span></div>'
            f'<div style="position: absolute; inset: 0; padding: {p(62)} {p(18)} {p(18)}; box-sizing: border-box; display: flex; flex-direction: column; gap: {p(14)}; text-align: left">{screen}</div>'
            f'<div style="position: absolute; left: 50%; bottom: {p(9)}; width: {p(140)}; height: {p(5)}; margin-left: -{p(70)}; border-radius: 99px; background: rgba(10,15,13,.85); z-index: 3"></div>'
            '<div style="position: absolute; inset: 0; pointer-events: none; z-index: 5; background: linear-gradient(118deg, rgba(255,255,255,.16) 0%, rgba(255,255,255,0) 28%)"></div>'
            '</div></div></div>')
def phone(screen, m):
    return iphone(screen, 250)
_r = lambda name, right, col='#12805C': f'<div style="display: flex; justify-content: space-between; align-items: center; gap: 8px; padding: 9px 10px; background: #FFFFFF; border-radius: 12px; box-shadow: inset 0 0 0 1px #E3EAE6; font-size: 12px; font-weight: 800"><span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{name}</span><span style="flex: none; color: {col}">{right}</span></div>'
MATCHES = ('<div style="font-size: 11px; font-weight: 800; letter-spacing: 1px; color: #8A968F; margin-top: 2px">MATCHED SO FAR</div>'
           + _r('Google Play', 'up to $100') + _r('ATM fees (Visa)', 'up to $1,000') + _r('Beef purchases', 'cash share', '#5B6862'))
READY = ('<div style="font-size: 11px; font-weight: 800; letter-spacing: 1px; color: #8A968F; margin-top: 2px">ALSO READY TO FILE</div>'
         + _r('Google Play', 'Signed') + _r('ATM fees (Visa)', 'Signed')
         + '<span style="margin-top: auto; height: 40px; border-radius: 12px; background: #0F3B2E; color: #FFFFFF; font-size: 13px; font-weight: 800; display: flex; align-items: center; justify-content: center">Submit 3 claims</span>')
def v2(m):
    screens = [
        '<div style="font-size: 11px; font-weight: 800; letter-spacing: 1px; color: #8A968F">QUESTION 2 OF 8</div>' + ui_quiz(m, True) + '<div style="display: flex; align-items: baseline; justify-content: space-between"><span style="font-size: 12px; font-weight: 800; color: #5B6862">Your estimate</span><span style="font-size: 26px; font-weight: 800; letter-spacing: -1px; color: #12805C">$295</span></div>' + MATCHES,
        '<div style="font-size: 11px; font-weight: 800; letter-spacing: 1px; color: #8A968F">REVIEW AND SIGN</div>' + ui_sign(m, True) + READY,
        '<div style="font-size: 11px; font-weight: 800; letter-spacing: 1px; color: #8A968F">YOUR CLAIMS</div>' + ui_track() ,
    ]
    cols = ''
    for i, (k, t, d, tag) in enumerate(STEPS):
        cols += (f'<div style="flex: 1 1 0; min-width: 0; display: flex; flex-direction: column; align-items: center; gap: 22px; text-align: center">{phone(screens[i], m)}'
                 f'<div style="display: flex; flex-direction: column; align-items: center; gap: 8px; max-width: 320px"><span style="width: 34px; height: 34px; border-radius: 50%; background: #3DDC97; color: #0F3B2E; font-weight: 800; font-size: 15px; display: flex; align-items: center; justify-content: center">{i+1}</span>'
                 f'<h3 style="margin: 0; font-size: 22px; letter-spacing: -0.4px; color: #FFFFFF">{t}</h3><p style="margin: 0; font-size: 15px; line-height: 1.55; color: #C9D6CF">{d}</p></div></div>')
    return (f'<section class="meshDark" style="min-height: 100%; box-sizing: border-box; padding: {52 if m else 96}px {20 if m else 72}px; color: #FFFFFF">'
            f'<div style="display: flex; flex-direction: column; align-items: center; gap: 12px; text-align: center; margin-bottom: {32 if m else 60}px">{eyebrow(c="#3DDC97")}<h2 style="margin: 0; font-size: {32 if m else 52}px; line-height: 1.05; letter-spacing: -1.6px; max-width: 820px">Three steps, then the settlement pays you.</h2><p style="margin: 0; font-size: 17px; color: #C9D6CF; max-width: 560px">We handle the paperwork. Your money comes when each settlement pays out, usually a few months after the claim deadline.</p></div>'
            f'<div style="display: flex; {"flex-direction: column; gap: 48px" if m else "gap: 40px"}; align-items: {"center" if m else "flex-start"}">{cols}</div></section>')

# ---------- V3: sticky headline with stat chips + numbered list ----------
def v3(m):
    stats = [('60 sec', 'to see what you are owed'), ('1 tap', 'to sign every claim'), ('$0', 'cut of your payouts')]
    left = (f'<div style="flex: 0 0 {"auto" if m else "430px"}; display: flex; flex-direction: column; gap: 18px; text-align: left">{eyebrow()}'
            f'<h2 style="margin: 0; font-size: {34 if m else 52}px; line-height: 1.03; letter-spacing: -1.8px; color: #0F3B2E">We do the claim work. <em style="font-family: \'Instrument Serif\', serif; font-weight: 400; color: #12805C">You keep the money.</em></h2>'
            '<p style="margin: 0; font-size: 17px; line-height: 1.6; color: #43504A">Most people never claim the settlements they qualify for because finding and filing them takes hours. Claimclub turns it into a minute.</p>'
            '<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px">'
            + ''.join(f'<div style="background: #FFFFFF; border-radius: 16px; padding: 14px 12px; box-shadow: inset 0 0 0 1px #E3EAE6"><div style="font-size: {22 if m else 26}px; font-weight: 800; letter-spacing: -0.8px; color: #12805C">{a}</div><div style="font-size: 12.5px; font-weight: 700; color: #5B6862; line-height: 1.35">{b}</div></div>' for a, b in stats)
            + f'</div><a href="#" style="align-self: flex-start; display: inline-flex; align-items: center; gap: 8px; min-height: 50px; padding: 0 24px; border-radius: 999px; background: #3DDC97; color: #0F3B2E; font-size: 16px; font-weight: 800; text-decoration: none">See what I could be owed{ic("arrow", 18, 2.4)}</a></div>')
    items = ''
    for i, (k, t, d, tag) in enumerate(STEPS):
        items += (f'<div style="display: flex; gap: 18px; padding: 24px; border-radius: 22px; background: #FFFFFF; box-shadow: 0 1px 2px rgba(10,15,13,.04), inset 0 0 0 1px #E3EAE6; text-align: left">'
                  f'<div style="flex: none; display: flex; flex-direction: column; align-items: center; gap: 10px"><span style="width: 52px; height: 52px; border-radius: 16px; background: #E9F6EF; color: #12805C; display: flex; align-items: center; justify-content: center">{ic(k, 24, 2)}</span><span style="font-size: 13px; font-weight: 800; color: #9AA8A0">0{i+1}</span></div>'
                  f'<div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 8px"><h3 style="margin: 0; font-size: 21px; letter-spacing: -0.4px; color: #0F3B2E">{t}</h3><p style="margin: 0; font-size: 15px; line-height: 1.6; color: #43504A">{d}</p>'
                  + ('' if m else f'<div style="margin-top: 6px; max-width: 380px">{UIS[i](m)}</div>') + '</div></div>')
    return (f'<section style="min-height: 100%; box-sizing: border-box; background: #F3F6F4; padding: {48 if m else 96}px {20 if m else 80}px"><div style="display: flex; {"flex-direction: column; gap: 32px" if m else "gap: 64px; align-items: flex-start"}">{left}'
            f'<div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 14px">{items}</div></div></section>')

# ---------- V4: on your own vs with Claimclub, then the three steps ----------
def v4(m):
    own = ['Hunt for settlement notices across dozens of sites', 'Read eligibility rules and deadlines for each one', 'Fill in a separate claim form every time', 'Keep track of claim IDs and check back for months']
    us = ['We match you to every open settlement in a minute', 'We pre-fill each official form from one set of answers', 'You sign once and we file it', 'We track every claim and tell you when it pays']
    col = lambda title, rows, good: (f'<div style="flex: 1 1 0; min-width: 0; border-radius: 22px; padding: 22px; background: {"#0F3B2E" if good else "#FFFFFF"}; color: {"#FFFFFF" if good else "#0A0F0D"}; box-shadow: {"0 24px 50px rgba(15,59,46,.25)" if good else "inset 0 0 0 1px #E3EAE6"}; text-align: left; display: flex; flex-direction: column; gap: 14px">'
            f'<div style="display: flex; justify-content: space-between; align-items: center; gap: 10px"><span style="font-size: 18px; font-weight: 800">{title}</span><span style="font-size: 12px; font-weight: 800; padding: 4px 10px; border-radius: 99px; background: {"#3DDC97" if good else "#FDECEC"}; color: {"#0F3B2E" if good else "#B8333A"}">{"About 1 minute" if good else "Hours per claim"}</span></div>'
            + ''.join(f'<div style="display: flex; gap: 10px; align-items: flex-start; font-size: 15px; line-height: 1.45; font-weight: 600; color: {"#E4F2EB" if good else "#43504A"}"><span style="width: 22px; height: 22px; flex: none; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: {"#3DDC97" if good else "#FDECEC"}; color: {"#0F3B2E" if good else "#B8333A"}">{ic("check" if good else "x", 13, 3)}</span>{r}</div>' for r in rows) + '</div>')
    steps = ''.join(f'<div style="flex: 1 1 0; min-width: 0; display: flex; gap: 12px; align-items: flex-start; text-align: left"><span style="flex: none; width: 40px; height: 40px; border-radius: 12px; background: #E9F6EF; color: #12805C; display: flex; align-items: center; justify-content: center">{ic(k, 20, 2)}</span><span style="display: flex; flex-direction: column; gap: 4px"><b style="font-size: 16px; color: #0F3B2E">{i+1}. {t}</b><span style="font-size: 14px; line-height: 1.5; color: #5B6862">{tag}</span></span></div>' for i, (k, t, d, tag) in enumerate(STEPS))
    return (f'<section style="min-height: 100%; box-sizing: border-box; background: #F3F6F4; padding: {48 if m else 96}px {20 if m else 80}px">'
            f'<div style="display: flex; flex-direction: column; align-items: center; gap: 12px; text-align: center; margin-bottom: {28 if m else 48}px">{eyebrow()}<h2 style="margin: 0; font-size: {32 if m else 50}px; line-height: 1.05; letter-spacing: -1.6px; color: #0F3B2E; max-width: 820px">Claiming on your own takes hours. With Claimclub it takes a minute.</h2></div>'
            f'<div style="display: flex; {"flex-direction: column; gap: 14px" if m else "gap: 20px; align-items: stretch"}; max-width: 1100px; margin: 0 auto">{col("On your own", own, False)}{col("With Claimclub", us, True)}</div>'
            f'<div style="display: flex; {"flex-direction: column; gap: 18px" if m else "gap: 32px"}; max-width: 1100px; margin: {28 if m else 48}px auto 0; padding-top: {24 if m else 36}px; border-top: 1px solid #DDE5E0">{steps}</div></section>')

VARIANTS = [('HowV1', 'How it works V1 · Timeline with alternating steps', v1), ('HowV2', 'How it works V2 · Dark band with three phone screens', v2),
            ('HowV3', 'How it works V3 · Headline with stats, numbered step cards', v3), ('HowV4', 'How it works V4 · On your own vs with Claimclub', v4)]

HEAD = '''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>%s</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Instrument+Serif:ital@0;1&family=Mrs+Saint+Delafield&display=swap" rel="stylesheet">
<style>
body{margin:0}
.meshDark{background:radial-gradient(140%% 100%% at 100%% 0%%, #1F7A57 0%%, rgba(31,122,87,0) 55%%),radial-gradient(120%% 120%% at 0%% 100%%, #05211A 0%%, rgba(5,33,26,0) 60%%),linear-gradient(165deg, #134A39 0%%, #0F3B2E 45%%, #0A2C22 100%%)}
@keyframes popIn{0%%,10%%{opacity:0;transform:translateY(10px) scale(.96)}20%%,90%%{opacity:1;transform:none}100%%{opacity:1}}
.pop{animation:popIn 4s ease-in-out infinite}
@keyframes tapY{0%%,60%%,100%%{box-shadow:0 0 0 0 rgba(61,220,151,0)}70%%{box-shadow:0 0 0 6px rgba(61,220,151,.45)}}
.tapY{animation:tapY 3s ease-in-out infinite}
@keyframes sign{from{clip-path:inset(0 100%% 0 0)}to{clip-path:inset(0 0 0 0)}}
.sig{animation:sign 2.4s ease-out infinite alternate}
@media (prefers-reduced-motion: reduce){.pop,.tapY,.sig{animation:none}}
.scroll{scrollbar-width:thin;scrollbar-color:#C9D3CD transparent}
</style>
</helmet>
'''
JS = '''<script type="text/x-dc" data-dc-script data-props='{"$preview":{"width":1926,"height":980}}'>
class Component extends DCLogic { renderVals() { return {}; } }
</script>
</body>
</html>
'''

def build():
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    y0 = max(b['y'] + b['h'] for k, b in c['boards'].items() if not k.startswith('HowV')) + 260
    c['notes']['tH'] = {'x': 0, 'y': y0, 'text': 'How Claimclub works · 4 section designs (desktop and mobile)', 'kind': 'title1', 'maxW': 3900, 'w': 240}
    if 'noteOrder' in c and 'tH' not in c['noteOrder']: c['noteOrder'].append('tH')
    for k, (name, title, fn) in enumerate(VARIANTS):
        page = (f'<div style="width: 1926px; height: 980px; box-sizing: border-box; padding: 24px; background: #E7ECE9; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 14px">'
                f'<div style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #43504A">{title.upper()}</div>'
                '<div style="display: flex; gap: 48px; align-items: flex-start">'
                f'<div class="scroll" style="width: 1440px; height: 900px; flex: none; overflow-y: auto; border-radius: 18px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{fn(False)}</div>'
                f'<div class="scroll" style="width: 390px; height: 844px; flex: none; overflow-y: auto; border-radius: 28px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{fn(True)}</div>'
                '</div></div>\n</x-dc>\n')
        open(os.path.join(OUT, name + '.dc.html'), 'w').write(HEAD % title + page + JS)
        c['boards'][name + '.dc.html'] = {'x': (k % 2) * 2006, 'y': y0 + 220 + (k // 2) * 1060, 'w': 1926, 'h': 980, 'is_interactive': True, 'title': title}
        if name + '.dc.html' not in c['order']: c['order'].append(name + '.dc.html')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w'))
    print('built', [v[0] for v in VARIANTS], 'y0', y0)

if __name__ == '__main__':
    build()
