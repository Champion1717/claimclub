import re,json
s=open('make.py').read()
def rep(o,n,cnt=1):
    global s
    assert o in s,o[:100]; s=s.replace(o,n,cnt)
# refresh embedded settlements (now with amt/max)
i=s.index('  sets() { return '); j=s.index('\n',i)
s=s[:i]+'  sets() { return '+open('sets.json').read().replace('\\"','\\\\"')+'; }'+s[j:]
# ---- constructor: load session + saved app state ----
i=s.index("    this.state = { st: { apple: 'ready'"); j=s.index('\n',i)
s=s[:j+1]+"""    this.state.mm = ''; this.state.mmPick = ''; this.state.cancelled = false; this.state.plan = '1m'; this.state.joinedOn = 'Nov 12, 2026';
    this.loadLive();
"""+s[j+1:]
rep("  claims() {","""  loadLive() {
    let ss = null, saved = null, prefs = null;
    try { ss = JSON.parse(localStorage.getItem('claimclub_session') || 'null'); } catch (e) {}
    try { saved = JSON.parse(localStorage.getItem('claimclub_app') || 'null'); } catch (e) {}
    try { prefs = JSON.parse(localStorage.getItem('claimclub_prefs') || 'null'); } catch (e) {}
    if (prefs) { if (prefs.theme) this.state.theme = prefs.theme; if (prefs.scale) this.state.scale = prefs.scale; }
    if (!ss || !ss.ids || !ss.ids.length) return;
    this._live = true;
    const P = ss.p || {}, D = this.sets(), st = {}, signed = ss.signed || [];
    const mine = ss.ids.map(id => D.find(d => d.id === id)).filter(Boolean);
    mine.forEach(d => { st[d.id] = signed.indexOf(d.id) >= 0 ? 'filed' : 'ready'; });
    this._mine = mine.map(d => this.toClaim(d));
    const addr = [P.street, P.city, [P.st, P.zip].filter(Boolean).join(' ')].filter(Boolean).join(', ');
    Object.assign(this.state, { st, plan: ss.plan || '', paidKind: ss.paid || (ss.plan ? 'member' : 'fee'), joinedOn: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      prof: { name: P.name || '', email: P.email || '', phone: P.phone || '', dob: P.dob || '', addr, past: [] },
      acct: { email: P.email ? 1 : 0, auth: signed.length ? 1 : 0, name: P.name && addr ? 1 : 0, dob: P.dob && P.phone ? 1 : 0, bank: ss.bank ? 1 : 0 }, myState: P.st || '' });
    if (saved && saved.sig === ss.ids.join(',')) {
      ['st', 'added', 'prof', 'acct', 'payDef', 'ans', 'cancelled', 'plan', 'seq', 'mmPending'].forEach(k => { if (saved[k] !== undefined) this.state[k] = saved[k]; });
    }
  }
  toClaim(d) {
    const v = d.amt > 0 ? d.amt : d.max > 0 ? d.max : 0, days = this.daysTo(d.dl);
    return { id: d.id, co: d.co, title: d.title, amt: v ? (d.amt > 0 && d.max > d.amt ? '$' + d.amt.toLocaleString('en-US') + '+' : (d.amt > 0 ? '$' : 'Up to $') + v.toLocaleString('en-US')) : 'Varies', n: v, days: days > 0 ? days : 0,
      kind: d.mode === 'auto' ? 'auto' : d.cat === 'arb' ? 'arb' : 'here', need: !!this.forms()[d.id], why: d.who };
  }
  componentDidUpdate() {
    const s = this.state;
    try { localStorage.setItem('claimclub_prefs', JSON.stringify({ theme: s.theme, scale: s.scale })); } catch (e) {}
    if (!this._live) return;
    try { const ss = JSON.parse(localStorage.getItem('claimclub_session') || 'null'); if (!ss) return;
      localStorage.setItem('claimclub_app', JSON.stringify({ sig: ss.ids.join(','), st: s.st, added: s.added, prof: s.prof, acct: s.acct, payDef: s.payDef, ans: s.ans, cancelled: s.cancelled, plan: s.plan, seq: s.seq, mmPending: s.mmPending })); } catch (e) {}
  }
  claims() {
    if (this._live) return this._mine.concat(this.extras().filter(x => (this.state.ans || {})[x.id] === 'yes' && !this._mine.some(m => m.id === x.id)), (this.state.added || []).filter(x => !this._mine.some(m => m.id === x.id)));
    return this.demoClaims();
  }
  demoClaims() {""")
# daysTo used in loadLive before defined? it's a method, fine.
# ---- my state for near-you ----
rep("const s = this.state, MY = 'CA';","const s = this.state, MY = s.myState || 'CA', STN = { AL: 'Alabama', AZ: 'Arizona', AR: 'Arkansas', CA: 'California', CO: 'Colorado', DC: 'Washington, DC', FL: 'Florida', GA: 'Georgia', ID: 'Idaho', IL: 'Illinois', KY: 'Kentucky', MA: 'Massachusetts', MD: 'Maryland', MI: 'Michigan', MN: 'Minnesota', MO: 'Missouri', NC: 'North Carolina', NJ: 'New Jersey', NM: 'New Mexico', NY: 'New York', OH: 'Ohio', OR: 'Oregon', PA: 'Pennsylvania', PR: 'Puerto Rico', RI: 'Rhode Island', SC: 'South Carolina', TN: 'Tennessee', TX: 'Texas', VA: 'Virginia', WA: 'Washington', WV: 'West Virginia' };")
rep("totalOpen: open.length, nearN: near.length, isNear: s.scope === 'near' };","totalOpen: open.length, nearN: near.length, isNear: s.scope === 'near', myStateName: STN[MY] || MY };")
rep("State and city settlements for California, based on your mailing address.","State and city settlements for {{ myStateName }}, based on your mailing address.")
# ---- personal details in markup ----
rep('font-size: 22px; letter-spacing: -0.5px">Hi Henry','font-size: 22px; letter-spacing: -0.5px">Hi {{ firstName }}')
rep('<span style="font-weight: 800">Henry Sidwell</span>','<span style="font-weight: 800">{{ profName }}</span>')
rep('<span style="font-size: 14px; font-weight: 800">Signed Nov 12, 2026</span>','<span style="font-size: 14px; font-weight: 800">Signed {{ joinedOn }}</span>')
s=s.replace('Monthly · $29.99/month','{{ planLine }}')
rep('font-weight: 800; display: flex; align-items: center; justify-content: center">H</span></header>','font-weight: 800; display: flex; align-items: center; justify-content: center">{{ initial }}</span></header>')
rep('<span style="font-size: 13px; font-weight: 800">Membership <span style="color: #17603F">· Active</span></span>','<span style="font-size: 13px; font-weight: 800">{{ planHead }} <span style="color: #17603F">{{ planBadge }}</span></span>')
# ---- values ----
rep("      ...this.setsVals(), ...this.infoVals(),","""      ...this.setsVals(), ...this.infoVals(), ...this.mmVals(),
      firstName: ((s.prof.name || '').split(' ')[0]) || 'there', profName: s.prof.name || 'Saved in Your info', initial: ((s.prof.name || 'C').charAt(0) || 'C').toUpperCase(), joinedOn: s.joinedOn,""")
# ---- manage membership ----
rep("  goInfo(h) {","""  mmVals() {
    const s = this.state, P = { '1m': { name: '1 month', per: '$29.99/mo', bill: '$29.99 every month', price: '$29.99', first: '$7.50' }, '3m': { name: '3 months', per: '$24.99/mo', bill: '$74.97 every 3 months', price: '$74.97', first: '$18.74', tag: 'Save 17%' }, '6m': { name: '6 months', per: '$19.99/mo', bill: '$119.94 every 6 months', price: '$119.94', first: '$29.99', tag: 'Save 33%' } };
    const member = !!s.plan, cur = P[s.plan] || P['1m'], pick = s.mmPick || s.plan || '6m';
    const d = new Date(); d.setMonth(d.getMonth() + ({ '1m': 1, '3m': 3, '6m': 6 }[s.plan] || 1)); const renew = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    const row = (on) => 'width:100%;display:flex;align-items:center;gap:12px;text-align:left;padding:12px 14px;border-radius:14px;color:#0A0F0D;' + (on ? 'background:#EAF2EE;box-shadow:inset 0 0 0 2px #12805C' : 'background:#FFFFFF;box-shadow:inset 0 0 0 1.5px #DDE5E0');
    const dot = (on) => 'width:20px;height:20px;flex:none;border-radius:50%;box-sizing:border-box;' + (on ? 'border:6px solid #12805C;background:#FFFFFF' : 'border:2px solid #C9D3CD');
    return {
      planHead: member ? 'Membership' : 'Filing fee', planBadge: member ? (s.cancelled ? '· Ends ' + renew : '· Active') : '· Paid',
      planLine: member ? cur.name.charAt(0).toUpperCase() + cur.name.slice(1) + ' · ' + cur.per : 'One-time · $99',
      mmOpen: !!s.mm, mmHome: s.mm === 'home', mmCancel: s.mm === 'cancel', mmDone: s.mm === 'done', isMember: member, notMember: !member,
      mmStatus: s.cancelled ? 'Ends ' + renew + '. You keep everything until then.' : (s.mmPending ? 'Switching to ' + P[s.mmPending].name + ' on ' + renew + '.' : 'Renews ' + renew + ' at ' + cur.bill + '.'),
      mmPlans: Object.keys(P).map(k => ({ name: P[k].name, per: P[k].per, bill: P[k].bill, tag: P[k].tag || '', hasTag: !!P[k].tag, cur: k === s.plan, st: row(pick === k), dot: dot(pick === k), tap: () => this.setState({ mmPick: k }) })),
      mmCanSwitch: member && pick !== s.plan && !s.cancelled, mmSwitchLabel: 'Switch to ' + P[pick].name,
      mmSwitch: () => this.setState({ mmPending: pick, mm: '', note: { head: 'Plan change scheduled', sub: 'Your plan switches to ' + P[pick].name + ' on ' + renew + '. No charge today.', logo: this.logo('cc', 'C') } }),
      mmBill: member ? [{ date: s.joinedOn, what: cur.name + ' membership, 75% off first period', amt: cur.first }] : [{ date: s.joinedOn, what: 'Filing fee', amt: '$99' }],
      manage: () => this.setState({ mm: 'home', mmPick: '' }), mmClose: () => this.setState({ mm: '' }), mmToCancel: () => this.setState({ mm: 'cancel' }), mmKeep: () => this.setState({ mm: 'home' }),
      mmConfirm: () => this.setState({ cancelled: true, mmPending: '', mm: 'done' }), mmResume: () => this.setState({ cancelled: false, mm: '', note: { head: 'Membership resumed', sub: 'It renews ' + renew + '.', logo: this.logo('cc', 'C') } }),
      mmCancelled: !!s.cancelled, mmActive: !s.cancelled, renewDate: renew,
      mmLose: [this.claims().filter(c => s.st[c.id] && s.st[c.id] !== 'paid' && s.st[c.id] !== 'gone').length + ' claims tracked until they pay', 'Filing for every new settlement you match', 'All ' + this.sets().length + ' settlements and local scans', 'Text alerts for approvals and payouts'],
      joinUrl: '/d/start.html'
    };
  }
  goInfo(h) {""")
# settings: wire the manage button + legal links
rep('<button style="min-height: 34px; padding: 0 14px; border-radius: 99px; background: #EEF2F0; color: #0A0F0D; font-size: 13px; font-weight: 800">Manage membership</button>',
    '<sc-if value="{{ isMember }}" hint-placeholder-val="{{ true }}"><button onClick="{{ manage }}" style="min-height: 34px; padding: 0 14px; border-radius: 99px; background: #EEF2F0; color: #0A0F0D; font-size: 13px; font-weight: 800">Manage membership</button></sc-if><sc-if value="{{ notMember }}" hint-placeholder-val="{{ false }}"><a href="{{ joinUrl }}" style="min-height: 34px; display: inline-flex; align-items: center; padding: 0 14px; border-radius: 99px; background: #3DDC97; color: #0A0F0D; font-size: 13px; font-weight: 800; text-decoration: none">Become a member</a></sc-if>')
LEGAL='''      <section style="background: #FFFFFF; border-radius: 18px; box-shadow: 0 0 0 1px #E3EAE6; padding: 6px 16px">
        LINKS
      </section>
    </sc-if>
'''
links=''.join(f'<a href="https://claimclub.io{u}" target="_blank" rel="noopener" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 0; {"border-bottom: 1px solid #EEF2F0; " if k<3 else ""}font-size: 14px; font-weight: 800; color: #0A0F0D; text-decoration: none">{t}<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8A968F" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 3h6v6 M10 14 21 3 M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path></svg></a>' for k,(t,u) in enumerate([('Filing authorization','/legal/authorization.html'),('Terms and conditions','/legal/terms.html'),('Privacy policy','/legal/privacy.html'),('About Claimclub','/about.html')]))
i=s.index('    <sc-if value="{{ isSet }}"'); j=s.index('    </sc-if>\n',i)
s=s[:j]+LEGAL.replace('LINKS',links)+s[j+len('    </sc-if>\n'):]
# manage membership sheet markup (reuses sheet styles)
MM='''  <sc-if value="{{ mmOpen }}" hint-placeholder-val="{{ false }}"><div class="shWrap" style="position: absolute; inset: 0; z-index: 41; background: rgba(10,15,13,.45); display: flex; align-items: center; justify-content: center; animation: shFade .2s ease both">
    <div class="shCard" role="dialog" aria-modal="true" aria-label="Manage membership" style="width: 520px; max-width: calc(100% - 32px); max-height: calc(100% - 48px); display: flex; flex-direction: column; background: #FFFFFF; border-radius: 24px; box-shadow: 0 30px 80px rgba(0,0,0,.3); overflow: hidden; animation: shPop .3s cubic-bezier(.2,.9,.3,1.1) both">
      <div style="display: flex; align-items: center; justify-content: space-between; padding: 18px 20px 12px; border-bottom: 1px solid #EEF2F0"><h2 style="margin: 0; font-size: 18px">Manage membership</h2><button onClick="{{ mmClose }}" aria-label="Close" style="width: 32px; height: 32px; border-radius: 50%; background: #EEF2F0; color: #0A0F0D; display: flex; align-items: center; justify-content: center"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18 M6 6l12 12"></path></svg></button></div>
      <div class="scroll" style="flex-grow: 1; min-height: 0; overflow-y: auto; padding: 16px 20px 20px; display: flex; flex-direction: column; gap: 14px">
        <sc-if value="{{ mmHome }}" hint-placeholder-val="{{ true }}">
          <div style="padding: 12px 14px; border-radius: 14px; background: #F3F6F4; font-size: 13px; font-weight: 700; color: #43504A">{{ mmStatus }}</div>
          <span style="font-size: 13px; font-weight: 800; color: #5B6862">Your plan</span>
          <sc-for list="{{ mmPlans }}" as="p" hint-placeholder-count="3"><button onClick="{{ p.tap }}" style="{{ p.st }}"><span style="{{ p.dot }}"></span><span style="flex-grow: 1; display: flex; flex-direction: column; gap: 2px"><span style="font-size: 15px; font-weight: 800">{{ p.name }}<sc-if value="{{ p.cur }}" hint-placeholder-val="{{ false }}"> <span style="font-size: 11px; font-weight: 800; padding: 2px 8px; border-radius: 99px; background: #0F3B2E; color: #FFFFFF">Current</span></sc-if><sc-if value="{{ p.hasTag }}" hint-placeholder-val="{{ false }}"> <span style="font-size: 11px; font-weight: 800; padding: 2px 8px; border-radius: 99px; background: #E9F6EF; color: #17603F">{{ p.tag }}</span></sc-if></span><span style="font-size: 12px; color: #5B6862">{{ p.bill }}</span></span><span style="font-size: 15px; font-weight: 800">{{ p.per }}</span></button></sc-for>
          <sc-if value="{{ mmCanSwitch }}" hint-placeholder-val="{{ false }}"><button onClick="{{ mmSwitch }}" style="min-height: 44px; border-radius: 99px; background: #0A0F0D; color: #FFFFFF; font-size: 14px; font-weight: 800">{{ mmSwitchLabel }}</button></sc-if>
          <span style="font-size: 13px; font-weight: 800; color: #5B6862">Billing history</span>
          <sc-for list="{{ mmBill }}" as="b" hint-placeholder-count="1"><div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 10px 14px; border-radius: 12px; box-shadow: inset 0 0 0 1px #E3EAE6; font-size: 13px"><span style="display: flex; flex-direction: column; gap: 2px"><span style="font-weight: 800">{{ b.what }}</span><span style="color: #5B6862">{{ b.date }}</span></span><span style="font-weight: 800">{{ b.amt }}</span></div></sc-for>
          <sc-if value="{{ mmActive }}" hint-placeholder-val="{{ true }}"><button onClick="{{ mmToCancel }}" style="align-self: center; background: transparent; padding: 6px; font-size: 13px; font-weight: 800; color: #B8333A">Cancel membership</button></sc-if>
          <sc-if value="{{ mmCancelled }}" hint-placeholder-val="{{ false }}"><button onClick="{{ mmResume }}" style="min-height: 44px; border-radius: 99px; background: #3DDC97; color: #0A0F0D; font-size: 14px; font-weight: 800">Resume membership</button></sc-if>
        </sc-if>
        <sc-if value="{{ mmCancel }}" hint-placeholder-val="{{ false }}">
          <h3 style="margin: 0; font-size: 18px">Before you go</h3>
          <span style="font-size: 14px; color: #43504A">If you cancel, your membership ends {{ renewDate }}. After that you lose:</span>
          <div style="display: flex; flex-direction: column; gap: 8px"><sc-for list="{{ mmLose }}" as="l" hint-placeholder-count="4"><div style="display: flex; align-items: center; gap: 10px; font-size: 14px; font-weight: 700"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#B8333A" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18 M6 6l12 12"></path></svg>{{ l }}</div></sc-for></div>
          <div style="display: flex; gap: 10px; padding-top: 6px"><button onClick="{{ mmKeep }}" style="flex: 1; min-height: 46px; border-radius: 99px; background: #3DDC97; color: #0A0F0D; font-size: 14px; font-weight: 800">Keep membership</button><button onClick="{{ mmConfirm }}" style="flex: 1; min-height: 46px; border-radius: 99px; background: #FDECEC; color: #B8333A; font-size: 14px; font-weight: 800">Cancel membership</button></div>
        </sc-if>
        <sc-if value="{{ mmDone }}" hint-placeholder-val="{{ false }}">
          <h3 style="margin: 0; font-size: 18px">Your membership is cancelled</h3>
          <span style="font-size: 14px; color: #43504A">You won't be charged again. You keep every member feature until {{ renewDate }}, and claims we already filed keep going.</span>
          <div style="display: flex; gap: 10px"><button onClick="{{ mmResume }}" style="flex: 1; min-height: 46px; border-radius: 99px; background: #EEF2F0; color: #0A0F0D; font-size: 14px; font-weight: 800">Undo, keep it</button><button onClick="{{ mmClose }}" style="flex: 1; min-height: 46px; border-radius: 99px; background: #0A0F0D; color: #FFFFFF; font-size: 14px; font-weight: 800">Done</button></div>
        </sc-if>
      </div>
    </div>
  </div></sc-if>
'''
rep("NOTE='''","MMSHEET="+repr(MM)+"\nNOTE='''")
rep("+SHEET+NOTE+'</div>\\n'+TAIL","+SHEET+MMSHEET+NOTE+'</div>\\n'+TAIL")
open('make.py','w').write(s); print('ok')
