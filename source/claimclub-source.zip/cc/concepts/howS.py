# Simpler "How Claimclub works": 3 iterations with fuller, single-purpose phone screens. HowS1..HowS3.dc.html (desktop 1440 + mobile 390 per board).
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from how4 import iphone, ic, LOGO, HEAD, JS, OUT, eyebrow, APPLE

MINT, DARK, GREEN = '#3DDC97', '#0F3B2E', '#12805C'
STEPS = [('Answer a few questions', 'Tap yes or no. Takes about a minute.'),
         ('We file your claims', 'Sign once and we submit every form.'),
         ('Get paid when it pays out', "We'll tell you the moment money is sent.")]

# ---------- three full screens ----------
def scr_question():
    return ('<div style="display: flex; flex-direction: column; height: 100%; padding: 6px 2px 12px; box-sizing: border-box; gap: 16px">'
            '<div style="display: flex; gap: 3px">' + ''.join(f'<span style="flex: 1; height: 4px; border-radius: 99px; background: {GREEN if i < 3 else "#DDE5E0"}"></span>' for i in range(10)) + '</div>'
            '<div style="flex: 1; display: flex; flex-direction: column; justify-content: center; gap: 18px">'
            f'<span style="width: 74px; height: 74px; border-radius: 20px; background: #FFFFFF; box-shadow: 0 8px 20px rgba(10,15,13,.08); display: flex; align-items: center; justify-content: center">{APPLE.replace("width=\"20\" height=\"20\"", "width=\"40\" height=\"40\"")}</span>'
            '<span style="font-size: 25px; font-weight: 800; letter-spacing: -.6px; line-height: 1.15">Did you buy an iPhone 15 Pro or iPhone 16?</span></div>'
            f'<div style="display: flex; flex-direction: column; gap: 10px"><span class="tapY" style="height: 56px; border-radius: 18px; background: {MINT}; color: {DARK}; font-size: 18px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px">{ic("check", 20, 3)}Yes</span>'
            f'<span style="height: 56px; border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px #E3EAE6; font-size: 18px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px"><span style="color: #B8333A; display: flex">{ic("x", 20, 3)}</span>No</span></div></div>')

def scr_filed():
    rows = [('Apple', 'Up to $95'), ('Google Play', 'Up to $100'), ('Visa & Mastercard', 'Up to $1,000')]
    return ('<div style="display: flex; flex-direction: column; height: 100%; padding: 14px 2px 12px; box-sizing: border-box; gap: 14px; align-items: center; text-align: center">'
            f'<span class="pop" style="width: 76px; height: 76px; border-radius: 50%; background: {MINT}; color: {DARK}; display: flex; align-items: center; justify-content: center; margin-top: 10px">{ic("check", 40, 3)}</span>'
            '<span style="font-size: 25px; font-weight: 800; letter-spacing: -.6px">3 claims filed</span><span style="font-size: 14px; color: #5B6862; margin-top: -8px">Signed once, submitted for you.</span>'
            '<div style="width: 100%; display: flex; flex-direction: column; gap: 8px; margin-top: 6px">'
            + ''.join(f'<div style="display: flex; justify-content: space-between; align-items: center; padding: 14px; border-radius: 16px; background: #FFFFFF; box-shadow: 0 1px 2px rgba(10,15,13,.05); text-align: left"><span style="display: flex; flex-direction: column"><b style="font-size: 15px">{n}</b><span style="font-size: 12.5px; color: #5B6862; font-weight: 600">{a}</span></span><span style="display: flex; align-items: center; gap: 5px; font-size: 13px; font-weight: 800; color: {GREEN}">{ic("check", 15, 3)}Filed</span></div>' for n, a in rows)
            + '</div></div>')

def scr_notified():
    note = (f'<div class="pop" style="display: flex; gap: 11px; align-items: center; padding: 13px; border-radius: 20px; background: rgba(255,255,255,.92); box-shadow: 0 14px 30px rgba(10,15,13,.18); text-align: left">'
            f'<span style="width: 42px; height: 42px; flex: none; border-radius: 11px; background: {DARK}; display: flex; align-items: center; justify-content: center">{LOGO.format(s=26, c="#FFFFFF")}</span>'
            '<span style="flex: 1; display: flex; flex-direction: column; gap: 1px"><span style="display: flex; justify-content: space-between"><b style="font-size: 14px">Claimclub</b><span style="font-size: 12px; color: #6E7A73">now</span></span>'
            '<span style="font-size: 13.5px; line-height: 1.35"><b>Payout sent: $95</b> from the Apple settlement, to your PayPal.</span></span></div>')
    return ('<div style="position: absolute; inset: 0; background: linear-gradient(170deg, #CFF3E1 0%, #8FE0B9 45%, #3DB884 100%)"></div>'
            '<div style="position: relative; display: flex; flex-direction: column; align-items: center; height: 100%; padding-top: 18px; box-sizing: border-box; color: #0F3B2E">'
            '<span style="font-size: 15px; font-weight: 700">Saturday, March 6</span><span style="font-size: 78px; font-weight: 700; letter-spacing: -3px; line-height: 1">9:41</span>'
            f'<div style="width: 100%; margin-top: 34px">{note}</div></div>')

SCREENS = [scr_question, scr_filed, scr_notified]
phone = lambda i, w=250: iphone(SCREENS[i](), w, '#F3F6F4')
num = lambda i, bg=MINT, c=DARK: f'<span style="width: 32px; height: 32px; flex: none; border-radius: 50%; background: {bg}; color: {c}; font-weight: 800; font-size: 15px; display: flex; align-items: center; justify-content: center">{i + 1}</span>'

def crop(i, show, w=250):
    return f'<div style="height: {show}px; overflow: hidden; -webkit-mask-image: linear-gradient(180deg, #000 72%, transparent); mask-image: linear-gradient(180deg, #000 72%, transparent)">{phone(i, w)}</div>'

# ---------- S1: dark band, phones with one line under each ----------
def s1(m):
    cols = ''.join(f'<div style="flex: 1 1 0; display: flex; flex-direction: column; align-items: center; gap: 18px; text-align: center">{phone(i, 240) if m else phone(i)}'
                   f'<div style="display: flex; flex-direction: column; align-items: center; gap: 6px">{num(i)}<h3 style="margin: 4px 0 0; font-size: 21px; letter-spacing: -.4px">{t}</h3><p style="margin: 0; font-size: 15px; color: #C9D6CF">{d}</p></div></div>' for i, (t, d) in enumerate(STEPS))
    return (f'<section class="meshDark" style="color: #FFFFFF; padding: {48 if m else 88}px {16 if m else 72}px; min-height: 100%; box-sizing: border-box">'
            f'<div style="text-align: center; margin-bottom: {30 if m else 52}px; display: flex; flex-direction: column; gap: 10px; align-items: center">{eyebrow(c=MINT)}<h2 style="margin: 0; font-size: {30 if m else 46}px; letter-spacing: -1.4px; line-height: 1.08">Three steps. We do the rest.</h2></div>'
            f'<div style="display: flex; {"flex-direction: column; gap: 38px" if m else "gap: 40px"}">{cols}</div></section>')

# ---------- S2: light, title chips only, phones larger ----------
def s2(m):
    cols = ''.join(f'<div style="flex: 1 1 0; display: flex; flex-direction: column; align-items: center; gap: 22px">'
                   f'<span style="display: inline-flex; align-items: center; gap: 10px; padding: 8px 16px 8px 8px; border-radius: 99px; background: #FFFFFF; box-shadow: 0 6px 16px rgba(10,15,13,.07)">{num(i, DARK, "#FFFFFF")}<b style="font-size: 16px">{t}</b></span>'
                   f'{phone(i, 250) if m else phone(i, 270)}</div>' for i, (t, d) in enumerate(STEPS))
    return (f'<section style="background: #F3F6F4; padding: {48 if m else 88}px {16 if m else 64}px; min-height: 100%; box-sizing: border-box">'
            f'<div style="text-align: center; margin-bottom: {28 if m else 48}px; display: flex; flex-direction: column; gap: 10px; align-items: center"><h2 style="margin: 0; font-size: {30 if m else 46}px; letter-spacing: -1.4px; color: {DARK}">How Claimclub works</h2></div>'
            f'<div style="display: flex; {"flex-direction: column; gap: 34px" if m else "gap: 32px; align-items: flex-start"}">{cols}</div></section>')

# ---------- S3: dark band, phones staggered with a connecting line, big numbers ----------
def s3(m):
    if m:
        return s1(True).replace('Three steps. We do the rest.', 'Claim in a minute. Get paid later.')
    cols = ''
    for i, (t, d) in enumerate(STEPS):
        cols += (f'<div style="flex: 1 1 0; display: flex; flex-direction: column; align-items: center; gap: 18px; margin-top: {i * 46}px">'
                 f'<div style="display: flex; align-items: baseline; gap: 12px"><span style="font-size: 54px; font-weight: 800; color: {MINT}; line-height: 1; letter-spacing: -2px">0{i + 1}</span><b style="font-size: 20px; letter-spacing: -.4px; max-width: 200px; line-height: 1.2">{t}</b></div>'
                 f'{phone(i, 260)}</div>')
    return (f'<section class="meshDark" style="color: #FFFFFF; padding: 84px 72px; min-height: 100%; box-sizing: border-box">'
            f'<div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 44px"><div style="display: flex; flex-direction: column; gap: 10px">{eyebrow(c=MINT)}<h2 style="margin: 0; font-size: 46px; letter-spacing: -1.4px">Claim in a minute. Get paid later.</h2></div>'
            f'<span style="font-size: 15px; color: #C9D6CF; max-width: 300px; text-align: right">Settlements usually pay 2 to 6 months after the deadline.</span></div>'
            f'<div style="display: flex; gap: 40px; position: relative">{cols}</div></section>')

VARIANTS = [('HowS1', 'How it works, simpler · 1 · Dark band, one line per step', s1), ('HowS2', 'How it works, simpler · 2 · Light, title chips over bigger phones', s2),
            ('HowS3', 'How it works, simpler · 3 · Staggered phones with big step numbers', s3)]

def build():
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    y0 = max(b['y'] + b['h'] for k, b in c['boards'].items() if not k.startswith('HowS')) + 260
    c['notes']['tHS'] = {'x': 0, 'y': y0, 'text': 'How it works, simpler · 3 iterations (question, filed, notified)', 'kind': 'title1', 'maxW': 3900, 'w': 240}
    if 'tHS' not in c['noteOrder']: c['noteOrder'].append('tHS')
    for k, (name, title, fn) in enumerate(VARIANTS):
        page = (f'<div style="width: 1926px; height: 980px; box-sizing: border-box; padding: 24px; background: #E7ECE9; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 14px">'
                f'<div style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #43504A">{title.upper()}</div><div style="display: flex; gap: 48px; align-items: flex-start">'
                f'<div class="scroll" style="width: 1440px; height: 900px; flex: none; overflow-y: auto; border-radius: 18px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{fn(False)}</div>'
                f'<div class="scroll" style="width: 390px; height: 844px; flex: none; overflow-y: auto; border-radius: 28px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{fn(True)}</div></div></div>\n</x-dc>\n')
        open(os.path.join(OUT, name + '.dc.html'), 'w').write(HEAD % title + page + JS)
        c['boards'][name + '.dc.html'] = {'x': (k % 2) * 2006, 'y': y0 + 220 + (k // 2) * 1060, 'w': 1926, 'h': 980, 'is_interactive': True, 'title': title}
        if name + '.dc.html' not in c['order']: c['order'].append(name + '.dc.html')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w'))
    print('built', [v[0] for v in VARIANTS], 'y0', y0)

if __name__ == '__main__':
    build()
