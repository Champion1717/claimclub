# Member perks, 3 design drafts (Nov 15 2026). The perks screens now come BEFORE payment (choice > perks > plans),
# so they sell membership instead of welcoming a new member. Writes PerkA/PerkB/PerkC.dc.html, each showing
# the 3 screens on phones: 1 your claims in one dashboard, 2 alerts for new claims, 3 every settlement + near you.
import os
from how4 import HEAD, JS, OUT

INK, MUTE, LINE, MINT, GREEN, DARK = '#0A0F0D', '#5B6862', '#DDE5E0', '#3DDC97', '#12805C', '#0F3B2E'
LU = {
    'check': 'M20 6 9 17l-5-5', 'x': 'M18 6 6 18 M6 6l12 12', 'right': 'm9 18 6-6-6-6', 'back': 'm15 18-6-6 6-6',
    'bell': 'M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9 M10.3 21a1.94 1.94 0 0 0 3.4 0',
    'dash': 'M3 3h7v9H3z M14 3h7v5h-7z M14 12h7v9h-7z M3 16h7v5H3z',
    'pin': 'M20 10c0 5-5.5 10.2-7.4 11.8a1 1 0 0 1-1.2 0C9.5 20.2 4 15 4 10a8 8 0 0 1 16 0 M12 7a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
    'search': 'M11 3a8 8 0 1 0 0 16 8 8 0 0 0 0-16z m10 18-4.3-4.3',
    'lock': 'M5 11h14a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2z M7 11V7a5 5 0 0 1 10 0v4',
}
def ic(k, sz=16, c='currentColor', sw=2.2):
    return f'<svg width="{sz}" height="{sz}" viewBox="0 0 24 24" fill="none" stroke="{c}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex: none"><path d="{LU[k]}"></path></svg>'
def tile(ch, bg, sz=34, fg='#FFFFFF'):
    return f'<span style="width: {sz}px; height: {sz}px; flex: none; border-radius: {sz * .28:.0f}px; background: {bg}; color: {fg}; display: flex; align-items: center; justify-content: center; font-size: {sz * .44:.0f}px; font-weight: 800">{ch}</span>'
# placeholder rows (brand initial tiles); the live version would use the member's own matches and the real tiles
CLAIMS = [('A', '#111111', 'Apple', 'Filed', '#E9F6EF', '#17603F'), ('V', '#1A1F71', 'Visa & Mastercard', 'Ready to file', '#FFF4DB', '#8A5A00'),
          ('G', '#01875F', 'Google Play', 'In review', '#EAF1FF', '#2453A6'), ('C', '#CC0000', 'CVS', 'Paid $5', '#E9F6EF', '#17603F')]
NEW = [('N', '#E50914', 'Netflix', 'Up to $2,500', '2 min ago'), ('T', '#B5121B', 'Tyson & beef packers', 'Up to $100', 'Yesterday'), ('R', '#3D5AFE', 'RealPage', 'Up to $300', 'Tue')]
LOCAL = [('Concord Management', 'Florida security deposits', 'Share of $1.85M'), ('Progressive Residential', 'Florida eviction fees', '75% of fees back'), ('SELA Realty', 'Florida security deposits', '60% of deposit')]
STEPS = [('Your claims,', 'all in one dashboard', 'See every claim and exactly where it stands, from filed to paid, plus anything that still needs you.'),
         ('New claims,', 'the day they open', 'New settlements open every week. We check each one against your answers and tell you the moment you can file.'),
         ('Every settlement,', 'plus ones near you', 'Browse all 294 open settlements, and we scan for state and city settlements most people never hear about.')]

def phone(inner, bg='#FFFFFF'):
    return (f'<div style="width: 390px; height: 844px; flex: none; border-radius: 44px; overflow: hidden; background: {bg}; display: flex; flex-direction: column; position: relative; box-shadow: 0 0 0 10px #1A1D1C, 0 30px 80px rgba(10,15,13,.2)">'
            f'<div style="position: absolute; top: 12px; left: 50%; transform: translateX(-50%); width: 120px; height: 34px; border-radius: 99px; background: #000000; z-index: 5"></div>{inner}</div>')
def btn(t, bg=MINT, fg=DARK, h=56):
    return f'<div style="height: {h}px; flex: none; border-radius: 99px; background: {bg}; color: {fg}; display: flex; align-items: center; justify-content: center; gap: 8px; font-size: 17px; font-weight: 800">{t}</div>'

# mini UIs shared by the designs
def ui_claims(dark=False):
    rows = ''.join(f'<div style="display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 14px; background: #FFFFFF; box-shadow: 0 1px 3px rgba(10,15,13,.08)">'
                   f'{tile(c, bg)}<b style="flex: 1; font-size: 14.5px; color: {INK}; min-width: 0">{n}</b><span style="font-size: 12px; font-weight: 800; padding: 4px 9px; border-radius: 99px; background: {pb}; color: {pc}; white-space: nowrap">{st}</span></div>'
                   for c, bg, n, st, pb, pc in CLAIMS)
    return (f'<div style="display: flex; flex-direction: column; gap: 8px">'
            f'<div style="display: flex; justify-content: space-between; align-items: baseline; padding: 0 2px"><span style="font-size: 11.5px; font-weight: 800; letter-spacing: 1.1px; color: {"#B9E8D2" if dark else "#8A968F"}">YOUR CLAIMS</span><span style="font-size: 12.5px; font-weight: 800; color: {MINT if dark else GREEN}">Up to $1,400</span></div>{rows}</div>')
def ui_alerts():
    rows = ''.join(f'<div style="display: flex; align-items: center; gap: 10px; padding: 12px; border-radius: 18px; background: rgba(255,255,255,{.97 - i * .1:.2f}); box-shadow: 0 12px 26px rgba(10,15,13,.16)">'
                   f'<span style="width: 36px; height: 36px; flex: none; border-radius: 10px; background: {DARK}; display: flex; align-items: center; justify-content: center">{ic("bell", 18, MINT, 2.4)}</span>'
                   f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px"><span style="display: flex; justify-content: space-between; gap: 8px"><b style="font-size: 13.5px; color: {INK}">New claim match</b><span style="font-size: 11.5px; color: #8A968F; font-weight: 600">{t}</span></span>'
                   f'<span style="font-size: 12.5px; color: {MUTE}; font-weight: 600">You qualify for {n}. {v}.</span></span></div>'
                   for i, (c, bg, n, v, t) in enumerate(NEW))
    return f'<div style="display: flex; flex-direction: column; gap: 10px">{rows}</div>'
def ui_local(dark=False):
    rows = ''.join(f'<div style="display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 14px; background: #FFFFFF; box-shadow: 0 1px 3px rgba(10,15,13,.08)">'
                   f'<span style="width: 34px; height: 34px; flex: none; border-radius: 10px; background: #E9F6EF; display: flex; align-items: center; justify-content: center">{ic("pin", 17, GREEN, 2.4)}</span>'
                   f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column"><b style="font-size: 14px; color: {INK}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{n}</b><span style="font-size: 12px; color: {MUTE}; font-weight: 600">{w}</span></span>'
                   f'<span style="font-size: 11.5px; font-weight: 800; color: {GREEN}; text-align: right; max-width: 90px">{p}</span></div>' for n, w, p in LOCAL)
    return (f'<div style="display: flex; flex-direction: column; gap: 8px">'
            f'<div style="display: flex; align-items: center; gap: 8px; padding: 10px 12px; border-radius: 14px; background: {"rgba(255,255,255,.12)" if dark else "#F3F6F4"}; color: {"#FFFFFF" if dark else MUTE}; font-size: 14px; font-weight: 600">{ic("search", 16, "#FFFFFF" if dark else MUTE)}Search 294 open settlements</div>'
            f'<span style="font-size: 11.5px; font-weight: 800; letter-spacing: 1.1px; color: {"#B9E8D2" if dark else "#8A968F"}; padding: 4px 2px 0">NEAR MIAMI, FL</span>{rows}</div>')
UIS = [ui_claims, ui_alerts, ui_local]

# ---------- A: story screens (dark green, progress bars, big visual on top) ----------
def a_screen(i):
    h, em, p = STEPS[i]
    bars = ''.join(f'<span style="flex: 1; height: 4px; border-radius: 99px; background: {"#FFFFFF" if j <= i else "rgba(255,255,255,.28)"}"></span>' for j in range(3))
    vis = UIS[i](True) if i != 1 else ui_alerts()
    return phone(
        f'<div style="padding: 58px 20px 0; display: flex; flex-direction: column; gap: 14px">'
        f'<div style="display: flex; gap: 6px">{bars}</div>'
        f'<div style="display: flex; justify-content: space-between; align-items: center"><span style="display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 99px; background: rgba(255,255,255,.14); color: #FFFFFF; font-size: 12.5px; font-weight: 800">{ic("lock", 13, MINT, 2.6)}Members only</span>'
        f'<span style="font-size: 14px; font-weight: 700; color: rgba(255,255,255,.8)">Skip</span></div></div>'
        f'<div style="flex: 1; padding: 22px 20px 0; display: flex; flex-direction: column; justify-content: center">{vis}</div>'
        f'<div style="padding: 0 22px 34px; display: flex; flex-direction: column; gap: 12px">'
        f'<b style="font-size: 32px; line-height: 1.08; letter-spacing: -1px; color: #FFFFFF">{h}<br><span style="color: {MINT}">{em}</span></b>'
        f'<span style="font-size: 15.5px; line-height: 1.5; color: rgba(255,255,255,.78); font-weight: 600">{p}</span>'
        + btn('Next' if i < 2 else 'See plans · from $7.99', MINT, DARK) + '</div>',
        bg=f'radial-gradient(120% 70% at 100% 0%, rgba(61,220,151,.25), transparent 55%), linear-gradient(180deg, #0F3B2E, #0A2A20)')

# ---------- B: light editorial (number, headline, one clean card, dots) ----------
def b_screen(i):
    h, em, p = STEPS[i]
    dots = ''.join(f'<span style="width: {22 if j == i else 7}px; height: 7px; border-radius: 99px; background: {GREEN if j == i else LINE}"></span>' for j in range(3))
    return phone(
        f'<div style="padding: 58px 22px 0; display: flex; justify-content: space-between; align-items: center"><span style="width: 36px; height: 36px; border-radius: 99px; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; align-items: center; justify-content: center">{ic("back", 18, INK, 2.4)}</span>'
        f'<span style="font-size: 14px; font-weight: 700; color: {MUTE}">Skip</span></div>'
        f'<div style="padding: 18px 22px 0; display: flex; flex-direction: column; gap: 10px">'
        f'<span style="font-size: 13px; font-weight: 800; letter-spacing: 1.2px; color: {GREEN}">0{i + 1} · MEMBERSHIP</span>'
        f'<b style="font-size: 31px; line-height: 1.1; letter-spacing: -1px; color: {INK}">{h} <span style="color: {GREEN}">{em}</span></b>'
        f'<span style="font-size: 15px; line-height: 1.5; color: {MUTE}; font-weight: 600">{p}</span></div>'
        f'<div style="flex: 1; margin: 20px 16px 0; padding: 16px; border-radius: 24px; background: #F3F6F4; display: flex; flex-direction: column; justify-content: center">{UIS[i]()}</div>'
        f'<div style="padding: 18px 22px 34px; display: flex; flex-direction: column; align-items: center; gap: 16px"><div style="display: flex; gap: 6px">{dots}</div>'
        + '<div style="width: 100%">' + btn('Next' if i < 2 else 'Choose my plan', INK, '#FFFFFF') + '</div></div>')

# ---------- C: value comparison (with vs without membership, on every screen) ----------
CMP = [('Only the claims you file today', 'Every claim you match, tracked in one place'),
       ('Check back for new settlements yourself', 'An alert the day a new claim fits you'),
       ('A preview of 6 settlements', 'All 294, plus local ones near you')]
def c_screen(i):
    h, em, p = STEPS[i]
    no, yes = CMP[i]
    tabs = ''.join(f'<span style="flex: 1; text-align: center; padding: 8px 0; border-radius: 10px; font-size: 13px; font-weight: 800; {"background: #FFFFFF; color: " + INK + "; box-shadow: 0 1px 3px rgba(10,15,13,.12)" if j == i else "color: #8A968F"}">{t}</span>'
                   for j, t in enumerate(['Dashboard', 'Alerts', 'All claims']))
    return phone(
        f'<div style="padding: 58px 18px 0; display: flex; flex-direction: column; gap: 14px">'
        f'<div style="display: flex; gap: 4px; padding: 4px; border-radius: 14px; background: #E6ECE8">{tabs}</div>'
        f'<b style="font-size: 28px; line-height: 1.1; letter-spacing: -0.9px; color: {INK}; margin-top: 4px">{h} <span style="color: {GREEN}">{em}</span></b></div>'
        f'<div style="padding: 14px 18px 0">{UIS[i]()}</div>'
        f'<div style="flex: 1"></div>'
        f'<div style="margin: 0 18px; border-radius: 20px; overflow: hidden; box-shadow: inset 0 0 0 1.5px {LINE}">'
        f'<div style="display: flex; align-items: center; gap: 10px; padding: 12px 14px; background: #FFFFFF"><span style="width: 24px; height: 24px; flex: none; border-radius: 99px; background: #F3F6F4; display: flex; align-items: center; justify-content: center">{ic("x", 13, "#A1262E", 2.8)}</span>'
        f'<span style="display: flex; flex-direction: column"><span style="font-size: 11px; font-weight: 800; letter-spacing: 1px; color: #8A968F">FILING FEE ONLY</span><span style="font-size: 14px; font-weight: 700; color: {MUTE}">{no}</span></span></div>'
        f'<div style="display: flex; align-items: center; gap: 10px; padding: 12px 14px; background: #E9F6EF"><span style="width: 24px; height: 24px; flex: none; border-radius: 99px; background: {GREEN}; display: flex; align-items: center; justify-content: center">{ic("check", 13, "#FFFFFF", 3)}</span>'
        f'<span style="display: flex; flex-direction: column"><span style="font-size: 11px; font-weight: 800; letter-spacing: 1px; color: {GREEN}">WITH MEMBERSHIP</span><span style="font-size: 14px; font-weight: 800; color: {INK}">{yes}</span></span></div></div>'
        f'<div style="padding: 16px 18px 34px; display: flex; flex-direction: column; gap: 8px">' + btn('Next' if i < 2 else 'Join for $7.99 first month')
        + f'<span style="text-align: center; font-size: 13px; font-weight: 700; color: {MUTE}">{"Skip to plans" if i < 2 else "Then $29.99 a month. Cancel anytime."}</span></div>', bg='#FFFFFF')

INFO = {
 'A': ('PERKS DESIGN A · STORY', 'Dark green story screens with progress bars like Instagram stories. The real dashboard pieces sit in the middle (their claims, new-claim alerts, local settlements), with a big headline and one button. Last screen: "See plans · from $7.99".', a_screen),
 'B': ('PERKS DESIGN B · CLEAN', 'Light and calm, like the rest of the claim flow. Numbered 01, 02, 03 with the headline first and one clean card showing the feature. Dots at the bottom, black button. Last screen: "Choose my plan".', b_screen),
 'C': ('PERKS DESIGN C · COMPARE', 'Sells the upgrade directly: tabs for Dashboard, Alerts and All claims, the feature in action, then "Filing fee only" vs "With membership" for that perk. Last screen: "Join for $7.99 first month".', c_screen),
}
if __name__ == '__main__':
    for k, (title, desc, fn) in INFO.items():
        phones = ''.join(f'<div style="display: flex; flex-direction: column; gap: 18px; align-items: center"><span style="font-size: 13px; font-weight: 800; letter-spacing: 1px; color: #8A968F">SCREEN {i + 1}</span>{fn(i)}</div>' for i in range(3))
        page = ('<div data-board style="width: 1426px; height: 1100px; box-sizing: border-box; padding: 36px 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 24px">'
                f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #12805C">{title}</span>'
                f'<span style="font-size: 16px; color: #43504A; max-width: 1300px; line-height: 1.5; font-weight: 600">{desc}</span>'
                '<span style="font-size: 13px; color: #8A968F; font-weight: 600">Shown before payment: choice page &gt; these 3 screens &gt; plans. Claims and amounts are sample data; the live version uses their own matches.</span></div>'
                f'<div style="display: flex; gap: 46px; padding: 0 0 0 10px">{phones}</div></div>\n</x-dc>\n')
        open(os.path.join(OUT, f'Perk{k}.dc.html'), 'w').write(HEAD % f'Member perks, design {k}' + page + JS.replace('"width":1926,"height":980', '"width":1426,"height":1100'))
    print('ok')
