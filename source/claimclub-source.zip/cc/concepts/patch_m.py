s=open('make.py').read()
LOGO=open('/home/claude/cc/src/logo.txt').read().strip().replace('__C__','#0A0F0D').replace('#FFB224','#12805C')
s=s.replace("translateY(-16px) scale(.96)}60%%{opacity:1;transform:translateY(2px)","translateY(18px) scale(.96)}60%%{opacity:1;transform:translateY(-2px)")
s=s.replace('position: absolute; top: 22px; right: 24px; z-index: 50; width: 380px;','position: absolute; bottom: 24px; right: 24px; z-index: 50; width: 380px;')
i=s.index('# ---------------- A: Inbox'); j=s.index('# ---------------- B: Pipeline'); A=s[i:j]
R=[('<div style="display: flex; align-items: center; gap: 16px; padding: 12px 16px">','<div class="setupRow" style="display: flex; align-items: center; gap: 16px; padding: 12px 16px">'),
('<div style="width: 170px; flex: none; display: flex; flex-direction: column; gap: 6px"><span style="font-size: 12px; font-weight: 800; color: #5B6862">Finish','<div class="setupProg" style="width: 170px; flex: none; display: flex; flex-direction: column; gap: 6px"><span style="font-size: 12px; font-weight: 800; color: #5B6862">Finish'),
('<span style="width: 1px; align-self: stretch; background: #EEF2F0"></span>','<span class="setupDiv" style="width: 1px; align-self: stretch; background: #EEF2F0"></span>'),
('<span style="font-size: 14px; font-weight: 800; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{ nextLabel }}','<span class="curLbl" style="font-size: 14px; font-weight: 800; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{ nextLabel }}'),
('<span style="font-size: 12px; color: #B9CCC2">Tap File','<span class="hideM" style="font-size: 12px; color: #B9CCC2">Tap File'),
('<span style="font-size: 12px; color: #5B6A85">Nothing','<span class="hideM" style="font-size: 12px; color: #5B6A85">Nothing'),
('<div style="display: grid; grid-template-columns: repeat(3, minmax(0,1fr)); gap: 10px">','<div class="moreGrid" style="display: grid; grid-template-columns: repeat(3, minmax(0,1fr)); gap: 10px">'),
('<div style="display: flex; gap: 8px"><button style="min-height: 34px; padding: 0 14px; border-radius: 99px; background: #FFFFFF;','<div class="findBtns" style="display: flex; gap: 8px"><button style="min-height: 34px; padding: 0 14px; border-radius: 99px; background: #FFFFFF;'),
('<div style="flex-shrink: 0; display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 14px">','<div class="greet" style="flex-shrink: 0; display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 14px">'),
('<main class="scroll" style="flex-grow: 1; min-width: 0; overflow-y: auto; padding: 24px 32px 32px;','<main class="scroll amain" style="flex-grow: 1; min-width: 0; min-height: 0; overflow-y: auto; padding: 24px 32px 32px;'),
]
for o,n in R:
    assert o in A,o; A=A.replace(o,n)
s=s[:i]+A+s[j:]
M_CSS=r'''
.amain{padding:14px 14px 20px !important;gap:12px !important}
.greet h1{font-size:20px !important}.greet>div:last-child{width:100%}.greet>div:last-child>span{flex:1}
.setupRow{flex-wrap:wrap;gap:10px !important;padding:12px !important}.setupProg{width:100% !important}.setupDiv{display:none}.curLbl{white-space:normal !important}
.hideM{display:none}
.arow{grid-template-columns:34px minmax(0,1fr) auto auto !important;gap:10px !important;padding:9px 10px !important}.arow>.hideS{display:none}
.trow{grid-template-columns:34px minmax(0,1fr) auto !important;gap:10px !important;padding:10px 14px !important}.trow>.hideS{display:none}
.moreGrid{display:flex !important;overflow-x:auto;scroll-snap-type:x mandatory;margin:0 -16px;padding:0 16px;scrollbar-width:none}.moreGrid::-webkit-scrollbar{display:none}.moreGrid>*{flex:0 0 82%;scroll-snap-align:start}
.findBtns{width:100%}.findBtns button{flex:1;justify-content:center}
.note{left:12px !important;right:12px !important;bottom:78px !important;width:auto !important}
'''
TOP='''  <header style="flex: none; display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; background: #FFFFFF; border-bottom: 1px solid #E3EAE6"><div style="display: flex; align-items: center; gap: 7px"><svg width="24" height="24" viewBox="0 0 100 100" aria-hidden="true">'''+LOGO+'''</svg><span style="font-size: 17px; font-weight: 800; letter-spacing: -0.4px">claim<span style="font-weight: 500">club</span><span style="font-size: .72em; font-weight: 600; color: #12805C; margin-left: -0.06em">.io</span></span></div><span style="width: 32px; height: 32px; border-radius: 50%; background: #0F3B2E; color: #FFFFFF; font-size: 13px; font-weight: 800; display: flex; align-items: center; justify-content: center">H</span></header>
'''
NAVI=[('Claims','M3 3h7v9H3z M14 3h7v5h-7z M14 12h7v9h-7z M3 16h7v5H3z',1),('Settlements','M8 6h13 M8 12h13 M8 18h13 M3 6h.01 M3 12h.01 M3 18h.01',0),('Your info','M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2 M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z',0),('Settings','M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-2.82 1.17V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-2.82-1.17l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 3 13.17H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.17-2.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9.91 3V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 2.82 1.17l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 21 9.91V10a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z',0)]
NAV='  <nav style="flex: none; display: flex; justify-content: space-around; padding: 8px 6px 14px; background: #FFFFFF; border-top: 1px solid #E3EAE6">'+''.join(f'<span style="display: flex; flex-direction: column; align-items: center; gap: 3px; font-size: 11px; font-weight: 800; color: {"#0F3B2E" if on else "#8A968F"}"><svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="{d}"></path></svg>{t}</span>' for t,d,on in NAVI)+'</nav>\n'
s=s.replace("for name,src in [('DashA',A),('DashB',B),('DashC',C)]:","""M_CSS=%r
TOP=%r
NAV=%r
AM=A.replace('<title>Dashboard option A · To-do inbox</title>','<title>Dashboard option A · mobile</title>').replace('</style>\\n</helmet>',M_CSS+'</style>\\n</helmet>',1)
AM=AM.replace('min-height: 640px; box-sizing: border-box; background: #F3F6F4; color: #0A0F0D; font-family: Manrope, sans-serif; display: flex; overflow: hidden','min-height: 640px; box-sizing: border-box; background: #F3F6F4; color: #0A0F0D; font-family: Manrope, sans-serif; display: flex; flex-direction: column; overflow: hidden',1)
AM=AM.replace(side(0),TOP,1).replace('  </main>\\n','  </main>\\n'+NAV,1).replace('{"width":1440,"height":900}','{"width":390,"height":844}')
assert TOP in AM and NAV in AM
for name,src in [('DashA',A),('DashAM',AM),('DashB',B),('DashC',C)]:""" % (M_CSS,TOP,NAV))
open('make.py','w').write(s)
