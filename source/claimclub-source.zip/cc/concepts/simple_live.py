# Nov 18 2026: markup and logic for the simpler member dashboard (Henry picked it from the "Simpler dashboard" canvas page).
# make.py imports this. Tabs: Your claims, Find claims, Claim refunds, Manage subscriptions. Your info, Settings, Your cards and
# Add a charge open as popups (state.pop). JS lives in raw strings so backslashes stay as written.

def svg(d, s=18, w=2, extra=''):
    return f'<svg width="{s}" height="{s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="{w}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex: none{extra}"><path d="{d}"></path></svg>'
P = {'home': 'M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8 M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z',
     'search': 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z M21 21l-4.3-4.3',
     'receipt': 'M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8 M12 17.5v-11',
     'repeat': 'M17 2l4 4-4 4 M3 11v-1a4 4 0 0 1 4-4h14 M7 22l-4-4 4-4 M21 13v1a4 4 0 0 1-4 4H3',
     'lock': 'M5 11h14a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2z M7 11V7a5 5 0 0 1 10 0v4',
     'check': 'M20 6 9 17l-5-5', 'x': 'M18 6 6 18 M6 6l12 12', 'right': 'm9 18 6-6-6-6', 'plus': 'M5 12h14 M12 5v14',
     'card': 'M4 5h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z M2 10h20',
     'shield': 'M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z M9 12l2 2 4-4',
     'user': 'M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2 M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z',
     'help': 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3 M12 17h.01',
     'refresh': 'M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8 M21 3v5h-5 M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16 M8 16H3v5',
     'alert': 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z M12 8v4 M12 16h.01'}
SP = '<span class="spin"></span>'
def iff(v, inner, ph='false'): return f'<sc-if value="{{{{ {v} }}}}" hint-placeholder-val="{{{{ {ph} }}}}">{inner}</sc-if>'
MUT = 'color: #5B6862'
BIGN = lambda lbl, num, sub, tour='': f'<div {tour}style="display: flex; flex-direction: column; gap: 2px; padding-top: 4px"><span style="font-size: 14px; font-weight: 700; {MUT}">{lbl}</span><b class="sBigN" style="font-size: 52px; letter-spacing: -1.5px; line-height: 1.06">{num}</b><span style="font-size: 14px; font-weight: 600; {MUT}">{sub}</span></div>'
DARK = 'padding: 20px 22px; border-radius: 22px; background: #0F3B2E; color: #FFFFFF'
KICK = lambda t: f'<span style="font-size: 12px; font-weight: 800; letter-spacing: 1px; color: #3DDC97">{t}</span>'
BTN = 'min-height: 44px; padding: 0 20px; border-radius: 99px; font-size: 15px; font-weight: 800; display: inline-flex; align-items: center; justify-content: center; gap: 8px; white-space: nowrap'
MINT = BTN + '; background: #3DDC97; color: #0A0F0D'
WDARK = BTN + '; background: rgba(255,255,255,.12); color: #FFFFFF'
SOFTB = 'min-height: 38px; padding: 0 14px; border-radius: 99px; font-size: 14px; font-weight: 800; display: inline-flex; align-items: center; justify-content: center; gap: 6px; white-space: nowrap; background: #EEF2F0; color: #0A0F0D'
ROWST = 'display: flex; align-items: center; gap: 12px; padding: 12px 14px 12px 12px; border-radius: 16px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6'
LINKB = 'align-self: flex-start; background: transparent; padding: 4px 2px; font-size: 14px; font-weight: 800; color: #12805C'
H2 = lambda t: f'<h2 style="margin: 0; font-size: 16px">{t}</h2>'
def check(t): return f'<span style="display: flex; gap: 10px; align-items: flex-start; font-size: 14.5px; font-weight: 700; line-height: 1.4"><span style="width: 22px; height: 22px; flex: none; border-radius: 99px; background: rgba(61,220,151,.18); color: #3DDC97; display: inline-flex; align-items: center; justify-content: center">{svg(P["check"],13,3)}</span>{t}</span>'
INI = '<span style="{{ r.icSt }}">{{ r.ini }}</span>'

# ---------- desktop header (replaces the sidebar) ----------
def header_d(logo_side, pwrap):
    tab = lambda go, st, label, extra='': f'<button class="tabB" onClick="{{{{ {go} }}}}" style="{{{{ {st} }}}}">{label}{extra}</button>'
    badge = iff('hasReady', '<span style="padding: 1px 7px; border-radius: 99px; background: #3DDC97; color: #0A0F0D; font-size: 11.5px; font-weight: 800">{{ readyN }}</span>', 'true')
    lock = iff('mbLock', '<span style="display: flex; color: #8A968F">' + svg(P['lock'], 13, 2.4) + '</span>')
    nav = ('<nav aria-label="Dashboard" class="sTabs" style="display: flex; gap: 4px">' + tab('goDash', 'tabDash', 'Your claims', badge) + tab('goAll', 'tabAll', 'Find claims')
           + iff('mbOn', tab('goRefunds', 'tabRefunds', 'Claim refunds', lock) + tab('goSubs', 'tabSubs', 'Manage subscriptions', lock), 'true') + '</nav>')
    lg = logo_side.replace('padding: 0 8px 18px', 'padding: 0', 1)
    return ('<header style="flex: none; height: 68px; display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 0 24px; background: #FFFFFF; border-bottom: 1px solid #E3EAE6; position: relative; z-index: 30; box-sizing: border-box">'
            + '<div style="flex: 1 1 0; display: flex">' + lg + '</div>' + nav + '<div style="flex: 1 1 0; display: flex; justify-content: flex-end">' + pwrap + '</div></header>')

def nav_m():
    def b(go, st, d, label, extra=''):
        return f'<button onClick="{{{{ {go} }}}}" style="{{{{ {st} }}}}"><span style="position: relative; display: flex">{svg(P[d], 21)}{extra}</span>{label}</button>'
    badge = iff('hasReady', '<span style="position: absolute; right: -10px; top: -5px; min-width: 16px; height: 16px; padding: 0 4px; box-sizing: border-box; border-radius: 99px; background: #3DDC97; color: #0A0F0D; font-size: 10.5px; font-weight: 800; display: flex; align-items: center; justify-content: center">{{ readyN }}</span>', 'true')
    lock = iff('mbLock', '<span style="position: absolute; right: -8px; top: -4px; width: 15px; height: 15px; border-radius: 50%; background: #FFFFFF; color: #5B6862; display: flex; align-items: center; justify-content: center">' + svg(P['lock'], 10, 2.8) + '</span>')
    return ('  <nav style="flex: none; display: flex; justify-content: space-around; padding: 8px 4px 14px; background: #FFFFFF; border-top: 1px solid #E3EAE6">'
            + b('goDash', 'mDash', 'home', 'Claims', badge) + b('goAll', 'mAll', 'search', 'Find') + b('goRefunds', 'mRefunds', 'receipt', 'Refunds', lock) + b('goSubs', 'mSubs', 'repeat', 'Subscriptions', lock) + '</nav>\n')

# ---------- Your claims ----------
def chip(): return '<span style="{{ r.chipSt }}">' + iff('r.dot', '<span class="sdot"></span>') + '{{ r.chipT }}</span>'
DASH = ('    <sc-if value="{{ isDash }}" hint-placeholder-val="{{ true }}">\n'
 + iff('showBan', f'<div class="feeBan" style="display: flex; align-items: center; gap: 14px; flex-wrap: wrap; {DARK}"><span style="flex: 1; min-width: 200px; display: flex; flex-direction: column; gap: 3px"><b style="font-size: 16px">{{{{ feeHead }}}}</b><span style="font-size: 13.5px; color: #B7CEC4; line-height: 1.45">{{{{ feeSub }}}}</span></span><button onClick="{{{{ join }}}}" style="{MINT}">{{{{ joinLabel }}}}</button></div>')
 + BIGN('Coming to you', '{{ sTotal }}', '{{ sTotalSub }}', 'data-tour="total" ')
 + iff('hasNx', f'<section aria-label="Ready to file" class="cardin" style="display: flex; align-items: center; gap: 14px; flex-wrap: wrap; {DARK}"><img src="{{{{ nx.logo }}}}" alt="" style="width: 50px; height: 50px; flex: none; border-radius: 14px; background: #FFFFFF; padding: 7px; box-sizing: border-box; object-fit: contain"><span style="flex: 1; min-width: 170px; display: flex; flex-direction: column; gap: 3px">{KICK("NEXT UP")}<b style="font-size: 18px">{{{{ nx.head }}}}</b><span style="font-size: 13px; font-weight: 600; color: #B7CEC4">{{{{ nx.sub }}}}</span></span><button class="nxBtn" onClick="{{{{ nx.file }}}}" aria-label="File the {{{{ nx.co }}}} claim" style="{MINT}; min-height: 46px">' + iff('nx.busy', SP + 'Opening') + iff('nx.idle', 'Start', 'true') + '</button></section>', 'true')
 + iff('sCaught', f'<div class="cardin" style="padding: 18px; border-radius: 22px; background: #E9F6EF; display: flex; align-items: center; gap: 14px"><span class="sPop" style="width: 48px; height: 48px; flex: none; border-radius: 15px; background: #12805C; color: #FFFFFF; display: inline-flex; align-items: center; justify-content: center">{svg(P["check"], 22, 3)}</span><span style="flex: 1; display: flex; flex-direction: column; gap: 2px"><b style="font-size: 17px">You are all caught up</b><span style="font-size: 13.5px; font-weight: 600; {MUT}">Every claim is moving. We will tell you when one pays.</span></span></div>')
 + iff('sNewbie', f'<div class="cardin" style="display: flex; flex-direction: column; gap: 12px; {DARK}"><span style="width: 52px; height: 52px; border-radius: 16px; background: rgba(61,220,151,.16); color: #3DDC97; display: inline-flex; align-items: center; justify-content: center">{svg(P["search"], 24)}</span><b style="font-size: 20px">Find your first claim</b><span style="font-size: 14px; font-weight: 600; color: #B7CEC4; line-height: 1.5">Answer a few yes or no questions. Most people match 3 to 6 settlements.</span><button onClick="{{{{ findAll }}}}" style="{MINT}; width: 100%">Find claims</button></div>')
 + iff('sSetup', f'<div class="setupRow" style="display: flex; align-items: center; gap: 12px; padding: 12px 14px; border-radius: 16px; background: #FFF4DB"><span style="display: inline-flex; color: #8A5A00">{svg(P["user"], 20)}</span><span style="flex: 1; display: flex; flex-direction: column; gap: 1px"><b style="font-size: 14px; color: #8A5A00">Finish your account</b><span style="font-size: 12.5px; font-weight: 600; color: #43504A">{{{{ sSetupSub }}}}</span></span><button onClick="{{{{ setupGo }}}}" style="min-height: 34px; padding: 0 14px; border-radius: 99px; background: #0A0F0D; color: #FFFFFF; font-size: 13px; font-weight: 800">Finish</button></div>')
 + iff('sHasRows', '<section aria-label="Your claims" style="display: flex; flex-direction: column; gap: 8px">' + H2('Your claims')
   + '<sc-for list="{{ sRowsC }}" as="r" hint-placeholder-count="5"><div class="sRow {{ r.cls }}" style="' + ROWST + '"><button onClick="{{ r.info }}" aria-label="Details for the {{ r.co }} claim" style="flex: 1; min-width: 0; display: flex; align-items: center; gap: 12px; background: transparent; padding: 0; text-align: left; color: inherit"><img src="{{ r.logo }}" alt="" style="width: 42px; height: 42px; flex: none; border-radius: 12px; background: #FFFFFF; padding: 6px; box-sizing: border-box; object-fit: contain; box-shadow: inset 0 0 0 1px #E3EAE6"><span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><b style="font-size: 15px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{ r.co }} <span style="color: #12805C">{{ r.amtS }}</span></b><span style="{{ r.subSt }}">{{ r.subS }}</span></span></button>'
   + iff('r.isReady', '<button onClick="{{ r.file }}" aria-label="{{ r.fileAria }}" style="{{ r.fileSt }}">' + iff('r.busy', SP) + iff('r.blk', svg(P['lock'], 14, 2.4)) + '{{ r.fileT }}</button>')
   + iff('r.isNeeds', '<button onClick="{{ r.info }}" style="min-height: 38px; padding: 0 14px; border-radius: 99px; background: #FDECEC; color: #B8333A; font-size: 13.5px; font-weight: 800; display: inline-flex; align-items: center; gap: 7px"><span class="sdot"></span>Reply</button>')
   + iff('r.showChip', chip(), 'true') + '</div></sc-for>'
   + f'<button onClick="{{{{ findAll }}}}" style="{LINKB}">Find more claims</button></section>', 'true')
 + '\n    </sc-if>\n')

ALLHEAD = f'<div style="display: flex; flex-direction: column; gap: 4px"><b class="sBigT" style="font-size: 32px; letter-spacing: -0.8px">Find claims</b><span style="font-size: 14.5px; font-weight: 600; {MUT}">{{{{ pageSub }}}}</span></div>\n'

def lockcard(t, sub):
    return iff('mbLock', f'<div class="cardin" style="display: flex; flex-direction: column; gap: 12px; {DARK}"><span style="width: 52px; height: 52px; border-radius: 16px; background: rgba(61,220,151,.16); color: #3DDC97; display: inline-flex; align-items: center; justify-content: center">{svg(P["lock"], 24)}</span><b style="font-size: 20px">{t}</b><span style="font-size: 14px; font-weight: 600; color: #B7CEC4; line-height: 1.5">{sub}</span><button onClick="{{{{ joinMb }}}}" style="{MINT}; width: 100%">{{{{ joinLabelLong }}}}</button></div>')
def cardchip():
    return iff('hasCards', '<button class="sRow" onClick="{{ openCards }}" style="align-self: flex-start; display: inline-flex; align-items: center; gap: 8px; padding: 7px 12px 7px 8px; border-radius: 99px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; font-size: 13px; font-weight: 700; color: #43504A">' + '<span style="width: 24px; height: 24px; border-radius: 7px; background: #0F3B2E; color: #FFFFFF; display: inline-flex; align-items: center; justify-content: center">' + svg(P['card'], 14) + '</span>' + iff('cardChipBad', '<span class="sdot" style="color: #B8333A"></span>') + '{{ cardChipT }}' + svg(P['right'], 14) + '</button>')
def scanning(t, sub):
    return iff('plScanning', f'<div class="cardin" style="padding: 18px; border-radius: 20px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; gap: 10px"><div style="display: flex; align-items: center; gap: 10px">{SP}<b style="font-size: 15px">{t}</b></div><span style="height: 8px; border-radius: 99px; background: #EEF2F0; overflow: hidden; display: block"><span class="sBar" style="display: block; height: 100%; border-radius: 99px; background: #12805C"></span></span><span style="font-size: 13px; font-weight: 600; {MUT}">{sub}</span></div>')
def connect(flag, icon, t, checks, extra=''):
    ch = ''.join(check('<span style="color: #FFFFFF">' + c + '</span>') for c in checks)
    return iff(flag, f'<div class="cardin" style="display: flex; flex-direction: column; gap: 12px; {DARK}"><span style="width: 52px; height: 52px; border-radius: 16px; background: rgba(61,220,151,.16); color: #3DDC97; display: inline-flex; align-items: center; justify-content: center">{svg(P[icon], 24)}</span><b style="font-size: 20px">{t}</b>{ch}<button onClick="{{{{ cardGo }}}}" style="{MINT}; width: 100%">' + iff('connectBusy', SP) + '{{ connectL }}</button><span style="display: flex; gap: 7px; align-items: center; font-size: 12.5px; font-weight: 600; color: #B7CEC4">' + svg(P['shield'], 14) + '{{ plNote }}</span></div>' + extra)

REF = ('    <sc-if value="{{ isRefunds }}" hint-placeholder-val="{{ false }}">\n'
 + lockcard('Get money back from bad charges', 'Members connect a card and we find double charges, surprise fees and charges you do not know, then ask for the money back.')
 + '<sc-if value="{{ mbOk }}" hint-placeholder-val="{{ true }}">'
 + BIGN('Money you could get back', '{{ rBig }}', '{{ rBigSub }}') + cardchip()
 + scanning('Reading your charges', 'Usually under a minute. You can leave this page, we keep going.')
 + connect('rConnect', 'card', 'Find money you can get back', ['Double charges and surprise fees', 'Charges you do not know', 'Price hikes on subscriptions'], f'<button onClick="{{{{ openAdd }}}}" style="{LINKB}">+ Add a charge yourself instead</button>')
 + iff('hasTopFight', f'<section aria-label="Worth fighting" class="cardin" style="display: flex; align-items: center; gap: 14px; flex-wrap: wrap; {DARK}"><span style="width: 48px; height: 48px; flex: none; border-radius: 14px; background: #FFFFFF; color: #0F3B2E; display: inline-flex; align-items: center; justify-content: center; font-size: 20px; font-weight: 800">{{{{ tf.ini }}}}</span><span style="flex: 1; min-width: 170px; display: flex; flex-direction: column; gap: 3px">{KICK("WORTH FIGHTING")}<b style="font-size: 18px">{{{{ tf.head }}}}</b><span style="font-size: 13px; font-weight: 600; color: #B7CEC4">{{{{ tf.sub }}}}</span></span><span style="display: flex; gap: 8px"><button onClick="{{{{ tf.fight }}}}" style="{MINT}">{{{{ tf.fightL }}}}</button><button onClick="{{{{ tf.fine }}}}" style="{WDARK}">It&#39;s fine</button></span></section>')
 + iff('hasCards', '<section aria-label="Your charges" style="display: flex; flex-direction: column; gap: 8px"><div style="display: flex; align-items: center; justify-content: space-between; gap: 10px">' + H2('Your charges') + '<button onClick="{{ plSync }}" style="display: inline-flex; align-items: center; gap: 6px; background: transparent; padding: 4px; font-size: 13px; font-weight: 800; color: #12805C">' + svg(P['refresh'], 14, 2.4) + '{{ plSyncL }}</button></div>'
   + '<div class="chips" style="display: flex; gap: 6px; flex-wrap: wrap"><sc-for list="{{ chChips }}" as="c" hint-placeholder-count="3"><button onClick="{{ c.tap }}" aria-pressed="{{ c.on }}" style="{{ c.st }}">{{ c.l }}</button></sc-for></div>'
   + '<sc-for list="{{ chRows }}" as="r" hint-placeholder-count="4"><div class="sRow" style="' + ROWST + '; flex-direction: column; align-items: stretch; gap: 0"><button onClick="{{ r.tap }}" aria-expanded="{{ r.open }}" style="display: flex; align-items: center; gap: 12px; background: transparent; padding: 0; text-align: left; color: inherit">' + INI + '<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><b style="font-size: 15px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{ r.co }} <span style="color: #12805C">{{ r.amt }}</span></b><span style="font-size: 12.5px; font-weight: 600; color: #5B6862; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{ r.desc }}</span></span><span style="{{ r.pillSt }}">{{ r.pill }}</span></button>'
   + iff('r.open', '<div class="cardin" style="display: flex; flex-direction: column; gap: 10px; padding: 12px 0 2px 54px"><span style="font-size: 12.5px; font-weight: 700; color: #5B6862">{{ r.meta }}</span><sc-for list="{{ r.why }}" as="w" hint-placeholder-count="1"><span style="font-size: 13.5px; font-weight: 600; line-height: 1.45">{{ w.t }}</span></sc-for>'
     + iff('r.undecided', f'<div style="display: flex; gap: 8px; flex-wrap: wrap"><button onClick="{{{{ r.fight }}}}" style="{MINT}; min-height: 38px; font-size: 14px">{{{{ r.fightL }}}}</button><button onClick="{{{{ r.unknown }}}}" style="{SOFTB}">I don&#39;t know it</button><button onClick="{{{{ r.fine }}}}" style="{SOFTB}">It&#39;s fine</button></div>', 'true')
     + iff('r.decided', '<span style="{{ r.doneSt }}">{{ r.done }}</span>') + '</div>')
   + '</div></sc-for>' + iff('chNone', '<div style="padding: 18px; border-radius: 16px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; font-size: 14px; font-weight: 600; color: #5B6862; text-align: center">{{ chNoneT }}</div>')
   + iff('chMore', f'<button onClick="{{{{ chMoreGo }}}}" style="{SOFTB}; align-self: center">{{{{ chMoreL }}}}</button>') + '</section>')
 + iff('hasRq', '<section aria-label="In progress" style="display: flex; flex-direction: column; gap: 8px">' + H2('Requests in progress') + '<sc-for list="{{ rqList }}" as="r" hint-placeholder-count="1"><div class="sRow" style="' + ROWST + '; flex-direction: column; align-items: stretch; gap: 10px"><div style="display: flex; align-items: center; gap: 12px"><span style="width: 42px; height: 42px; flex: none; border-radius: 12px; background: #EEF2F0; display: inline-flex; align-items: center; justify-content: center; color: #0F3B2E">' + svg(P['receipt'], 19) + '</span><span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><b style="font-size: 15px">{{ r.co }} <span style="color: #12805C">{{ r.amt }}</span></b><span style="font-size: 12.5px; font-weight: 600; color: #5B6862; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{ r.what }}</span></span></div><div style="display: flex; gap: 6px"><sc-for list="{{ r.segs }}" as="g" hint-placeholder-count="3"><span style="flex: 1; display: flex; flex-direction: column; gap: 5px"><span style="{{ g.bar }}"></span><span style="{{ g.lt }}">{{ g.l }}</span></span></sc-for></div></div></sc-for></section>')
 + iff('hasCards', f'<button onClick="{{{{ openAdd }}}}" style="{LINKB}">+ Add a charge yourself</button>')
 + iff('noCardsRq', f'<button onClick="{{{{ openAdd }}}}" style="{LINKB}">+ Add another charge</button>')
 + '</sc-if>\n    </sc-if>\n')

SUBS = ('    <sc-if value="{{ isSubs }}" hint-placeholder-val="{{ false }}">\n'
 + lockcard('See every subscription in one place', 'Members get reminders before things renew, price hike alerts, and we cancel the ones you do not want.')
 + '<sc-if value="{{ mbOk }}" hint-placeholder-val="{{ true }}">'
 + BIGN('Your subscriptions', '{{ sBig }}', '{{ sBigSub }}') + cardchip()
 + scanning('Finding repeating charges', 'We need a couple of charges from the same company to spot a subscription.')
 + connect('sConnect', 'repeat', 'See every subscription in one place', ['Reminders before they renew', 'Price hike alerts', 'We cancel the ones you do not want'])
 + iff('hasRenNext', f'<section aria-label="Renewing soon" class="cardin" style="display: flex; align-items: center; gap: 14px; flex-wrap: wrap; {DARK}"><span style="width: 48px; height: 48px; flex: none; border-radius: 14px; background: #FFFFFF; color: #0F3B2E; display: inline-flex; align-items: center; justify-content: center; font-size: 20px; font-weight: 800">{{{{ rn.ini }}}}</span><span style="flex: 1; min-width: 170px; display: flex; flex-direction: column; gap: 3px">{KICK("{{ rn.kick }}")}<b style="font-size: 18px">{{{{ rn.head }}}}</b><span style="font-size: 13px; font-weight: 600; color: #B7CEC4">Still using it? We can cancel it for you.</span></span><span style="display: flex; gap: 8px"><button onClick="{{{{ rn.cancel }}}}" style="{MINT}">{{{{ rn.cancelL }}}}</button><button onClick="{{{{ rn.keep }}}}" style="{WDARK}">Keep</button></span></section>')
 + iff('hasCards', '<section aria-label="All subscriptions" style="display: flex; flex-direction: column; gap: 8px">' + H2('All subscriptions')
   + '<sc-for list="{{ subRows }}" as="r" hint-placeholder-count="4"><div class="sRow subRow" style="' + ROWST + '">' + INI + '<span class="subT" style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><b style="font-size: 15px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{ r.co }} <span style="color: #12805C">{{ r.amt }}</span> <span style="font-size: 12.5px; font-weight: 700; color: #8A968F">{{ r.per }}</span></b><span style="font-size: 12.5px; font-weight: 600; color: #5B6862; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{ r.sub }}</span></span>'
   + iff('r.undecided', f'<span class="subA" style="display: flex; gap: 6px; flex: none"><button onClick="{{{{ r.cancel }}}}" style="{SOFTB}">{{{{ r.cancelL }}}}</button><button onClick="{{{{ r.keep }}}}" style="{SOFTB}; background: transparent; color: #12805C">Keep</button></span>', 'true')
   + iff('r.decided', '<span style="{{ r.doneSt }}">{{ r.done }}</span>') + '</div></sc-for>'
   + iff('subNone', '<div style="padding: 18px; border-radius: 16px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; font-size: 14px; font-weight: 600; color: #5B6862; text-align: center">{{ subNoneT }}</div>') + '</section>')
 + '</sc-if>\n    </sc-if>\n')

# ---------- popups: Your info, Settings, Your cards, Add a charge ----------
FIELD = 'height: 48px; border-radius: 14px; border: 1.5px solid #DDE5E0; padding: 0 14px; font-size: 15.5px; font-family: inherit; font-weight: 700; color: #0A0F0D; background: #FFFFFF; box-sizing: border-box; width: 100%'
def lab(t, inp): return f'<label style="display: flex; flex-direction: column; gap: 6px; font-size: 13px; font-weight: 800; color: #43504A">{t}{inp}</label>'
CARDS_POP = iff('isCardsPop', '<div style="display: flex; flex-direction: column; gap: 10px">'
  + '<sc-for list="{{ cards }}" as="c" hint-placeholder-count="1"><div style="padding: 14px; border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; gap: 10px"><div style="display: flex; align-items: center; gap: 12px"><span style="width: 40px; height: 40px; flex: none; border-radius: 12px; background: #0F3B2E; color: #FFFFFF; display: inline-flex; align-items: center; justify-content: center">' + svg(P['card'], 19) + '</span><span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><b style="font-size: 15px">{{ c.n }}</b><span style="{{ c.subSt }}">{{ c.sub }}</span></span>'
  + iff('c.bad', '<span style="display: inline-flex; align-items: center; gap: 6px; font-size: 12.5px; font-weight: 800; padding: 5px 10px; border-radius: 99px; background: #FDECEC; color: #B8333A"><span class="sdot"></span>Sign in again</span>')
  + '</div><div style="display: flex; gap: 8px">' + iff('c.bad', '<button onClick="{{ c.fix }}" style="min-height: 38px; padding: 0 16px; border-radius: 99px; background: #0A0F0D; color: #FFFFFF; font-size: 14px; font-weight: 800">Fix connection</button>') + '<button onClick="{{ c.rm }}" aria-label="{{ c.rmAria }}" style="{{ c.rmSt }}">{{ c.rmL }}</button></div></div></sc-for>'
  + f'<button onClick="{{{{ cardAdd }}}}" style="{SOFTB}; min-height: 48px; width: 100%">' + svg(P['plus'], 16, 2.4) + '{{ cardAddL }}</button>'
  + '<span style="display: flex; gap: 7px; align-items: center; font-size: 12.5px; font-weight: 600; color: #5B6862">' + svg(P['shield'], 14) + 'Read only through Plaid. We can never move money. Remove deletes the data.</span>'
  + iff('plTest', '<span style="font-size: 12px; font-weight: 700; color: #8A5A00">Test connection (Plaid Sandbox)</span>') + '</div>')
ADD_POP = iff('isAddPop', '<div style="display: flex; flex-direction: column; gap: 14px"><span style="font-size: 14px; font-weight: 600; color: #5B6862; line-height: 1.5">A charge we did not catch? Tell us and we ask for it back.</span>'
  + lab('Company', f'<input type="text" value="{{{{ rqCo }}}}" onChange="{{{{ onRqCo }}}}" placeholder="Who charged you" autocomplete="off" style="{FIELD}">')
  + lab('Amount (optional)', f'<input type="text" inputmode="decimal" value="{{{{ rqAmt }}}}" onChange="{{{{ onRqAmt }}}}" placeholder="$0.00" style="{FIELD}">')
  + lab('What happened?', '<textarea value="{{ rqWhat }}" onChange="{{ onRqWhat }}" rows="3" maxlength="1000" placeholder="Charged twice, a fee I did not agree to, charged after I cancelled..." style="border-radius: 14px; border: 1.5px solid #DDE5E0; padding: 12px 14px; font-size: 15px; font-family: inherit; font-weight: 600; color: #0A0F0D; background: #FFFFFF; box-sizing: border-box; width: 100%; resize: vertical"></textarea>')
  + iff('hasRqErr', '<span role="alert" style="font-size: 13px; font-weight: 700; color: #B8333A">{{ rqErr }}</span>')
  + f'<button onClick="{{{{ addCharge }}}}" style="{MINT}; min-height: 52px; width: 100%">' + iff('rqBusy', SP) + 'Ask for it back</button></div>')

# Paywall (Nov 21 2026): Standard (or Fast, for local claims) taps Upgrade on a claim outside their plan.
PAY_POP = iff('isPayPop', '<div style="display: flex; flex-direction: column; gap: 14px">'
  + '<div style="display: flex; align-items: center; gap: 12px; padding: 14px; border-radius: 18px; background: #F3F6F4"><img src="{{ pw.logo }}" alt="" style="width: 48px; height: 48px; flex: none; border-radius: 13px; background: #FFFFFF; padding: 7px; box-sizing: border-box; object-fit: contain; box-shadow: inset 0 0 0 1px #E3EAE6"><span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><b style="font-size: 17px">{{ pw.co }} <span style="color: #12805C">{{ pw.amt }}</span></b><span style="font-size: 13px; font-weight: 600; color: #5B6862">{{ pw.dl }}</span></span>'
  + '<span style="display: inline-flex; align-items: center; gap: 5px; flex: none; font-size: 12px; font-weight: 800; padding: 5px 10px; border-radius: 99px; background: #FFF4DB; color: #8A5A00">' + svg(P['lock'], 12, 2.6) + '{{ pw.tag }}</span></div>'
  + '<span style="font-size: 14.5px; font-weight: 600; color: #43504A; line-height: 1.5">{{ pw.why }}</span>'
  + '<div role="radiogroup" style="display: flex; flex-direction: column; gap: 10px"><sc-for list="{{ pw.plans }}" as="o" hint-placeholder-count="2"><button role="radio" aria-checked="{{ o.on }}" onClick="{{ o.pick }}" style="{{ o.st }}">'
  + '<span style="{{ o.blk }}"><b style="font-size: 20px; line-height: 1">{{ o.num }}</b><span style="font-size: 9.5px; font-weight: 800; letter-spacing: .8px">{{ o.unit }}</span></span>'
  + '<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 6px; text-align: left"><span style="display: flex; align-items: center; gap: 8px"><b style="font-size: 16px">{{ o.name }}</b><span style="flex: 1"></span><b style="font-size: 17px; letter-spacing: -.4px">{{ o.price }}</b><span style="{{ o.radio }}">' + iff('o.on', svg(P['check'], 12, 3.4)) + '</span></span>'
  + '<sc-for list="{{ o.fl }}" as="f" hint-placeholder-count="3"><span style="{{ o.flSt }}">' + svg(P['check'], 13, 3) + '<span style="color: #0A0F0D">{{ f }}</span></span></sc-for></span></button></sc-for></div>'
  + f'<button onClick="{{{{ pw.go }}}}" style="{MINT}; min-height: 54px; width: 100%; font-size: 16px">' + iff('pw.busy', SP) + '{{ pw.cta }}</button>'
  + '<span style="font-size: 12.5px; font-weight: 600; color: #5B6862; text-align: center; line-height: 1.45">{{ pw.fine }}</span>'
  + f'<button onClick="{{{{ closePop }}}}" style="{LINKB}; align-self: center">{{{{ pw.keep }}}}</button></div>')

def pop(info_set):
    return ('  <sc-if value="{{ popOpen }}" hint-placeholder-val="{{ false }}"><div class="popWrap" style="position: absolute; inset: 0; z-index: 38; background: rgba(10,15,13,.45); display: flex; align-items: center; justify-content: center; animation: shFade .2s ease both">'
            + '<button onClick="{{ closePop }}" aria-label="Close" tabindex="-1" style="position: absolute; inset: 0; background: transparent; cursor: default"></button>'
            + '<div class="popCard" role="dialog" aria-modal="true" aria-label="{{ popTitle }}" style="{{ popCardSt }}"><div class="popGrab" style="display: none; align-self: center; width: 40px; height: 5px; border-radius: 99px; background: #DDE5E0; margin-top: 10px"></div>'
            + '<div style="display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 20px 24px 12px"><h2 style="margin: 0; font-size: 22px; letter-spacing: -0.4px">{{ popTitle }}</h2><button onClick="{{ closePop }}" aria-label="Close" style="width: 34px; height: 34px; flex: none; border-radius: 99px; background: #EEF2F0; color: #0A0F0D; display: flex; align-items: center; justify-content: center">' + svg(P['x'], 16, 2.6) + '</button></div>'
            + '<div class="scroll popBody" style="flex: 1 1 auto; min-height: 0; overflow-y: auto; padding: 4px 24px 24px; display: flex; flex-direction: column; gap: 14px">' + info_set + CARDS_POP + ADD_POP + PAY_POP + '</div></div></div></sc-if>\n')

HELP = '<a href="mailto:support@mail.claimclub.io" style="width: 100%; display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 12px; background: transparent; color: #26302B; font-size: 14px; font-weight: 700; text-decoration: none; box-sizing: border-box">' + svg(P['help'], 18) + '<span style="flex: 1">Help</span></a>'

CSS = r'''
.sroot{flex-direction:column!important}
.zwrap{max-width:720px;width:100%;margin:0 auto!important;gap:20px!important}
.sRow{transition:box-shadow .15s ease,transform .15s ease}
@media (hover:hover){.sRow:hover{box-shadow:inset 0 0 0 1.5px #12805C,0 8px 20px rgba(10,15,13,.08)!important;transform:translateY(-1px)}.tabB:hover{background:#F1F5F3!important}}
.tabB{transition:background .15s ease,color .15s ease}
.sdot{width:7px;height:7px;border-radius:99px;background:currentColor;display:inline-block;flex:none;animation:sPl 1.6s ease-out infinite}
@keyframes sPl{0%{box-shadow:0 0 0 0 currentColor}70%{box-shadow:0 0 0 7px transparent}100%{box-shadow:0 0 0 0 transparent}}
.sShine{position:relative;overflow:hidden}.sShine::after{content:"";position:absolute;inset:0;background:linear-gradient(100deg,transparent 30%,rgba(255,255,255,.5) 50%,transparent 70%);transform:translateX(-120%);animation:sSh 2.8s ease-in-out infinite}
@keyframes sSh{0%,55%{transform:translateX(-120%)}100%{transform:translateX(120%)}}
.sBar{animation:sBr 2.2s ease-in-out infinite}@keyframes sBr{0%{width:8%}60%{width:78%}100%{width:92%}}
.sPop{animation:sPp .45s cubic-bezier(.3,1.6,.6,1) both}@keyframes sPp{0%{transform:scale(.4);opacity:0}100%{transform:none;opacity:1}}
.popCard{position:relative;max-width:calc(100% - 32px);max-height:calc(100% - 48px);display:flex;flex-direction:column;background:#FFFFFF;border-radius:26px;box-shadow:0 30px 80px rgba(0,0,0,.3);overflow:hidden;animation:shPop .26s cubic-bezier(.2,.9,.3,1.1) both}
.dk .popCard{background:#151D1A}
.sHid{position:absolute!important;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
@media (prefers-reduced-motion:reduce){.sdot,.sShine::after,.sBar,.sPop,.popCard{animation:none!important}.sRow,.tabB{transition:none!important}}
'''
M_CSS = r'''
.zwrap{max-width:none}.sBigN{font-size:42px!important}
.sroot{height:100vh!important;min-height:0!important}@supports (height:100dvh){.sroot{height:100dvh!important}}
.sroot>nav{padding-bottom:calc(14px + env(safe-area-inset-bottom,0px))!important}
.popWrap{align-items:flex-end!important}
.popCard{width:100%!important;max-width:100%!important;max-height:92%!important;border-radius:26px 26px 0 0!important;animation:sSu .32s cubic-bezier(.2,.9,.3,1) both!important}
.popGrab{display:block!important}
@keyframes sSu{0%{transform:translateY(60px);opacity:.4}100%{transform:none;opacity:1}}
.popBody{padding:4px 18px 28px!important}
.subRow{flex-wrap:wrap}.subT{flex:1 1 calc(100% - 60px)!important}.subA{margin-left:54px}
.shWrap{align-items:flex-end!important}.shCard{width:100%!important;max-width:100%!important;max-height:92%!important;border-radius:26px 26px 0 0!important;animation:sSu .32s cubic-bezier(.2,.9,.3,1) both!important}
@media (prefers-reduced-motion:reduce){.popCard{animation:none!important}}
'''

JS = r'''
  simpleVals(all, ready, track) {
    const s = this.state, member = !!s.plan;
    const m0 = (n) => '$' + Math.round(n || 0).toLocaleString('en-US');
    const live = all.filter(r => r.st !== 'gone' && r.st !== 'denied');
    const tot = live.filter(r => r.st !== 'paid').reduce((t, r) => t + (r.mx || r.n || 0), 0);
    const paid = live.filter(r => r.st === 'paid').reduce((t, r) => t + (r.n || 0), 0);
    const nx = ready.filter(r => r.days > 0)[0] || ready[0] || null;
    const dleft = (r) => r.days > 0 ? 'Closes in ' + r.days + (r.days === 1 ? ' day' : ' days') : 'Ready to file';
    const CH = { ready: ['Ready to file', '#E3F6EC', '#12805C', 0], auto: ['Pays automatically', '#E3F4FB', '#0B5E86', 0], self: ['You file it', '#EDE9FB', '#4B33B5', 0], requested: ['Filing', '#EEF2F0', '#43504A', 1], needs_info: ['Action needed', '#FDECEC', '#B8333A', 1], filed: ['Filed', '#E8EEFB', '#2C4FA8', 1], review: ['In review', '#FFF4DB', '#8A5A00', 1], approved: ['Approved', '#E3F6EC', '#12805C', 0], paid: ['Paid', '#12805C', '#FFFFFF', 0], denied: ['Not approved', '#EEEEEE', '#6B6B6B', 0] };
    const ORD = { needs_info: 0, ready: 1, self: 2, requested: 3, filed: 4, review: 5, approved: 6, auto: 7, paid: 8, denied: 9 };
    const rows = all.filter(r => r !== nx).slice().sort((a, b) => ((ORD[a.st] ?? 5) - (ORD[b.st] ?? 5)) || ((a.days || 999) - (b.days || 999))).map(r => { const c = CH[r.st] || CH.ready;
      return Object.assign({}, r, { amtS: r.amt || '', subS: r.isReady ? dleft(r) : (r.next || r.stLabel || ''), subSt: 'font-size:12.5px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:' + (r.isReady && r.urgent ? '#B8333A' : '#5B6862'),
        showChip: !r.isReady && !r.isNeeds, chipT: r.st === 'paid' && r.amt ? 'Paid ' + r.amt : c[0], dot: !!c[3],
        chipSt: 'display:inline-flex;align-items:center;gap:7px;flex:none;font-size:12.5px;font-weight:800;padding:6px 12px;border-radius:99px;white-space:nowrap;background:' + c[1] + ';color:' + c[2], cls: (s.just === r.id ? 'just ' : '') + (r.st === 'paid' ? 'paidRow' : '') }); });
    const steps = this.setup(), left = steps.filter(x => !s.acct[x.id]).length;
    const tab = (on) => 'display:inline-flex;align-items:center;gap:7px;padding:9px 16px;border-radius:99px;font-size:14px;font-weight:800;white-space:nowrap;' + (on ? 'background:#E9F6EF;color:#12805C' : 'background:transparent;color:#43504A');
    const v = s.view === 'home' ? 'dash' : s.view;
    return {
      sTotal: tot ? 'Up to ' + m0(tot) : paid ? m0(paid) + ' paid' : '$0 so far',
      sTotalSub: live.length ? 'from ' + live.length + (live.length === 1 ? ' claim' : ' claims') + (paid ? ' · ' + m0(paid) + ' paid so far' : '') : 'No claims yet',
      hasNx: !!nx, nx: nx ? Object.assign({}, nx, { head: 'File your ' + nx.co + ' claim', sub: dleft(nx) + (ready.length > 1 ? ' · ' + (ready.length - 1) + ' more ready' : '') }) : { logo: '', co: '', head: '', sub: '', busy: false, idle: true, file: () => {} },
      sCaught: !nx && live.length > 0, sNewbie: !all.length, sRowsC: rows, sHasRows: rows.length > 0,
      sSetup: left > 0 && all.length > 0 && s.authState !== 'off', sSetupSub: left + (left === 1 ? ' step' : ' steps') + ' left so we can file for you faster', setupGo: () => this.goInfo(),
      tabDash: tab(v === 'dash'), tabAll: tab(v === 'all'), tabRefunds: tab(v === 'refunds'), tabSubs: tab(v === 'subs'),
      popOpen: !!s.pop, isInfo: s.pop === 'info', isSet: s.pop === 'settings', isCardsPop: s.pop === 'cards', isAddPop: s.pop === 'add',
      popTitle: { info: 'Your info', settings: 'Settings', cards: 'Your cards', add: 'Add a charge' }[s.pop] || '',
      popCardSt: 'width:' + (s.pop === 'info' ? 920 : 540) + 'px',
      closePop: () => this.setState({ pop: '' }), openCards: () => this.setState({ pop: 'cards', pm: false }), openAdd: () => this.setState({ pop: 'add', rqErr: '', pm: false })
    };
  }
'''

# Delete account link in the account menu (needed for Google Play). Lucide trash-2.
P['trash2'] = 'M3 6h18 M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6 M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2 M10 11v6 M14 11v6'
DELACC = '<a href="/delete-account" style="width: 100%; display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 12px; background: transparent; color: #5B6862; font-size: 14px; font-weight: 700; text-decoration: none; box-sizing: border-box">' + svg(P['trash2'], 18) + '<span style="flex: 1">Delete account</span></a>'
