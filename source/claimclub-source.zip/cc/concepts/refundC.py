# Start design for "Refund Club" (Nov 14): its own lander with the new center nav (Claim money | Refund Club) and a Refunds page in the member dashboard.
# Boards RefundL.dc.html (lander, desktop 1440 + mobile 390) and RefundD.dc.html (dashboard Refunds page, desktop 1440 + mobile 390). Not live.
import json, os, sys, base64
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from how4 import iphone, ic, IC, LOGO, HEAD, JS, OUT

MINT, DARK, GREEN = '#3DDC97', '#0F3B2E', '#12805C'
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
def logo(p):
    b = open(os.path.join(ROOT, p), 'rb').read(); t = 'image/svg+xml' if p.endswith('.svg') else 'image/png'
    return f'data:{t};base64,' + base64.b64encode(b).decode()
IC.update({
    'repeat': '<path d="m17 2 4 4-4 4"></path><path d="M3 11v-1a4 4 0 0 1 4-4h14"></path><path d="m7 22-4-4 4-4"></path><path d="M21 13v1a4 4 0 0 1-4 4H3"></path>',
    'hourglass': '<path d="M5 22h14"></path><path d="M5 2h14"></path><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"></path><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"></path>',
    'copy': '<rect width="14" height="14" x="8" y="8" rx="2" ry="2"></rect><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"></path>',
    'ban': '<circle cx="12" cy="12" r="10"></circle><path d="m4.9 4.9 14.2 14.2"></path>',
    'tag': '<path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"></path><circle cx="7.5" cy="7.5" r=".5" fill="currentColor"></circle>',
    'truck': '<path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"></path><path d="M15 18H9"></path><path d="M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14"></path><circle cx="17" cy="18" r="2"></circle><circle cx="7" cy="18" r="2"></circle>',
    'plane': '<path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z"></path>',
    'landmark': '<line x1="3" x2="21" y1="22" y2="22"></line><line x1="6" x2="6" y1="18" y2="11"></line><line x1="10" x2="10" y1="18" y2="11"></line><line x1="14" x2="14" y1="18" y2="11"></line><line x1="18" x2="18" y1="18" y2="11"></line><polygon points="12 2 20 7 4 7"></polygon>',
    'link': '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>',
    'receipt': '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"></path><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"></path><path d="M12 17.5v-11"></path>',
    'plus': '<path d="M5 12h14"></path><path d="M12 5v14"></path>',
    'grid': '<path d="M3 3h7v9H3z M14 3h7v5h-7z M14 12h7v9h-7z M3 16h7v5H3z"></path>',
    'list': '<path d="M8 6h13 M8 12h13 M8 18h13 M3 6h.01 M3 12h.01 M3 18h.01"></path>',
    'user': '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle>',
    'hand': '<path d="M18 11V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2"></path><path d="M14 10V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2"></path><path d="M10 10.5V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2v8"></path><path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15"></path>',
})
brand = lambda s=28, c='#FFFFFF': (f'<span style="display: flex; align-items: center; gap: 8px">{LOGO.format(s=s, c=c)}'
    f'<span style="font-size: {round(s * .7)}px; font-weight: 800; letter-spacing: -0.4px; color: {c}">claim<span style="font-weight: 500">club</span><span style="font-size: .72em; font-weight: 600; color: {MINT if c == "#FFFFFF" else GREEN}; margin-left: -0.06em">.io</span></span></span>')
MESH = 'background: radial-gradient(120% 90% at 100% 0%, #2A9B70 0%, rgba(42,155,112,0) 55%), radial-gradient(120% 120% at 0% 100%, #06261C 0%, rgba(6,38,28,0) 60%), linear-gradient(165deg, #17563F 0%, #0F3B2E 50%, #0A2C22 100%)'

# ---------- the new center nav (shared by the homepage and Refund Club) ----------
def tabs(active, m=False):
    t = lambda name, on: (f'<span style="display: flex; align-items: center; justify-content: center; gap: 6px; {"flex: 1;" if m else ""} min-height: {36 if m else 40}px; padding: 0 {14 if m else 18}px; border-radius: 99px; font-size: {13.5 if m else 15}px; font-weight: 800; white-space: nowrap; '
                          + (f'background: #FFFFFF; color: {DARK}; box-shadow: 0 4px 12px rgba(0,0,0,.18)' if on else 'color: rgba(255,255,255,.85)') + f'">{name}</span>')
    return (f'<nav aria-label="Products" style="display: flex; gap: 4px; padding: 4px; border-radius: 99px; background: rgba(255,255,255,.12); box-shadow: inset 0 0 0 1px rgba(255,255,255,.16); {"width: 100%; box-sizing: border-box" if m else ""}">'
            + t('Claim money', active == 'claim') + t('Refund Club', active == 'refund') + '</nav>')
def navbar(active, m=False):
    right = (f'<span style="display: flex; align-items: center; gap: {10 if m else 18}px"><span style="font-size: {14 if m else 15}px; font-weight: 700; color: #FFFFFF">Log in</span>'
             f'<span style="min-height: {38 if m else 42}px; padding: 0 {14 if m else 18}px; border-radius: 99px; background: {MINT}; color: {DARK}; font-size: {14 if m else 15}px; font-weight: 800; display: flex; align-items: center">Get started</span></span>')
    if m:
        return f'<header style="display: flex; flex-direction: column; gap: 12px; padding: 14px 16px 0"><div style="display: flex; align-items: center; justify-content: space-between">{brand(24)}{right}</div>{tabs(active, True)}</header>'
    return f'<header style="display: grid; grid-template-columns: 1fr auto 1fr; align-items: center; padding: 22px 40px"><span>{brand(28)}</span>{tabs(active)}<span style="justify-self: end">{right}</span></header>'

# ---------- phone screen: refunds found ----------
FOUND = [('netflix', 'logos2/netflix.svg', 'Netflix', 'Charged after you canceled', '$47.97'),
         ('gym', None, 'City Fitness', 'Hard-to-cancel membership', '$39.99'),
         ('amazon', 'logos/amazon.svg', 'Amazon', 'Duplicate charge', '$32.18'),
         ('ubereats', 'logos2/ubereats.png', 'Uber Eats', 'Order never arrived', '$24.60'),
         ('disney', 'logos2/disney.png', 'Disney+', 'Free trial turned paid', '$13.99')]
def mark(src, name, icon='hand', s=40):
    if src: return f'<img src="{logo(src)}" alt="" style="width: {s}px; height: {s}px; flex: none; border-radius: {round(s * .28)}px; background: #FFFFFF; padding: {round(s * .16)}px; box-sizing: border-box; object-fit: contain; box-shadow: inset 0 0 0 1px #E3EAE6">'
    return f'<span style="width: {s}px; height: {s}px; flex: none; border-radius: {round(s * .28)}px; background: #E9F6EF; color: {GREEN}; display: flex; align-items: center; justify-content: center">{ic(icon, round(s * .5), 2.2)}</span>'
def scr_found(n=4):
    rows = ''.join(f'<div style="display: flex; align-items: center; gap: 9px; padding: 9px; border-radius: 14px; background: #FFFFFF; box-shadow: 0 1px 2px rgba(10,15,13,.05)">{mark(src, nm, "hand", 34)}'
                   f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column"><b style="font-size: 13px">{nm}</b><span style="font-size: 10.5px; color: #5B6862; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{why}</span></span>'
                   f'<b style="font-size: 13px; color: {GREEN}">{amt}</b></div>' for k, src, nm, why, amt in FOUND[:n])
    return ('<div style="display: flex; flex-direction: column; height: 100%; padding: 12px 0 10px; box-sizing: border-box; gap: 10px">'
            '<span style="font-size: 11px; font-weight: 800; letter-spacing: 1px; color: #5B6862; text-align: center">REFUNDS WE FOUND</span>'
            f'<span style="font-size: 38px; font-weight: 800; letter-spacing: -1.5px; color: {GREEN}; text-align: center; line-height: 1">$158.73</span>'
            '<span style="font-size: 11.5px; color: #5B6862; font-weight: 700; text-align: center; margin-top: -4px">from 5 charges in the last 90 days</span>'
            f'<div style="display: flex; flex-direction: column; gap: 6px">{rows}</div>'
            f'<span style="margin-top: auto; min-height: 42px; border-radius: 99px; background: {DARK}; color: #FFFFFF; font-size: 14px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 6px">Fight all 5{ic("arrow", 16, 2.4)}</span></div>')

KINDS = [('repeat', 'Forgotten subscriptions', 'Charges for apps and services you stopped using.'),
         ('hourglass', 'Free trials that turned paid', 'The trial ended and the charges started.'),
         ('copy', 'Duplicate charges', 'Billed twice for the same thing.'),
         ('ban', 'Hard-to-cancel memberships', 'Gyms and plans that make leaving hard. We cancel for you.'),
         ('tag', 'Price drops after you buy', 'Stores with price protection owe you the difference.'),
         ('truck', 'Late or missing orders', 'Deliveries that never showed up or came broken.'),
         ('plane', 'Travel fees', 'Canceled flights, bag fees and hotel resort fees.'),
         ('landmark', 'Bank fees', 'Overdraft and surprise account fees you can ask back.')]
STEPS = [('link', 'Connect a card or add a charge', 'Link your bank to scan your charges, or tell us about one charge yourself.'),
         ('search', 'We spot what you can get back', 'We flag charges that qualify for a refund, cancellation or credit.'),
         ('hand', 'We fight it for you', 'You approve each one. We cancel, write to the company and follow up until it is settled.')]
CONTROL = [('check', 'You approve every request', 'Nothing is sent until you say yes.'),
           ('shield', 'Read-only access', 'We can see charges. We can never move your money.'),
           ('ban', 'Cancel anytime', 'One tap in Settings. No calls.')]

def lander(m):
    pad = 16 if m else 40
    hero_txt = (f'<div style="display: flex; flex-direction: column; gap: {14 if m else 22}px; {"align-items: center; text-align: center" if m else "max-width: 600px"}">'
                f'<span style="display: inline-flex; align-items: center; gap: 8px; align-self: {"center" if m else "flex-start"}; padding: 6px 12px 6px 6px; border-radius: 99px; background: rgba(255,255,255,.12); font-size: 13px; font-weight: 800; color: #FFFFFF"><span style="padding: 3px 9px; border-radius: 99px; background: {MINT}; color: {DARK}">New</span>Refund Club</span>'
                f'<h1 style="margin: 0; font-size: {38 if m else 62}px; line-height: 1.02; font-weight: 800; letter-spacing: -0.045em; color: #FFFFFF">Charges you never wanted.<span style="display: block; margin-top: 0.2em; font-family: \'Instrument Serif\', serif; font-style: italic; font-weight: 400; letter-spacing: -0.02em; color: {MINT}">We get your money back.</span></h1>'
                + ('' if m else '<p style="margin: 0; font-size: 18px; line-height: 1.6; color: #CFE5DA; max-width: 520px">Refund Club finds forgotten subscriptions, double charges and fees you can get back. Then we cancel and ask for the refund for you.</p>') +
                f'<div style="display: flex; {"flex-direction: column; width: 100%" if m else ""}; gap: 12px"><span style="min-height: 56px; padding: 0 28px; border-radius: 99px; background: #FFFFFF; color: {DARK}; font-size: 17px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px">Find my refunds{ic("arrow", 18, 2.4)}</span>'
                f'<span style="min-height: 56px; padding: 0 24px; border-radius: 99px; box-shadow: inset 0 0 0 1.5px rgba(255,255,255,.4); color: #FFFFFF; font-size: 16px; font-weight: 700; display: flex; align-items: center; justify-content: center">See what we can get back</span></div></div>')
    phone = f'<div style="{"zoom: .78; margin-bottom: -40px" if m else ""}; display: flex; justify-content: center">{iphone(scr_found(5 if not m else 4), 300, "#F3F6F4")}</div>'
    hero = (f'<section style="{MESH}; {"" if m else "border-radius: 0"}; overflow: hidden">{navbar("refund", m)}'
            f'<div style="max-width: 1440px; margin: 0 auto; padding: {28 if m else 40}px {pad}px 0; display: flex; {"flex-direction: column; gap: 26px" if m else "align-items: flex-start; justify-content: space-between; gap: 40px"}">{hero_txt}'
            f'<div style="{"" if m else "align-self: flex-end; margin-bottom: -130px"}">{phone}</div></div></section>')
    tile = lambda k, t, d: (f'<div style="display: flex; flex-direction: column; gap: 10px; padding: {18 if m else 22}px; border-radius: 22px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6">'
                            f'<span style="width: 44px; height: 44px; border-radius: 14px; background: #E9F6EF; color: {GREEN}; display: flex; align-items: center; justify-content: center">{ic(k, 22, 2.2)}</span>'
                            f'<b style="font-size: {16 if m else 17}px; letter-spacing: -.3px">{t}</b><span style="font-size: 14px; line-height: 1.5; color: #5B6862">{d}</span></div>')
    kinds = (f'<section style="padding: {48 if m else 80}px {pad}px {40 if m else 80}px; background: #F3F6F4"><div style="max-width: 1240px; margin: 0 auto; display: flex; flex-direction: column; gap: {20 if m else 32}px">'
             f'<h2 style="margin: 0; font-size: {30 if m else 46}px; letter-spacing: -1.4px; line-height: 1.08; color: {DARK}">What we can get back</h2>'
             f'<div style="display: grid; grid-template-columns: repeat({2 if m else 4}, minmax(0, 1fr)); gap: {10 if m else 16}px">' + ''.join(tile(*x) for x in KINDS) + '</div></div></section>')
    step = lambda i, k, t, d: (f'<div style="flex: 1 1 0; display: flex; flex-direction: column; gap: 12px; padding: 24px; border-radius: 24px; background: rgba(255,255,255,.07); box-shadow: inset 0 0 0 1px rgba(255,255,255,.12)">'
                               f'<span style="display: flex; align-items: center; gap: 10px"><span style="width: 32px; height: 32px; border-radius: 50%; background: {MINT}; color: {DARK}; font-weight: 800; display: flex; align-items: center; justify-content: center">{i + 1}</span>{ic(k, 22, 2.2, MINT)}</span>'
                               f'<b style="font-size: 20px; letter-spacing: -.4px; color: #FFFFFF">{t}</b><span style="font-size: 15px; line-height: 1.55; color: #C9D6CF">{d}</span></div>')
    how = (f'<section style="{MESH}; padding: {48 if m else 88}px {pad}px"><div style="max-width: 1240px; margin: 0 auto; display: flex; flex-direction: column; gap: {22 if m else 36}px">'
           f'<h2 style="margin: 0; font-size: {30 if m else 46}px; letter-spacing: -1.4px; color: #FFFFFF; text-align: center">How Refund Club works</h2>'
           f'<div style="display: flex; {"flex-direction: column" if m else ""}; gap: 14px">' + ''.join(step(i, *x) for i, x in enumerate(STEPS)) + '</div></div></section>')
    ctl = lambda k, t, d: (f'<div style="flex: 1 1 0; display: flex; gap: 12px; align-items: flex-start"><span style="width: 36px; height: 36px; flex: none; border-radius: 50%; background: #E9F6EF; color: {GREEN}; display: flex; align-items: center; justify-content: center">{ic(k, 18, 2.4)}</span>'
                           f'<span style="display: flex; flex-direction: column; gap: 4px"><b style="font-size: 16px">{t}</b><span style="font-size: 14px; color: #5B6862; line-height: 1.5">{d}</span></span></div>')
    control = (f'<section style="padding: {44 if m else 80}px {pad}px; background: #FFFFFF"><div style="max-width: 1240px; margin: 0 auto; display: flex; flex-direction: column; gap: 24px">'
               f'<h2 style="margin: 0; font-size: {30 if m else 40}px; letter-spacing: -1.2px; color: {DARK}">You stay in control</h2>'
               f'<div style="display: flex; {"flex-direction: column" if m else ""}; gap: 22px">' + ''.join(ctl(*x) for x in CONTROL) + '</div></div></section>')
    cta = (f'<section style="padding: 0 {pad}px {48 if m else 90}px; background: #FFFFFF"><div style="max-width: 1240px; margin: 0 auto; border-radius: 30px; padding: {30 if m else 52}px; box-sizing: border-box; background: {DARK}; color: #FFFFFF; display: flex; {"flex-direction: column; gap: 18px" if m else "align-items: center; justify-content: space-between; gap: 30px"}">'
           f'<span style="display: flex; flex-direction: column; gap: 8px"><b style="font-size: {26 if m else 34}px; letter-spacing: -1px; line-height: 1.1">Included with Claimclub membership.</b><span style="font-size: 15px; color: #C9D6CF">Already a member? Refund Club is waiting in your dashboard.</span></span>'
           f'<span style="min-height: 56px; padding: 0 28px; border-radius: 99px; background: {MINT}; color: {DARK}; font-size: 17px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px; white-space: nowrap">Find my refunds{ic("arrow", 18, 2.4)}</span></div></section>')
    return f'<div style="font-family: Manrope, sans-serif; color: #0A0F0D">{hero}{kinds}{how}{control}{cta}</div>'

# ---------- dashboard: Refunds page ----------
PROG = [('logos2/myfitnesspal.png', 'MyFitnessPal', 'Premium renewal after cancel', '$79.99', 1), ('logos2/seatgeek.png', 'SeatGeek', 'Fees on a canceled event', '$41.20', 2), ('logos/starbucks.svg', 'Starbucks', 'Charged twice', '$6.45', 3)]
STAGES = ['Requested', 'Company replied', 'Refunded']
def dash(m):
    tile = lambda t, v, sub, c='#0A0F0D': f'<div style="flex: 1 1 0; min-width: 0; padding: 14px 16px; border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; gap: 2px"><span style="font-size: 12px; font-weight: 800; color: #5B6862">{t}</span><b style="font-size: {22 if m else 26}px; letter-spacing: -.6px; color: {c}">{v}</b><span style="font-size: 12px; color: #8A968F; font-weight: 600">{sub}</span></div>'
    tiles = f'<div style="display: flex; gap: 10px; {"flex-wrap: wrap" if m else ""}">{tile("Found", "$158.73", "5 charges")}{tile("In progress", "$127.64", "3 requests", "#2C4FA8")}{tile("Refunded", "$6.45", "1 so far", GREEN)}</div>'
    row = lambda src, nm, why, amt: (f'<div style="display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: 16px; background: #FFFFFF">{mark(src, nm, "hand", 40)}'
        f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column"><b style="font-size: 15px">{nm} <span style="color: {GREEN}">{amt}</span></b><span style="font-size: 12.5px; color: #5B6862; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{why}</span></span>'
        + ('' if m else '<span style="font-size: 12px; font-weight: 800; color: #5B6862; padding: 4px 9px; border-radius: 99px; background: #EEF2F0; white-space: nowrap">Not now</span>') +
        f'<span style="min-height: 38px; padding: 0 16px; border-radius: 99px; background: {MINT}; color: {DARK}; font-size: 14px; font-weight: 800; display: flex; align-items: center; white-space: nowrap">Fight it</span></div>')
    found = (f'<div style="border-radius: 24px; background: {DARK}; padding: 14px; display: flex; flex-direction: column; gap: 8px">'
             f'<div style="display: flex; align-items: center; justify-content: space-between; padding: 4px 6px 6px"><span style="display: flex; align-items: center; gap: 8px; color: #FFFFFF"><b style="font-size: 18px">Ready to fight</b><span style="padding: 2px 9px; border-radius: 99px; background: {MINT}; color: {DARK}; font-size: 12px; font-weight: 800">5</span></span>'
             + ('' if m else '<span style="font-size: 13px; color: #B9CCC2; font-weight: 600">You approve each one before we send it</span>') + '</div>'
             + ''.join(row(src, nm, why, amt) for k, src, nm, why, amt in FOUND) + '</div>')
    prog_row = lambda src, nm, why, amt, at: (f'<div style="display: flex; {"flex-direction: column; align-items: stretch" if m else "align-items: center"}; gap: 12px; padding: 12px 16px; border-top: 1px solid #EEF2F0">'
        f'<span style="display: flex; align-items: center; gap: 12px; flex: 1; min-width: 0">{mark(src, nm, "hand", 36)}<span style="display: flex; flex-direction: column; min-width: 0"><b style="font-size: 15px">{nm} <span style="color: {GREEN}">{amt}</span></b><span style="font-size: 12.5px; color: #5B6862; font-weight: 600">{why}</span></span></span>'
        f'<span style="display: flex; gap: 4px; {"" if m else "width: 360px"}">' + ''.join(f'<span style="flex: 1; display: flex; flex-direction: column; gap: 4px"><span style="height: 5px; border-radius: 99px; background: {GREEN if j < at else "#E3EAE6"}"></span><span style="font-size: 11px; font-weight: 700; color: {"#0A0F0D" if j < at else "#8A968F"}">{st}</span></span>' for j, st in enumerate(STAGES)) + '</span></div>')
    prog = (f'<div style="border-radius: 24px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; overflow: hidden"><div style="padding: 14px 16px; display: flex; align-items: center; gap: 8px"><b style="font-size: 18px">In progress</b><span style="padding: 2px 9px; border-radius: 99px; background: #E8EEFB; color: #2C4FA8; font-size: 12px; font-weight: 800">3</span></div>'
            + ''.join(prog_row(*x) for x in PROG) + '</div>')
    side_cards = (f'<div style="display: flex; flex-direction: column; gap: 12px">'
        f'<div style="padding: 18px; border-radius: 22px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; gap: 10px"><span style="width: 40px; height: 40px; border-radius: 12px; background: #E9F6EF; color: {GREEN}; display: flex; align-items: center; justify-content: center">{ic("link", 20, 2.2)}</span><b style="font-size: 16px">Scan for refunds</b><span style="font-size: 13.5px; color: #5B6862; line-height: 1.5">Connect a card or bank, read-only. We check your last 90 days of charges and keep watching.</span><span style="min-height: 40px; border-radius: 99px; background: #0A0F0D; color: #FFFFFF; font-size: 14px; font-weight: 800; display: flex; align-items: center; justify-content: center">Connect a card</span></div>'
        f'<div style="padding: 18px; border-radius: 22px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; gap: 10px"><span style="width: 40px; height: 40px; border-radius: 12px; background: #FFF4DB; color: #8A5A00; display: flex; align-items: center; justify-content: center">{ic("receipt", 20, 2.2)}</span><b style="font-size: 16px">Add a charge yourself</b>'
        + ''.join(f'<span style="height: 40px; border-radius: 12px; box-shadow: inset 0 0 0 1.5px #DDE5E0; padding: 0 12px; display: flex; align-items: center; font-size: 13.5px; font-weight: 600; color: #8A968F">{ph}</span>' for ph in ('Company, like Planet Fitness', 'Amount, like $39.99', 'What happened?')) +
        f'<span style="min-height: 40px; border-radius: 99px; background: #EEF2F0; color: #0A0F0D; font-size: 14px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 6px">{ic("plus", 16, 2.4)}Add charge</span></div></div>')
    head = (f'<div style="display: flex; flex-direction: column; gap: 4px"><h1 style="margin: 0; font-size: 22px; letter-spacing: -.5px">Refunds</h1><span style="font-size: 13px; color: #5B6862">Charges you can get back. You approve each one, then we cancel and request the refund.</span></div>')
    if m:
        top = (f'<header style="display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; background: #FFFFFF; border-bottom: 1px solid #E3EAE6">{brand(22, "#0A0F0D")}<span style="width: 32px; height: 32px; border-radius: 50%; background: {DARK}; color: #FFFFFF; font-size: 13px; font-weight: 800; display: flex; align-items: center; justify-content: center">H</span></header>')
        nav = ('<nav style="display: flex; justify-content: space-around; padding: 8px 6px 14px; background: #FFFFFF; border-top: 1px solid #E3EAE6">' + ''.join(
            f'<span style="display: flex; flex-direction: column; align-items: center; gap: 3px; font-size: 11px; font-weight: 800; color: {DARK if on else "#8A968F"}">{ic(k, 21, 2)}{t}</span>' for k, t, on in [('grid', 'Claims', 0), ('list', 'Find claims', 0), ('receipt', 'Refunds', 1), ('user', 'Account', 0)]) + '</nav>')
        body = f'<main style="flex: 1; overflow-y: auto; padding: 16px; display: flex; flex-direction: column; gap: 14px">{head}{tiles}{found}{prog}{side_cards}</main>'
        return f'<div style="height: 100%; display: flex; flex-direction: column; background: #F3F6F4; font-family: Manrope, sans-serif; color: #0A0F0D">{top}{body}{nav}</div>'
    item = lambda k, t, on: f'<span style="display: flex; align-items: center; gap: 12px; padding: 11px 12px; border-radius: 12px; font-size: 15px; font-weight: 700; {"background: #EAF2EE; color: #0F3B2E" if on else "color: #43504A"}">{ic(k, 19, 2)}{t}{"<span style=\"margin-left: auto; padding: 2px 7px; border-radius: 99px; background: " + MINT + "; color: " + DARK + "; font-size: 11px; font-weight: 800\">5</span>" if t == "Refunds" else ""}</span>'
    side = (f'<aside style="width: 232px; flex: none; display: flex; flex-direction: column; gap: 6px; padding: 22px 16px; background: #FFFFFF; border-right: 1px solid #E3EAE6; box-sizing: border-box"><span style="padding: 0 8px 18px">{brand(26, "#0A0F0D")}</span>'
            + item('grid', 'Dashboard', 0) + item('list', 'Find claims', 0) + item('receipt', 'Refunds', 1) +
            f'<div style="margin-top: auto; padding: 12px; border-radius: 18px; background: #F3F6F4; display: flex; flex-direction: column; gap: 4px"><span style="display: flex; align-items: center; gap: 10px; padding-bottom: 6px"><span style="width: 40px; height: 40px; border-radius: 50%; box-shadow: inset 0 0 0 4px {GREEN}; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 800">71%</span><span style="display: flex; flex-direction: column"><b style="font-size: 14px">Henry Sidwell</b><span style="font-size: 12px; color: #5B6862">Account 71% complete</span></span></span>'
            f'<span style="display: flex; align-items: center; gap: 10px; padding: 9px 10px; font-size: 14px; font-weight: 700; color: #43504A">{ic("user", 18, 2)}Your info</span><span style="display: flex; align-items: center; gap: 10px; padding: 9px 10px; font-size: 14px; font-weight: 700; color: #43504A">{ic("shield", 18, 2)}Settings</span></div></aside>')
    main = (f'<main style="flex: 1; min-width: 0; overflow-y: auto; padding: 24px 32px; display: flex; flex-direction: column; gap: 16px">{head}{tiles}'
            f'<div style="display: grid; grid-template-columns: minmax(0, 1fr) 300px; gap: 16px; align-items: start"><div style="display: flex; flex-direction: column; gap: 16px">{found}{prog}</div>{side_cards}</div></main>')
    return f'<div style="height: 100%; display: flex; background: #F3F6F4; font-family: Manrope, sans-serif; color: #0A0F0D">{side}{main}</div>'

def board(name, title, fn):
    page = (f'<div style="width: 1926px; height: 980px; box-sizing: border-box; padding: 24px; background: #E7ECE9; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 14px">'
            f'<div style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #43504A">{title.upper()}</div><div style="display: flex; gap: 48px; align-items: flex-start">'
            f'<div class="scroll" style="width: 1440px; height: 900px; flex: none; overflow-y: auto; border-radius: 18px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{fn(False)}</div>'
            f'<div class="scroll" style="width: 390px; height: 844px; flex: none; overflow-y: auto; border-radius: 28px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{fn(True)}</div></div></div>\n</x-dc>\n')
    open(os.path.join(OUT, name + '.dc.html'), 'w').write(HEAD % title + page + JS)

if __name__ == '__main__':
    board('RefundL', 'Refund Club · lander with the new Claim money | Refund Club nav (start design)', lander)
    board('RefundD', 'Refund Club · Refunds page in the dashboard (start design)', dash)
    print('built RefundL, RefundD')
