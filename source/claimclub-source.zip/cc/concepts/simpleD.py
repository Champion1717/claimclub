# Nov 18 2026: simpler member dashboard drafts for Henry (canvas only). Boards SimpleA/B/C (dashboard directions) and SimpleF (filing one question per screen).
import html
OUT='/home/claude/canvas/project/'
G='#12805C'; DK='#0F3B2E'; MINT='#3DDC97'; INK='#0A0F0D'; MUT='#5B6862'; LINE='#E3EAE6'; BG='#E9EEEB'; SOFT='#E9F6EF'
e=html.escape
T={'apple':'/_blob/67b39b46fb819bf79cf2a034e3eaf5ab?t','amazon':'/_blob/a506ff685feeef2af5e291793acc60c4?t','visa':'/_blob/802f5819abbdba32337f465f8df2f316?t','googleplay':'/_blob/fff3cc7ec5d6cd1e996f451ee9045581?t','realpage':'/_blob/db93ff119ed82ac214d13401f1e7f659','cvs':'/_blob/1ceb7905467ce333f9268b10d05d201d'}
IC={'check':'<path d="M20 6 9 17l-5-5"/>','home':'<path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
'search':'<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>','user':'<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>','arrow':'<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
'clock':'<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>','mail':'<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>','x':'<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
'back':'<path d="m15 18-6-6 6-6"/>','zap':'<path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/>',
'pen':'<path d="M12 20h9"/><path d="M16.376 3.622a1 1 0 0 1 3.002 3.002L7.368 18.635a2 2 0 0 1-.855.506l-2.872.838a.5.5 0 0 1-.62-.62l.838-2.872a2 2 0 0 1 .506-.854z"/>','wallet':'<path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/>'}
def ic(n,s=18,c='currentColor',w=2): return f'<svg aria-hidden="true" width="{s}" height="{s}" viewBox="0 0 24 24" fill="none" stroke="{c}" stroke-width="{w}" stroke-linecap="round" stroke-linejoin="round" style="flex: none">{IC[n]}</svg>'
def logo(k,s=40,r=12): return f'<img src="{T[k]}" alt="" style="width: {s}px; height: {s}px; flex: none; border-radius: {r}px; object-fit: cover; background: #FFFFFF; box-shadow: inset 0 0 0 1px {LINE}">'
CL=[('amazon','Amazon','Varies','ready','Closes in 14 days'),('apple','Apple','$95','ready','Closes in 34 days'),('visa','Visa & Mastercard','Up to $1,000','ready','Closes in 84 days'),('googleplay','Google Play','$100','auto','Pays automatically'),('realpage','RealPage','$100','filing','We are filing it'),('cvs','CVS','$5','paid','Paid Nov 2')]
HEAD='''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{t}</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&amp;display=swap" rel="stylesheet">
<style>
body{{margin:0}}
button{{font-family:inherit;border:0;cursor:pointer}}
img[src$="?t"]{{box-shadow:none !important}}
</style>
</helmet>
'''
def board(fn,title,w,h,label,desc,note,body):
    s=HEAD.format(t=e(title))+f'<div data-board style="width: {w}px; height: {h}px; box-sizing: border-box; padding: 36px 40px; background: {BG}; font-family: \'Manrope\', sans-serif; color: {INK}; display: flex; flex-direction: column; gap: 26px; overflow: hidden">'
    s+=f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: {G}">{e(label)}</span><span style="font-size: 16px; color: #43504A; max-width: 1640px; line-height: 1.5; font-weight: 600">{e(desc)}</span><span style="font-size: 13px; color: #6F7C75; font-weight: 600">{e(note)}</span></div>'
    s+=body+'</div>\n</x-dc>\n'+f'<script type="text/x-dc" data-dc-script data-props=\'{{"$preview":{{"width":{w},"height":{h}}}}}\'>\nclass Component extends DCLogic {{ renderVals() {{ return {{}}; }} }}\n</script>\n</body>\n</html>\n'
    open(OUT+fn,'w').write(s)
def brand(sz=18): return f'<span style="font-size: {sz}px; font-weight: 800; letter-spacing: -0.4px">claim<span style="font-weight: 500">club</span><span style="color: {G}">.io</span></span>'
def desk(inner,tabs=('Claims','Find more','Account'),on=0):
    tb=''.join(f'<a href="#" style="padding: 8px 16px; border-radius: 99px; font-size: 14px; font-weight: 800; text-decoration: none; {"background: "+SOFT+"; color: "+G if i==on else "color: #43504A"}">{t}</a>' for i,t in enumerate(tabs))
    return f'<div style="width: 1180px; height: 860px; flex: none; border-radius: 18px; overflow: hidden; background: #F7F9F8; box-shadow: 0 30px 80px rgba(10,15,13,.18); display: flex; flex-direction: column"><div style="height: 64px; flex: none; display: flex; align-items: center; justify-content: space-between; padding: 0 28px; background: #FFFFFF; border-bottom: 1px solid {LINE}">{brand()}<nav style="display: flex; gap: 4px">{tb}</nav><span style="width: 36px; height: 36px; border-radius: 99px; background: {DK}; color: #FFFFFF; display: inline-flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 800">M</span></div><div style="flex: 1; overflow: hidden; display: flex; justify-content: center; padding: 36px 28px">{inner}</div></div>'
def phone(inner,tabs=True,on=0):
    tb=''
    if tabs:
        tb='<div style="height: 70px; flex: none; display: flex; border-top: 1px solid '+LINE+'; background: #FFFFFF">'+''.join(f'<a href="#" style="flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 3px; font-size: 11.5px; font-weight: 800; text-decoration: none; color: {G if i==on else "#8A968F"}">{ic(n,21)}{t}</a>' for i,(n,t) in enumerate([('home','Claims'),('search','Find more'),('user','Account')]))+'</div>'
    return f'<div style="width: 390px; height: 844px; flex: none; border-radius: 46px; background: #F7F9F8; box-shadow: 0 0 0 10px #0A0F0D, 0 30px 70px rgba(10,15,13,.25); overflow: hidden; display: flex; flex-direction: column"><div style="height: 58px; flex: none; display: flex; align-items: center; justify-content: space-between; padding: 6px 22px 0">{brand(17)}<span style="width: 32px; height: 32px; border-radius: 99px; background: {DK}; color: #FFFFFF; display: inline-flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 800">M</span></div><div style="flex: 1; overflow: hidden; padding: 8px 18px 18px; display: flex; flex-direction: column; gap: 14px">{inner}</div>{tb}</div>'
def btn(t,kind='mint',full=False,h=44):
    st={'mint':f'background: {MINT}; color: {INK}','dark':f'background: {INK}; color: #FFFFFF','soft':f'background: #EEF2F0; color: {INK}','white':f'background: #FFFFFF; color: {INK}'}[kind]
    return f'<button type="button" style="{"width: 100%; " if full else ""}min-height: {h}px; padding: 0 20px; border-radius: 99px; font-size: 15px; font-weight: 800; {st}">{e(t)}</button>'
def chip(st):
    m={'ready':None,'auto':('Pays automatically','#E3F4FB','#0B5E86'),'filing':('Filing','#EEF2F0','#43504A'),'paid':('Paid $5','#12805C','#FFFFFF'),'review':('In review','#FFF4DB','#8A5A00')}[st]
    return f'<span style="font-size: 12.5px; font-weight: 800; padding: 6px 12px; border-radius: 99px; white-space: nowrap; background: {m[1]}; color: {m[2]}">{m[0]}</span>'
def row(k,co,amt,st,sub,compact=False):
    right=btn('File','mint',h=38 if compact else 40) if st=='ready' else chip(st)
    return f'<div style="display: flex; align-items: center; gap: 12px; padding: {"10px 12px" if compact else "12px 16px"}; border-radius: 16px; background: #FFFFFF; box-shadow: inset 0 0 0 1px {LINE}">{logo(k,38 if compact else 42)}<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><b style="font-size: 15px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{e(co)} <span style="color: {G}">{e(amt)}</span></b><span style="font-size: 12.5px; font-weight: 600; color: {MUT}">{e(sub)}</span></span>{right}</div>'

# ---------- A: one screen ----------
def a_content(m):
    big=f'<div style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 14px; font-weight: 700; color: {MUT}">Coming to you</span><b style="font-size: {44 if m else 56}px; letter-spacing: -1.5px; line-height: 1.05">Up to $1,305</b><span style="font-size: 14px; font-weight: 600; color: {MUT}">from 6 claims · $5 paid so far</span></div>'
    nxt=f'<div style="padding: {18 if m else 22}px; border-radius: 22px; background: {DK}; color: #FFFFFF; display: flex; align-items: center; gap: 14px; flex-wrap: wrap">{logo("amazon",48,14)}<span style="flex: 1; min-width: 160px; display: flex; flex-direction: column; gap: 3px"><span style="font-size: 12px; font-weight: 800; letter-spacing: 1px; color: {MINT}">NEXT UP</span><b style="font-size: 18px">File your Amazon claim</b><span style="font-size: 13px; font-weight: 600; color: #B7CEC4">Closes in 14 days · about 2 min</span></span>{btn("Start","mint",full=m,h=46)}</div>'
    lst='<div style="display: flex; flex-direction: column; gap: 8px"><b style="font-size: 16px">Your claims</b>'+''.join(row(*c,compact=m) for c in CL[1:])+'</div>'
    return big+nxt+lst
board('SimpleA.dc.html','Simple A',1840,1100,'SIMPLER DASHBOARD · A · ONE SCREEN','Dashboard and Your claims become one page. One number at the top, one "Next up" card with the single thing to do, then every claim on one line with one button or one status word. Three tabs: Claims, Find more, Account. No stat tiles, chart, disclaimers or setup bar on the home screen; account details are asked for inside a claim only when that claim needs them.','Sample member. Same data as today, about a third of the text.',
 f'<div style="display: flex; gap: 70px; align-items: flex-start">{desk("<div style=\"width: 680px; display: flex; flex-direction: column; gap: 22px\">"+a_content(False)+"</div>")}{phone(a_content(True))}</div>')

# ---------- B: one at a time ----------
def b_content(m):
    prog=f'<div style="display: flex; flex-direction: column; gap: 8px"><div style="display: flex; justify-content: space-between; font-size: 14px; font-weight: 800"><span>1 of 6 done</span><span style="color: {G}">Up to $1,305</span></div><span style="display: block; height: 8px; border-radius: 99px; background: #DDE6E1"><span style="display: block; width: 17%; height: 8px; border-radius: 99px; background: {G}"></span></span></div>'
    card=f'<div style="padding: {22 if m else 30}px; border-radius: 26px; background: #FFFFFF; box-shadow: 0 1px 0 {LINE}, 0 20px 50px rgba(10,15,13,.10); display: flex; flex-direction: column; gap: 16px; align-items: center; text-align: center">{logo("amazon",72,20)}<span style="font-size: 12.5px; font-weight: 800; letter-spacing: 1px; color: {G}">NEXT CLAIM</span><b style="font-size: {24 if m else 30}px; line-height: 1.2; letter-spacing: -0.6px">Amazon may owe you a refund</b><span style="font-size: 15px; font-weight: 600; color: {MUT}; line-height: 1.5; max-width: 420px">For returns that were never refunded, refunded late or refunded short.</span><div style="display: flex; gap: 8px; flex-wrap: wrap; justify-content: center"><span style="font-size: 13px; font-weight: 800; padding: 6px 12px; border-radius: 99px; background: {SOFT}; color: {G}">Payout varies</span><span style="font-size: 13px; font-weight: 800; padding: 6px 12px; border-radius: 99px; background: #FDECEC; color: #B8333A">14 days left</span><span style="font-size: 13px; font-weight: 800; padding: 6px 12px; border-radius: 99px; background: #EEF2F0; color: #43504A">2 min</span></div><div style="display: flex; flex-direction: column; gap: 8px; width: 100%">{btn("File this claim","mint",full=True,h=52)}<div style="display: flex; gap: 8px">{btn("Later","soft",full=True)}{btn("Not for me","soft",full=True)}</div></div></div>'
    up=f'<div style="display: flex; align-items: center; gap: 10px"><span style="font-size: 13px; font-weight: 800; color: {MUT}">Coming up</span>'+''.join(logo(k,30,9) for k in ['apple','visa'])+f'<span style="font-size: 13px; font-weight: 700; color: {MUT}">and 1 more</span></div>'
    done=f'<div style="display: flex; flex-direction: column; gap: 8px"><b style="font-size: 15px">Handled</b>'+''.join(row(*c,compact=True) for c in CL[3:])+'</div>'
    return prog+card+up+done
board('SimpleB.dc.html','Simple B',1840,1100,'SIMPLER DASHBOARD · B · ONE AT A TIME','The home screen shows one claim at a time, like a to-do card: what it is in one line, payout, days left, how long it takes, and File this claim, Later or Not for me. A progress bar shows how many are done. Everything already handled sits below in a short list. Good for people who would otherwise stall on a long list.','Sample member.',
 f'<div style="display: flex; gap: 70px; align-items: flex-start">{desk("<div style=\"width: 560px; display: flex; flex-direction: column; gap: 22px\">"+b_content(False)+"</div>")}{phone(b_content(True))}</div>')

# ---------- C: money first ----------
def c_content(m):
    wal=f'<div style="padding: {20 if m else 26}px; border-radius: 24px; background: {DK}; color: #FFFFFF; display: flex; flex-direction: column; gap: 14px"><span style="display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 800; color: {MINT}">{ic("wallet",18)}YOUR CLAIMS WALLET</span><div style="display: flex; gap: {20 if m else 40}px"><span style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 13px; font-weight: 700; color: #B7CEC4">On the way</span><b style="font-size: {30 if m else 40}px; letter-spacing: -1px">$1,300</b></span><span style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 13px; font-weight: 700; color: #B7CEC4">Paid to you</span><b style="font-size: {30 if m else 40}px; letter-spacing: -1px; color: {MINT}">$5</b></span></div></div>'
    def sec(t,n,rows): return f'<div style="display: flex; flex-direction: column; gap: 8px"><span style="display: flex; align-items: center; gap: 8px"><b style="font-size: 15px">{t}</b><span style="font-size: 12px; font-weight: 800; padding: 2px 8px; border-radius: 99px; background: #EEF2F0; color: #43504A">{n}</span></span>{rows}</div>'
    a=sec('Needs you',3,''.join(row(*c,compact=True) for c in CL[:3] if not m or c[0]!='visa')+('' if not m else f'<span style="font-size: 13px; font-weight: 800; color: {G}">+1 more</span>'))
    b=sec("We're on it",2,''.join(row(*c,compact=True) for c in CL[3:5]))
    c=sec('Paid',1,row(*CL[5],compact=True))
    return wal+a+b+c
board('SimpleC.dc.html','Simple C',1840,1100,'SIMPLER DASHBOARD · C · MONEY FIRST','Reads like a banking app. One wallet card with two numbers, On the way and Paid to you. Claims are grouped by who has to act: Needs you (with a File button), We\'re on it (one status word), Paid. No progress bars or fine print on the list; details open when you tap a claim.','Sample member.',
 f'<div style="display: flex; gap: 70px; align-items: flex-start">{desk("<div style=\"width: 680px; display: flex; flex-direction: column; gap: 22px\">"+c_content(False)+"</div>")}{phone(c_content(True))}</div>')

# ---------- F: filing one question per screen ----------
def fscreen(step,inner,bottom):
    dots=''.join(f'<span style="flex: 1; height: 5px; border-radius: 99px; background: {G if i<=step else "#DDE6E1"}"></span>' for i in range(4))
    top=f'<div style="display: flex; align-items: center; gap: 12px"><span style="width: 36px; height: 36px; border-radius: 99px; background: #EEF2F0; display: inline-flex; align-items: center; justify-content: center">{ic("back" if step else "x",18)}</span><div style="flex: 1; display: flex; gap: 5px">{dots}</div></div>'
    return phone(top+f'<div style="flex: 1; display: flex; flex-direction: column; gap: 16px; padding-top: 18px">{inner}</div><div style="display: flex; flex-direction: column; gap: 8px">{bottom}</div>',tabs=False)
big=lambda t: f'<b style="font-size: 27px; line-height: 1.2; letter-spacing: -0.6px">{t}</b>'
sub=lambda t: f'<span style="font-size: 15.5px; font-weight: 600; line-height: 1.5; color: {MUT}">{t}</span>'
f1=fscreen(0,logo('amazon',64,18)+big('Amazon may owe you a refund')+sub('People whose returns were never refunded, refunded late or refunded short since 2017 can get that money back.')+f'<div style="display: flex; gap: 8px; flex-wrap: wrap"><span style="font-size: 13px; font-weight: 800; padding: 6px 12px; border-radius: 99px; background: {SOFT}; color: {G}">Payout varies</span><span style="font-size: 13px; font-weight: 800; padding: 6px 12px; border-radius: 99px; background: #FDECEC; color: #B8333A">14 days left</span></div>',btn("Check if I qualify","dark",True,54))
f2=fscreen(1,f'<span style="font-size: 13px; font-weight: 800; letter-spacing: 1px; color: {G}">QUESTION 1 OF 1</span>'+big('Since 2017, did Amazon miss, delay or short a refund for something you returned?')+sub('Not sure? Check Your Orders on Amazon for returns.'),btn("Yes","mint",True,58)+btn("No","white",True,58).replace('background: #FFFFFF','background: #FFFFFF; box-shadow: inset 0 0 0 1.5px #DDE5E0'))
f3=fscreen(2,f'<span style="width: 64px; height: 64px; border-radius: 20px; background: {SOFT}; color: {G}; display: inline-flex; align-items: center; justify-content: center">{ic("mail",30)}</span>'+big('Did you get an email or postcard about this?')+sub('It is from the settlement administrator and has a Notice ID on it. No notice is fine, we can ask for one.'),btn("Yes, I have it","mint",True,58)+btn("No, or I can't find it","white",True,58).replace('background: #FFFFFF','background: #FFFFFF; box-shadow: inset 0 0 0 1.5px #DDE5E0'))
f4=fscreen(3,big('Sign and we file it')+sub('We fill in the official form with your saved info and send you the claim ID in about 2 days.')+f'<div style="padding: 16px; border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1px {LINE}; display: flex; flex-direction: column; gap: 10px"><span style="font-size: 12px; font-weight: 800; color: #8A968F">PAID TO</span><b style="font-size: 15px">PayPal · maria@example.com</b><span style="font-size: 12px; font-weight: 800; color: #8A968F">YOUR SIGNATURE</span><span style="font-size: 22px; font-weight: 700; border-bottom: 1.5px solid {INK}; padding-bottom: 4px">Maria Lopez</span></div><span style="display: flex; gap: 10px; align-items: flex-start; font-size: 13.5px; font-weight: 600; color: #43504A; line-height: 1.45"><span style="width: 22px; height: 22px; flex: none; border-radius: 7px; background: {G}; color: #FFFFFF; display: inline-flex; align-items: center; justify-content: center">{ic("check",14,w=3)}</span>My answers are true and Claimclub can file this claim for me.</span>',btn("Sign and file","mint",True,58)+f'<span style="text-align: center; font-size: 12.5px; font-weight: 700; color: {G}">Read the full authorization</span>')
def cap(t): return f'<span style="max-width: 390px; text-align: center; font-size: 14px; font-weight: 700; color: #43504A; line-height: 1.45">{t}</span>'
cols=''.join(f'<div style="display: flex; flex-direction: column; gap: 16px; align-items: center">{s}{cap(c)}</div>' for s,c in [(f1,'1 · What it is, in one line, plus payout and days left'),(f2,'2 · One question per screen, big Yes and No'),(f3,'3 · Notice explained in one sentence, no codes unless they have it'),(f4,'4 · Sign with name and payout prefilled, legal text one tap away')])
board('SimpleF.dc.html','Simple filing',1840,1100,'SIMPLER FILING · ONE QUESTION PER SCREEN','Works with any of the three dashboards. Filing becomes 3 to 5 full screens instead of one long sheet: what the case is, one question at a time with big buttons, the notice question in plain words, then sign. Extra details (like order numbers) get their own screen only when the claim needs them. The legal attestation moves behind a link with one plain checkbox.','Amazon sample, same content as the live spec.',
 f'<div style="display: flex; gap: 60px; justify-content: center">{cols}</div>')
print('done')
