# Homepage hero tile concepts with the top half of a realistic iPhone (like claimmoney.com): HeroP1..HeroP4.dc.html boards.
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import how4
from how4 import iphone, ic, LOGO, HEAD, JS, OUT

B = {'apple': '/_blob/7fd6ec4499df609a19ab46e16342f49d', 'googleplay': '/_blob/7f4390cee228878d694a9ab5d8bd863a', 'visa': '/_blob/17d130cb2fd653ada0d1561043e8aa56',
     'amazon': '/_blob/9e823dce7e60dc8d8b58da2243d7151d', 'cvs': '/_blob/1ceb7905467ce333f9268b10d05d201d', 'tyson': '/_blob/c655327b9222899295d427826bd844fe',
     'equifax': '/_blob/f0fd40dfbbdad8b7c7e13aefc1e6c491', 'netflix': '/_blob/6450426b362962920828f44df101d658'}
logo = lambda k, s=40, r=11: f'<img src="{B[k]}" alt="" style="width: {s}px; height: {s}px; flex: none; border-radius: {r}px; object-fit: contain; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; padding: {round(s*.16)}px; box-sizing: border-box">'
noproof = '<span style="display: inline-flex; align-items: center; gap: 3px; font-size: 10.5px; font-weight: 800; color: #17603F; background: #DDF5E8; padding: 2px 7px; border-radius: 99px">' + ic('check', 10, 3.2) + 'No proof</span>'

def row(k, amt, sub, np=True, btn='Claim', dim=False):
    return (f'<div style="display: flex; align-items: center; gap: 10px; padding: 10px; background: #FFFFFF; border-radius: 16px; box-shadow: 0 1px 2px rgba(10,15,13,.06); opacity: {.45 if dim else 1}">{logo(k)}'
            f'<div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><b style="font-size: 15px; letter-spacing: -.3px; white-space: nowrap">{amt}</b><span style="font-size: 11.5px; font-weight: 600; color: #8A968F; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{sub}{" · No proof" if np else ""}</span></div>'
            f'<span style="flex: none; padding: 7px 13px; border-radius: 99px; background: #12805C; color: #FFFFFF; font-size: 12.5px; font-weight: 800">{btn}</span></div>')

def apphead(title):
    return (f'<div style="display: flex; align-items: center; justify-content: space-between; padding: 2px 2px 4px"><span style="font-size: 22px; font-weight: 800; letter-spacing: -.6px">{title}</span>'
            '<span style="width: 30px; height: 30px; border-radius: 50%; background: #0F3B2E; color: #FFFFFF; font-size: 12px; font-weight: 800; display: flex; align-items: center; justify-content: center">M</span></div>')

def phone_half(screen, pop='', w=340, show=540):
    """Top part of the phone, fading out at the bottom into the hero tile, with an optional card that pops out over it."""
    return (f'<div style="position: relative; width: {w + 120}px; height: {show}px; flex: none">'
            f'<div style="position: absolute; left: 60px; top: 0; width: {w}px; height: {show}px; overflow: hidden; -webkit-mask-image: linear-gradient(180deg, #000 62%, transparent 100%); mask-image: linear-gradient(180deg, #000 62%, transparent 100%)">{iphone(screen, w, "#F3F6F4")}</div>'
            f'{pop}</div>')

def popcard(inner, top, rot=-4, pos='left: 0; right: 0'):
    return (f'<div style="position: absolute; {pos}; top: {top}px; transform: rotate({rot}deg); background: #FFFFFF; border-radius: 22px; padding: 14px 16px; '
            f'box-shadow: 0 30px 60px rgba(0,0,0,.35), 0 0 0 1px rgba(10,15,13,.04); z-index: 6; color: #0A0F0D">{inner}</div>')

# ---------- four phone ideas ----------
def p1():  # settlements list + big Apple card popping out (closest to claimmoney)
    scr = (apphead('Settlements') + '<div style="display: flex; gap: 6px"><span style="padding: 6px 12px; border-radius: 99px; background: #0F3B2E; color: #FFFFFF; font-size: 12px; font-weight: 800">All</span><span style="padding: 6px 12px; border-radius: 99px; background: #FFFFFF; font-size: 12px; font-weight: 700; color: #43504A">No proof</span><span style="padding: 6px 12px; border-radius: 99px; background: #FFFFFF; font-size: 12px; font-weight: 700; color: #43504A">Closing soon</span></div>'
           + '<div style="height: 64px"></div>' + row('googleplay', 'Up to $100', 'Closes in 28 days') + row('visa', 'Up to $1,000', 'Closes in 88 days') + row('tyson', 'Up to $100', 'Closes in 17 days'))
    card = ('<div style="display: flex; align-items: center; gap: 14px">' + logo('apple', 62, 16) +
            '<div style="flex: 1; display: flex; flex-direction: column; gap: 3px"><div style="display: flex; align-items: center; gap: 8px"><b style="font-size: 24px; letter-spacing: -.6px">$95</b>' + noproof + '</div><span style="font-size: 13px; font-weight: 600; color: #8A968F">Apple Siri settlement · 38 days left</span></div>'
            '<span style="padding: 11px 20px; border-radius: 99px; background: #12805C; color: #FFFFFF; font-size: 16px; font-weight: 800; box-shadow: inset 0 -2px 0 rgba(0,0,0,.2)">Claim</span></div>')
    return phone_half(scr, popcard(card, 128, -3))

def p2():  # estimate screen + "claim filed" notification
    scr = ('<div style="display: flex; flex-direction: column; align-items: center; gap: 4px; padding: 8px 0 4px; text-align: center"><span style="font-size: 12px; font-weight: 800; letter-spacing: 1px; color: #8A968F">YOU COULD BE OWED</span><span style="font-size: 46px; font-weight: 800; letter-spacing: -1.8px; color: #12805C; line-height: 1">$1,295</span><span style="font-size: 12.5px; font-weight: 700; color: #5B6862">from 6 settlements you matched</span></div>'
           + row('apple', 'Up to $95', 'Apple Siri settlement', btn='File') + row('visa', 'Up to $1,000', 'ATM fees', btn='File') + row('googleplay', 'Up to $100', 'Google Play', btn='File') + row('cvs', 'Up to $10', 'CVS app users', btn='File', dim=True))
    note = ('<div style="display: flex; align-items: center; gap: 12px; width: 300px"><span style="width: 44px; height: 44px; flex: none; border-radius: 12px; background: #0F3B2E; display: flex; align-items: center; justify-content: center">' + LOGO.format(s=26, c='#FFFFFF') + '</span>'
            '<span style="flex: 1; display: flex; flex-direction: column; gap: 1px"><span style="display: flex; justify-content: space-between; gap: 8px"><b style="font-size: 14.5px">Claim filed</b><span style="font-size: 12px; color: #8A968F; font-weight: 600">now</span></span><span style="font-size: 13px; color: #43504A">We filed your Apple claim. Up to $95.</span></span></div>')
    return phone_half(scr, popcard(note, 300, 3, 'left: 10px; width: max-content'))

def p3():  # quiz screen + matched chip
    scr = ('<div style="display: flex; justify-content: space-between; align-items: center"><span style="font-size: 12px; font-weight: 800; letter-spacing: 1px; color: #8A968F">QUESTION 2 OF 8</span><span style="font-size: 12px; font-weight: 800; color: #12805C">$100 so far</span></div>'
           '<div style="height: 6px; border-radius: 99px; background: #E3EAE6"><div style="width: 25%; height: 100%; border-radius: 99px; background: #12805C"></div></div>'
           '<div style="background: #FFFFFF; border-radius: 20px; padding: 18px; display: flex; flex-direction: column; gap: 14px; margin-top: 6px">' + logo('apple', 52, 14) +
           '<span style="font-size: 21px; font-weight: 800; letter-spacing: -.5px; line-height: 1.2">Did you buy an iPhone 15 Pro or iPhone 16?</span><span style="font-size: 13px; color: #5B6862; line-height: 1.45">Bought in the U.S. between 2024 and 2025. No receipt needed.</span>'
           '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px"><span style="height: 46px; border-radius: 14px; background: #0F3B2E; color: #FFFFFF; font-weight: 800; display: flex; align-items: center; justify-content: center">Yes</span><span style="height: 46px; border-radius: 14px; box-shadow: inset 0 0 0 1.5px #DDE5E0; font-weight: 800; color: #43504A; display: flex; align-items: center; justify-content: center">No</span></div></div>')
    chip = ('<div style="display: flex; align-items: center; gap: 10px">' + f'<span style="width: 36px; height: 36px; border-radius: 50%; background: #3DDC97; color: #0F3B2E; display: flex; align-items: center; justify-content: center">{ic("check", 20, 3)}</span>'
            '<span style="display: flex; flex-direction: column"><b style="font-size: 20px; letter-spacing: -.5px">+$95 matched</b><span style="font-size: 12.5px; color: #5B6862; font-weight: 600">Apple Siri settlement</span></span></div>')
    return phone_half(scr, popcard(chip, 300, -5, 'right: -6px; width: max-content'))

def p4():  # claims tracker + payout notification
    st = lambda t, on, cur=False: f'<span style="flex: 1; display: flex; flex-direction: column; gap: 4px; font-size: 10.5px; font-weight: 800; color: {"#12805C" if on else "#9AA8A0"}"><span style="height: 5px; border-radius: 99px; background: {"#12805C" if on and not cur else ("#3DDC97" if cur else "#E3EAE6")}"></span>{t}</span>'
    track = lambda k, name, a, b, c, d: (f'<div style="background: #FFFFFF; border-radius: 16px; padding: 12px; display: flex; flex-direction: column; gap: 10px"><div style="display: flex; align-items: center; gap: 10px">{logo(k, 36, 10)}<b style="font-size: 14px; flex: 1">{name}</b></div>'
                                          f'<div style="display: flex; gap: 4px">{st("Filed", a)}{st("Review", b, cur=b and not c)}{st("Approved", c, cur=c and not d)}{st("Paid", d)}</div></div>')
    scr = (apphead('Your claims') + '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px"><div style="background: #FFFFFF; border-radius: 14px; padding: 10px 12px"><span style="font-size: 11px; font-weight: 700; color: #5B6862">Estimated</span><div style="font-size: 20px; font-weight: 800">$1,295</div></div><div style="background: #FFFFFF; border-radius: 14px; padding: 10px 12px"><span style="font-size: 11px; font-weight: 700; color: #5B6862">Paid to you</span><div style="font-size: 20px; font-weight: 800; color: #12805C">$100</div></div></div>'
           + track('googleplay', 'Google Play', 1, 1, 1, 1) + track('apple', 'Apple Siri', 1, 1, 0, 0) + track('visa', 'ATM fees (Visa)', 1, 0, 0, 0))
    note = ('<div style="display: flex; align-items: center; gap: 12px; width: 290px"><span style="width: 44px; height: 44px; flex: none; border-radius: 12px; background: #3DDC97; color: #0F3B2E; display: flex; align-items: center; justify-content: center">' + ic('wallet', 22, 2.2) + '</span>'
            '<span style="display: flex; flex-direction: column; gap: 1px"><b style="font-size: 14.5px">Payout sent · $100</b><span style="font-size: 13px; color: #43504A">Google Play settlement, sent to your PayPal</span></span></div>')
    return phone_half(scr, popcard(note, 70, -3, 'left: 0; width: max-content'))

VARIANTS = [('HeroP1', 'Hero phone V1 · Settlements list, Apple card pops out', p1), ('HeroP2', 'Hero phone V2 · Your estimate, "Claim filed" alert', p2),
            ('HeroP3', 'Hero phone V3 · Quiz question, "+$95 matched" chip', p3), ('HeroP4', 'Hero phone V4 · Claims tracker, "Payout sent" alert', p4)]

def hero(vis, m):
    stars = '<span style="display: inline-flex; gap: 2px">' + ''.join('<svg width="16" height="16" viewBox="0 0 24 24" fill="#3DDC97" aria-hidden="true"><path d="M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"></path></svg>' for _ in range(5)) + '</span>'
    nav = (f'<div style="display: flex; align-items: center; justify-content: space-between; padding: {"16px 18px 0" if m else "22px 40px 0"}"><span style="display: flex; align-items: center; gap: 9px">{LOGO.format(s=26 if m else 28, c="#FFFFFF")}<span style="font-size: {18 if m else 20}px; font-weight: 800; letter-spacing: -.6px">claim<span style="font-weight: 500">club</span><span style="font-size: .72em; color: #3DDC97">.io</span></span></span>'
           f'<span style="display: flex; align-items: center; gap: {12 if m else 16}px"><span style="font-size: 15px; font-weight: 700">Log in</span><span style="background: #3DDC97; color: #0F3B2E; font-size: {14 if m else 15}px; font-weight: 800; padding: {"10px 14px" if m else "11px 18px"}; border-radius: 999px">Get started</span></span></div>')
    text = (f'<div style="flex: {"none" if m else "1 1 520px"}; min-width: 0; display: flex; flex-direction: column; gap: {18 if m else 24}px; align-items: {"center" if m else "flex-start"}; text-align: {"center" if m else "left"}">'
            f'<h1 style="margin: 0; font-size: {38 if m else 60}px; line-height: 1.02; letter-spacing: -.045em">Big companies settle lawsuits all the time. <span style="font-family: \'Instrument Serif\', serif; font-style: italic; font-weight: 400; letter-spacing: -.02em; color: #3DDC97">You could be owed a share.</span></h1>'
            f'<p style="margin: 0; font-size: {16 if m else 18}px; line-height: 1.6; color: #C9D6CF; max-width: 520px">Tap the claims that apply to you, see your total in under a minute, and we file them for you.</p>'
            f'<div style="display: flex; flex-wrap: wrap; gap: 12px; justify-content: {"center" if m else "flex-start"}"><span style="background: #FFFFFF; color: #0F3B2E; font-size: 17px; font-weight: 800; padding: 16px 28px; border-radius: 999px">See what I could be owed</span>' + ('' if m else '<span style="box-shadow: inset 0 0 0 1.5px rgba(255,255,255,.35); font-size: 17px; font-weight: 800; padding: 16px 22px; border-radius: 999px">Browse settlements</span>') + '</div>'
            f'<span style="display: flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 700">{stars}4.8 · 2,317 reviews</span></div>')
    if m:
        body = f'<div style="display: flex; flex-direction: column; align-items: center; gap: 30px; padding: 28px 20px 0">{text}<div style="transform: scale(.78); transform-origin: 50% 0; margin-bottom: -119px">{vis}</div></div>'
    else:
        body = f'<div style="display: flex; align-items: flex-end; justify-content: space-between; gap: 40px; padding: 40px 40px 0; min-height: 620px; box-sizing: border-box"><div style="align-self: center; padding-bottom: 40px; max-width: 760px">{text}</div>{vis}</div>'
    return f'<section class="meshDark" style="color: #FFFFFF; overflow: hidden; font-family: Manrope, sans-serif">{nav}{body}</section>'

def build():
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    y0 = max(b['y'] + b['h'] for k, b in c['boards'].items() if not k.startswith('HeroP')) + 260
    c['notes']['tHP'] = {'x': 0, 'y': y0, 'text': 'Homepage hero · realistic phone (top half) concepts', 'kind': 'title1', 'maxW': 3900, 'w': 240}
    if 'noteOrder' in c and 'tHP' not in c['noteOrder']: c['noteOrder'].append('tHP')
    for k, (name, title, fn) in enumerate(VARIANTS):
        vis = fn()
        page = (f'<div style="width: 1926px; height: 980px; box-sizing: border-box; padding: 24px; background: #E7ECE9; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 14px">'
                f'<div style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #43504A">{title.upper()}</div>'
                '<div style="display: flex; gap: 48px; align-items: flex-start">'
                f'<div class="scroll" style="width: 1440px; height: 900px; flex: none; overflow-y: auto; border-radius: 18px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{hero(vis, False)}</div>'
                f'<div class="scroll" style="width: 390px; height: 844px; flex: none; overflow-y: auto; border-radius: 28px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{hero(vis, True)}</div>'
                '</div></div>\n</x-dc>\n')
        open(os.path.join(OUT, name + '.dc.html'), 'w').write(HEAD % title + page + JS)
        c['boards'][name + '.dc.html'] = {'x': (k % 2) * 2006, 'y': y0 + 220 + (k // 2) * 1060, 'w': 1926, 'h': 980, 'is_interactive': True, 'title': title}
        if name + '.dc.html' not in c['order']: c['order'].append(name + '.dc.html')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w'))
    print('built', [v[0] for v in VARIANTS], 'y0', y0)

if __name__ == '__main__':
    build()
