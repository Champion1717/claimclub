# Flow B for the pricing test (Nov 16 2026, design only, not live).
# Offer copied from ClaimMoney's model per Henry: a 7-day trial for $2 (96% off), then $49 a year.
# Flow A stays as it is today (membership $7.99 first month then $29.99/mo, or $49.99 filing fee).
# Writes FlowB1..4 and AdminAB boards into ../project.
import os, io, contextlib
from how4 import HEAD, JS, OUT
from perksD import ic, phone, INK, MUTE, LINE, MINT, GREEN, DARK
from choiceD import LOGO, mint_btn
with contextlib.redirect_stdout(io.StringIO()):
    from payD import wallets, orline, cardform, paybtn, secure, email_row, zig

FULL, TODAY, OFF, DAYS, ENDS, PERMO = '$49', '$2', '96%', 7, 'Nov 23, 2026', '$4.08'
CLAIMS = [('Apple', 'Up to $95'), ('Visa & Mastercard', 'Up to $1,000'), ('Google Play', 'Up to $100'), ('Amazon', 'Up to $250'), ('Tyson', 'Up to $100'), ('CVS', 'Up to $10')]
PERKS = ['Files your 6 claims, no filing fee', 'Every new claim you qualify for, filed for you', 'An alert the day a new claim opens',
         'All 294 settlements, plus local ones near you', 'Track every claim in one dashboard']
RENEW = f'Your trial ends {ENDS}. Then {FULL} a year ({PERMO}/mo) unless you cancel before then. Cancel anytime in your dashboard.'

def h(t, sz=32, center=True):
    return f'<b style="font-size: {sz}px; letter-spacing: -1px; line-height: 1.12; text-align: {"center" if center else "left"}">{t}</b>'
def sub(t, center=True, sz=16):
    return f'<span style="font-size: {sz}px; font-weight: 600; color: {MUTE}; text-align: {"center" if center else "left"}; line-height: 1.45">{t}</span>'
def chip(t, bg='#FFF4DB', fg='#8A5A00'):
    return f'<span style="padding: 5px 10px; border-radius: 99px; background: {bg}; color: {fg}; font-size: 12px; font-weight: 800; letter-spacing: .4px; white-space: nowrap">{t}</span>'
def tiles(n=6, sz=30):
    cols = ['#111111', '#1A1F71', '#01875F', '#FF9900', '#B5121B', '#CC0000']
    return '<span style="display: flex">' + ''.join(f'<span style="width: {sz}px; height: {sz}px; border-radius: 9px; background: {c}; color: #FFFFFF; font-size: 13px; font-weight: 800; display: flex; align-items: center; justify-content: center; margin-left: {0 if i == 0 else -6}px; box-shadow: 0 0 0 2px #FFFFFF">{n_[0]}</span>' for i, (c, (n_, _)) in enumerate(zip(cols, CLAIMS[:n]))) + '</span>'
def summary(m=False):
    return (f'<div style="display: flex; align-items: center; gap: 12px; padding: {12 if m else 14}px {14 if m else 18}px; border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}">'
            f'{tiles(4 if m else 6)}<span style="flex: 1; display: flex; flex-direction: column"><b style="font-size: {15 if m else 16}px">6 claims ready</b><span style="font-size: 12.5px; font-weight: 600; color: {MUTE}">Apple, Visa &amp; Mastercard, Google Play and 3 more</span></span>'
            f'<span style="display: flex; flex-direction: column; align-items: flex-end"><span style="font-size: 11.5px; font-weight: 800; color: {MUTE}">UP TO</span><b style="font-size: {20 if m else 22}px; letter-spacing: -0.6px; color: {GREEN}">$1,555</b></span></div>')

# ---------- the offer card (flow B's one and only choice) ----------
def offer(m=False):
    perks = ''.join(f'<div style="display: flex; align-items: center; gap: 10px; font-size: {14 if m else 15}px; font-weight: 700; color: #FFFFFF">'
                    f'<span style="width: 22px; height: 22px; flex: none; border-radius: 99px; background: rgba(61,220,151,.18); display: flex; align-items: center; justify-content: center">{ic("check", 13, MINT, 3)}</span>{t}</div>' for t in PERKS)
    return (f'<div style="position: relative; border-radius: 24px; padding: {20 if m else 26}px; background: radial-gradient(120% 90% at 100% 0%, rgba(61,220,151,.25), transparent 55%), linear-gradient(165deg, #1B5A44, #0A2A20); color: #FFFFFF; display: flex; flex-direction: column; gap: {14 if m else 16}px; box-shadow: 0 20px 44px rgba(10,42,32,.28)">'
            f'<div style="display: flex; justify-content: space-between; align-items: center"><span style="font-size: 12px; font-weight: 800; letter-spacing: 1.3px; color: #CFE9DD">CLAIMCLUB MEMBERSHIP</span>{chip(OFF + " OFF TODAY", MINT, DARK)}</div>'
            f'<div style="display: flex; align-items: flex-end; gap: 12px"><b style="font-size: {56 if m else 64}px; letter-spacing: -2.5px; line-height: .9">{TODAY}</b>'
            f'<span style="display: flex; flex-direction: column; padding-bottom: 4px"><span style="font-size: 16px; font-weight: 700; color: #9FC3B4; text-decoration: line-through">{FULL}</span><span style="font-size: {14 if m else 15}px; font-weight: 800">for your first {DAYS} days</span></span></div>'
            f'<span style="font-size: {13 if m else 14}px; font-weight: 600; color: #CFE9DD; margin-top: -6px">Then {FULL} a year, just {PERMO} a month. Cancel anytime.</span>'
            f'<div style="height: 1px; background: rgba(255,255,255,.12)"></div><div style="display: flex; flex-direction: column; gap: {9 if m else 11}px">{perks}</div></div>')
def timeline(m=False):
    st = [('Today', f'Pay {TODAY}. We start filing your claims.'), (f'Day {DAYS - 2}', 'We email you a reminder.'), (f'Day {DAYS}', f'{FULL} for the year, unless you cancel.')]
    out = ''
    for i, (a, b) in enumerate(st):
        out += (f'<div style="flex: 1; display: flex; flex-direction: column; gap: 4px; min-width: 0"><span style="display: flex; align-items: center; gap: 8px"><span style="width: 12px; height: 12px; border-radius: 99px; background: {GREEN if i == 0 else "#FFFFFF"}; box-shadow: inset 0 0 0 2.5px {GREEN}; flex: none"></span>'
                f'<span style="flex: 1; height: 2px; background: {LINE if i < 2 else "transparent"}"></span></span><b style="font-size: 13px">{a}</b><span style="font-size: 12px; font-weight: 600; color: {MUTE}; line-height: 1.35">{b}</span></div>')
    return f'<div style="display: flex; gap: {8 if m else 12}px; padding: 4px 2px">{out}</div>'
def fine(center=True):
    return f'<span style="font-size: 12px; font-weight: 600; color: {MUTE}; line-height: 1.45; text-align: {"center" if center else "left"}">{RENEW}</span>'
def cta(t=None, h=56):
    return mint_btn(f'{ic("lock", 16, DARK, 2.4)}{t or "Start my " + str(DAYS) + "-day trial · " + TODAY}', h)

# ---------- frames: same as the live flow (desktop side panel, phone with sticky button) ----------
def side(rec=None):
    if rec: inner = rec
    else:
        pts = ''.join(f'<div style="display: flex; align-items: center; gap: 10px; font-size: 15px; font-weight: 700; color: #FFFFFF"><span style="width: 6px; height: 6px; border-radius: 99px; background: {MINT}"></span>{t}</div>'
                      for t in ['Every settlement is court-approved', 'We pre-fill and submit your claims', 'Payouts come straight from the settlement', 'Cancel anytime'])
        inner = (f'<span style="font-size: 12px; font-weight: 800; letter-spacing: 1.4px; color: #CFE9DD">YOUR ESTIMATE SO FAR</span><b style="font-size: 52px; letter-spacing: -2px; color: #FFFFFF; line-height: 1">$1,555</b>'
                 f'<span style="font-size: 15px; font-weight: 700; color: #CFE9DD">6 claims ready to file</span><div style="display: flex; flex-direction: column; gap: 12px; margin-top: 14px">{pts}</div>')
    return (f'<div style="width: 400px; flex: none; padding: 36px; box-sizing: border-box; background: radial-gradient(120% 70% at 100% 0%, rgba(61,220,151,.22), transparent 55%), linear-gradient(170deg, #1B5A44, #0A2A20); display: flex; flex-direction: column; gap: 10px">{inner}</div>')
def desk(main, rec=None, w=640):
    return (f'<div style="width: 1280px; height: 880px; flex: none; border-radius: 16px; overflow: hidden; background: #F7F9F8; box-shadow: 0 30px 80px rgba(10,15,13,.18); display: flex; flex-direction: column">'
            f'<div style="height: 72px; flex: none; display: flex; align-items: center; justify-content: space-between; padding: 0 36px; border-bottom: 1px solid #E8EEEA; background: #FFFFFF">'
            f'<span style="display: flex; align-items: center; gap: 16px"><span style="width: 42px; height: 42px; border-radius: 12px; background: #F1F4F2; display: flex; align-items: center; justify-content: center">{ic("back", 18, INK, 2.4)}</span>{LOGO}</span>'
            f'<span style="font-size: 13.5px; font-weight: 700; color: {MUTE}">Not a law firm · Free to check</span></div>'
            f'<div style="flex: 1; display: flex; min-height: 0">{side(rec)}<div style="flex: 1; display: flex; justify-content: center; align-items: center; padding: 24px 40px"><div style="width: {w}px; display: flex; flex-direction: column; gap: 16px">{main}</div></div></div></div>')
def mob(inner, foot='', overlay=''):
    return phone(f'<div style="padding: 56px 18px 0; display: flex; align-items: center; gap: 12px"><span style="width: 34px; height: 34px; border-radius: 99px; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; align-items: center; justify-content: center">{ic("back", 17, INK, 2.4)}</span>{LOGO}</div>'
                 f'<div style="flex: 1; overflow: hidden; padding: 12px 18px 0; display: flex; flex-direction: column; gap: 12px">{inner}</div>'
                 + (f'<div style="padding: 12px 18px 30px; background: #FFFFFF; box-shadow: 0 -10px 24px rgba(10,15,13,.06); display: flex; flex-direction: column; gap: 8px">{foot}</div>' if foot else '') + overlay, bg='#F3F6F4')

# ---------- trial receipt (desktop side panel and the phone sheet strip) ----------
def receipt(m=False):
    rows = ''.join(f'<div style="display: flex; justify-content: space-between; gap: 10px; padding: 5px 0; font-size: 13.5px"><span style="display: flex; align-items: center; gap: 8px; font-weight: 700">{ic("check", 14, GREEN, 2.6)}{c}</span><span style="font-weight: 800; color: {GREEN}">{v}</span></div>' for c, v in CLAIMS)
    dash = '<div style="border-top: 2px dashed #DDE5E0; margin: 10px 0"></div>'
    line = lambda a, b, bold=False, col=INK: f'<div style="display: flex; justify-content: space-between; gap: 10px; font-size: {15 if bold else 13.5}px; font-weight: {800 if bold else 700}; color: {col}; padding: 3px 0"><span>{a}</span><span>{b}</span></div>'
    return (f'<div style="display: flex; flex-direction: column; filter: drop-shadow(0 18px 30px rgba(0,0,0,.35))">'
            f'<div style="background: #FFFFFF; border-radius: 18px 18px 0 0; padding: 20px 20px 12px; display: flex; flex-direction: column; color: {INK}">'
            f'<div style="display: flex; justify-content: space-between"><span style="font-size: 11.5px; font-weight: 800; letter-spacing: 1.2px; color: #8A968F">YOUR CLAIMS RECEIPT</span><span style="font-size: 11.5px; font-weight: 700; color: #8A968F">Nov 16, 2026</span></div>'
            f'<span style="font-size: 13px; font-weight: 700; color: {MUTE}; margin-top: 8px">Expected earnings</span><b style="font-size: 40px; letter-spacing: -1.5px; line-height: 1.05; color: {GREEN}">Up to $1,555</b>'
            + dash + rows + dash
            + line('Membership, 1 year', FULL + '.00') + line(f'{OFF} off your first {DAYS} days', '-$47.00', col=GREEN) + line('Due today', TODAY + '.00', True)
            + f'<span style="font-size: 12px; font-weight: 600; color: {MUTE}; margin-top: 6px; line-height: 1.4">Renews {ENDS} at {FULL}.00 a year. Cancel anytime before then and you pay nothing more.</span>'
            f'<div style="display: flex; justify-content: space-between; font-size: 13.5px; font-weight: 800; margin-top: 10px"><span>Your share of every payout</span><span style="color: {GREEN}">100%</span></div>'
            f'</div>{zig()}</div>')
def strip():
    return (f'<div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 14px; border-radius: 16px; background: #E9F6EF">'
            f'<span style="display: flex; flex-direction: column; gap: 1px"><span style="font-size: 12px; font-weight: 700; color: #17603F">Expected earnings</span><b style="font-size: 22px; letter-spacing: -0.6px; color: {GREEN}">Up to $1,555</b></span>'
            f'<span style="display: flex; flex-direction: column; align-items: flex-end; gap: 3px"><span style="font-size: 12.5px; font-weight: 800; color: #17603F">{TODAY} today · {OFF} off</span>'
            f'<span style="font-size: 12px; font-weight: 700; color: {MUTE}">Then {FULL}/yr from {ENDS[:6]}</span></span></div>')
def consent():
    return (f'<div style="display: flex; gap: 10px; align-items: flex-start; padding: 12px 14px; border-radius: 14px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}">'
            f'<span style="width: 20px; height: 20px; flex: none; border-radius: 6px; background: {GREEN}; display: flex; align-items: center; justify-content: center; margin-top: 1px">{ic("check", 13, "#FFFFFF", 3)}</span>'
            f'<span style="font-size: 12.5px; font-weight: 600; color: #43504A; line-height: 1.45">I agree to pay {TODAY} today and {FULL} on {ENDS}, then every year until I cancel. I can cancel anytime in my dashboard.</span></div>')

# ---------- B1: the offer page (replaces "File your claims" + "Choose your plan") ----------
def b1():
    d = desk(h('File your 6 claims for ' + TODAY) + sub(f'Try membership for {DAYS} days. We start filing today.') + summary() + offer() + timeline() + cta() + fine())
    m = mob(h('File your 6 claims for ' + TODAY, 26, False) + sub(f'Try membership for {DAYS} days. We start filing today.', False, 14.5) + summary(True) + offer(True), cta() + f'<span style="font-size: 11.5px; font-weight: 600; color: {MUTE}; text-align: center; line-height: 1.4">Then {FULL} a year from {ENDS}. Cancel anytime.</span>')
    return d, m

# ---------- B2: payment (desktop: receipt in the side panel, checkout on the right; phone: the sheet) ----------
def b2():
    right = (f'<div style="display: flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 800; color: {MUTE}">{ic("back", 16, MUTE)}Back</div>'
             + h(f'Pay {TODAY} today', 28, False) + sub(f'{DAYS}-day trial of Claimclub membership, then {FULL} a year.', False, 15)
             + f'<span style="font-size: 12px; font-weight: 800; letter-spacing: 1px; color: #8A968F">EXPRESS CHECKOUT</span>' + wallets(False, 52, 20) + orline() + cardform() + email_row() + consent()
             + paybtn(f'Start my trial · {TODAY}') + secure())
    d = desk(right, rec=receipt(), w=520)
    under = h('File your 6 claims for ' + TODAY, 24, False) + summary(True) + offer(True)
    sheet = (f'<div style="position: absolute; inset: 0; background: rgba(10,15,13,.45); z-index: 3"></div>'
             f'<div style="position: absolute; left: 0; right: 0; bottom: 0; height: 700px; z-index: 4; background: #FFFFFF; border-radius: 28px 28px 0 0; padding: 10px 18px 30px; box-sizing: border-box; display: flex; flex-direction: column; gap: 12px; box-shadow: 0 -20px 40px rgba(10,15,13,.18)">'
             f'<span style="width: 40px; height: 5px; border-radius: 99px; background: #D5DDD8; align-self: center"></span>'
             f'<div style="display: flex; align-items: center; justify-content: space-between"><span style="display: flex; flex-direction: column; gap: 2px"><b style="font-size: 20px">Pay {TODAY} today</b><span style="font-size: 13px; color: {MUTE}; font-weight: 600">{DAYS}-day trial · then {FULL} a year</span></span>'
             f'<span style="width: 32px; height: 32px; border-radius: 99px; background: #EEF2F0; display: flex; align-items: center; justify-content: center">{ic("x", 16, INK)}</span></div>'
             + strip() + wallets(False, 50, 19) + orline() + cardform() + consent().replace('font-size: 12.5px', 'font-size: 11.5px') + paybtn(f'Start my trial · {TODAY}') + '</div>')
    m = mob(under, overlay=sheet)
    return d, m

# ---------- B3: after paying: trial in the dashboard, the reminder email, cancel ----------
def b3():
    card = (f'<div style="width: 560px; padding: 22px; border-radius: 22px; background: #FFFFFF; box-shadow: 0 0 0 1px #E3EAE6, 0 20px 40px rgba(10,15,13,.08); display: flex; flex-direction: column; gap: 14px">'
            f'<div style="display: flex; justify-content: space-between; align-items: center"><b style="font-size: 18px">Membership</b>{chip("TRIAL · 5 DAYS LEFT", "#E8EEFB", "#2C4FA8")}</div>'
            f'<div style="display: flex; flex-direction: column; gap: 6px; font-size: 14px; font-weight: 700"><div style="display: flex; justify-content: space-between"><span style="color: {MUTE}">Paid today</span><span>{TODAY}.00</span></div>'
            f'<div style="display: flex; justify-content: space-between"><span style="color: {MUTE}">Trial ends</span><span>{ENDS}</span></div><div style="display: flex; justify-content: space-between"><span style="color: {MUTE}">Then</span><span>{FULL}.00 a year</span></div></div>'
            f'<div style="height: 8px; border-radius: 99px; background: #EEF2F0; overflow: hidden"><span style="display: block; width: 29%; height: 100%; background: {GREEN}"></span></div>'
            f'<span style="font-size: 12.5px; font-weight: 600; color: {MUTE}">Your 6 claims keep being filed whatever you choose. Canceling only stops new claims after {ENDS}.</span>'
            f'<div style="display: flex; gap: 10px"><span style="flex: 1; height: 44px; border-radius: 99px; background: #EEF2F0; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 800">Cancel trial</span>'
            f'<span style="flex: 1; height: 44px; border-radius: 99px; background: {INK}; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 800">Keep membership</span></div></div>')
    email = (f'<div style="width: 560px; border-radius: 22px; background: #FFFFFF; box-shadow: 0 0 0 1px #E3EAE6, 0 20px 40px rgba(10,15,13,.08); overflow: hidden; display: flex; flex-direction: column">'
             f'<div style="padding: 14px 20px; border-bottom: 1px solid #EEF2F0; font-size: 13px; color: {MUTE}; font-weight: 700">From: Claimclub &lt;updates@claimclub.io&gt;<br>Subject: <b style="color: {INK}">Your trial ends in 2 days</b></div>'
             f'<div style="padding: 22px 20px; display: flex; flex-direction: column; gap: 12px; font-size: 14.5px; line-height: 1.55; color: #26302B"><span>Hi Ana,</span>'
             f'<span>Your Claimclub trial ends on <b>{ENDS}</b>. Unless you cancel, we will charge {FULL}.00 for a year of membership.</span>'
             f'<span>So far we have filed <b>4 of your 6 claims</b>, worth up to $1,555.</span>'
             f'<span style="display: flex; gap: 10px"><span style="padding: 10px 16px; border-radius: 99px; background: {MINT}; color: {DARK}; font-weight: 800; font-size: 14px">Keep membership</span><span style="padding: 10px 16px; border-radius: 99px; box-shadow: inset 0 0 0 1.5px {LINE}; font-weight: 800; font-size: 14px">Cancel in one tap</span></span></div></div>')
    note = lambda t, s: f'<div style="display: flex; flex-direction: column; gap: 4px; width: 560px"><span style="font-size: 13px; font-weight: 800; letter-spacing: 1px; color: #8A968F">{t}</span><span style="font-size: 14px; font-weight: 600; color: #43504A; line-height: 1.45">{s}</span></div>'
    return (f'<div style="display: flex; gap: 40px; align-items: flex-start"><div style="display: flex; flex-direction: column; gap: 14px">{note("DASHBOARD · MEMBERSHIP", "Shown in Manage membership and on the overview while the trial runs. Cancel works right here, no email or call needed.")}{card}</div>'
            f'<div style="display: flex; flex-direction: column; gap: 14px">{note("EMAIL · 2 DAYS BEFORE IT RENEWS", "Sent automatically by Stripe\'s trial reminder or our own email, with a one-tap cancel link.")}{email}</div></div>')

# ---------- B4: the two flows side by side ----------
def b4():
    A = ['7 questions', 'Estimate', 'Email', 'Membership or filing fee', 'Pick 1, 3 or 6 months', 'Pay ($7.99 or $49.99)', 'Details', 'Email code', 'Sign forms', 'Dashboard']
    B = ['7 questions', 'Estimate', 'Email', None, f'Trial offer ({TODAY}, then {FULL}/yr)', f'Pay ({TODAY})', 'Details', 'Email code', 'Sign forms', 'Dashboard']
    def col(title, steps, other, accent):
        out = ''
        for i, s in enumerate(steps):
            diff = s != other[i]
            if s is None:
                out += f'<div style="height: 52px; border-radius: 14px; border: 2px dashed #CBD5CF; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 700; color: #8A968F">Step removed</div>'; continue
            out += (f'<div style="height: 52px; border-radius: 14px; padding: 0 16px; display: flex; align-items: center; gap: 12px; background: {accent if diff else "#FFFFFF"}; color: {"#FFFFFF" if diff else INK}; box-shadow: {"none" if diff else "inset 0 0 0 1.5px " + LINE}">'
                    f'<span style="width: 26px; height: 26px; border-radius: 99px; background: {"rgba(255,255,255,.18)" if diff else "#EEF2F0"}; font-size: 12.5px; font-weight: 800; display: flex; align-items: center; justify-content: center">{i + 1}</span><b style="font-size: 15px">{s}</b></div>')
        return f'<div style="width: 420px; display: flex; flex-direction: column; gap: 10px"><b style="font-size: 20px; margin-bottom: 4px">{title}</b>{out}</div>'
    key = (f'<div style="width: 520px; display: flex; flex-direction: column; gap: 14px; font-size: 14.5px; font-weight: 600; color: #43504A; line-height: 1.5">'
           f'<b style="font-size: 20px; color: {INK}">What changes in B</b>'
           f'<span><b style="color: {INK}">One offer instead of two choices.</b> No filing fee option and no 1, 3 or 6 month picker. Everyone gets the same {DAYS}-day trial.</span>'
           f'<span><b style="color: {INK}">Lower price today, higher value later.</b> A: $7.99 now, $29.99 a month after (about $360 a year). B: {TODAY} now, {FULL} a year after ({PERMO} a month).</span>'
           f'<span><b style="color: {INK}">Same everything else.</b> Questions, estimate, details, email code, signing, bank step and dashboard stay the same, so the test only measures the offer.</span>'
           f'<span><b style="color: {INK}">Who sees which.</b> Each new visitor gets A or B at random (50/50) and keeps it on that browser. <span style="font-family: monospace">?flow=a</span> or <span style="font-family: monospace">?flow=b</span> forces one for testing.</span></div>')
    return f'<div style="display: flex; gap: 40px; align-items: flex-start">{col("Flow A · live today", A, B, "#2C4FA8")}{col("Flow B · trial offer", B, A, GREEN)}{key}</div>'

# ---------- AdminAB: Funnel page with the offer test ----------
def admin():
    th = lambda t: f'<th style="text-align: left; padding: 10px 12px; font-size: 11.5px; font-weight: 800; letter-spacing: .8px; color: #8A968F; border-bottom: 1px solid #E3EAE6">{t}</th>'
    td = lambda t, b=False, c=INK: f'<td style="padding: 12px; font-size: 14px; font-weight: {800 if b else 600}; color: {c}; border-bottom: 1px solid #EEF2F0">{t}</td>'
    # sample numbers, clearly labelled as such on the board
    rows = [('A · membership or fee', '1,204', '512', '61', '5.1%', '$611', '$90 (3 kept)', '$11.49'), ('B · $2 trial, $49/yr', '1,188', '498', '143', '12.0%', '$286', '$1,862 (38 kept)', '$15.02')]
    tbl = ('<table style="width: 100%; border-collapse: collapse"><tr>' + ''.join(th(x) for x in ['FLOW', 'VISITORS', 'REACHED OFFER', 'PAID', 'PAID / VISITOR', 'FIRST PAYMENTS', 'RENEWALS', 'REVENUE / BUYER']) + '</tr>'
           + ''.join('<tr>' + td(r[0], True) + ''.join(td(x, i == 3, GREEN if i == 3 else INK) for i, x in enumerate(r[1:])) + '</tr>' for r in rows) + '</table>')
    steps = [('Question 1', 1204, 1188), ('Estimate', 902, 895), ('Email', 731, 726), ('Offer page', 512, 498), ('Payment', 141, 233), ('Paid', 61, 143), ('Signed forms', 55, 121)]
    bars = ''
    for s, a, b in steps:
        bars += (f'<div style="display: grid; grid-template-columns: 130px 1fr 60px; gap: 10px; align-items: center; font-size: 13px; font-weight: 700"><span>{s}</span>'
                 f'<span style="display: flex; flex-direction: column; gap: 4px"><span style="height: 10px; width: {a / 12.04:.1f}%; border-radius: 99px; background: #2C4FA8"></span><span style="height: 10px; width: {b / 12.04:.1f}%; border-radius: 99px; background: {GREEN}"></span></span>'
                 f'<span style="display: flex; flex-direction: column; font-size: 11.5px; color: {MUTE}"><span>{a:,}</span><span>{b:,}</span></span></div>')
    seg = lambda items, on: '<span style="display: inline-flex; padding: 3px; border-radius: 99px; background: #EEF2F0">' + ''.join(f'<span style="padding: 6px 12px; border-radius: 99px; font-size: 13px; font-weight: 800; {"background: #FFFFFF; box-shadow: 0 1px 3px rgba(10,15,13,.12)" if i == on else "color: " + MUTE}">{t}</span>' for i, t in enumerate(items)) + '</span>'
    nav = ''.join(f'<span style="padding: 10px 14px; border-radius: 12px; font-size: 14px; font-weight: 700; {"background: #E9F6EF; color: " + GREEN if t == "Funnel" else "color: #43504A"}">{t}</span>' for t in ['Overview', 'Filing queue', 'Refunds', 'Members', 'Funnel', 'Settings'])
    return (f'<div style="width: 1500px; height: 900px; border-radius: 16px; overflow: hidden; background: #F7F9F8; box-shadow: 0 30px 80px rgba(10,15,13,.18); display: flex">'
            f'<div style="width: 230px; flex: none; background: #FFFFFF; border-right: 1px solid #E3EAE6; padding: 22px 14px; display: flex; flex-direction: column; gap: 4px"><span style="padding: 0 10px 16px">{LOGO}</span>{nav}</div>'
            f'<div style="flex: 1; padding: 30px 36px; display: flex; flex-direction: column; gap: 18px; overflow: hidden">'
            f'<div style="display: flex; justify-content: space-between; align-items: flex-end"><span style="display: flex; flex-direction: column; gap: 4px"><b style="font-size: 26px; letter-spacing: -0.6px">Funnel</b><span style="font-size: 14px; font-weight: 600; color: {MUTE}">How far visitors get, and which offer earns more.</span></span>'
            f'<span style="display: flex; gap: 10px">{seg(["All flows", "A", "B"], 0)}{seg(["Phone", "Desktop", "Both"], 2)}{seg(["7 days", "30 days", "90 days"], 1)}</span></div>'
            f'<div style="padding: 20px; border-radius: 18px; background: #FFFFFF; box-shadow: 0 0 0 1px #E3EAE6"><div style="display: flex; justify-content: space-between; margin-bottom: 8px"><b style="font-size: 17px">Offer test</b><span style="font-size: 13px; font-weight: 700; color: {MUTE}">Split 50/50 · a winner is called once each flow has about 1,000 visitors</span></div>{tbl}</div>'
            f'<div style="flex: 1; padding: 20px; border-radius: 18px; background: #FFFFFF; box-shadow: 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; gap: 12px"><div style="display: flex; justify-content: space-between"><b style="font-size: 17px">Step by step</b>'
            f'<span style="display: flex; gap: 14px; font-size: 12.5px; font-weight: 800; color: {MUTE}"><span style="display: flex; align-items: center; gap: 6px"><span style="width: 10px; height: 10px; border-radius: 3px; background: #2C4FA8"></span>Flow A</span><span style="display: flex; align-items: center; gap: 6px"><span style="width: 10px; height: 10px; border-radius: 3px; background: {GREEN}"></span>Flow B</span></span></div>{bars}</div>'
            f'</div></div>')

BOARDS = {
 'FlowB1': ('FLOW B · OFFER PAGE', f'Flow B replaces "File your claims" and "Choose your plan" with one offer: {TODAY} for a {DAYS}-day trial ({OFF} off), then {FULL} a year ({PERMO} a month). No filing fee option and no plan picker. The timeline under the card spells out today, the reminder and the renewal day, so nobody is surprised.', lambda: b1(), 1060),
 'FlowB2': ('FLOW B · PAYMENT', f'Same in-page payment sheet as flow A. The receipt shows the full {FULL} price, the {OFF} discount and {TODAY}.00 due today, plus the renewal date. A checked box records that they agree to the {FULL} renewal on {ENDS}; it is required in many states for trials that turn into paid plans.', lambda: b2(), 1060),
 'FlowB3': ('FLOW B · DURING THE TRIAL', f'After paying, the dashboard shows the trial with its end date and one-tap cancel, and an email goes out 2 days before the {FULL} charge. Their claims keep being filed even if they cancel.', lambda: (b3(), ''), 760),
 'FlowB4': ('FLOW A VS FLOW B', 'Only the offer and payment steps differ (highlighted). Everything before and after is the same, so the test measures the offer and nothing else.', lambda: (b4(), ''), 820),
 'AdminAB': ('ADMIN · FUNNEL WITH THE OFFER TEST', 'Funnel page with a flow filter (All, A, B) next to the device and date filters, and an Offer test table comparing visitors, how many reached the offer, paid, paid per visitor, first payments, renewals and revenue per buyer. The step chart puts A and B side by side at every step. Numbers here are made up to show the layout.', lambda: (admin(), ''), 1080),
}
if __name__ == '__main__':
    for name, (title, desc, fn, hgt) in BOARDS.items():
        d, m = fn()
        page = ('<div data-board style="width: 1840px; height: %dpx; box-sizing: border-box; padding: 36px 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 26px">' % hgt
                + f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #12805C">{title}</span>'
                f'<span style="font-size: 16px; color: #43504A; max-width: 1640px; line-height: 1.5; font-weight: 600">{desc}</span>'
                f'<span style="font-size: 13px; color: #8A968F; font-weight: 600">Pricing test draft, not live. Offer: {TODAY} today for {DAYS} days ({OFF} off {FULL}), then {FULL} a year. Sample member and claims.</span></div>'
                f'<div style="display: flex; gap: 46px; align-items: flex-start">{d}{m}</div></div>\n</x-dc>\n')
        open(os.path.join(OUT, f'{name}.dc.html'), 'w').write(HEAD % f'{title.title()}' + page + JS.replace('"width":1926,"height":980', '"width":1840,"height":%d' % hgt))
    print('ok')
