# Admin panel drafts (Nov 23 2026, design only). Henry: the admin shows too little at a glance.
# Three dashboard types, each desktop + phone, on the canvas page "Admin":
#   AdminA  Today: what needs you first (action cards with due times), then KPIs with sparklines,
#           queue preview with SLA, live offer test, recent activity.
#   AdminB  Ops board: claims pipeline as columns (Requested > Needs info > Filed > Review > Approved > Paid),
#           thin KPI strip on top, live activity rail on the right.
#   AdminC  Report: date range, KPIs with change vs last period, one big chart with metric tabs,
#           funnel bars, offer test and source tables, alert banner.
# Icons: Lucide (lucide-static, copied into ./lucide). Numbers are samples.
import os, re, shutil
from tierE import HEAD, JS, OUT

HERE = os.path.dirname(os.path.abspath(__file__))
LDIR = os.path.join(HERE, 'lucide')
INK, MUTE, LINE, MINT, GREEN, DARK, BG, RED, AMB = '#0A0F0D', '#5B6862', '#E3EAE6', '#3DDC97', '#12805C', '#0F3B2E', '#F3F6F4', '#C2413B', '#B7791F'

def ic(name, sz=18, col='currentColor', sw=2):
    p = os.path.join(LDIR, name + '.svg')
    if not os.path.exists(p):
        shutil.copy(f'/tmp/luc/node_modules/lucide-static/icons/{name}.svg', p)
    s = re.sub(r'<!--.*?-->', '', open(p).read(), flags=re.S).strip()
    s = re.sub(r'class="[^"]*"', '', s)
    s = s.replace('width="24"', f'width="{sz}"').replace('height="24"', f'height="{sz}"')
    s = s.replace('stroke="currentColor"', f'stroke="{col}"').replace('stroke-width="2"', f'stroke-width="{sw}"')
    return re.sub(r'\s+', ' ', s).replace('<svg ', '<svg style="flex: none; display: block" ')

def chip(t, bg, fg):
    return f'<span style="display: inline-flex; align-items: center; height: 22px; padding: 0 9px; border-radius: 99px; background: {bg}; color: {fg}; font-size: 11.5px; font-weight: 800; white-space: nowrap">{t}</span>'
ST = {'requested': ('Requested', '#EAF1FF', '#2F5BD3'), 'needs': ('Needs info', '#FFF4E0', AMB), 'filed': ('Filed', '#E9F6EF', GREEN),
      'review': ('In review', '#F1ECFF', '#6B46C1'), 'approved': ('Approved', '#E6F7F1', '#0E7A5A'), 'paid': ('Paid', DARK, '#FFFFFF'),
      'late': ('Late', '#FDECEB', RED)}
def st(k): t, b, f = ST[k]; return chip(t, b, f)
def card(body, pad=20, extra=''):
    return f'<div style="background: #FFFFFF; border-radius: 16px; box-shadow: inset 0 0 0 1px {LINE}; padding: {pad}px; display: flex; flex-direction: column; gap: 14px; {extra}">{body}</div>'
def h2(t, right=''):
    return f'<div style="display: flex; align-items: center; justify-content: space-between; gap: 10px"><b style="font-size: 15px; letter-spacing: -.2px">{t}</b>{right}</div>'
def link(t): return f'<span style="font-size: 13px; font-weight: 800; color: {GREEN}; display: inline-flex; align-items: center; gap: 4px">{t}{ic("chevron-right", 14, GREEN)}</span>'
def spark(vals, w=110, h=34, col=GREEN, fill=True):
    mx, mn = max(vals), min(vals); r = (mx - mn) or 1
    pts = [(i * w / (len(vals) - 1), h - 3 - (v - mn) / r * (h - 6)) for i, v in enumerate(vals)]
    d = 'M' + ' L'.join(f'{x:.1f} {y:.1f}' for x, y in pts)
    f = f'<path d="{d} L{w} {h} L0 {h} Z" fill="{col}" opacity=".12"/>' if fill else ''
    return f'<svg width="{w}" height="{h}" viewBox="0 0 {w} {h}" style="display: block; flex: none">{f}<path d="{d}" fill="none" stroke="{col}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/></svg>'
def delta(t, up=True, good=True):
    c = GREEN if good else RED
    return f'<span style="display: inline-flex; align-items: center; gap: 2px; font-size: 12px; font-weight: 800; color: {c}">{ic("arrow-up-right" if up else "arrow-down-right", 13, c)}{t}</span>'
def avatar(n, sz=30, bg='#E9F6EF', fg=GREEN):
    return f'<span style="width: {sz}px; height: {sz}px; flex: none; border-radius: 99px; background: {bg}; color: {fg}; display: flex; align-items: center; justify-content: center; font-size: {sz * .4:.0f}px; font-weight: 800">{n[0]}</span>'

# ---------- sample data ----------
SPARK = {'vis': [180, 210, 190, 260, 240, 300, 280, 330, 310, 360, 342, 390, 420, 401],
         'trial': [6, 9, 7, 11, 10, 14, 12, 15, 13, 17, 16, 19, 21, 18],
         'paid': [41, 43, 44, 47, 49, 50, 54, 56, 57, 61, 63, 66, 68, 71],
         'rev': [120, 140, 130, 180, 170, 210, 200, 240, 230, 260, 250, 290, 310, 300],
         'conv': [31, 33, 30, 34, 36, 35, 37, 36, 38, 39, 38, 40, 41, 41]}
QUEUE = [('Maria Lopez', 'Equifax data breach', 'Priority', 'late', '3h late'),
         ('James Carter', 'Apple Siri privacy', 'Fast', 'requested', 'Due in 5h'),
         ('Ana Ruiz', 'Visa and Mastercard ATM fees', 'Fast', 'needs', 'Replied 20m ago'),
         ('Derek Shaw', 'Google Play Store', 'Monthly', 'requested', 'Due tomorrow'),
         ('Kim Nguyen', 'RealPage rent pricing', 'Yearly', 'requested', 'Due in 2 days'),
         ('Tom Becker', 'CVS generic drug pricing', 'Yearly', 'requested', 'Due in 2 days')]
FEED = [('credit-card', GREEN, 'Kim Nguyen started a free trial', 'Offer H · Meta', '2m'),
        ('file-check', GREEN, 'Equifax claim filed for Jon Park', 'Claim ID EQX-88213', '14m'),
        ('message-square', AMB, 'Ana Ruiz answered a Needs info request', 'Visa and Mastercard', '20m'),
        ('user-plus', '#2F5BD3', 'New account: tom.b@gmail.com', 'Offer F · Google Ads', '38m'),
        ('rotate-ccw', RED, 'Trial cancelled: lee.w@yahoo.com', 'Offer F · day 2', '1h'),
        ('badge-dollar-sign', GREEN, 'Trial converted to paid, $49.99', 'Offer H · day 3', '2h'),
        ('search', '#6B46C1', 'Case finder found 3 new settlements', 'Top Class Actions, ClaimDepot', '3h')]

# ---------- shell ----------
NAV = [('layout-dashboard', 'Overview', None), ('inbox', 'Filing queue', '12'), ('sparkles', 'New cases', '5'), ('receipt', 'Refunds', '2'),
       ('users', 'Members', None), ('chart-no-axes-column', 'Funnel', None), ('settings', 'Settings', None)]
def side(on=0, light=False):
    bg, fg, mut = ('#FFFFFF', INK, '#5B6862') if light else ('#0A1F18', '#FFFFFF', '#A9BDB3')
    rows = ''
    for i, (icn, t, ct) in enumerate(NAV):
        sel = i == on
        sbg = ('#E9F6EF' if light else 'rgba(61,220,151,.16)') if sel else 'transparent'
        col = (GREEN if light else '#FFFFFF') if sel else mut
        badge = f'<span style="margin-left: auto; font-size: 11px; font-weight: 800; padding: 2px 8px; border-radius: 99px; background: {MINT}; color: {INK}">{ct}</span>' if ct else ''
        rows += f'<div style="display: flex; align-items: center; gap: 11px; padding: 10px 12px; border-radius: 11px; background: {sbg}; color: {col}; font-size: 14px; font-weight: 700">{ic(icn, 18, col)}{t}{badge}</div>'
    brd = f'border-right: 1px solid {LINE};' if light else ''
    return (f'<div style="width: 232px; flex: none; background: {bg}; {brd} padding: 22px 14px; display: flex; flex-direction: column; gap: 4px; box-sizing: border-box">'
            f'<div style="display: flex; align-items: baseline; gap: 8px; padding: 0 12px 18px"><b style="font-size: 19px; color: {fg}; letter-spacing: -.5px">claim<span style="font-weight: 500">club</span></b><span style="font-size: 10px; font-weight: 800; letter-spacing: 1.4px; color: {MINT if not light else GREEN}">ADMIN</span></div>'
            f'{rows}<div style="margin-top: auto; display: flex; align-items: center; gap: 10px; padding: 12px; color: {mut}; font-size: 12.5px; font-weight: 600">{avatar("H", 28, MINT, INK)}sidwellh17@gmail.com</div></div>')
def desk(body, on=0, light=False, h=1000):
    return (f'<div style="width: 1440px; height: {h}px; flex: none; border-radius: 18px; overflow: hidden; background: {BG}; box-shadow: 0 20px 50px rgba(10,15,13,.14); display: flex">'
            f'{side(on, light)}<div style="flex: 1; min-width: 0; padding: 28px 32px; display: flex; flex-direction: column; gap: 20px; overflow: hidden">{body}</div></div>')
def phone(body, h=1000, tabs=('Today', 'Queue', 'Members', 'Funnel', 'More'), on=0):
    icn = {'Today': 'layout-dashboard', 'Queue': 'inbox', 'Members': 'users', 'Funnel': 'chart-no-axes-column', 'More': 'menu', 'Board': 'kanban', 'Report': 'chart-line'}
    nav = ''.join(f'<div style="flex: 1; display: flex; flex-direction: column; align-items: center; gap: 3px; font-size: 10.5px; font-weight: 800; color: {GREEN if i == on else "#8A968F"}">{ic(icn[t], 20, GREEN if i == on else "#8A968F")}{t}</div>' for i, t in enumerate(tabs))
    return (f'<div style="width: 390px; height: {h}px; flex: none; border-radius: 40px; overflow: hidden; background: {BG}; box-shadow: 0 0 0 10px #1C2420, 0 24px 50px rgba(10,15,13,.25); display: flex; flex-direction: column">'
            f'<div style="height: 46px; flex: none"></div><div style="flex: 1; overflow: hidden; padding: 4px 16px 16px; display: flex; flex-direction: column; gap: 14px">{body}</div>'
            f'<div style="height: 70px; flex: none; background: #FFFFFF; border-top: 1px solid {LINE}; display: flex; align-items: center; padding-bottom: 10px">{nav}</div></div>')
def head(t, sub, right=''):
    return (f'<div style="display: flex; align-items: flex-end; justify-content: space-between; gap: 16px"><div style="display: flex; flex-direction: column; gap: 4px">'
            f'<b style="font-size: 28px; letter-spacing: -.8px">{t}</b><span style="font-size: 14px; font-weight: 600; color: {MUTE}">{sub}</span></div>{right}</div>')
def btn(t, icn=None, dark=True):
    bg, fg = (INK, '#FFFFFF') if dark else ('#FFFFFF', INK)
    return f'<span style="display: inline-flex; align-items: center; gap: 8px; height: 40px; padding: 0 16px; border-radius: 12px; background: {bg}; color: {fg}; font-size: 13.5px; font-weight: 800; box-shadow: inset 0 0 0 1px {LINE}">{ic(icn, 16, fg) if icn else ""}{t}</span>'

# =============== A: Today ===============
def a_action(icn, col, bg, n, t, sub, cta):
    return (f'<div style="flex: 1; min-width: 0; background: #FFFFFF; border-radius: 16px; box-shadow: inset 0 0 0 1px {LINE}; padding: 16px; display: flex; flex-direction: column; gap: 10px">'
            f'<div style="display: flex; align-items: center; justify-content: space-between"><span style="width: 36px; height: 36px; border-radius: 11px; background: {bg}; display: flex; align-items: center; justify-content: center">{ic(icn, 18, col)}</span><b style="font-size: 26px; letter-spacing: -.6px">{n}</b></div>'
            f'<div style="display: flex; flex-direction: column; gap: 2px"><b style="font-size: 14px">{t}</b><span style="font-size: 12.5px; font-weight: 600; color: {MUTE}">{sub}</span></div>'
            f'{link(cta)}</div>')
ACTIONS = [('inbox', RED, '#FDECEB', '12', 'Claims to file', '1 late · 3 due today', 'Open queue'),
           ('message-square', AMB, '#FFF4E0', '4', 'Member replies', 'Needs info answered', 'Review'),
           ('sparkles', '#6B46C1', '#F1ECFF', '5', 'New cases', 'From the case finder', 'Approve'),
           ('receipt', '#2F5BD3', '#EAF1FF', '2', 'Refund requests', 'Waiting on you', 'Open'),
           ('mail-warning', RED, '#FDECEB', '1', 'Email failed', 'Status email to Ana R.', 'Retry')]
def kpi(t, v, d, sp, good=True, up=True, w=110):
    return (f'<div style="flex: 1; min-width: 0; background: #FFFFFF; border-radius: 16px; box-shadow: inset 0 0 0 1px {LINE}; padding: 16px; display: flex; flex-direction: column; gap: 8px">'
            f'<span style="font-size: 12.5px; font-weight: 700; color: {MUTE}">{t}</span>'
            f'<div style="display: flex; align-items: flex-end; justify-content: space-between; gap: 8px"><div style="display: flex; flex-direction: column; gap: 3px"><b style="font-size: 26px; letter-spacing: -.8px">{v}</b><span style="display: flex; align-items: center; gap: 5px; white-space: nowrap">{delta(d, up, good)}<span style="font-size: 11.5px; font-weight: 600; color: #8A968F">vs last wk</span></span></div>{spark(sp, 84, 36, GREEN if good else RED)}</div></div>')
KPIS = [('Visitors today', '401', '12%', SPARK['vis']), ('Trials started', '18', '+6', SPARK['trial']),
        ('Paying members', '71', '+9', SPARK['paid']), ('Revenue, 7 days', '$1,842', '18%', SPARK['rev']),
        ('Trial to paid', '41%', '3 pts', SPARK['conv'])]
def qrow(r, m=False):
    n, s, plan, k, due = r
    dc = RED if k == 'late' else (AMB if 'today' in due or 'h' in due.split()[-1] else MUTE)
    if m:
        return (f'<div style="display: flex; align-items: center; gap: 12px; padding: 12px 0; border-top: 1px solid {LINE}">{avatar(n, 34)}'
                f'<div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><b style="font-size: 14px">{n}</b><span style="font-size: 12.5px; font-weight: 600; color: {MUTE}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{s}</span></div>'
                f'<div style="display: flex; flex-direction: column; align-items: flex-end; gap: 4px">{st(k)}<span style="font-size: 11.5px; font-weight: 700; color: {dc}">{due}</span></div></div>')
    return (f'<div style="display: grid; grid-template-columns: 1.3fr 1.6fr .8fr .9fr 1fr 70px; align-items: center; gap: 12px; padding: 11px 0; border-top: 1px solid {LINE}; font-size: 13.5px; font-weight: 600">'
            f'<span style="display: flex; align-items: center; gap: 10px; font-weight: 800">{avatar(n, 28)}{n}</span><span style="color: #2B3631; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{s}</span>'
            f'<span style="color: {MUTE}">{plan}</span><span>{st(k)}</span><span style="font-weight: 700; color: {dc}; white-space: nowrap">{due}</span>'
            f'<span style="justify-self: end; font-size: 13px; font-weight: 800; color: {GREEN}">File</span></div>')
def qhead():
    return (f'<div style="display: grid; grid-template-columns: 1.3fr 1.6fr .8fr .9fr 1fr 70px; gap: 12px; font-size: 11.5px; font-weight: 800; letter-spacing: .6px; color: #8A968F">'
            '<span>MEMBER</span><span>SETTLEMENT</span><span>PLAN</span><span>STATUS</span><span>DUE</span><span></span></div>')
def offer_mini(m=False):
    row = lambda k, t, v, tr, pd, w, win=False: (
        f'<div style="display: flex; flex-direction: column; gap: 8px; padding: 12px 0; border-top: 1px solid {LINE}">'
        f'<div style="display: flex; align-items: center; justify-content: space-between"><span style="display: flex; align-items: center; gap: 8px"><b style="width: 24px; height: 24px; border-radius: 8px; background: {DARK if win else "#EEF2F0"}; color: {"#FFFFFF" if win else INK}; display: flex; align-items: center; justify-content: center; font-size: 12px">{k}</b><b style="font-size: 13.5px">{t}</b></span>{chip("Leading", "#E9F6EF", GREEN) if win else ""}</div>'
        f'<div style="display: flex; gap: 14px; font-size: 12.5px; font-weight: 700; color: {MUTE}"><span>{v} visitors</span><span>{tr} trials</span><span style="color: {INK}">{pd} per visitor</span></div>'
        f'<div style="height: 6px; border-radius: 99px; background: #EEF2F0; overflow: hidden"><div style="width: {w}%; height: 100%; background: {GREEN if win else "#A9BDB3"}"></div></div></div>')
    return card(h2('Offer test, last 7 days', chip('50 / 50', '#EEF2F0', INK))
                + '<div>' + row('H', '3 days free, then $49.99/yr', '1,204', '58', '$0.71', 71, True) + row('F', '3 days free, then $19.99/mo', '1,188', '61', '$0.52', 52) + '</div>'
                + f'<span style="font-size: 12px; font-weight: 600; color: #8A968F">Per visitor = expected revenue per visitor, using trial to paid so far.</span>')
def feed(n=7, m=False):
    rows = ''.join(f'<div style="display: flex; gap: 12px; align-items: flex-start; padding: 10px 0; border-top: 1px solid {LINE}">'
                   f'<span style="width: 30px; height: 30px; flex: none; border-radius: 10px; background: #F3F6F4; display: flex; align-items: center; justify-content: center">{ic(i, 15, c)}</span>'
                   f'<div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><span style="font-size: 13px; font-weight: 700; line-height: 1.35">{t}</span><span style="font-size: 12px; font-weight: 600; color: #8A968F">{s}</span></div>'
                   f'<span style="font-size: 11.5px; font-weight: 700; color: #8A968F">{w}</span></div>' for i, c, t, s, w in FEED[:n])
    return rows
def a_desk():
    top = head('Good afternoon, Henry', 'Monday, November 23 · Live: offers F and H', btn('Search members', 'search', False))
    acts = '<div style="display: flex; gap: 14px">' + ''.join(a_action(*a) for a in ACTIONS) + '</div>'
    k = '<div style="display: flex; gap: 14px">' + ''.join(kpi(*x) for x in KPIS) + '</div>'
    q = card(h2('Next up in the filing queue', link('All 12')) + '<div>' + qhead() + ''.join(qrow(r) for r in QUEUE) + '</div>', extra='flex: 1.65; min-width: 0')
    right = '<div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 14px">' + offer_mini() + card(h2('Recent activity', link('All')) + '<div>' + feed(3) + '</div>') + '</div>'
    lbl = lambda t: f'<span style="font-size: 11.5px; font-weight: 800; letter-spacing: 1.2px; color: #8A968F; margin-bottom: -8px">{t}</span>'
    return desk(top + lbl('NEEDS YOU') + acts + lbl('HOW IT IS GOING') + k + f'<div style="display: flex; gap: 14px; align-items: flex-start">{q}{right}</div>')
def a_phone():
    top = (f'<div style="display: flex; align-items: center; justify-content: space-between"><div style="display: flex; flex-direction: column; gap: 2px"><b style="font-size: 24px; letter-spacing: -.6px">Today</b>'
           f'<span style="font-size: 13px; font-weight: 600; color: {MUTE}">Mon, Nov 23 · offers F and H</span></div>{avatar("H", 36, MINT, INK)}</div>')
    acts = card(h2('Needs you', '') + ''.join(
        f'<div style="display: flex; align-items: center; gap: 12px; padding: 4px 0"><span style="width: 34px; height: 34px; border-radius: 10px; background: {bg}; display: flex; align-items: center; justify-content: center">{ic(i, 17, c)}</span>'
        f'<div style="flex: 1; display: flex; flex-direction: column; gap: 1px"><b style="font-size: 14px">{t}</b><span style="font-size: 12px; font-weight: 600; color: {MUTE}">{s}</span></div><b style="font-size: 18px">{n}</b>{ic("chevron-right", 16, "#A9BDB3")}</div>'
        for i, c, bg, n, t, s, _ in ACTIONS[:4]), pad=16, extra='gap: 8px')
    ks = '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px">' + ''.join(
        f'<div style="background: #FFFFFF; border-radius: 14px; box-shadow: inset 0 0 0 1px {LINE}; padding: 12px; display: flex; flex-direction: column; gap: 6px"><span style="font-size: 11.5px; font-weight: 700; color: {MUTE}">{t}</span><b style="font-size: 21px; letter-spacing: -.5px">{v}</b>{spark(sp, 140, 26)}</div>'
        for t, v, _, sp in KPIS[:4]) + '</div>'
    q = card(h2('Next up', link('All 12')) + '<div style="margin-top: -6px">' + ''.join(qrow(r, True) for r in QUEUE[:3]) + '</div>', pad=16, extra='gap: 8px')
    return phone(top + acts + ks + q)

# =============== B: Ops board ===============
COLS = [('requested', 'Requested', 9, [('James Carter', 'Apple Siri privacy', 'Fast', 'Due in 5h', False), ('Derek Shaw', 'Google Play Store', 'Monthly', 'Due tomorrow', False), ('Kim Nguyen', 'RealPage rent pricing', 'Yearly', '2 days', False), ('Maria Lopez', 'Equifax data breach', 'Priority', '3h late', True)]),
        ('needs', 'Needs info', 4, [('Ana Ruiz', 'Visa and Mastercard', 'Fast', 'Replied 20m ago', False), ('Sam Ortiz', 'Toyota airbag recall', 'Yearly', 'Waiting 2 days', False), ('Lee Wong', 'CVS drug pricing', 'Monthly', 'Waiting 4 days', False)]),
        ('filed', 'Filed', 38, [('Jon Park', 'Equifax data breach', 'EQX-88213', '14m ago', False), ('Rita Hall', 'Apple Siri privacy', 'SIRI-40021', 'Yesterday', False), ('Ben Cole', 'Google Play Store', 'GP-11902', '2 days ago', False)]),
        ('review', 'In review', 11, [('Ava Moss', 'Kia window motor', 'Proof checked', '6 days', False), ('Nick Fry', 'RealPage rent pricing', 'Admin reviewing', '9 days', False)]),
        ('approved', 'Approved', 6, [('Lucy Diaz', 'T-Mobile data breach', 'Pays in Jan', '$85 est.', False), ('Omar Ali', 'Fortnite refunds', 'Pays in Feb', '$40 est.', False)]),
        ('paid', 'Paid', 14, [('Zoe King', 'Meta pixel privacy', 'Paid Nov 19', '$62', False), ('Ivan Lee', 'Wells Fargo fees', 'Paid Nov 12', '$118', False)])]
def bcard(c, k):
    n, s, a, b, late = c
    return (f'<div style="background: #FFFFFF; border-radius: 13px; box-shadow: inset 0 0 0 1px {RED if late else LINE}{", 0 1px 2px rgba(10,15,13,.04)"}; padding: 12px; display: flex; flex-direction: column; gap: 8px">'
            f'<div style="display: flex; align-items: center; gap: 8px">{avatar(n, 24)}<b style="font-size: 13px; flex: 1; white-space: nowrap">{n}</b>{ic("grip-vertical", 14, "#C5D1CB")}</div>'
            f'<span style="font-size: 12.5px; font-weight: 700; color: #2B3631; line-height: 1.35">{s}</span>'
            f'<div style="display: flex; align-items: center; justify-content: space-between; font-size: 11.5px; font-weight: 700; color: {MUTE}"><span>{a}</span><span style="color: {RED if late else MUTE}">{b}</span></div></div>')
def bcol(k, t, n, cards):
    _, bgc, fgc = ST[k]
    dot = fgc if k != 'paid' else GREEN
    return (f'<div style="flex: 1; min-width: 0; background: #EBF0ED; border-radius: 16px; padding: 12px; display: flex; flex-direction: column; gap: 10px">'
            f'<div style="display: flex; align-items: center; gap: 8px; padding: 2px 4px"><span style="width: 8px; height: 8px; border-radius: 99px; background: {dot}"></span><b style="font-size: 13.5px">{t}</b><span style="margin-left: auto; font-size: 12px; font-weight: 800; color: {MUTE}">{n}</span></div>'
            + ''.join(bcard(c, k) for c in cards) + (f'<span style="font-size: 12px; font-weight: 800; color: {MUTE}; padding: 2px 4px">+ {n - len(cards)} more</span>' if n > len(cards) else '') + '</div>')
def strip(m=False):
    items = [('Visitors today', '401', '+12%'), ('Trials today', '18', '+6'), ('Paying members', '71', '+9 wk'), ('Revenue 7d', '$1,842', '+18%'), ('Filed this week', '38', '+11'), ('Paid out to members', '$2,410', 'all time')]
    if m:
        return ('<div style="display: flex; gap: 8px; overflow: hidden; margin: 0 -16px; padding: 0 16px">' + ''.join(
            f'<div style="flex: none; background: #FFFFFF; border-radius: 12px; box-shadow: inset 0 0 0 1px {LINE}; padding: 10px 12px; display: flex; flex-direction: column; gap: 2px"><span style="font-size: 11px; font-weight: 700; color: {MUTE}">{t}</span><b style="font-size: 17px">{v}</b></div>' for t, v, _ in items[:4]) + '</div>')
    return (f'<div style="display: flex; background: #FFFFFF; border-radius: 16px; box-shadow: inset 0 0 0 1px {LINE}">' + ''.join(
        f'<div style="flex: 1; padding: 14px 18px; display: flex; flex-direction: column; gap: 3px; {"border-left: 1px solid " + LINE if i else ""}"><span style="font-size: 12px; font-weight: 700; color: {MUTE}">{t}</span>'
        f'<div style="display: flex; align-items: baseline; gap: 8px"><b style="font-size: 21px; letter-spacing: -.5px">{v}</b><span style="font-size: 12px; font-weight: 800; color: {GREEN}">{d}</span></div></div>' for i, (t, v, d) in enumerate(items)) + '</div>')
def filters():
    f = lambda t, on=False: f'<span style="display: inline-flex; align-items: center; gap: 6px; height: 34px; padding: 0 12px; border-radius: 10px; font-size: 13px; font-weight: 800; background: {INK if on else "#FFFFFF"}; color: {"#FFFFFF" if on else INK}; box-shadow: inset 0 0 0 1px {LINE}">{t}</span>'
    return ('<div style="display: flex; gap: 8px; align-items: center">' + f('All claims', True) + f('Late (1)') + f('Priority') + f('VA files') + f('Bot files') + f('Member files')
            + f'<span style="margin-left: auto; display: inline-flex; align-items: center; gap: 8px; height: 34px; padding: 0 12px; border-radius: 10px; background: #FFFFFF; box-shadow: inset 0 0 0 1px {LINE}; font-size: 13px; font-weight: 600; color: #8A968F; width: 220px">{ic("search", 15, "#8A968F")}Member or settlement</span></div>')
def b_desk():
    top = head('Claims board', 'Drag a claim to change its status. Members get the email for that status.', btn('Open next claim', 'arrow-right'))
    board_ = '<div style="display: flex; gap: 12px; align-items: flex-start">' + ''.join(bcol(*c) for c in COLS) + '</div>'
    return desk(top + strip() + filters() + board_, on=1, light=True)
def b_phone():
    top = (f'<div style="display: flex; align-items: center; justify-content: space-between"><b style="font-size: 24px; letter-spacing: -.6px">Claims board</b>{avatar("H", 36, MINT, INK)}</div>')
    seg = ('<div style="display: flex; gap: 6px; overflow: hidden; margin: 0 -16px; padding: 0 16px">' + ''.join(
        f'<span style="flex: none; display: inline-flex; align-items: center; gap: 6px; height: 34px; padding: 0 12px; border-radius: 99px; font-size: 13px; font-weight: 800; background: {INK if i == 0 else "#FFFFFF"}; color: {"#FFFFFF" if i == 0 else INK}; box-shadow: inset 0 0 0 1px {LINE}">{t} <span style="opacity: .6">{n}</span></span>'
        for i, (k, t, n, _) in enumerate(COLS)) + '</div>')
    cards = ''.join(bcard(c, 'requested') for c in COLS[0][3]) + ''.join(bcard(c, 'requested') for c in COLS[1][3][:1])
    hint = f'<span style="font-size: 12px; font-weight: 700; color: #8A968F; text-align: center">Swipe a card left or right to move it</span>'
    return phone(top + strip(True) + seg + cards + hint, tabs=('Today', 'Board', 'Members', 'Funnel', 'More'), on=1)

# =============== C: Report ===============
def ranges(on=2):
    return (f'<div style="display: inline-flex; background: #FFFFFF; border-radius: 12px; box-shadow: inset 0 0 0 1px {LINE}; padding: 4px; gap: 2px">' + ''.join(
        f'<span style="height: 32px; display: inline-flex; align-items: center; padding: 0 12px; border-radius: 9px; font-size: 13px; font-weight: 800; background: {INK if i == on else "transparent"}; color: {"#FFFFFF" if i == on else MUTE}">{t}</span>'
        for i, t in enumerate(['Today', '7 days', '30 days', '90 days', 'Custom'])) + '</div>')
def bigchart(w=760, h=240, m=False):
    vis = [210, 230, 220, 260, 280, 300, 290, 320, 350, 330, 360, 390, 370, 400, 420, 410, 440, 470, 450, 480, 510, 490, 530, 560, 540, 580, 600, 590, 620, 640]
    rev = [40, 55, 48, 60, 72, 70, 66, 80, 90, 85, 95, 110, 100, 120, 130, 125, 140, 150, 145, 160, 175, 170, 185, 200, 190, 210, 225, 220, 235, 250]
    bw = w / len(rev)
    bars = ''.join(f'<rect x="{i * bw + bw * .2:.1f}" y="{h - 20 - r / 260 * (h - 40):.1f}" width="{bw * .6:.1f}" height="{r / 260 * (h - 40):.1f}" rx="3" fill="{MINT}" opacity=".55"/>' for i, r in enumerate(rev))
    pts = ' L'.join(f'{i * bw + bw / 2:.1f} {h - 20 - v / 700 * (h - 40):.1f}' for i, v in enumerate(vis))
    grid = ''.join(f'<line x1="0" x2="{w}" y1="{20 + j * (h - 40) / 4:.1f}" y2="{20 + j * (h - 40) / 4:.1f}" stroke="{LINE}"/>' for j in range(5))
    tip_x = 22 * bw + bw / 2
    tip = '' if m else (f'<line x1="{tip_x:.0f}" x2="{tip_x:.0f}" y1="14" y2="{h - 20}" stroke="{INK}" stroke-dasharray="3 3" opacity=".4"/>'
                        f'<circle cx="{tip_x:.0f}" cy="{h - 20 - 530 / 700 * (h - 40):.1f}" r="5" fill="#FFFFFF" stroke="{DARK}" stroke-width="2.5"/>')
    return (f'<svg width="{w}" height="{h}" viewBox="0 0 {w} {h}" style="display: block">{grid}{bars}<path d="M{pts}" fill="none" stroke="{DARK}" stroke-width="2.5" stroke-linejoin="round"/>{tip}'
            f'<text x="0" y="{h - 3}" font-size="11" font-weight="700" fill="#8A968F" font-family="Manrope">Oct 25</text><text x="{w}" y="{h - 3}" font-size="11" font-weight="700" fill="#8A968F" text-anchor="end" font-family="Manrope">Today</text></svg>')
def c_kpis():
    items = [('Visitors', '12,480', '24%', True, True), ('Trials started', '512', '31%', True, True), ('Trial to paid', '41%', '3 pts', True, True),
             ('Paying members', '71', '+29', True, True), ('Revenue', '$6,920', '27%', True, True), ('Ad spend', '$4,110', '9%', True, False)]
    return ('<div style="display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap: 12px">' + ''.join(
        f'<div style="background: #FFFFFF; border-radius: 14px; box-shadow: inset 0 0 0 1px {LINE}; padding: 14px; display: flex; flex-direction: column; gap: 5px"><span style="font-size: 12px; font-weight: 700; color: {MUTE}">{t}</span><b style="font-size: 23px; letter-spacing: -.6px">{v}</b>'
        f'<span style="display: flex; align-items: center; gap: 6px">{delta(d, up, good)}<span style="font-size: 11.5px; font-weight: 600; color: #8A968F">vs prior 30d</span></span></div>' for t, v, d, up, good in items) + '</div>')
FUN = [('Started questions', 12480, '100%'), ('Saw estimate', 8610, '69%'), ('Entered email', 4230, '34%'), ('Saw offer', 3870, '31%'), ('Opened payment', 1240, '10%'), ('Started trial', 512, '4.1%'), ('Paid after trial', 196, '1.6%')]
def funnel_(m=False):
    rows = ''
    for i, (t, n, p) in enumerate(FUN):
        w = n / FUN[0][1] * 100
        drop = '' if not i else f'<span style="font-size: 11.5px; font-weight: 800; color: {RED if (1 - n / FUN[i - 1][1]) > .5 else "#8A968F"}">-{(1 - n / FUN[i - 1][1]) * 100:.0f}%</span>'
        rows += (f'<div style="display: grid; grid-template-columns: {"110px" if m else "150px"} 1fr {"52px" if m else "110px"}; align-items: center; gap: 12px">'
                 f'<span style="font-size: 13px; font-weight: 700">{t}</span><div style="height: 26px; border-radius: 8px; background: #EEF2F0; overflow: hidden"><div style="width: {max(w, 2):.1f}%; height: 100%; border-radius: 8px; background: {DARK if i == len(FUN) - 2 else GREEN}; opacity: {1 - i * .07:.2f}"></div></div>'
                 f'<span style="display: flex; justify-content: flex-end; align-items: baseline; gap: 8px"><b style="font-size: 13px">{n:,}</b>{"" if m else drop}</span></div>')
    return rows
def table(cols, rows, widths):
    gt = ' '.join(widths)
    hd = f'<div style="display: grid; grid-template-columns: {gt}; gap: 10px; font-size: 11.5px; font-weight: 800; letter-spacing: .5px; color: #8A968F; padding-bottom: 8px">' + ''.join(f'<span style="{"text-align: right" if j else ""}">{c}</span>' for j, c in enumerate(cols)) + '</div>'
    bd = ''.join(f'<div style="display: grid; grid-template-columns: {gt}; gap: 10px; padding: 10px 0; border-top: 1px solid {LINE}; font-size: 13px; font-weight: 700">' + ''.join(f'<span style="{"text-align: right" if j else "font-weight: 800"}">{c}</span>' for j, c in enumerate(r)) + '</div>' for r in rows)
    return '<div>' + hd + bd + '</div>'
def c_desk():
    top = head('Report', 'October 25 to November 23 · compared with the 30 days before', '<div style="display: flex; gap: 10px; align-items: center">' + ranges() + btn('Export CSV', 'download', False) + '</div>')
    alert = (f'<div style="display: flex; align-items: center; gap: 12px; background: #FFF4E0; border-radius: 14px; padding: 12px 16px; font-size: 13.5px; font-weight: 700; color: #6B4A10">'
             f'{ic("triangle-alert", 18, AMB)}Saw offer to Opened payment dropped from 38% to 32% on phones since Nov 20.<span style="margin-left: auto">{link("See by device")}</span></div>')
    tabs = ('<div style="display: flex; gap: 18px">' + ''.join(f'<span style="font-size: 13.5px; font-weight: 800; padding-bottom: 6px; {"box-shadow: inset 0 -2px 0 " + GREEN + "; color: " + INK if i == 0 else "color: #8A968F"}">{t}</span>' for i, t in enumerate(['Visitors and revenue', 'Trials', 'Members', 'Claims filed', 'Ad spend'])) + '</div>')
    legend = f'<div style="display: flex; gap: 16px; font-size: 12px; font-weight: 700; color: {MUTE}"><span style="display: flex; align-items: center; gap: 6px"><span style="width: 14px; height: 3px; background: {DARK}; border-radius: 2px"></span>Visitors</span><span style="display: flex; align-items: center; gap: 6px"><span style="width: 10px; height: 10px; background: {MINT}; border-radius: 3px; opacity: .7"></span>Revenue</span></div>'
    chart = card(f'<div style="display: flex; justify-content: space-between; align-items: center">{tabs}{legend}</div>' + bigchart(600, 240), extra='flex: 1.5; min-width: 0')
    fun = card(h2('Claim flow funnel', link('By offer')) + f'<div style="display: flex; flex-direction: column; gap: 9px">{funnel_()}</div>', extra='flex: 1; min-width: 0')
    off = card(h2('Offer test') + table(['OFFER', 'VISITORS', 'TRIALS', 'TO PAID', '$ / VISITOR'], [['H · $49.99/yr', '6,240', '262', '44%', '$0.92'], ['F · $19.99/mo', '6,240', '250', '38%', '$0.61']], ['1.6fr', '1fr', '1fr', '1fr', '1fr']), extra='flex: 1; min-width: 0')
    src = card(h2('By source') + table(['SOURCE', 'VISITORS', 'TRIALS', 'SPEND', 'COST PER TRIAL'], [['Meta', '7,920', '301', '$2,940', '$9.77'], ['Google Ads', '2,880', '142', '$1,170', '$8.24'], ['Organic', '1,280', '58', '$0', '$0'], ['Other', '400', '11', '$0', '$0']], ['1.4fr', '1fr', '1fr', '1fr', '1.2fr']), extra='flex: 1.3; min-width: 0')
    return desk(top + alert + c_kpis() + f'<div style="display: flex; gap: 14px; align-items: flex-start">{chart}{fun}</div><div style="display: flex; gap: 14px; align-items: flex-start">{off}{src}</div>', on=5)
def c_phone():
    top = (f'<div style="display: flex; align-items: center; justify-content: space-between"><b style="font-size: 24px; letter-spacing: -.6px">Report</b>'
           f'<span style="display: inline-flex; align-items: center; gap: 6px; height: 34px; padding: 0 12px; border-radius: 99px; background: #FFFFFF; box-shadow: inset 0 0 0 1px {LINE}; font-size: 13px; font-weight: 800">30 days{ic("chevron-down", 14, INK)}</span></div>')
    ks = '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px">' + ''.join(
        f'<div style="background: #FFFFFF; border-radius: 14px; box-shadow: inset 0 0 0 1px {LINE}; padding: 12px; display: flex; flex-direction: column; gap: 4px"><span style="font-size: 11.5px; font-weight: 700; color: {MUTE}">{t}</span><b style="font-size: 20px; letter-spacing: -.5px">{v}</b>{delta(d)}</div>'
        for t, v, d in [('Visitors', '12,480', '24%'), ('Trials', '512', '31%'), ('Trial to paid', '41%', '3 pts'), ('Revenue', '$6,920', '27%')]) + '</div>'
    ch = card(h2('Visitors and revenue') + bigchart(326, 150, True), pad=16)
    fun = card(h2('Funnel') + f'<div style="display: flex; flex-direction: column; gap: 8px">{funnel_(True)}</div>', pad=16)
    return phone(top + ks + ch + fun, tabs=('Today', 'Queue', 'Members', 'Report', 'More'), on=3)

def board(name, label, note, d, m, h=1180):
    page = (f'<div data-board style="width: 1970px; height: {h}px; box-sizing: border-box; padding: 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: {INK}; display: flex; flex-direction: column; gap: 26px">'
            f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: {GREEN}">{label}</span>'
            f'<span style="font-size: 16px; color: #43504A; font-weight: 600; max-width: 1300px; line-height: 1.45">{note}</span></div>'
            f'<div style="display: flex; gap: 60px; align-items: flex-start">{d}{m}</div></div>\n</x-dc>\n')
    open(os.path.join(OUT, f'{name}.dc.html'), 'w').write(HEAD % label.title() + page + JS.replace('"width":1926,"height":980', f'"width":1970,"height":{h}'))

if __name__ == '__main__':
    board('AdminA', 'ADMIN · A · TODAY', 'Opens on what needs you: claims to file (late ones in red), member replies, new cases, refunds and failed emails, each one tap away. Below that, five numbers with 14-day trend lines, the next claims in the queue with their due time, the live offer test and recent activity. Sample numbers.', a_desk(), a_phone())
    board('AdminB', 'ADMIN · B · OPS BOARD', 'The claims pipeline as columns, Requested to Paid, with counts. Drag a card to change its status (members get that status email). Late claims have a red edge. One strip of numbers on top and quick filters for late, Priority and who files it. On phones, swipe cards between columns. Sample numbers.', b_desk(), b_phone())
    board('AdminC', 'ADMIN · C · REPORT', 'A growth report: pick a date range, six numbers compared with the period before, one big chart with tabs, the claim flow funnel with the drop at each step, the offer test and results by ad source with cost per trial. An alert line calls out anything that moved a lot. Sample numbers.', c_desk(), c_phone())
    print('ok')
