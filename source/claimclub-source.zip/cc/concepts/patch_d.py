s=open('make.py').read()
def rep(o,n):
    global s
    assert o in s,o[:90]; s=s.replace(o,n,1)
bg={'#FFFFFF':'#161E1B','#F3F6F4':'#0E1412','#EEF2F0':'#232D29','#EEF2F8':'#18202C','#DCE4F3':'#26324A','#E9F6EF':'#12301F','#EAF2EE':'#1C2B25','#E3EAE6':'#2A3430','#E1E6F0':'#283042','#DDE5E0':'#2A3430','#FFF4DB':'#3A2E12','#E8EEFB':'#1C2740','#E3EAE6':'#2A3430'}
fg={'#0A0F0D':'#E9F1ED','#5B6862':'#9AA8A1','#43504A':'#B3C0B9','#8A968F':'#7F8C86','#22324A':'#D0DBEF','#5B6A85':'#95A5C4','#8A93A6':'#7A8499','#12805C':'#4FD69C','#0F3B2E':'#7FD9AA','#6B4600':'#F2C46B','#8A5A00':'#F0B850','#2C4FA8':'#9DB5F2','#17603F':'#7FD9AA'}
L=['.dk{background:#0E1412 !important;color:#E9F1ED !important;color-scheme:dark}']
for a,b in bg.items():
    for sp in [' ','']:
        L.append(f'.dk :not(img)[style*="background:{sp}{a}"]{{background:{b} !important}}')
for a,b in fg.items():
    for sp in [' ','']:
        L.append(f'.dk [style*=";{sp}color:{sp}{a}"],.dk [style^="color:{sp}{a}"]{{color:{b} !important}}')
# dark buttons become light
for sp in [' ','']:
    L.append(f'.dk :not(.note)[style*="background:{sp}#0A0F0D"]{{background:#E9F1ED !important;color:#0A0F0D !important}}')
# keep dark text on mint
for sp in [' ','']:
    L.append(f'.dk [style*="background:{sp}#3DDC97"],.dk [style*="background:{sp}#3DDC97"] *{{color:#0A0F0D !important}}')
L+=['.dk [style*="0 0 0 1px #E3EAE6"],.dk [style*="0 0 0 1px #DCE2EE"]{box-shadow:0 0 0 1px #26302C !important}',
'.dk [style*="inset 0 0 0 1px #E3EAE6"],.dk [style*="inset 0 0 0 1px #DDE5E0"]{box-shadow:inset 0 0 0 1px #2E3A35 !important}',
'.dk [style*="inset 0 0 0 1.5px #DDE5E0"]{box-shadow:inset 0 0 0 1.5px #34413B !important}',
'.dk [style*="inset 0 0 0 2px #C9D3CD"]{box-shadow:inset 0 0 0 2px #3C4944 !important}',
'.dk [style*="solid #EEF2F0"],.dk [style*="solid #E3EAE6"],.dk [style*="solid #DDE5E0"]{border-color:#26302C !important}',
'.dk .arow{background:#161E1B}.dk .trow{border-top-color:#232B38}',
'.dk svg [fill="#0A0F0D"]{fill:#E9F1ED}',
'.dk .note{box-shadow:0 0 0 1px #2A3530,0 24px 60px rgba(0,0,0,.5) !important}',
'.dk .shWrap{background:rgba(0,0,0,.6) !important}',
'.dk img[style*="background: #FFFFFF"]{box-shadow:none !important}',
'.dk .scroll{scrollbar-color:#34413B transparent}']
DARK='\\n'.join(L)
# A head with dark css + root class
rep("A=HEAD%('Dashboard option A · To-do inbox',A_CSS)+ROOT+sideA()","A=HEAD%('Dashboard option A · To-do inbox',A_CSS+'\\n'+DARK_CSS)+ROOT.replace('<div style=','<div class=\"{{ rootCls }}\" style=',1)+sideA()")
rep("# ---------------- A: Inbox ----------------","# ---------------- A: Inbox ----------------\nDARK_CSS='"+DARK+"'")
# state + values
rep("view: 'dash', scale: 'm',","view: 'dash', scale: 'm', theme: 'light',")
rep("      zoomSt:","""      rootCls: (s.theme === 'dark' || (s.theme === 'system' && typeof matchMedia !== 'undefined' && matchMedia('(prefers-color-scheme: dark)').matches)) ? 'dk' : '',
      themes: [['light', 'Light', '#F3F6F4', '#FFFFFF', '#0F3B2E'], ['dark', 'Dark', '#0E1412', '#161E1B', '#0F3B2E'], ['system', 'System', 'linear-gradient(90deg,#F3F6F4 50%,#0E1412 50%)', 'linear-gradient(90deg,#FFFFFF 50%,#161E1B 50%)', '#0F3B2E']].map(([k, t, a, b, c]) => ({ t, on: s.theme === k, tap: () => this.setState({ theme: k }),
        st: 'flex:1;display:flex;flex-direction:column;align-items:center;gap:8px;padding:10px;border-radius:14px;font-weight:800;font-size:13px;' + (s.theme === k ? 'background:#EAF2EE;color:#0F3B2E;box-shadow:inset 0 0 0 2px #12805C' : 'background:#FFFFFF;color:#43504A;box-shadow:inset 0 0 0 1.5px #DDE5E0'),
        pv: 'width:100%;height:46px;border-radius:9px;display:flex;flex-direction:column;gap:5px;padding:7px;box-sizing:border-box;background:' + a, pv1: 'height:9px;width:60%;border-radius:4px;background:' + c, pv2: 'flex:1;border-radius:5px;background:' + b })),
      zoomSt:""")
# settings card
rep("""      <section style="background: #FFFFFF; border-radius: 18px; box-shadow: 0 0 0 1px #E3EAE6; padding: 6px 16px">""","""      <section style="background: #FFFFFF; border-radius: 18px; box-shadow: 0 0 0 1px #E3EAE6; padding: 16px; display: flex; flex-direction: column; gap: 12px">
        <div style="display: flex; flex-direction: column; gap: 2px"><h2 style="margin: 0; font-size: 16px">Appearance</h2><span style="font-size: 12px; color: #5B6862">Light, dark, or match your device.</span></div>
        <div style="display: flex; gap: 10px"><sc-for list="{{ themes }}" as="t" hint-placeholder-count="3"><button onClick="{{ t.tap }}" aria-pressed="{{ t.on }}" style="{{ t.st }}"><span style="{{ t.pv }}"><span style="{{ t.pv1 }}"></span><span style="{{ t.pv2 }}"></span></span>{{ t.t }}</button></sc-for></div>
      </section>
      <section style="background: #FFFFFF; border-radius: 18px; box-shadow: 0 0 0 1px #E3EAE6; padding: 6px 16px">""")
open('make.py','w').write(s); print('ok')
