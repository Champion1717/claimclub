# "File your claims" page drafts (Nov 15 2026): the choice page now carries the membership perks.
# Membership is the main option, the one-time filing fee is second, and the claims list is a short summary.
# Replaces the separate perks screens. Writes Choice1..3.dc.html (desktop and phone side by side).
import os
from how4 import HEAD, JS, OUT
from perksD import ic, tile, phone, LU, INK, MUTE, LINE, MINT, GREEN, DARK

LU.update({
    'file': 'M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z M14 2v4a2 2 0 0 0 2 2h4 M9 15l2 2 4-4',
    'refund': 'M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8 M3 3v5h5',
    'star': 'M11.5 2.7a.5.5 0 0 1 .9 0l2.3 4.7a2 2 0 0 0 1.5 1.1l5.2.8a.5.5 0 0 1 .3.9l-3.8 3.6a2 2 0 0 0-.6 1.8l.9 5.2a.5.5 0 0 1-.8.5l-4.6-2.4a2 2 0 0 0-1.9 0l-4.6 2.4a.5.5 0 0 1-.8-.5l.9-5.2a2 2 0 0 0-.6-1.8L1.8 10.2a.5.5 0 0 1 .3-.9l5.2-.8a2 2 0 0 0 1.5-1.1z',
})
CL = [('A', '#111111'), ('C', '#CC0000'), ('V', '#1A1F71'), ('G', '#01875F'), ('T', '#B5121B'), ('R', '#3D5AFE')]
# (icon, membership perk, filing fee gets it?)
PERKS = [('file', 'Files your 6 claims, no filing fee', True),
         ('star', 'Every new claim you qualify for, filed for you', False),
         ('bell', 'An alert the day a new claim opens', False),
         ('search', 'All 294 settlements, plus local ones near you', False),
         ('dash', 'Track every claim in one dashboard', True),
         ('refund', 'Refund Club: fight bad charges, cancel subscriptions', False)]
LOGO = '<span style="font-size: 20px; font-weight: 800; letter-spacing: -0.5px">claim<span style="font-weight: 500">club</span><span style="color: #12805C">.io</span></span>'

def logos(sz=26, n=6):
    return '<span style="display: flex">' + ''.join(f'<span style="margin-left: {0 if i == 0 else -7}px; border-radius: 9px; box-shadow: 0 0 0 2px #FFFFFF">{tile(c, bg, sz)}</span>' for i, (c, bg) in enumerate(CL[:n])) + '</span>'
def summary_strip(dark=False, m=False):
    # the shortened "file your claims" part: logos, count, total
    fg, sub = ('#FFFFFF', 'rgba(255,255,255,.72)') if dark else (INK, MUTE)
    return (f'<div style="display: flex; align-items: center; gap: 12px; padding: 12px 14px; border-radius: 16px; background: {"rgba(255,255,255,.1)" if dark else "#FFFFFF"}; box-shadow: {"none" if dark else "inset 0 0 0 1.5px " + LINE}">'
            f'{logos(24 if m else 26, 3 if m else 6)}<span style="flex: 1; min-width: 0; display: flex; flex-direction: column"><b style="font-size: {14 if m else 15}px; color: {fg}">6 claims ready</b><span style="font-size: 12.5px; font-weight: 600; color: {sub}; white-space: nowrap">{"Apple, CVS and 4 more" if m else "Apple, CVS, Visa &amp; Mastercard and 3 more"}</span></span>'
            f'<span style="display: flex; flex-direction: column; align-items: flex-end"><span style="font-size: 11px; font-weight: 700; color: {sub}">Up to</span><b style="font-size: 20px; letter-spacing: -0.5px; color: {MINT if dark else GREEN}">$1,400</b></span></div>')
def perk_rows(color=INK, check_bg=GREEN, size=14.5, gap=11, icons=False):
    out = ''
    for k, t, _ in PERKS:
        mark = (f'<span style="width: 30px; height: 30px; flex: none; border-radius: 9px; background: rgba(61,220,151,.16); display: flex; align-items: center; justify-content: center">{ic(k, 16, MINT if color == "#FFFFFF" else GREEN, 2.3)}</span>' if icons
                else f'<span style="width: 20px; height: 20px; flex: none; border-radius: 99px; background: {check_bg}; display: flex; align-items: center; justify-content: center">{ic("check", 12, "#FFFFFF" if check_bg == GREEN else DARK, 3)}</span>')
        out += f'<div style="display: flex; align-items: center; gap: 10px; font-size: {size}px; font-weight: 700; color: {color}; line-height: 1.35">{mark}<span>{t}</span></div>'
    return f'<div style="display: flex; flex-direction: column; gap: {gap}px">{out}</div>'
def mint_btn(t, h=56, fs=17):
    return f'<div style="height: {h}px; flex: none; border-radius: 99px; background: {MINT}; color: {DARK}; display: flex; align-items: center; justify-content: center; gap: 8px; font-size: {fs}px; font-weight: 800; box-shadow: 0 10px 24px rgba(61,220,151,.3)">{t}</div>'
def plan_seg(dark=True, m=False):
    P = [('1 month', '$7.99'), ('3 months', '$18.99'), ('6 months', '$29.99')]
    out = ''
    for i, (a, b) in enumerate(P):
        on = i == 0
        bg = ('#FFFFFF' if on else 'transparent') if dark else ('#FFFFFF' if on else 'transparent')
        out += (f'<span style="flex: 1; padding: {7 if m else 8}px 4px; border-radius: 11px; text-align: center; display: flex; flex-direction: column; gap: 1px; background: {bg}; {"box-shadow: 0 1px 3px rgba(10,15,13,.18)" if on else ""}">'
                f'<b style="font-size: {12.5 if m else 13.5}px; color: {INK if on else ("rgba(255,255,255,.85)" if dark else INK)}">{a}</b><span style="font-size: 11.5px; font-weight: 700; color: {GREEN if on else ("rgba(255,255,255,.6)" if dark else MUTE)}">{b} first</span></span>')
    return f'<div style="display: flex; gap: 4px; padding: 4px; border-radius: 14px; background: {"rgba(255,255,255,.12)" if dark else "#E6ECE8"}">{out}</div>'
def fee_option(dense=False):
    return (f'<div style="display: flex; align-items: center; gap: 12px; padding: {12 if dense else 14}px 16px; border-radius: 16px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}">'
            f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><b style="font-size: 14.5px; color: {INK}">Just file these 6 claims</b><span style="font-size: 12.5px; font-weight: 600; color: {MUTE}">One-time filing fee. No updates or new claims.</span></span>'
            f'<span style="flex: none; padding: 8px 14px; border-radius: 99px; box-shadow: inset 0 0 0 1.5px {INK}; font-size: 14px; font-weight: 800; color: {INK}">$49.99</span></div>')
def keep_line(dark=False):
    return f'<div style="display: flex; align-items: center; justify-content: center; gap: 6px; font-size: 12.5px; font-weight: 700; color: {"rgba(255,255,255,.7)" if dark else MUTE}">{ic("check", 13, MINT if dark else GREEN, 3)}You keep 100% of every payout either way</div>'

def desk(main, w=640, center=False):
    return (f'<div style="width: 1280px; height: 900px; flex: none; border-radius: 16px; overflow: hidden; background: #F7F9F8; box-shadow: 0 30px 80px rgba(10,15,13,.18); display: flex; flex-direction: column">'
            f'<div style="height: 64px; flex: none; display: flex; align-items: center; justify-content: space-between; padding: 0 28px; border-bottom: 1px solid #E8EEEA; background: #FFFFFF">'
            f'<span style="display: flex; align-items: center; gap: 14px"><span style="width: 34px; height: 34px; border-radius: 99px; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; align-items: center; justify-content: center">{ic("back", 17, INK, 2.4)}</span>{LOGO}</span>'
            f'<span style="font-size: 13px; font-weight: 800; color: {MUTE}">EN · ES</span></div>'
            f'<div style="flex: 1; overflow: hidden; display: flex; justify-content: center; align-items: {"center" if center else "flex-start"}; padding: 34px 0"><div style="width: {w}px; display: flex; flex-direction: column; gap: 16px">{main}</div></div></div>')
def mob(inner, foot):
    return phone(f'<div style="padding: 56px 18px 0; display: flex; align-items: center; gap: 12px"><span style="width: 34px; height: 34px; border-radius: 99px; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; align-items: center; justify-content: center">{ic("back", 17, INK, 2.4)}</span>{LOGO}</div>'
                 f'<div style="flex: 1; overflow: hidden; padding: 12px 18px 0; display: flex; flex-direction: column; gap: 12px">{inner}</div>'
                 f'<div style="padding: 12px 18px 30px; background: #FFFFFF; box-shadow: 0 -10px 24px rgba(10,15,13,.06); display: flex; flex-direction: column; gap: 8px">{foot}</div>', bg='#F3F6F4')
def h(t, sz=30): return f'<b style="font-size: {sz}px; line-height: 1.12; letter-spacing: -0.9px; color: {INK}">{t}</b>'
def p(t, sz=15): return f'<span style="font-size: {sz}px; line-height: 1.5; font-weight: 600; color: {MUTE}; margin-top: -6px">{t}</span>'

# ---------- 1: one big membership card, fee as a quiet row under it ----------
def card1(m=False):
    return (f'<div style="border-radius: 24px; padding: {18 if m else 24}px; background: radial-gradient(120% 80% at 100% 0%, rgba(61,220,151,.22), transparent 55%), linear-gradient(160deg, #134A39, #0A2A20); display: flex; flex-direction: column; gap: {14 if m else 16}px; box-shadow: 0 18px 40px rgba(10,42,32,.25)">'
            f'<div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 10px"><span style="display: flex; flex-direction: column; gap: 4px">'
            f'<span style="align-self: flex-start; padding: 4px 10px; border-radius: 99px; background: {MINT}; color: {DARK}; font-size: 11.5px; font-weight: 800; letter-spacing: .4px">MOST POPULAR</span>'
            f'<b style="font-size: {22 if m else 26}px; color: #FFFFFF; letter-spacing: -0.6px">Membership</b></span>'
            f'<span style="display: flex; flex-direction: column; align-items: flex-end"><b style="font-size: {30 if m else 36}px; color: #FFFFFF; letter-spacing: -1px; line-height: 1">$7.99</b><span style="font-size: 12px; font-weight: 700; color: rgba(255,255,255,.7)">first month, then $29.99</span></span></div>'
            + perk_rows('#FFFFFF', MINT, 13.5 if m else 15, 9 if m else 11) + (plan_seg(True, m) if not m else '') + (mint_btn('Join and file free · $7.99') if not m else '') + '</div>')
def v1():
    d = desk(h('File your 6 claims') + p('Pick how you want us to file. Either way, every payout goes straight to you.') + summary_strip() + card1() + fee_option() + keep_line())
    mm = mob(h('File your 6 claims', 26) + summary_strip(m=True) + card1(True) + fee_option(True),
             plan_seg(False, True) + mint_btn('Join and file free · $7.99', 54, 16) + f'<span style="text-align: center; font-size: 12px; color: {MUTE}; font-weight: 600">Then $29.99 a month. Cancel anytime.</span>')
    return d, mm

# ---------- 2: side by side, membership taller and highlighted, checks and crosses per perk ----------
def col(member, m=False):
    rows = ''
    for k, t, fee in PERKS:
        has = member or fee
        rows += (f'<div style="display: flex; align-items: flex-start; gap: 9px; font-size: {13 if m else 14}px; font-weight: 700; line-height: 1.35; color: {INK if has else "#A0AAA5"}">'
                 + (f'<span style="width: 18px; height: 18px; flex: none; margin-top: 1px; border-radius: 99px; background: {GREEN}; display: flex; align-items: center; justify-content: center">{ic("check", 11, "#FFFFFF", 3.2)}</span>' if has
                    else f'<span style="width: 18px; height: 18px; flex: none; margin-top: 1px; border-radius: 99px; background: #EEF1EF; display: flex; align-items: center; justify-content: center">{ic("x", 10, "#A0AAA5", 3)}</span>')
                 + f'<span style="{"text-decoration: line-through" if not has else ""}">{t if member or k != "file" else "Files your 6 claims"}</span></div>')
    if member:
        return (f'<div style="flex: 1.25; border-radius: 22px; padding: 20px; background: #FFFFFF; box-shadow: 0 0 0 2.5px {GREEN}, 0 16px 36px rgba(18,128,92,.16); display: flex; flex-direction: column; gap: 14px; position: relative">'
                f'<span style="position: absolute; top: -12px; left: 20px; padding: 4px 10px; border-radius: 99px; background: {GREEN}; color: #FFFFFF; font-size: 11.5px; font-weight: 800; letter-spacing: .4px">BEST VALUE</span>'
                f'<span style="display: flex; justify-content: space-between; align-items: baseline"><b style="font-size: 20px">Membership</b><span><b style="font-size: 28px; letter-spacing: -0.8px">$7.99</b><span style="font-size: 12px; font-weight: 700; color: {MUTE}"> first month</span></span></span>'
                f'<span style="font-size: 12.5px; font-weight: 700; color: {MUTE}; margin-top: -10px">Then $29.99 a month. Cancel anytime.</span>{rows}<div style="flex: 1"></div>{mint_btn("Join and file free", 52, 16)}</div>')
    return (f'<div style="flex: 1; border-radius: 22px; padding: 20px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; flex-direction: column; gap: 14px; margin-top: 18px">'
            f'<span style="display: flex; justify-content: space-between; align-items: baseline"><b style="font-size: 18px">Filing fee</b><b style="font-size: 24px; letter-spacing: -0.6px">$49.99</b></span>'
            f'<span style="font-size: 12.5px; font-weight: 700; color: {MUTE}; margin-top: -10px">One time, just these 6 claims.</span>{rows}<div style="flex: 1"></div>'
            f'<div style="height: 52px; border-radius: 99px; box-shadow: inset 0 0 0 1.5px {INK}; display: flex; align-items: center; justify-content: center; font-size: 15px; font-weight: 800">Pay $49.99 once</div></div>')
def v2():
    head = (f'<div style="display: flex; flex-direction: column; align-items: center; gap: 6px; text-align: center">{h("File your 6 claims", 34)}'
            f'<span style="font-size: 16px; line-height: 1.5; font-weight: 600; color: {MUTE}">Up to $1,400 is waiting. Choose how we file it.</span></div>')
    d = desk(head + summary_strip() + f'<div style="display: flex; gap: 16px; align-items: stretch; margin-top: 8px">{col(True)}{col(False)}</div>' + keep_line(), w=760, center=True)
    return d, None

# ---------- Draft 2, three phone iterations ----------
def m2_foot(sub='Then $29.99 a month. Cancel anytime.'):
    return mint_btn('Join and file free · $7.99', 54, 16) + f'<span style="text-align: center; font-size: 12px; color: {MUTE}; font-weight: 600">{sub}</span>'
def m2a():
    # stacked: full membership card, then a compact fee card that lists what it leaves out
    member = col(True, True).replace('flex: 1.25;', '').replace(mint_btn("Join and file free", 52, 16), '').replace('<div style="flex: 1"></div>', '')
    fee = (f'<div style="border-radius: 18px; padding: 14px 16px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; flex-direction: column; gap: 6px">'
           f'<span style="display: flex; justify-content: space-between; align-items: center"><b style="font-size: 15px">Filing fee</b><span style="padding: 6px 12px; border-radius: 99px; box-shadow: inset 0 0 0 1.5px {INK}; font-size: 13.5px; font-weight: 800">$49.99 once</span></span>'
           f'<span style="font-size: 12.5px; font-weight: 600; color: {MUTE}; line-height: 1.45">Just these 6 claims. No new claims, alerts, all settlements or Refund Club.</span></div>')
    return mob(h('File your 6 claims', 26) + summary_strip(m=True) + f'<div style="margin-top: 8px">{member}</div>' + fee, m2_foot())
def m2b():
    # comparison table: one row per perk, a column each for membership and the fee
    head = (f'<div style="display: grid; grid-template-columns: 1fr 74px 74px; align-items: end; gap: 6px; padding: 0 12px">'
            f'<span></span><span style="text-align: center; padding: 8px 0; border-radius: 12px 12px 0 0; background: {GREEN}; color: #FFFFFF; display: flex; flex-direction: column"><b style="font-size: 12px">Member</b><span style="font-size: 12px; font-weight: 800">$7.99</span></span>'
            f'<span style="text-align: center; padding: 8px 0; color: {MUTE}; display: flex; flex-direction: column"><b style="font-size: 12px">Fee</b><span style="font-size: 12px; font-weight: 800">$49.99</span></span></div>')
    yes = f'<span style="width: 22px; height: 22px; border-radius: 99px; background: {GREEN}; display: flex; align-items: center; justify-content: center">{ic("check", 12, "#FFFFFF", 3.2)}</span>'
    no = f'<span style="width: 22px; height: 22px; border-radius: 99px; background: #EEF1EF; display: flex; align-items: center; justify-content: center">{ic("x", 11, "#A0AAA5", 3)}</span>'
    rows = ''.join(f'<div style="display: grid; grid-template-columns: 1fr 74px 74px; align-items: center; gap: 6px; padding: 10px 12px; {"border-top: 1px solid #EEF1EF" if i else ""}">'
                   f'<span style="font-size: 13px; font-weight: 700; line-height: 1.35">{t if k != "file" else "Files your 6 claims"}</span>'
                   f'<span style="display: flex; justify-content: center; background: #F1FAF5; align-self: stretch; align-items: center; margin: -10px 0">{yes}</span><span style="display: flex; justify-content: center">{yes if fee else no}</span></div>'
                   for i, (k, t, fee) in enumerate(PERKS))
    table = f'<div style="display: flex; flex-direction: column">{head}<div style="border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}; overflow: hidden">{rows}</div></div>'
    foot = (mint_btn('Join and file free · $7.99', 54, 16)
            + f'<div style="height: 48px; border-radius: 99px; box-shadow: inset 0 0 0 1.5px {INK}; display: flex; align-items: center; justify-content: center; font-size: 15px; font-weight: 800">Pay $49.99 once instead</div>')
    return mob(h('File your 6 claims', 26) + summary_strip(m=True) + table, foot)
def m2c():
    # swipe cards: membership card in view, the fee card peeks in from the right
    member = col(True, True).replace('flex: 1.25;', 'width: 300px; flex: none;').replace(mint_btn("Join and file free", 52, 16), '')
    fee = col(False, True).replace('flex: 1;', 'width: 300px; flex: none;').replace('margin-top: 18px', 'margin-top: 0')
    dots = f'<div style="display: flex; justify-content: center; gap: 6px"><span style="width: 20px; height: 7px; border-radius: 99px; background: {GREEN}"></span><span style="width: 7px; height: 7px; border-radius: 99px; background: {LINE}"></span></div>'
    rail = f'<div style="display: flex; gap: 12px; margin: 0 -18px; padding: 14px 18px 0; overflow: hidden">{member}{fee}</div>'
    return mob(h('File your 6 claims', 26) + summary_strip(m=True) + rail + dots, m2_foot('Swipe to see the $49.99 filing fee.'))

# ---------- 3: dark perks grid (icon tiles), receipt line on top, fee as a text link ----------
def grid(m=False):
    cells = ''.join(f'<div style="padding: {12 if m else 16}px; border-radius: 18px; background: rgba(255,255,255,.08); display: flex; flex-direction: column; gap: 8px">'
                    f'<span style="width: {32 if m else 38}px; height: {32 if m else 38}px; border-radius: 11px; background: rgba(61,220,151,.18); display: flex; align-items: center; justify-content: center">{ic(k, 17 if m else 20, MINT, 2.3)}</span>'
                    f'<span style="font-size: {12.5 if m else 14}px; font-weight: 700; line-height: 1.35; color: #FFFFFF">{t}</span></div>' for k, t, _ in PERKS)
    return f'<div style="display: grid; grid-template-columns: repeat({2 if m else 3}, minmax(0, 1fr)); gap: {8 if m else 10}px">{cells}</div>'
def v3():
    dark = 'radial-gradient(100% 60% at 100% 0%, rgba(61,220,151,.18), transparent 55%), linear-gradient(170deg, #0F3B2E, #08221A)'
    main = (f'<div style="border-radius: 28px; padding: 28px; background: {dark}; display: flex; flex-direction: column; gap: 18px">'
            f'<span style="font-size: 12.5px; font-weight: 800; letter-spacing: 1.2px; color: {MINT}">JOIN CLAIMCLUB</span>'
            f'<b style="font-size: 32px; line-height: 1.1; letter-spacing: -1px; color: #FFFFFF; margin-top: -8px">File these 6 claims free,<br>and every one after.</b>'
            + summary_strip(True) + grid() + plan_seg(True) + mint_btn('Join for $7.99 and file free') +
            f'<span style="text-align: center; font-size: 12.5px; font-weight: 600; color: rgba(255,255,255,.7); margin-top: -6px">Then $29.99 a month. Cancel anytime. You keep 100% of every payout.</span></div>'
            f'<div style="display: flex; justify-content: center; gap: 6px; font-size: 14.5px; font-weight: 700; color: {MUTE}">Only want these 6 filed?<span style="color: {INK}; text-decoration: underline; text-underline-offset: 3px">Pay $49.99 once</span></div>')
    d = desk(main, w=720)
    mm = phone(f'<div style="padding: 56px 18px 0; display: flex; align-items: center; gap: 12px"><span style="width: 34px; height: 34px; border-radius: 99px; background: rgba(255,255,255,.12); display: flex; align-items: center; justify-content: center">{ic("back", 17, "#FFFFFF", 2.4)}</span>'
               f'<span style="font-size: 20px; font-weight: 800; letter-spacing: -0.5px; color: #FFFFFF">claim<span style="font-weight: 500">club</span><span style="color: {MINT}">.io</span></span></div>'
               f'<div style="flex: 1; overflow: hidden; padding: 14px 18px 0; display: flex; flex-direction: column; gap: 14px">'
               f'<b style="font-size: 27px; line-height: 1.1; letter-spacing: -0.9px; color: #FFFFFF">File these 6 claims free, and every one after.</b>' + summary_strip(True, True) + grid(True) + '</div>'
               f'<div style="padding: 12px 18px 30px; display: flex; flex-direction: column; gap: 9px">' + mint_btn('Join for $7.99 and file free', 54, 16)
               + f'<span style="text-align: center; font-size: 13px; font-weight: 700; color: rgba(255,255,255,.75)">Only these 6? <span style="color: #FFFFFF; text-decoration: underline">Pay $49.99 once</span></span></div>', bg=dark)
    return d, mm

INFO = {
 1: ('CHOICE PAGE · DRAFT 1 · MEMBERSHIP CARD', 'One big dark membership card with every perk, the plan switch and the main button. The claims are one short line on top (logos, count, Up to $1,400). The filing fee sits underneath as a quiet white row.', v1),
 2: ('CHOICE PAGE · DRAFT 2 · SIDE BY SIDE (CENTERED)', 'Membership and filing fee next to each other, centered on the page with the heading centered above. Membership is taller, outlined in green and marked Best value; the fee column shows what it does not include (crossed out). Phone versions are on the board to the right.', v2),
 3: ('CHOICE PAGE · DRAFT 3 · DARK PERKS GRID', 'The whole page sells membership: headline "File these 6 claims free, and every one after", the claims line, a grid of the 6 perks, plan switch and button. The filing fee is a text link at the bottom.', v3),
}
def board(name, title, desc, body, w, h=1110):
    page = (f'<div data-board style="width: {w}px; height: {h}px; box-sizing: border-box; padding: 36px 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 26px">'
            f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #12805C">{title}</span>'
            f'<span style="font-size: 16px; color: #43504A; max-width: {w - 120}px; line-height: 1.5; font-weight: 600">{desc}</span>'
            '<span style="font-size: 13px; color: #8A968F; font-weight: 600">Replaces the separate perks screens: email &gt; this page &gt; payment sheet. Sample claims; the live page uses their own matches and total.</span></div>'
            f'<div style="display: flex; gap: 46px; align-items: flex-start">{body}</div></div>\n</x-dc>\n')
    open(os.path.join(OUT, name + '.dc.html'), 'w').write(HEAD % title + page + JS.replace('"width":1926,"height":980', f'"width":{w},"height":{h}'))
if __name__ == '__main__':
    for n, (title, desc, fn) in INFO.items():
        d, mm = fn()
        if mm is None: board(f'Choice{n}', title, desc, d, 1360)
        else: board(f'Choice{n}', title, desc, d + mm, 1840)
    lab = lambda t, ph: f'<div style="display: flex; flex-direction: column; gap: 18px; align-items: center"><span style="font-size: 13px; font-weight: 800; letter-spacing: 1px; color: #8A968F">{t}</span>{ph}</div>'
    board('Choice2M', 'CHOICE PAGE · DRAFT 2 ON PHONES · 3 ITERATIONS',
          'A: stacked. The full membership card, then a small filing fee card that says what it leaves out. B: comparison table. One row per perk with a Member and a Fee column, two buttons at the bottom. C: swipe cards. The membership card fills the screen and the filing fee card peeks in from the right.',
          lab('A · STACKED', m2a()) + lab('B · TABLE', m2b()) + lab('C · SWIPE CARDS', m2c()), 1400)
    print('ok')
