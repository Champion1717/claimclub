# Refund Club flow, 3 playable iterations styled like the claim flow (header with back, logo and progress; green "found so far" panel on desktop; big question cards).
# RFlow1 quick yes/no questions, RFlow2 connect a card and scan, RFlow3 tap what happened then add details. Desktop 1280x800 + mobile 390x844 per board. Not live.
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from how4 import ic, IC, LOGO, HEAD, OUT
from refundC import logo, MINT, DARK, GREEN, brand
IC.update({'chev': '<path d="m15 18-6-6 6-6"></path>', 'lock': '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path>', 'mail': '<rect width="20" height="16" x="2" y="4" rx="2"></rect><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path>'})

LG = {'netflix': 'logos2/netflix.svg', 'amazon': 'logos/amazon.svg', 'ubereats': 'logos2/ubereats.png', 'disney': 'logos2/disney.png', 'bestbuy': 'logos2/bestbuy.png', 'bofa': 'logos/bofa.svg', 'capone': 'logos2/capone.png'}
def mk(key, icon='receipt', s=52, r=16):
    if key in LG: return f'<img src="{logo(LG[key])}" alt="" style="width: {s}px; height: {s}px; flex: none; border-radius: {r}px; background: #FFFFFF; padding: {round(s * .16)}px; box-sizing: border-box; object-fit: contain; box-shadow: 0 6px 16px rgba(10,15,13,.08), inset 0 0 0 1px #E3EAE6">'
    return f'<span style="width: {s}px; height: {s}px; flex: none; border-radius: {r}px; background: #FFFFFF; color: {GREEN}; display: flex; align-items: center; justify-content: center; box-shadow: 0 6px 16px rgba(10,15,13,.08), inset 0 0 0 1px #E3EAE6">{ic(icon, round(s * .48), 2.2)}</span>'
chip = lambda t, g=True: f'<span style="padding: 4px 10px; border-radius: 99px; font-size: 12.5px; font-weight: 800; {"background: #E9F6EF; color: #17603F" if g else "background: #EEF2F0; color: #43504A"}">{t}</span>'
BTN = 'border: 0; cursor: pointer; font-family: inherit;'
primary = lambda t, a='next', extra='': f'<button data-a="{a}" style="{BTN} width: 100%; min-height: 58px; border-radius: 99px; background: {MINT}; color: {DARK}; font-size: 17px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px; {extra}">{t}</button>'
ghost = lambda t, a='next': f'<button data-a="{a}" style="{BTN} align-self: center; background: transparent; color: #5B6862; font-size: 14px; font-weight: 800; padding: 8px">{t}</button>'
H1 = lambda t, m: f'<h1 style="margin: 0; font-size: {27 if m else 36}px; line-height: 1.12; font-weight: 800; letter-spacing: -0.9px">{t}</h1>'
SUB = lambda t: f'<p style="margin: 0; font-size: 15px; line-height: 1.5; color: #5B6862">{t}</p>'

# ---------- question cards (iteration 1) ----------
Q = [('netflix', 'repeat', 'Netflix', 47.97, 'Were you charged by Netflix after you canceled?', 'Even one month counts.'),
     ('amazon', 'copy', 'Amazon', 32.18, 'Did Amazon charge you twice for one order?', 'In the last 90 days.'),
     ('gym', 'ban', 'Gym membership', 39.99, 'Do you pay for a gym you stopped going to?', 'We cancel it and ask for the last charge back.'),
     ('ubereats', 'truck', 'Uber Eats', 24.60, 'Did a delivery arrive late, cold or missing items?', 'Food delivery in the last 60 days.'),
     ('disney', 'hourglass', 'Disney+', 13.99, 'Did a free trial turn into a paid plan?', 'Any streaming or app trial.'),
     ('plane', 'plane', 'Airline', 120.00, 'Was a flight canceled or delayed 3+ hours this year?', 'Airlines often owe a refund or credit.'),
     ('bank', 'landmark', 'Your bank', 35.00, 'Did your bank charge an overdraft fee this year?', 'Banks often waive the first one when asked.'),
     ('bestbuy', 'tag', 'Best Buy', 60.00, 'Did something you bought drop in price within 15 days?', 'Price match refunds the difference.')]
def qview(i, q, m):
    key, icon, co, amt, title, sub = q
    return (f'<div class="rv" data-step="q{i}" data-amt="{amt}" data-co="{co}" data-key="{key}" style="display: {"flex" if i == 0 else "none"}; flex-direction: column; gap: 18px; width: 100%; max-width: 560px; margin: auto">'
            f'<div style="display: flex; align-items: center; gap: 14px">{mk(key, icon, 60 if not m else 56)}<span style="display: flex; flex-direction: column; gap: 6px"><b style="font-size: 15px; color: #43504A">{co}</b><span style="display: flex; gap: 6px">{chip("About $" + format(amt, ",.0f") + " back")}{chip("We handle it", False)}</span></span></div>'
            f'{H1(title, m)}{SUB(sub)}'
            f'<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px"><button data-a="no" style="{BTN} min-height: {62 if m else 68}px; border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px #DDE5E0; font-size: 19px; font-weight: 800; color: #0A0F0D; display: flex; align-items: center; justify-content: center; gap: 8px"><span style="color: #B8333A; display: flex">{ic("x", 20, 3)}</span>No</button>'
            f'<button data-a="yes" style="{BTN} min-height: {62 if m else 68}px; border-radius: 18px; background: {MINT}; color: {DARK}; font-size: 19px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 10px 24px rgba(61,220,151,.35)">{ic("check", 20, 3)}Yes</button></div>'
            f'{ghost("Not sure? Skip", "no")}</div>')

def result_view(m, step='res', title='Based on your answers, you could get back', cta='Get my money back'):
    return (f'<div class="rv" data-step="{step}" style="display: none; flex-direction: column; gap: 16px; width: 100%; max-width: 560px; margin: auto">'
            f'<span style="text-align: center; font-size: 15px; font-weight: 800; color: #5B6862">{title}</span>'
            # receipt card, the Refund Club take on the claim flow's check
            '<div style="position: relative; padding: 22px 22px 18px; border-radius: 8px 8px 0 0; background: #FFFFFF; box-shadow: 0 18px 40px rgba(10,15,13,.12); transform: rotate(-1.2deg); display: flex; flex-direction: column; gap: 8px; font-family: ui-monospace, Menlo, monospace">'
            f'<div style="display: flex; justify-content: space-between; align-items: center"><span style="display: flex; align-items: center; gap: 6px; font-family: Manrope, sans-serif; font-weight: 800; font-size: 13px; letter-spacing: .5px">{LOGO.format(s=18, c="#0A0F0D")}REFUND CLUB</span><span style="font-size: 11px; color: #8A968F">RECEIPT</span></div>'
            '<div class="rList" style="display: flex; flex-direction: column; gap: 5px; font-size: 12.5px; color: #26302B; padding: 8px 0; border-top: 1px dashed #C9D3CD; border-bottom: 1px dashed #C9D3CD; min-height: 40px"></div>'
            f'<div style="display: flex; justify-content: space-between; align-items: baseline"><span style="font-size: 12px; font-weight: 700">TOTAL BACK</span><b class="rTot" style="font-family: Manrope, sans-serif; font-size: 34px; letter-spacing: -1px; color: {GREEN}">$0</b></div>'
            '<span style="position: absolute; left: 0; right: 0; bottom: -10px; height: 10px; background: linear-gradient(-45deg, transparent 6px, #FFFFFF 0) 0 0/12px 10px, linear-gradient(45deg, transparent 6px, #FFFFFF 0) 0 0/12px 10px"></span></div>'
            '<span style="text-align: center; font-size: 12.5px; color: #8A968F; margin-top: 8px">An estimate based on typical refunds. Companies decide the final amount.</span>'
            f'{primary(cta + ic("arrow", 18, 2.4))}</div>')
def email_view(m, step='email'):
    return (f'<div class="rv" data-step="{step}" style="display: none; flex-direction: column; gap: 14px; width: 100%; max-width: 520px; margin: auto">'
            f'{H1("Where should we send updates?", m)}{SUB("We email you each time a company replies or a refund lands.")}'
            '<span style="font-size: 13px; font-weight: 800; color: #43504A">Your email</span>'
            f'<span style="height: 56px; border-radius: 16px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px #DDE5E0; display: flex; align-items: center; gap: 10px; padding: 0 16px; font-size: 16px; color: #8A968F">{ic("mail", 18, 2)}you@email.com</span>'
            f'{primary("Continue")}</div>')
def done_view(m, step='done', head='You are a member', sub='Your dashboard now has Refunds and Claims. Approve each refund request and we start fighting.'):
    return (f'<div class="rv" data-step="{step}" style="display: none; flex-direction: column; gap: 14px; width: 100%; max-width: 520px; margin: auto; align-items: center; text-align: center">'
            f'<span style="width: 84px; height: 84px; border-radius: 50%; background: {MINT}; color: {DARK}; display: flex; align-items: center; justify-content: center">{ic("check", 42, 3)}</span>'
            f'{H1(head, m)}{SUB(sub)}{primary("Open my dashboard" + ic("arrow", 18, 2.4))}{ghost("Start over", "restart")}</div>')

def plan_view(m, step='plan'):
    perk = lambda k, t, d: f'<span style="display: flex; gap: 10px; align-items: flex-start"><span style="width: 30px; height: 30px; flex: none; border-radius: 9px; background: #E9F6EF; color: {GREEN}; display: flex; align-items: center; justify-content: center">{ic(k, 16, 2.4)}</span><span style="display: flex; flex-direction: column"><b style="font-size: 14.5px">{t}</b><span style="font-size: 13px; color: #5B6862">{d}</span></span></span>'
    tabs = ''.join(f'<span style="flex: 1; min-height: 38px; border-radius: 11px; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 800; {"background: #FFFFFF; color: #0A0F0D; box-shadow: 0 1px 3px rgba(10,15,13,.12)" if on else "color: #5B6862"}">{t}</span>' for t, on in (('1 month', True), ('3 months', False), ('6 months', False)))
    return (f'<div class="rv" data-step="{step}" style="display: none; flex-direction: column; gap: 14px; width: 100%; max-width: 560px; margin: auto">'
            f'{H1("One membership, all your money back", m)}{SUB("Claimclub membership covers Refund Club and Claim money. Join once, get both.")}'
            f'<div style="display: flex; flex-direction: column; gap: 10px; padding: 16px; border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6">'
            + perk('receipt', 'Refund Club', 'We cancel and fight every charge you approve.') + perk('file', 'Claim money', 'We file every class action settlement you match.') + perk('bell', 'Alerts', 'New refunds, new settlements and trials about to renew.') + '</div>'
            f'<div style="display: flex; gap: 4px; padding: 4px; border-radius: 14px; background: #E6ECE8">{tabs}</div>'
            f'<div style="display: flex; justify-content: space-between; align-items: center; padding: 16px; border-radius: 18px; background: {DARK}; color: #FFFFFF"><span style="display: flex; flex-direction: column"><b style="font-size: 16px">Monthly</b><span style="font-size: 13px; color: #B9CCC2">$7.99 first month, then $29.99/mo. Cancel anytime.</span></span><b style="font-size: 28px; letter-spacing: -1px">$7.99</b></div>'
            f'{primary("Start getting my money back · $7.99 today")}{ghost("Already a member? Log in", "next")}</div>')

# ---------- iteration 2: connect and scan ----------
BANKS = [('bofa', 'Bank of America'), ('capone', 'Capital One'), ('', 'Chase'), ('', 'Wells Fargo'), ('', 'American Express'), ('', 'Other bank')]
FOUND2 = [('netflix', 'repeat', 'Netflix', 'Charged after you canceled', 47.97), ('gym', 'ban', 'City Fitness', 'Gym you have not used since July', 39.99), ('amazon', 'copy', 'Amazon', 'Charged twice on Oct 3', 32.18),
          ('ubereats', 'truck', 'Uber Eats', 'Order marked late', 24.60), ('disney', 'hourglass', 'Disney+', 'Free trial turned paid', 13.99), ('bank', 'landmark', 'Bank fee', 'Overdraft fee on Sep 28', 35.00)]
def v2_views(m):
    intro = (f'<div class="rv" data-step="intro" style="display: flex; flex-direction: column; gap: 16px; width: 100%; max-width: 560px; margin: auto">'
             f'<span style="width: 60px; height: 60px; border-radius: 18px; background: #E9F6EF; color: {GREEN}; display: flex; align-items: center; justify-content: center">{ic("search", 28, 2.2)}</span>'
             f'{H1("Find every charge you can get back", m)}{SUB("Connect a card and we check your last 90 days for refunds, forgotten subscriptions and fees. Takes about 30 seconds.")}'
             f'<div style="display: flex; flex-direction: column; gap: 8px; padding: 14px; border-radius: 16px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6">' + ''.join(f'<span style="display: flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 700; color: #26302B"><span style="color: {GREEN}; display: flex">{ic(k, 16, 2.4)}</span>{t}</span>' for k, t in (('lock', 'Read-only. We can never move your money.'), ('shield', 'Bank-level encryption.'), ('check', 'You approve every refund request.'))) + '</div>'
             f'{primary("Connect a card" + ic("arrow", 18, 2.4))}{ghost("Add a charge by hand instead", "manual")}</div>')
    bank = (f'<div class="rv" data-step="bank" style="display: none; flex-direction: column; gap: 14px; width: 100%; max-width: 560px; margin: auto">{H1("Pick your bank", m)}{SUB("Choose the card you use most. You can add more later.")}'
            f'<div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px">' + ''.join(
                f'<button data-a="scan" style="{BTN} display: flex; align-items: center; gap: 10px; padding: 12px; border-radius: 16px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px #E3EAE6; font-size: 14.5px; font-weight: 800; color: #0A0F0D; text-align: left">{mk(k, "landmark", 36, 10)}{n}</button>' for k, n in BANKS) + '</div>'
            f'<span style="display: flex; align-items: center; justify-content: center; gap: 6px; font-size: 12.5px; color: #8A968F; font-weight: 700">{ic("lock", 14, 2.4)}Secure connection through our bank partner</span></div>')
    rows = ''.join(f'<div class="fr" data-amt="{a}" data-co="{co}" style="display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: 16px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; opacity: 0; transform: translateY(8px); transition: opacity .3s, transform .3s">'
                   f'{mk(k, icn, 40, 12)}<span style="flex: 1; min-width: 0; display: flex; flex-direction: column"><b style="font-size: 15px">{co} <span style="color: {GREEN}">${a:.2f}</span></b><span style="font-size: 12.5px; color: #5B6862; font-weight: 600">{why}</span></span>'
                   f'<button data-a="tog" aria-label="Include {co}" class="tk" style="{BTN} width: 28px; height: 28px; flex: none; border-radius: 9px; background: {GREEN}; color: #FFFFFF; display: flex; align-items: center; justify-content: center">{ic("check", 16, 3)}</button></div>' for k, icn, co, why, a in FOUND2)
    scan = (f'<div class="rv" data-step="scan" style="display: none; flex-direction: column; gap: 12px; width: 100%; max-width: 560px; margin: auto">'
            f'<span class="scH" style="font-size: 13px; font-weight: 800; letter-spacing: 1px; color: #5B6862">CHECKING 412 CHARGES</span>'
            f'<div style="height: 6px; border-radius: 99px; background: #E3EAE6; overflow: hidden"><span class="scB" style="display: block; height: 100%; width: 0; background: {GREEN}; transition: width .25s linear"></span></div>'
            f'{H1("<span class=scN>0</span> refunds found", m)}<div style="display: flex; flex-direction: column; gap: 8px">{rows}</div>'
            f'<div class="scDone" style="display: none; flex-direction: column; gap: 10px"><span style="font-size: 13px; color: #5B6862; font-weight: 700; text-align: center">Uncheck anything you want to keep. You approve each request later too.</span>{primary("Fight <span class=selN>6</span> charges" + ic("arrow", 18, 2.4))}</div></div>')
    manual = (f'<div class="rv" data-step="manual" style="display: none; flex-direction: column; gap: 12px; width: 100%; max-width: 520px; margin: auto">{H1("Tell us about one charge", m)}'
              + ''.join(f'<span style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 13px; font-weight: 800; color: #43504A">{l}</span><span style="height: 52px; border-radius: 14px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px #DDE5E0; display: flex; align-items: center; padding: 0 14px; font-size: 15px; color: #8A968F">{p}</span></span>' for l, p in (('Company', 'Planet Fitness'), ('Amount', '$39.99'), ('What happened?', 'Still charged after I canceled'))) +
              f'{primary("Add charge", "email")}</div>')
    return intro + bank + scan + manual + email_view(m) + plan_view(m) + done_view(m)

# ---------- iteration 3: tap what happened, then details ----------
KIND3 = [('repeat', 'Charged after I canceled', 'sub'), ('hourglass', 'Free trial turned paid', 'trial'), ('copy', 'Charged twice', 'dup'), ('ban', 'Can not cancel a membership', 'gym'),
         ('truck', 'Order late or missing', 'order'), ('plane', 'Flight canceled or delayed', 'flight'), ('landmark', 'Bank or overdraft fee', 'bank'), ('tag', 'Price dropped after I bought', 'price')]
DETAIL = {'sub': ('Which subscription?', ['Netflix', 'Spotify', 'Hulu', 'Amazon Prime', 'Other'], 15.99), 'trial': ('Which app or service?', ['Disney+', 'Audible', 'Peacock', 'Apple TV+', 'Other'], 13.99),
          'dup': ('Where were you charged twice?', ['Amazon', 'Target', 'Walmart', 'Uber', 'Other'], 32.18), 'gym': ('Which membership?', ['Planet Fitness', 'LA Fitness', '24 Hour Fitness', 'Equinox', 'Other'], 39.99),
          'order': ('Which store or app?', ['Uber Eats', 'DoorDash', 'Amazon', 'Instacart', 'Other'], 24.60), 'flight': ('Which airline?', ['American', 'Delta', 'United', 'Southwest', 'Other'], 120.00),
          'bank': ('Which bank?', ['Chase', 'Bank of America', 'Wells Fargo', 'Capital One', 'Other'], 35.00), 'price': ('Which store?', ['Best Buy', 'Target', 'Walmart', 'Home Depot', 'Other'], 60.00)}
def v3_views(m):
    tiles = ''.join(f'<button data-a="pick" data-k="{k}" class="tile" style="{BTN} position: relative; display: flex; flex-direction: column; align-items: flex-start; gap: 10px; padding: 14px; border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px #E3EAE6; text-align: left; font-size: {14 if m else 15}px; font-weight: 800; color: #0A0F0D; min-height: {104 if m else 112}px">'
                    f'<span style="width: 38px; height: 38px; border-radius: 12px; background: #E9F6EF; color: {GREEN}; display: flex; align-items: center; justify-content: center">{ic(icn, 20, 2.2)}</span>{t}'
                    f'<span class="tick" style="position: absolute; top: 12px; right: 12px; width: 22px; height: 22px; border-radius: 7px; box-shadow: inset 0 0 0 1.5px #C3CEC8; display: flex; align-items: center; justify-content: center; color: #FFFFFF">{ic("check", 14, 3.4)}</span></button>' for icn, t, k in KIND3)
    pick = (f'<div class="rv" data-step="pick" style="display: flex; flex-direction: column; gap: 14px; width: 100%; max-width: 620px; margin: auto">{H1("What happened to you?", m)}{SUB("Tap everything that sounds familiar from the last year.")}'
            f'<div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px">{tiles}</div>{primary("<span class=pkL>Pick at least one</span>", "details")}</div>')
    det = ''.join(f'<div class="rv" data-step="d_{k}" data-k="{k}" data-amt="{amt}" style="display: none; flex-direction: column; gap: 14px; width: 100%; max-width: 560px; margin: auto">'
                  f'<span style="display: flex; align-items: center; gap: 10px">{mk("", icn, 48, 14)}<b style="font-size: 15px; color: #43504A">{t}</b></span>{H1(q, m)}'
                  f'<div style="display: flex; flex-wrap: wrap; gap: 8px">' + ''.join(f'<button data-a="co" data-co="{o}" class="opt" style="{BTN} min-height: 44px; padding: 0 16px; border-radius: 99px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px #DDE5E0; font-size: 15px; font-weight: 800; color: #0A0F0D">{o}</button>' for o in opts) + '</div>'
                  f'<span style="font-size: 13px; font-weight: 800; color: #43504A">About how much?</span><div style="display: flex; gap: 8px">' + ''.join(f'<button data-a="amt" data-v="{v}" class="amt" style="{BTN} flex: 1; min-height: 44px; border-radius: 14px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px #DDE5E0; font-size: 15px; font-weight: 800; color: #0A0F0D">{lbl}</button>' for v, lbl in ((10, "Under $20"), (35, "$20 to $50"), (75, "$50 to $100"), (150, "$100+"))) + '</div>'
                  f'{primary("Next", "dnext")}{ghost("I am not sure", "dnext")}</div>' for icn, t, k in KIND3 for q, opts, amt in [DETAIL[k]])
    return pick + det + result_view(m) + email_view(m) + plan_view(m) + done_view(m)

# ---------- frames ----------
def frame(views, m, total_steps, left_note):
    head_d = (f'<header style="flex: none; height: 80px; display: flex; align-items: center; justify-content: space-between; padding: 0 36px; background: #FFFFFF; border-bottom: 1px solid #E3EAE6">'
              f'<span style="display: flex; align-items: center; gap: 16px"><button data-a="back" aria-label="Back" style="{BTN} width: 44px; height: 44px; border-radius: 12px; background: #F3F6F4; color: #0A0F0D; display: flex; align-items: center; justify-content: center">{ic("chev", 20, 2.4)}</button>{brand(26, "#0A0F0D")}<span style="padding: 4px 10px; border-radius: 99px; background: #E9F6EF; color: #17603F; font-size: 12px; font-weight: 800">Refund Club</span></span>'
              f'<span style="display: flex; align-items: center; gap: 12px"><span style="display: flex; gap: 4px">' + ''.join(f'<span class="pb" style="width: 26px; height: 5px; border-radius: 99px; background: #E3EAE6"></span>' for _ in range(total_steps)) + '</span><span class="pbN" style="font-size: 14px; font-weight: 800; color: #43504A"></span></span>'
              '<span style="font-size: 13.5px; font-weight: 700; color: #5B6862">Free to check · Not a bank</span></header>')
    left = (f'<aside style="width: 400px; flex: none; background: radial-gradient(120% 80% at 100% 0%, #2A9B70 0%, rgba(42,155,112,0) 55%), linear-gradient(170deg, #17563F 0%, #0F3B2E 50%, #0A2C22 100%); color: #FFFFFF; padding: 40px 36px; box-sizing: border-box; display: flex; flex-direction: column; gap: 14px">'
            '<span style="font-size: 13px; font-weight: 800; letter-spacing: 1.4px; color: #CFE5DA">REFUNDS FOUND SO FAR</span><b class="fTot" style="font-size: 52px; letter-spacing: -2px; line-height: 1">$0</b><span class="fN" style="font-size: 15px; font-weight: 700">0 charges</span>'
            '<div class="fList" style="display: flex; flex-direction: column; gap: 8px; overflow: auto"></div>'
            f'<div class="fEmpty" style="padding: 18px; border-radius: 16px; background: rgba(255,255,255,.08); font-size: 15px; line-height: 1.55; color: #DCE7E1">{left_note}</div>'
            '<span style="margin-top: auto; font-size: 12.5px; color: #B9CCC2; line-height: 1.5">Amounts are typical refunds for each kind of charge. Companies decide the final amount.</span></aside>')
    if m:
        head = (f'<header style="flex: none; padding: 12px 16px 10px; background: #FFFFFF; display: flex; flex-direction: column; gap: 10px"><div style="display: flex; align-items: center; justify-content: space-between">'
                f'<span style="display: flex; align-items: center; gap: 10px"><button data-a="back" aria-label="Back" style="{BTN} width: 36px; height: 36px; border-radius: 10px; background: #F3F6F4; color: #0A0F0D; display: flex; align-items: center; justify-content: center">{ic("chev", 18, 2.4)}</button>{brand(22, "#0A0F0D")}</span>'
                f'<b class="fTot" style="min-width: 44px; height: 34px; padding: 0 12px; border-radius: 10px; background: {DARK}; color: #FFFFFF; font-size: 15px; display: flex; align-items: center; justify-content: center">$0</b></div>'
                f'<span style="display: flex; align-items: center; gap: 8px"><span style="flex: 1; display: flex; gap: 3px">' + ''.join(f'<span class="pb" style="flex: 1; height: 5px; border-radius: 99px; background: #E3EAE6"></span>' for _ in range(total_steps)) + '</span><span class="pbN" style="font-size: 12px; font-weight: 800; color: #43504A"></span></span></header>')
        return (f'<div class="rf" data-n="{total_steps}" style="width: 390px; height: 844px; display: flex; flex-direction: column; background: #F7F9F8; font-family: Manrope, sans-serif; color: #0A0F0D; overflow: hidden; border-radius: 28px">{head}'
                f'<main style="flex: 1; min-height: 0; overflow-y: auto; padding: 16px 20px 28px; display: flex; flex-direction: column">{views}</main></div>')
    return (f'<div class="rf" data-n="{total_steps}" style="width: 1280px; height: 800px; display: flex; flex-direction: column; background: #F7F9F8; font-family: Manrope, sans-serif; color: #0A0F0D; overflow: hidden; border-radius: 18px">{head_d}'
            f'<div style="flex: 1; min-height: 0; display: flex">{left}<main style="flex: 1; min-width: 0; overflow-y: auto; padding: 40px 60px; display: flex; flex-direction: column">{views}</main></div></div>')

PLAY = r"""
  componentDidMount() {
    const roots = [document]; document.querySelectorAll('*').forEach((el) => { if (el.shadowRoot) roots.push(el.shadowRoot); });
    roots.forEach((r) => r.querySelectorAll('.rf').forEach((f) => { if (!f._p) { f._p = 1; this.wire(f); } }));
  }
  wire(f) {
    const kind = f.closest('[data-kind]').dataset.kind, views = [...f.querySelectorAll('.rv')], N = +f.dataset.n;
    let hist = [], items = [], picks = {}, dq = [], cur = views[0], dsel = {};
    const money = (n) => '$' + n.toLocaleString('en-US', { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 });
    const byStep = (s) => views.find((v) => v.dataset.step === s);
    const paint = () => {
      const tot = items.reduce((t, x) => t + x.amt, 0);
      f.querySelectorAll('.fTot,.rTot').forEach((e) => { e.textContent = money(Math.round(tot * 100) / 100); });
      f.querySelectorAll('.fN').forEach((e) => { e.textContent = items.length + (items.length === 1 ? ' charge' : ' charges'); });
      f.querySelectorAll('.fEmpty').forEach((e) => { e.style.display = items.length ? 'none' : 'block'; });
      f.querySelectorAll('.fList,.rList').forEach((l) => { const rc = l.classList.contains('rList'); l.innerHTML = ''; items.forEach((x) => { const r = document.createElement('div');
        r.style.cssText = rc ? 'display:flex;justify-content:space-between' : 'display:flex;justify-content:space-between;align-items:center;padding:12px 14px;border-radius:14px;background:rgba(255,255,255,.08);font-size:15px;font-weight:800';
        r.innerHTML = '<span></span><span></span>'; r.children[0].textContent = x.co; r.children[1].textContent = money(x.amt); if (!rc) r.children[1].style.color = '#3DDC97'; l.appendChild(r); }); });
      const idx = Math.max(0, views.indexOf(cur)), pos = kind === 'q' ? Math.min(idx, N - 1) : Math.min(hist.length, N - 1);
      f.querySelectorAll('.pb').forEach((b, k) => { b.style.background = k <= pos ? '#12805C' : '#E3EAE6'; });
      f.querySelectorAll('.pbN').forEach((e) => { e.textContent = (pos + 1) + ' of ' + N; });
      const n = Object.keys(picks).length; f.querySelectorAll('.pkL').forEach((e) => { e.textContent = n ? 'Continue with ' + n : 'Pick at least one'; });
      f.querySelectorAll('.tile').forEach((t) => { const on = !!picks[t.dataset.k]; t.style.background = on ? '#E9F6EF' : '#FFFFFF'; t.style.boxShadow = 'inset 0 0 0 ' + (on ? 2 : 1.5) + 'px ' + (on ? '#12805C' : '#E3EAE6'); const tk = t.querySelector('.tick'); tk.style.background = on ? '#12805C' : 'transparent'; });
      const sel = f.querySelectorAll('.fr[data-on="1"]').length; f.querySelectorAll('.selN').forEach((e) => { e.textContent = sel; });
    };
    const show = (v, push) => { if (!v) return; if (push !== false && cur) hist.push(cur); views.forEach((x) => { x.style.display = x === v ? 'flex' : 'none'; }); cur = v; v.animate([{ opacity: 0, transform: 'translateY(10px)' }, { opacity: 1, transform: 'none' }], { duration: 160, easing: 'ease-out' }); paint(); };
    const nextOf = (v) => views[views.indexOf(v) + 1];
    const scan = () => { show(byStep('scan')); const rows = [...f.querySelectorAll('.fr')], bar = f.querySelector('.scB'), n = f.querySelector('.scN'); let k = 0; items = [];
      f.querySelector('.scDone').style.display = 'none'; rows.forEach((r) => { r.style.opacity = 0; r.style.transform = 'translateY(8px)'; r.dataset.on = '1'; r.querySelector('.tk').style.background = '#12805C'; });
      const t = setInterval(() => { if (k < rows.length) { const r = rows[k]; r.style.opacity = 1; r.style.transform = 'none'; items.push({ co: r.dataset.co, amt: +r.dataset.amt }); k += 1; n.textContent = k; bar.style.width = (k / rows.length * 100) + '%'; paint(); }
        else { clearInterval(t); f.querySelector('.scDone').style.display = 'flex'; f.querySelector('.scH').textContent = 'DONE · 412 CHARGES CHECKED'; } }, 420); };
    const restart = () => { hist = []; items = []; picks = {}; dq = []; dsel = {}; f.querySelectorAll('.opt,.amt').forEach((b) => { b.style.background = '#FFFFFF'; b.style.color = '#0A0F0D'; }); show(views[0], false); };
    f.addEventListener('click', (e) => {
      const b = e.target.closest('[data-a]'); if (!b || !f.contains(b)) return; const a = b.dataset.a, v = b.closest('.rv');
      if (a === 'back') { if (hist.length) { const p = hist.pop(); if (kind === 'q' && cur.dataset.step.startsWith('q')) items = items.filter((x) => x.co !== p.dataset.co); show(p, false); } return; }
      if (a === 'restart') { restart(); return; }
      if (a === 'yes') { items.push({ co: v.dataset.co, amt: +v.dataset.amt }); show(nextOf(v)); return; }
      if (a === 'no') { show(nextOf(v)); return; }
      if (a === 'scan') { scan(); return; }
      if (a === 'manual') { show(byStep('manual')); return; }
      if (a === 'email') { items = [{ co: 'Planet Fitness', amt: 39.99 }]; show(byStep('email')); return; }
      if (a === 'tog') { const r = b.closest('.fr'), on = r.dataset.on !== '1'; r.dataset.on = on ? '1' : '0'; b.style.background = on ? '#12805C' : '#FFFFFF'; b.style.boxShadow = on ? 'none' : 'inset 0 0 0 1.5px #C3CEC8'; items = [...f.querySelectorAll('.fr[data-on="1"]')].map((x) => ({ co: x.dataset.co, amt: +x.dataset.amt })); paint(); return; }
      if (a === 'pick') { const k = b.dataset.k; if (picks[k]) delete picks[k]; else picks[k] = 1; paint(); return; }
      if (a === 'details') { if (!Object.keys(picks).length) return; dq = views.filter((x) => x.dataset.step.startsWith('d_') && picks[x.dataset.k]); items = []; show(dq.shift()); return; }
      if (a === 'co' || a === 'amt') { v.querySelectorAll(a === 'co' ? '.opt' : '.amt').forEach((x) => { const on = x === b; x.style.background = on ? '#0F3B2E' : '#FFFFFF'; x.style.color = on ? '#FFFFFF' : '#0A0F0D'; }); dsel[v.dataset.k + a] = a === 'co' ? b.dataset.co : +b.dataset.v; return; }
      if (a === 'dnext') { items.push({ co: dsel[v.dataset.k + 'co'] || v.querySelector('b').textContent, amt: dsel[v.dataset.k + 'amt'] || +v.dataset.amt }); show(dq.length ? dq.shift() : byStep('res')); return; }
      if (a === 'next') { if (cur.dataset.step === 'intro') { show(byStep('bank')); return; } if (cur.dataset.step === 'scan') { show(byStep('email')); return; } show(cur.dataset.step === 'res' ? byStep('email') : cur.dataset.step === 'email' ? byStep('plan') : cur.dataset.step === 'plan' ? byStep('done') : nextOf(cur)); return; }
    });
    paint();
  }
"""
VARS = [('RFlow1', 'q', 'Refund Club flow · 1 · Quick yes or no questions (like the claim flow)', lambda m: ''.join(qview(i, q, m) for i, q in enumerate(Q)) + result_view(m) + email_view(m) + plan_view(m) + done_view(m), len(Q) + 3,
         'Charges you can get back will show up here as you answer.'),
        ('RFlow2', 's', 'Refund Club flow · 2 · Connect a card and we scan for refunds', v2_views, 6, 'Connect a card and we list every charge you can get back here.'),
        ('RFlow3', 'p', 'Refund Club flow · 3 · Tap what happened, then add a few details', v3_views, 6, 'Pick what happened and we add up what you could get back.')]

def build():
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    y0 = 21200
    c['notes']['tRFF'] = {'x': 0, 'y': y0, 'text': 'Refund Club flow · 3 playable iterations (click through each one, desktop and mobile)', 'kind': 'title1', 'maxW': 3600, 'w': 240}
    if 'tRFF' not in c['noteOrder']: c['noteOrder'].append('tRFF')
    for k, (name, kind, title, fn, n, note) in enumerate(VARS):
        page = (f'<div data-kind="{kind}" style="width: 1766px; height: 940px; box-sizing: border-box; padding: 24px; background: #E7ECE9; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 14px">'
                f'<div style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #43504A">{title.upper()}</div><div style="display: flex; gap: 48px; align-items: flex-start">'
                f'<div style="box-shadow: 0 30px 70px rgba(10,15,13,.14); border-radius: 18px">{frame(fn(False), False, n, note)}</div><div style="box-shadow: 0 30px 70px rgba(10,15,13,.14); border-radius: 28px">{frame(fn(True), True, n, note)}</div></div></div>\n</x-dc>\n')
        js = ('<script type="text/x-dc" data-dc-script data-props=\'{"$preview":{"width":1766,"height":940}}\'>\nclass Component extends DCLogic { renderVals() { return {}; }' + PLAY + '}\n</script>\n</body>\n</html>\n')
        open(os.path.join(OUT, name + '.dc.html'), 'w').write(HEAD % title + page + js)
        c['boards'][name + '.dc.html'] = {'x': (k % 2) * 1846, 'y': y0 + 220 + (k // 2) * 1020, 'w': 1766, 'h': 940, 'is_interactive': True, 'title': title}
        if name + '.dc.html' not in c['order']: c['order'].append(name + '.dc.html')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w'))
    print('built', [v[0] for v in VARS])

if __name__ == '__main__':
    build()
