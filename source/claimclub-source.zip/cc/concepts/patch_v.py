import json,re
s=open('make.py').read()
def rep(o,n):
    global s
    assert o in s,o[:100]; s=s.replace(o,n,1)
SETS=open('sets.json').read(); LOGOS=open('logos.json').read()
# ---------- state ----------
rep("theme: 'light',","theme: 'light', prof: { name: 'Henry Sidwell', email: 'henry@example.com', phone: '', dob: '', addr: '1234 Market St, Apt 5, San Francisco, CA 94103', past: [] }, edit: '', draft: '', err: '', pastDraft: '', payDef: 'Check', q: '', cat: 'all', scope: 'all', sort: 'soon', openS: '', shown: 20, added: [], hl: '',")
# ---------- claims + logos ----------
rep("].concat(this.extras().filter(x => (this.state.ans || {})[x.id] === 'yes'));","].concat(this.extras().filter(x => (this.state.ans || {})[x.id] === 'yes'), this.state.added || []);")
rep("  logos() {\n    return {","  sets() { return "+SETS+"; }\n  logo(id, co) {\n    const L = this.logos();\n    if (L[id]) return L[id];\n    const ch = (co || '?').replace(/[^A-Za-z0-9]/g, '').charAt(0).toUpperCase() || '?';\n    return 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 40 40\"><rect width=\"40\" height=\"40\" rx=\"10\" fill=\"#12805C\"/><text x=\"20\" y=\"27\" font-family=\"Arial,sans-serif\" font-weight=\"700\" font-size=\"18\" text-anchor=\"middle\" fill=\"#FFFFFF\">' + ch + '</text></svg>');\n  }\n  logos() {\n    return Object.assign("+LOGOS+", {")
# close the Object.assign: find end of logos() return object
i=s.index("  logos() {\n    return Object.assign("); j=s.index("};",i)
s=s[:j]+"});"+s[j+2:]
s=s.replace("logo: L[c.id] || '',","logo: this.logo(c.id, c.co),",1)
rep("note: { co: c.co, logo: this.logos()[id], claimId: 'CC-' + seq, amt: c.amt } });","note: { head: 'Filed with ' + c.co, sub: 'Claim CC-' + seq + ' · We\\'ll track it until it pays', logo: this.logo(id, c.co) } });")
rep("hasNote: !!s.note, note: s.note || { co: '', logo: '', claimId: '', amt: '' },","hasNote: !!s.note, note: s.note || { head: '', sub: '', logo: '' },")
# ---------- setup bar routing ----------
rep("nextLabel: next ? next.label : '', nextAct: () => next && mark(next.id),","nextLabel: next ? next.label : '', nextAct: () => { if (!next) return; if (['dob', 'past', 'bank'].indexOf(next.id) >= 0) this.goInfo(next.id); else mark(next.id); },")
# ---------- views, scale, theme ----------
i=s.index("      isDash: s.view === 'dash',"); j=s.index("      rootCls:",i)
s=s[:i]+"""      isDash: s.view === 'dash', isAll: s.view === 'all', isInfo: s.view === 'info', isSet: s.view === 'settings',
      goDash: () => this.setState({ view: 'dash' }), goAll: () => this.setState({ view: 'all' }), goInfo: () => this.setState({ view: 'info' }), goSet: () => this.setState({ view: 'settings' }),
      ...['dash', 'all', 'info', 'settings'].reduce((o, v) => { const on = s.view === v, K = v.charAt(0).toUpperCase() + v.slice(1);
        o['nav' + K] = 'display:flex;align-items:center;gap:12px;padding:11px 12px;border-radius:12px;font-size:15px;font-weight:700;text-align:left;' + (on ? 'background:#EAF2EE;color:#0F3B2E' : 'background:transparent;color:#43504A');
        o['m' + K] = 'display:flex;flex-direction:column;align-items:center;gap:3px;font-size:11px;font-weight:800;background:transparent;color:' + (on ? '#0F3B2E' : '#8A968F'); return o; }, {}),
      ...this.setsVals(), ...this.infoVals(),
"""+s[j:]
rep("      rootCls: (s.theme === 'dark' || (s.theme === 'system' && typeof matchMedia !== 'undefined' && matchMedia('(prefers-color-scheme: dark)').matches)) ? 'dk' : '',",
    "      rootCls: ((s.theme === 'dark' || (s.theme === 'system' && typeof matchMedia !== 'undefined' && matchMedia('(prefers-color-scheme: dark)').matches)) ? 'dk ' : '') + 'z-' + s.scale,")
rep("      zoomSt: 'display:flex;flex-direction:column;gap:14px;zoom:' + ({ s: 0.86, m: 1, l: 1.14 }[s.scale]),","      zoomSt: 'display:flex;flex-direction:column;gap:14px',")
# ---------- new methods ----------
rep("  setupVals() {","""  goInfo(h) { clearTimeout(this._hl); this.setState({ view: 'info', hl: h }); this._hl = setTimeout(() => this.setState({ hl: '' }), 2600); }
  daysTo(dl) { return Math.ceil((new Date(dl + 'T23:59:59') - new Date()) / 864e5); }
  setsVals() {
    const s = this.state, MY = 'CA';
    const open = this.sets().filter(d => this.daysTo(d.dl) > 0);
    const nation = open.filter(d => !d.st), near = open.filter(d => d.st && d.st.split(',').indexOf(MY) >= 0);
    const CATS = [['all', 'All'], ['cash', 'No proof needed'], ['privacy', 'Privacy & data'], ['products', 'Products'], ['apps', 'Apps & calls'], ['bank', 'Banking'], ['health', 'Health'], ['auto', 'Auto'], ['invest', 'Investing & jobs'], ['arb', 'Arbitration']];
    const base = s.scope === 'near' ? near : nation, q = s.q.trim().toLowerCase();
    let list = base.filter(d => s.cat === 'all' || (s.cat === 'cash' ? (d.proof === 'No proof' || d.mode === 'auto') : d.cat === s.cat));
    if (q) list = list.filter(d => (d.co + ' ' + d.title + ' ' + d.who + ' ' + d.area).toLowerCase().indexOf(q) >= 0);
    list = list.slice().sort((a, b) => s.sort === 'az' ? a.co.localeCompare(b.co) : a.dl.localeCompare(b.dl));
    const STL = { ready: 'Ready to file', filed: 'Filed', review: 'In review', approved: 'Approved', paid: 'Paid' };
    const chip = (on) => 'flex:none;min-height:34px;padding:0 14px;border-radius:99px;font-size:13px;font-weight:800;white-space:nowrap;' + (on ? 'background:#0F3B2E;color:#FFFFFF' : 'background:#FFFFFF;color:#43504A;box-shadow:inset 0 0 0 1.5px #DDE5E0');
    const fmt = (dl) => new Date(dl + 'T12:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    const rows = list.slice(0, s.shown).map(d => {
      const days = this.daysTo(d.dl), mine = s.st[d.id] && s.st[d.id] !== 'gone', isOpen = s.openS === d.id;
      const proofSt = d.mode === 'auto' ? 'background:#E8EEFB;color:#2C4FA8' : d.proof === 'No proof' ? 'background:#E9F6EF;color:#17603F' : 'background:#FFF4DB;color:#8A5A00';
      return { id: d.id, co: d.co, title: d.title, pay: d.pay, logo: this.logo(d.id, d.co), who: d.who, fund: d.fund || 'Not disclosed', dlFmt: fmt(d.dl), area: d.area, isLocal: !!d.st,
        proof: d.mode === 'auto' ? 'Automatic' : d.proof === 'No proof' ? 'No proof' : 'Needs ' + d.proof.toLowerCase(),
        proofSt: 'font-size:11px;font-weight:800;padding:2px 8px;border-radius:99px;white-space:nowrap;' + proofSt,
        dl: days + 'd left', dlSt: 'font-size:12px;font-weight:800;padding:4px 9px;border-radius:99px;white-space:nowrap;' + (days <= 7 ? 'background:#FDECEC;color:#B8333A' : 'background:#EEF2F0;color:#43504A'),
        how: d.mode === 'auto' ? 'Paid automatically to people on the class list. We track it for you.' : d.mode === 'site' ? 'Filed on the official settlement site with your documents. We prefill what we can and walk you through it.' : 'We file it for you with your saved info.',
        mine, notMine: !mine, myLabel: STL[s.st[d.id]] || '', isOpen, chev: 'transition:transform .2s;' + (isOpen ? 'transform:rotate(180deg)' : ''),
        toggle: () => this.setState({ openS: isOpen ? '' : d.id }), check: () => this.setState({ openS: d.id }),
        add: () => { const c = { id: d.id, co: d.co, title: d.title, amt: d.pay.length > 18 ? 'Varies' : d.pay, n: 0, days, kind: d.mode === 'auto' ? 'auto' : d.cat === 'arb' ? 'arb' : 'here', why: d.who };
          this.setState({ added: (s.added || []).concat([c]), st: Object.assign({}, s.st, { [d.id]: 'ready' }), openS: '', note: { head: 'Added ' + d.co, sub: 'It is waiting in Ready to file on your dashboard', logo: this.logo(d.id, d.co) } });
          clearTimeout(this._t2); this._t2 = setTimeout(() => this.setState({ note: null }), 3600); },
        goMine: () => this.setState({ view: 'dash' }), notMe: () => this.setState({ openS: '' }) };
    });
    return { sRows: rows, sCount: list.length, sShown: Math.min(list.length, s.shown), sMore: list.length > s.shown, sNone: list.length === 0, showMore: () => this.setState({ shown: s.shown + 20 }),
      q: s.q, onQ: (e) => this.setState({ q: e.target.value, shown: 20 }), clearQ: () => this.setState({ q: '' }), hasQ: !!s.q,
      cats: CATS.map(([k, t]) => ({ t, st: chip(s.cat === k), tap: () => this.setState({ cat: k, shown: 20 }) })),
      scopes: [['all', 'Nationwide', nation.length], ['near', 'Near you · ' + MY, near.length]].map(([k, t, n]) => ({ t, n, st: 'flex:1;display:flex;align-items:center;justify-content:center;gap:8px;min-height:38px;border-radius:12px;font-size:14px;font-weight:800;' + (s.scope === k ? 'background:#FFFFFF;color:#0A0F0D;box-shadow:0 1px 3px rgba(10,15,13,.12)' : 'background:transparent;color:#5B6862'), tap: () => this.setState({ scope: k, shown: 20, openS: '' }) })),
      sorts: [['soon', 'Closing soon'], ['az', 'A to Z']].map(([k, t]) => ({ t, st: 'font-size:13px;font-weight:800;padding:4px 2px;background:transparent;' + (s.sort === k ? 'color:#0A0F0D;box-shadow:inset 0 -2px 0 #12805C' : 'color:#8A968F'), tap: () => this.setState({ sort: k }) })),
      totalOpen: open.length, nearN: near.length, isNear: s.scope === 'near' };
  }
  infoVals() {
    const s = this.state, P = s.prof, tip = (k) => ({ open: s.info === k, toggle: () => this.setState({ info: s.info === k ? '' : k }) });
    const ring = (k) => 'background:#FFFFFF;border-radius:18px;padding:6px 16px;transition:box-shadow .3s;box-shadow:' + (s.hl === k ? '0 0 0 3px #3DDC97' : '0 0 0 1px #E3EAE6');
    const V = { name: [/^.{2,}$/, 'Enter your full legal name'], dob: [/^(0[1-9]|1[0-2])\\/(0[1-9]|[12]\\d|3[01])\\/(19|20)\\d\\d$/, 'Use MM/DD/YYYY'], phone: [/^\\D*(\\d\\D*){10,11}$/, 'Enter a 10 digit phone number'], email: [/^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$/, 'Enter a valid email'], addr: [/^.{8,}$/, 'Enter street, city, state and ZIP'] };
    const save = (k) => { const v = s.draft.trim(); if (!V[k][0].test(v)) { this.setState({ err: V[k][1] }); return; }
      const prof = Object.assign({}, P, { [k]: v }), acct = Object.assign({}, s.acct);
      if (prof.dob && prof.phone) acct.dob = 1;
      this.setState({ prof, acct, edit: '', draft: '', err: '' }); };
    const F = [['name', 'Legal name', 'For filing', 'Administrators match your claim to their class list by legal name.', ''], ['dob', 'Date of birth', 'For filing', 'Some claim forms use it to confirm who you are and block duplicate claims.', 'MM/DD/YYYY'], ['phone', 'Phone', 'For notifications', 'We text you approvals and payouts. Some forms also ask for a phone number.', '(555) 555-5555'], ['email', 'Email', 'Account', 'Filing receipts and claim updates go here.', 'name@example.com'], ['addr', 'Current mailing address', 'For filing', 'Checks are mailed here, and administrators use it to find you on the class list.', 'Street, city, state, ZIP']];
    const TAG = { 'For filing': 'background:#E9F6EF;color:#17603F', 'For notifications': 'background:#E8EEFB;color:#2C4FA8', 'Account': 'background:#EEF2F0;color:#43504A', 'For payouts': 'background:#FFF4DB;color:#8A5A00' };
    const row = ([k, label, tag, why, ph]) => { const t = tip('f-' + k), ed = s.edit === k;
      return { k, label, tag, why, ph, val: P[k] || '', empty: !P[k], filled: !!P[k], editing: ed, viewing: !ed, open: t.open, toggle: t.toggle,
        tagSt: 'font-size:11px;font-weight:800;padding:2px 8px;border-radius:99px;white-space:nowrap;' + TAG[tag],
        btn: P[k] ? 'Edit' : 'Add', btnSt: 'flex:none;min-height:32px;padding:0 14px;border-radius:99px;font-size:13px;font-weight:800;' + (P[k] ? 'background:#EEF2F0;color:#0A0F0D' : 'background:#0A0F0D;color:#FFFFFF'),
        start: () => this.setState({ edit: k, draft: P[k] || '', err: '' }), draft: s.draft, onDraft: (e) => this.setState({ draft: e.target.value, err: '' }),
        save: () => save(k), cancel: () => this.setState({ edit: '', draft: '', err: '' }), err: ed ? s.err : '', hasErr: ed && !!s.err };
    };
    const pays = ['Direct deposit', 'PayPal', 'Check'].map(o => ({ o, st: 'min-height:34px;padding:0 14px;border-radius:99px;font-size:13px;font-weight:800;' + (s.payDef === o ? 'background:#0F3B2E;color:#FFFFFF' : 'background:#FFFFFF;color:#0A0F0D;box-shadow:inset 0 0 0 1.5px #DDE5E0'), tap: () => this.setState({ payDef: o }) }));
    const bt = tip('i-bank'), pt = tip('i-past');
    return { personal: F.slice(0, 4).map(row), address: row(F[4]),
      pastList: P.past.map((p, i) => ({ p, rm: () => this.setState({ prof: Object.assign({}, P, { past: P.past.filter((_, j) => j !== i) }) }) })), hasPast: P.past.length > 0, pastDraft: s.pastDraft,
      onPast: (e) => this.setState({ pastDraft: e.target.value }), addPast: () => { const v = s.pastDraft.trim(); if (v.length < 8) return; this.setState({ prof: Object.assign({}, P, { past: P.past.concat([v]) }), pastDraft: '', acct: Object.assign({}, s.acct, { past: 1 }) }); },
      noPast: () => this.setState({ acct: Object.assign({}, s.acct, { past: 1 }) }), pastDone: !!s.acct.past && !P.past.length,
      bankOn: !!s.acct.bank, bankOff: !s.acct.bank, connect: () => this.setState({ acct: Object.assign({}, s.acct, { bank: 1 }), payDef: 'Direct deposit' }), disconnect: () => this.setState({ acct: Object.assign({}, s.acct, { bank: 0 }), payDef: s.payDef === 'Direct deposit' ? 'Check' : s.payDef }),
      pays, payNeedsBank: s.payDef === 'Direct deposit' && !s.acct.bank, tBank: bt, tPast: pt,
      cardPersonal: ring('dob'), cardAddr: ring('past'), cardPay: ring('bank'), cardPlain: ring('') };
  }
  setupVals() {""")
open('make.py','w').write(s); print('logic ok')
