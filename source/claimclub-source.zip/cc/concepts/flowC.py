# ClaimMoney-style claim flow, Claimclub theme, iOS look (Nov 22 2026, canvas only, not live).
# Henry: ClaimMoney explains the whole process first, then asks broad questions that apply to almost everyone,
# then checks each chosen claim with its own questions. Build the same kind of flow for Claimclub, iOS styling,
# iOS system font (SF Pro on Apple devices, Inter elsewhere). Canvas page "Flow C (iOS)".
# Board FlowC: one playable phone plus a storyboard of every screen. All rendering is in the JS below (render()).
import os, json, base64
from how4 import HEAD, OUT

HERE = os.path.dirname(os.path.abspath(__file__)); CC = os.path.join(HERE, '..')
SETS = {s['id']: s for s in json.load(open(os.path.join(HERE, 'sets.json')))}
SPEC = {x['id']: x for x in json.load(open(os.path.join(CC, 'data', 'filing_specs.json')))}
import re as _re
import revR
# Tiles that are only a letter (RealPage "R", flea and tick "P") get a Lucide glyph on the same brand gradient instead.
GLYPH = {'realpage': '<path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"/><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"/><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"/><path d="M10 6h4M10 10h4M10 14h4M10 18h4"/>',
         'fleatick': '<circle cx="11" cy="4" r="2"/><circle cx="18" cy="8" r="2"/><circle cx="20" cy="16" r="2"/><path d="M9 10a5 5 0 0 1 5 5v3.5a3.5 3.5 0 0 1-6.84 1.045Q6.52 17.48 4.46 16.84A3.5 3.5 0 0 1 5.5 10Z"/>'}
def tile(i):
    svg = open(os.path.join(CC, 'tiles', i + '.svg')).read()
    if i in GLYPH:
        svg = _re.sub(r'<text[^>]*>[^<]*</text>', '<svg x="15" y="15" width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round">' + GLYPH[i] + '</svg>', svg)
    return 'data:image/svg+xml;base64,' + base64.b64encode(svg.encode()).decode()
def b64(svg): return 'data:image/svg+xml;base64,' + base64.b64encode(svg.encode()).decode()
# Custom Claimclub illustrations (brand greens, soft 3D): ART_SEARCH for the quiz intro, ART_BAG for "You can file for up to".
ART_SEARCH = b64('''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><defs>
<linearGradient id="c1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2A9D6F"/><stop offset="1" stop-color="#0F3B2E"/></linearGradient>
<linearGradient id="c2" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#E9F7F0"/><stop offset="1" stop-color="#BFE6D3"/></linearGradient>
<linearGradient id="rim" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6BF0B5"/><stop offset="1" stop-color="#1FA36A"/></linearGradient>
<radialGradient id="gl" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="#FFFFFF" stop-opacity=".95"/><stop offset="1" stop-color="#DDF7EA" stop-opacity=".55"/></radialGradient>
<filter id="sh" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="0" dy="8" stdDeviation="8" flood-color="#0F3B2E" flood-opacity=".22"/></filter></defs>
<g filter="url(#sh)"><rect x="38" y="44" width="92" height="118" rx="18" fill="url(#c2)" transform="rotate(-10 84 103)"/>
<rect x="58" y="34" width="92" height="118" rx="18" fill="url(#c1)" transform="rotate(6 104 93)"/></g>
<g transform="rotate(6 104 93)" fill="#FFFFFF"><rect x="72" y="56" width="40" height="8" rx="4" opacity=".9"/><rect x="72" y="74" width="62" height="7" rx="3.5" opacity=".45"/><rect x="72" y="90" width="52" height="7" rx="3.5" opacity=".45"/>
<circle cx="80" cy="124" r="9" fill="#3DDC97"/><path d="M75.5 124l3 3 6-6" fill="none" stroke="#0F3B2E" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><rect x="96" y="120" width="36" height="8" rx="4" opacity=".7"/></g>
<g filter="url(#sh)"><path d="M150 150l26 26" stroke="#0F3B2E" stroke-width="16" stroke-linecap="round"/><circle cx="130" cy="130" r="34" fill="url(#gl)" stroke="url(#rim)" stroke-width="10"/></g>
<text x="130" y="143" text-anchor="middle" font-family="-apple-system,Inter,Arial,sans-serif" font-weight="800" font-size="36" fill="#12805C">$</text>
<path d="M30 58l3 7 7 3-7 3-3 7-3-7-7-3 7-3z" fill="#3DDC97"/><path d="M168 46l2 5 5 2-5 2-2 5-2-5-5-2 5-2z" fill="#3DDC97"/></svg>''')
ART_BAG = b64('''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><defs>
<radialGradient id="bg" cx=".35" cy=".3" r=".9"><stop offset="0" stop-color="#5BEAA9"/><stop offset=".45" stop-color="#22A86F"/><stop offset="1" stop-color="#0E5A40"/></radialGradient>
<linearGradient id="tie" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#0F3B2E"/><stop offset="1" stop-color="#1B6B4E"/></linearGradient>
<radialGradient id="coin" cx=".35" cy=".3" r=".9"><stop offset="0" stop-color="#FFF6C9"/><stop offset=".5" stop-color="#FFD25C"/><stop offset="1" stop-color="#E0A21A"/></radialGradient>
<filter id="sh" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="0" dy="10" stdDeviation="9" flood-color="#04140E" flood-opacity=".35"/></filter></defs>
<g filter="url(#sh)"><path d="M78 58c-6-10-12-22-4-28 8-6 18 4 26 4s18-10 26-4c8 6 2 18-4 28z" fill="#1E8C5E"/>
<path d="M76 60h48c30 18 46 46 46 74 0 30-26 46-70 46s-70-16-70-46c0-28 16-56 46-74z" fill="url(#bg)"/>
<rect x="72" y="54" width="56" height="13" rx="6.5" fill="url(#tie)"/>
<path d="M58 98c-6 14-8 26-6 36" stroke="#FFFFFF" stroke-opacity=".35" stroke-width="8" stroke-linecap="round" fill="none"/></g>
<text x="100" y="152" text-anchor="middle" font-family="-apple-system,Inter,Arial,sans-serif" font-weight="800" font-size="64" fill="#FFFFFF">$</text>
<g filter="url(#sh)"><ellipse cx="160" cy="172" rx="22" ry="9" fill="#C98A10"/><ellipse cx="160" cy="166" rx="22" ry="9" fill="url(#coin)"/><ellipse cx="160" cy="158" rx="22" ry="9" fill="#C98A10"/><ellipse cx="160" cy="152" rx="22" ry="9" fill="url(#coin)"/></g>
<path d="M36 50l3 8 8 3-8 3-3 8-3-8-8-3 8-3z" fill="#3DDC97"/><path d="M170 70l2.5 6 6 2.5-6 2.5-2.5 6-2.5-6-6-2.5 6-2.5z" fill="#FFD25C"/><path d="M28 130l2 5 5 2-5 2-2 5-2-5-5-2 5-2z" fill="#3DDC97"/></svg>''')

ART_CASH = b64('''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 220 200"><defs>
<linearGradient id="n" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5BEAA9"/><stop offset="1" stop-color="#1E8C5E"/></linearGradient>
<linearGradient id="n2" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3DDC97"/><stop offset="1" stop-color="#12805C"/></linearGradient>
<filter id="sh" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="0" dy="10" stdDeviation="9" flood-color="#04140E" flood-opacity=".4"/></filter></defs>
<g filter="url(#sh)"><rect x="30" y="112" width="150" height="62" rx="10" fill="#0E5A40"/><rect x="30" y="100" width="150" height="62" rx="10" fill="url(#n2)"/><rect x="30" y="88" width="150" height="62" rx="10" fill="#1E8C5E"/>
<g transform="rotate(-12 110 80)"><rect x="40" y="46" width="150" height="70" rx="10" fill="url(#n)"/><rect x="50" y="56" width="130" height="50" rx="7" fill="none" stroke="#FFFFFF" stroke-opacity=".5" stroke-width="2"/><circle cx="115" cy="81" r="18" fill="#FFFFFF" fill-opacity=".9"/><text x="115" y="90" text-anchor="middle" font-family="-apple-system,Inter,Arial,sans-serif" font-weight="800" font-size="26" fill="#12805C">$</text></g>
<rect x="96" y="86" width="18" height="76" fill="#0F3B2E" opacity=".85"/></g>
<path d="M28 40l3 7 7 3-7 3-3 7-3-7-7-3 7-3z" fill="#3DDC97"/><path d="M192 30l2.5 6 6 2.5-6 2.5-2.5 6-2.5-6-6-2.5 6-2.5z" fill="#FFD25C"/><path d="M196 150l2 5 5 2-5 2-2 5-2-5-5-2 5-2z" fill="#3DDC97"/></svg>''')
ART_COIN = b64('''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><defs>
<radialGradient id="c" cx=".35" cy=".3" r=".9"><stop offset="0" stop-color="#9FF5CB"/><stop offset=".5" stop-color="#3DDC97"/><stop offset="1" stop-color="#12805C"/></radialGradient>
<filter id="sh" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="0" dy="12" stdDeviation="10" flood-color="#04140E" flood-opacity=".4"/></filter></defs>
<circle cx="100" cy="100" r="88" fill="#3DDC97" opacity=".12"/><circle cx="100" cy="100" r="70" fill="#3DDC97" opacity=".12"/>
<g filter="url(#sh)"><circle cx="100" cy="104" r="56" fill="#0E5A40"/><circle cx="100" cy="96" r="56" fill="url(#c)"/><circle cx="100" cy="96" r="44" fill="none" stroke="#FFFFFF" stroke-opacity=".5" stroke-width="3"/></g>
<path d="M82 96l12 12 24-26" fill="none" stroke="#0F3B2E" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M30 46l3 7 7 3-7 3-3 7-3-7-7-3 7-3z" fill="#FFD25C"/><path d="M170 60l2.5 6 6 2.5-6 2.5-2.5 6-2.5-6-6-2.5 6-2.5z" fill="#3DDC97"/><path d="M160 160l2 5 5 2-5 2-2 5-2-5-5-2 5-2z" fill="#3DDC97"/></svg>''')

# Broad questions: short, apply to most people. Each maps to one settlement; that settlement's own questions come later.
BROAD = [('apple', 'Do you own an iPhone?'), ('visa', 'Have you ever paid a fee to use an ATM?'), ('hyundaikia', 'Have you owned or leased a Hyundai or Kia?'),
         ('googleplay', 'Have you bought an app on an Android phone?'), ('realpage', 'Have you rented an apartment since 2018?'),
         ('fleatick', 'Do you have a dog or a cat?'), ('toyota', 'Have you owned or leased a Toyota?'), ('seatgeek', 'Have you bought tickets on SeatGeek?')]
# One short line per claim for the Choose your claims list (no truncation).
SHORT = {'apple': 'Bought an iPhone 15 Pro or iPhone 16', 'visa': 'Paid an out-of-network ATM fee', 'hyundaikia': 'Own or lease a listed Hyundai or Kia',
         'googleplay': 'Bought apps on Google Play', 'realpage': 'Rented an apartment since 2018', 'fleatick': 'Bought K9 Advantix or Advantage',
         'toyota': 'Own or lease a listed Toyota', 'seatgeek': 'Bought SeatGeek tickets in Nevada'}
REVIEWS = [{'n': r[0], 'p': r[1], 'img': revR.PH(r[2]), 'amt': r[3], 'q': r[6]} for r in revR.R[:5]]
D = []
for i, q in BROAD:
    s, p = SETS[i], SPEC.get(i, {})
    mx = s.get('max') or s.get('amt') or 0
    D.append({'id': i, 'co': s['co'], 'title': s['title'], 'q': q, 'max': mx, 'pay': ('Up to $' + f'{mx:,}') if mx else 'Refund owed',
              'dl': s.get('dl'), 'who': s.get('who', ''), 'short': SHORT[i], 'proof': s.get('proof', ''), 'tile': tile(i),
              'checks': [x['q'] for x in (p.get('qualify') or [])][:3] or ['Does this sound like you? ' + s.get('who', '')]})
NOPEN = sum(1 for s in SETS.values() if not s.get('st') and (s.get('dl') or '9') >= '2026-11-22')

CSS = r"""
.fc{--ink:#000000;--sec:#6E6E73;--sep:rgba(60,60,67,.14);--fill:#F2F2F7;--brand:#12805C;--dark:#0F3B2E;--mint:#3DDC97;
 font-family:-apple-system,BlinkMacSystemFont,Inter,"Helvetica Neue",Arial,sans-serif;color:var(--ink);-webkit-font-smoothing:antialiased;
 width:390px;height:844px;flex:none;border-radius:50px;overflow:hidden;position:relative;background:#FFFFFF;isolation:isolate;display:flex;flex-direction:column;box-shadow:0 0 0 11px #1C1C1E,0 0 0 12px #3A3A3C,0 30px 60px rgba(0,0,0,.25);user-select:none}
.fc *{box-sizing:border-box}
.fc .sb{height:50px;flex:none;display:flex;align-items:center;justify-content:space-between;padding:6px 30px 0 36px;font-weight:600;font-size:16px;letter-spacing:-.2px}
.fc .di{position:absolute;top:11px;left:50%;transform:translateX(-50%);width:122px;height:35px;border-radius:20px;background:#000}
.fc .nav{height:44px;flex:none;display:flex;align-items:center;gap:10px;padding:0 18px}
.fc .nav .bk{width:30px;height:30px;display:flex;align-items:center;justify-content:center;margin-left:-6px;cursor:pointer;color:var(--brand)}
.fc .lg{font-weight:700;font-size:19px;letter-spacing:-.4px}.fc .lg i{font-style:normal;color:var(--brand)}
.fc .pr{margin-left:auto;width:112px;height:5px;border-radius:9px;background:#E5E5EA;overflow:hidden}.fc .pr b{display:block;height:100%;background:var(--brand);border-radius:9px;transition:width .3s}
.fc .bd{flex:1;min-height:0;display:flex;flex-direction:column;padding:8px 20px 0;overflow:hidden}
.fc .t1{font-size:32px;line-height:1.1;font-weight:700;letter-spacing:-.8px;margin:6px 0 0}
.fc .t1 em{font-style:normal;color:var(--brand)}
.fc .sub{font-size:17px;line-height:1.4;color:var(--sec);margin-top:10px;letter-spacing:-.2px}
.fc .ft{flex:none;padding:12px 20px 34px;display:flex;flex-direction:column;gap:10px}
.fc .btn{height:54px;border-radius:15px;border:0;background:var(--dark);color:#FFF;font:inherit;font-size:17px;font-weight:600;letter-spacing:-.2px;display:flex;align-items:center;justify-content:center;gap:8px;cursor:pointer;width:100%}
.fc .btn:disabled{background:#D1D1D6;color:#FFF;cursor:default}
.fc .btn.ln{background:#FFF;color:var(--ink);box-shadow:inset 0 0 0 1.5px #D1D1D6}
.fc .btn.mint{background:var(--mint);color:var(--dark)}
.fc .lk{background:none;border:0;font:inherit;font-size:16px;color:var(--brand);font-weight:600;cursor:pointer;height:34px}
.fc .opt{display:flex;align-items:center;gap:12px;min-height:60px;padding:14px 16px;border-radius:14px;background:var(--fill);font-size:17px;font-weight:600;letter-spacing:-.3px;cursor:pointer;line-height:1.25}
.fc .opt.on{background:#E6F4EE;box-shadow:inset 0 0 0 2px var(--brand)}
.fc .ck{margin-left:auto;width:24px;height:24px;flex:none;border-radius:99px;box-shadow:inset 0 0 0 1.75px #C7C7CC;display:flex;align-items:center;justify-content:center}
.fc .ck.sq{border-radius:7px}
.fc .on .ck{background:var(--brand);box-shadow:none}
.fc .grp{background:#FFF;border-radius:14px;overflow:hidden}
.fc .row{display:flex;align-items:center;gap:12px;padding:12px 16px;position:relative}
.fc .row+.row:before{content:"";position:absolute;left:16px;right:0;top:0;height:.5px;background:var(--sep)}
.fc .chip{display:inline-flex;align-items:center;gap:4px;font-size:12.5px;font-weight:600;padding:3px 8px;border-radius:99px;background:#E6F4EE;color:var(--brand)}
.fc .card{background:#FFF;border-radius:18px;box-shadow:0 1px 2px rgba(0,0,0,.06),0 8px 24px rgba(0,0,0,.08)}
.fc .rb{width:76px;height:76px;border-radius:99px;border:0;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:transform .12s}.fc .rb:active{transform:scale(.92)}
.fc .yn{height:54px;border-radius:15px;background:#FFF;box-shadow:inset 0 0 0 1.5px #D1D1D6;font-size:17px;font-weight:600;display:flex;align-items:center;justify-content:center;cursor:pointer;flex:1}
.fc .yn.on{background:var(--dark);color:#FFF;box-shadow:none}
.fc .yn.no.on{background:#3A3A3C}
.fc .seg{display:flex;background:#E9E9EB;border-radius:10px;padding:2px;gap:2px}
.fc .seg span{flex:1;height:34px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:15px;font-weight:600;cursor:pointer;color:#3C3C43}
.fc .seg span.on{background:#FFF;box-shadow:0 1px 3px rgba(0,0,0,.12)}
.fc .emo{font-size:76px;line-height:1;text-align:center}
.fc .inp{height:52px;border-radius:12px;background:var(--fill);border:0;font:inherit;font-size:17px;padding:0 16px;width:100%;outline:none;color:var(--ink)}
.fc .lab{font-size:13px;color:var(--sec);font-weight:500;margin:0 4px 6px;text-transform:uppercase;letter-spacing:.2px}
.fc .scr>*{flex-shrink:0}.fc .scr{overflow:auto;scrollbar-width:none}.fc .scr::-webkit-scrollbar{display:none}
.fc .fadein{animation:fcIn .22s ease-out both}
@keyframes fcIn{from{opacity:0;transform:translateX(14px)}to{opacity:1;transform:none}}
@keyframes fcSpin{to{transform:rotate(360deg)}}
@keyframes fcPop{0%{transform:scale(.6);opacity:0}70%{transform:scale(1.06);opacity:1}100%{transform:scale(1)}}
@keyframes fcFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}
@media (prefers-reduced-motion: reduce){.fc *{animation:none !important;transition:none !important}}
.sbd{display:flex;flex-wrap:wrap;gap:34px 26px}
.mini{width:195px;height:422px;position:relative;flex:none}
.mini .fc{transform:scale(.5);transform-origin:0 0;position:absolute;left:0;top:0;pointer-events:none}
.mini span.cap{position:absolute;top:432px;left:0;width:195px;text-align:center;font:600 13px/1.3 -apple-system,BlinkMacSystemFont,Inter,sans-serif;color:#43504A}
"""

JSR = r"""
  componentDidMount() {
    const roots = [document]; document.querySelectorAll('*').forEach((el) => { if (el.shadowRoot) roots.push(el.shadowRoot); });
    roots.forEach((root) => root.querySelectorAll('[data-fc]').forEach((el) => { if (!el._fc) { el._fc = 1; this.boot(el); } }));
    roots.forEach((root) => root.querySelectorAll('[data-setoffer]').forEach((b) => { b.onclick = () => { const ph = root.querySelector('[data-fc]:not([data-step])'); root.querySelectorAll('[data-setoffer]').forEach((x) => { x.style.background = x === b ? '#0F3B2E' : '#FFF'; x.style.color = x === b ? '#FFF' : '#0F3B2E'; }); if (ph && ph._setOffer) ph._setOffer(b.dataset.setoffer); }; }));
  }
  boot(el) {
    const D = __DATA__, NOPEN = __NOPEN__;
    const STEPS = ['w1', 'gap', 'w2', 'w3', 'w4', 'rev', 'name', 'pains', 'goal', 'plan', 'qintro'].concat(D.map((d, i) => 'q' + i)).concat(['load', 'est', 'pick', 'chk', 'win', 'offer', 'paid', 'profile', 'done']);
    const money = (n) => '$' + Math.round(n).toLocaleString('en-US');
    const fmtD = (iso) => { if (!iso) return 'No deadline'; const d = new Date(iso + 'T12:00:00'); return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }); };
    const daysL = (iso) => iso ? Math.max(0, Math.round((new Date(iso + 'T12:00:00') - new Date('2026-11-22T12:00:00')) / 864e5)) : null;
    const I = (p, s, c, w) => '<svg width="' + (s || 20) + '" height="' + (s || 20) + '" viewBox="0 0 24 24" fill="none" stroke="' + (c || 'currentColor') + '" stroke-width="' + (w || 2.2) + '" stroke-linecap="round" stroke-linejoin="round" style="flex:none;display:block"><path d="' + p + '"/></svg>';
    const P = { back: 'm15 18-6-6 6-6', check: 'M20 6 9 17l-5-5', x: 'M18 6 6 18 M6 6l12 12', cal: 'M8 2v4 M16 2v4 M3 10h18 M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z',
      user: 'M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2 M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z', tag: 'M12.6 2.6A2 2 0 0 0 11.2 2H4a2 2 0 0 0-2 2v7.2a2 2 0 0 0 .6 1.4l8.7 8.7a2.4 2.4 0 0 0 3.4 0l6.6-6.6a2.4 2.4 0 0 0 0-3.4z M7.5 7.5h.01',
      lock: 'M5 11h14a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2z M7 11V7a5 5 0 0 1 10 0v4', bell: 'M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9 M10.3 21a1.94 1.94 0 0 0 3.4 0',
      send: 'm22 2-7 20-4-9-9-4Z M22 2 11 13', search: 'm21 21-4.34-4.34 M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z', coins: 'M8 14a6 6 0 1 0 0-12 6 6 0 0 0 0 12z M18.09 10.37A6 6 0 1 1 10.34 18 M7 6h1v4',
      shield: 'M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z', gavel: 'm14 13-7.5 7.5a2.12 2.12 0 0 1-3-3L11 10 m5 6 6-6 m-8-8 6 6', heart: 'M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z' };
    const T = (d, s) => '<img src="' + d.tile + '" alt="" draggable="false" style="width:' + s + 'px;height:' + s + 'px;border-radius:' + Math.round(s * .24) + 'px;flex:none;display:block">';
    const PAINS = ["I'm not sure what I qualify for", "I don't have time to find and file claims", 'I miss claim deadlines', 'I lose track of claims and payouts', 'A little extra money would help'];
    const GOALS = ['Cover everyday bills', 'Handle a surprise cost', 'Pay down debt', 'Build my savings', 'Treat myself', 'Just see what I may be owed'];
    const init = () => ({ s: 0, name: '', pains: {}, goal: '', yes: {}, sel: {}, chk: {}, ci: 0, agree: false, plan: 'yearly', load: 0, p: {}, offer: el.dataset.offer || 'A', pk: '6m' });
    let st = init();
    const fixed = el.dataset.step;
    if (fixed) { // storyboard: sample answers so each frame shows real content
      st = Object.assign(init(), { s: STEPS.indexOf(fixed), name: 'Ana', pains: { 0: 1, 2: 1 }, goal: GOALS[3], yes: { apple: 1, visa: 1, realpage: 1, fleatick: 1, hyundaikia: 1 }, load: 4 });
      st.sel = { apple: 1, visa: 1, realpage: 1, fleatick: 1 }; if (fixed === 'chk') st.chk = { apple: { 0: 'y' } }; if (fixed === 'paid') st.payDone = 1; if (['win', 'offer', 'paid', 'profile', 'done'].includes(fixed)) D.forEach((d) => { if (st.sel[d.id]) st.chk[d.id] = Object.fromEntries(d.checks.map((q, k) => [k, 'y'])); });
    }
    const VAR = (k) => (fixed === k || (fixed && fixed.startsWith(k)) ? el.dataset.v : '') || 'a';
    const matched = () => D.filter((d) => st.yes[d.id]);
    const picked = () => D.filter((d) => st.sel[d.id]);
    const elig = () => picked().filter((d) => d.checks.every((q, k) => (st.chk[d.id] || {})[k] === 'y'));
    const sum = (L) => L.reduce((t, d) => t + (d.max || 0), 0);
    const go = (n) => { st.s = Math.max(0, Math.min(STEPS.length - 1, n)); draw(true); if (STEPS[st.s] === 'load') runLoad(); };
    const next = () => go(st.s + 1);
    let lt;
    const runLoad = () => { st.load = 0; clearInterval(lt); lt = setInterval(() => { st.load += 1; draw(); if (st.load >= 4) { clearInterval(lt); setTimeout(() => { if (STEPS[st.s] === 'load') next(); }, 500); } }, 650); };

    const chrome = (inner, o) => {
      o = o || {};
      const pct = Math.round(((st.s + 1) / STEPS.length) * 100);
      return '<div class="di"></div><div class="sb"><span>9:41</span><span style="display:flex;gap:6px;align-items:center"><svg width="18" height="12" viewBox="0 0 18 12"><rect x="0" y="8" width="3" height="4" rx="1" fill="#000"/><rect x="5" y="5" width="3" height="7" rx="1" fill="#000"/><rect x="10" y="2.5" width="3" height="9.5" rx="1" fill="#000"/><rect x="15" y="0" width="3" height="12" rx="1" fill="#000"/></svg><svg width="26" height="13" viewBox="0 0 26 13"><rect x=".5" y=".5" width="22" height="12" rx="3.5" fill="none" stroke="#000" opacity=".4"/><rect x="2" y="2" width="19" height="9" rx="2" fill="#000"/><rect x="24" y="4.5" width="1.5" height="4" rx=".75" fill="#000" opacity=".4"/></svg></span></div>'
        + (o.noNav ? '' : '<div class="nav">' + (st.s > 0 && !o.noBack ? '<span class="bk" data-a="back">' + I(P.back, 26, 'currentColor', 2.6) + '</span>' : '') + '<span class="lg">claimclub<i>.io</i></span>' + (o.noBar ? '' : '<span class="pr"><b style="width:' + pct + '%"></b></span>') + (o.pill || '') + '</div>')
        + inner;
    };
    const foot = (b) => '<div class="ft">' + b + '</div>';
    const btn = (t, a, dis, cls) => '<button class="btn ' + (cls || '') + '" data-a="' + a + '"' + (dis ? ' disabled' : '') + '>' + t + '</button>';

    const S = {};
    // 1 to 4: explain the whole thing before asking anything
    S.w1 = () => { const v = VAR('w1'); const tiles = D.slice(0, 6);
      let art;
      if (v === 'b') art = '<div style="flex:1;display:flex;align-items:center;justify-content:center;position:relative;margin-top:10px"><div style="width:100%;border-radius:28px;background:radial-gradient(120% 120% at 0% 0%,#2A9D6F,#0F3B2E 60%);padding:26px 22px;color:#FFF;position:relative;overflow:hidden">'
        + '<span style="font-size:12.5px;font-weight:700;letter-spacing:1px;color:#9FE5C4">SETTLED IN CLASS ACTIONS EVERY YEAR</span><b style="display:block;font-size:64px;letter-spacing:-2.5px;line-height:1.05;margin-top:6px;color:#3DDC97">$40B+</b><span style="font-size:15px;color:#CFE9DD">Most people never file their share.</span>'
        + '<div style="display:flex;margin-top:22px">' + tiles.map((d, k) => '<span style="margin-left:' + (k ? -12 : 0) + 'px;padding:3px;border-radius:16px;background:#0F3B2E">' + T(d, 46) + '</span>').join('') + '<span style="margin-left:-12px;width:52px;height:52px;border-radius:16px;background:#3DDC97;color:#0F3B2E;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:14px;border:3px solid #0F3B2E">+' + (NOPEN - 6) + '</span></div>'
        + '<span style="position:absolute;right:-30px;top:-30px;width:150px;height:150px;border-radius:99px;border:22px solid rgba(61,220,151,.12)"></span></div></div>';
      else if (v === 'c') art = '<div style="flex:1;position:relative;margin-top:14px"><div style="position:absolute;left:12px;right:12px;top:26px;height:230px;border-radius:14px;background:#FFF;box-shadow:0 10px 30px rgba(0,0,0,.12);padding:20px;transform:rotate(-3deg);animation:fcFloat 4s ease-in-out infinite">'
        + '<span style="font-size:11px;font-weight:800;letter-spacing:1.2px;color:#8E8E93">LEGAL NOTICE</span><b style="display:block;font-size:20px;letter-spacing:-.4px;margin-top:6px;line-height:1.2">You may be owed money from a class action settlement</b><i style="display:block;height:7px;border-radius:9px;background:#E5E5EA;margin-top:14px"></i><i style="display:block;height:7px;width:80%;border-radius:9px;background:#E5E5EA;margin-top:8px"></i><i style="display:block;height:7px;width:60%;border-radius:9px;background:#E5E5EA;margin-top:8px"></i>'
        + '<span style="position:absolute;right:16px;bottom:16px;font-size:13px;font-weight:800;color:#12805C;border:2.5px solid #12805C;border-radius:8px;padding:3px 9px;transform:rotate(-8deg)">UNCLAIMED</span></div>'
        + '<div style="position:absolute;left:0;right:0;bottom:6px;height:200px;border-radius:24px;background:linear-gradient(160deg,#1E7A55,#0F3B2E);clip-path:polygon(0 18%,50% 48%,100% 18%,100% 100%,0 100%);display:flex;align-items:flex-end;padding:20px"><span style="display:flex">' + tiles.slice(0, 5).map((d, k) => '<span style="margin-left:' + (k ? -10 : 0) + 'px;padding:2px;border-radius:12px;background:#0F3B2E">' + T(d, 38) + '</span>').join('') + '</span><b style="margin-left:auto;color:#3DDC97;font-size:15px">' + NOPEN + ' open cases</b></div></div>';
      else art = '<div style="flex:1;position:relative;margin-top:14px">' + tiles.map((d, i) => '<div style="position:absolute;left:' + [30, 150, 250, 60, 190, 110][i] + 'px;top:' + [20, 0, 40, 120, 110, 60][i] + 'px;transform:rotate(' + [-10, 6, 12, -4, 8, -14][i] + 'deg);animation:fcFloat ' + (3 + i * .4) + 's ease-in-out infinite">' + T(d, 74) + '</div>').join('')
        + '<div style="position:absolute;left:0;right:0;bottom:12px;height:200px"><span style="position:absolute;left:0;top:0;width:130px;height:40px;border-radius:18px 18px 0 0;background:#155F44"></span><div style="position:absolute;left:0;right:0;top:22px;bottom:0;border-radius:0 26px 26px 26px;background:linear-gradient(160deg,#1E7A55,#0F3B2E);display:flex;align-items:flex-end;padding:22px"><b style="color:#FFF;font-size:30px;line-height:1;letter-spacing:-.5px">UNCLAIMED<br>MONEY</b><span style="margin-left:auto;color:#3DDC97;font-weight:700;font-size:15px">' + NOPEN + ' open cases</span></div></div></div>';
      return chrome('<div class="bd"><h1 class="t1">Companies owe people <em>money</em>. Most never claim it.</h1><p class="sub">When a company settles a class action, the court sets money aside for everyone affected. You only get paid if you file a claim.</p>' + art + '</div>' + foot(btn('Continue', 'next')), { noBack: true }); };
    S.gap = () => chrome('<div class="bd"><h1 class="t1">About <em>$1 billion</em> in settlement money goes unclaimed every year.</h1><p class="sub">Fewer than 1 in 10 people ever file for their share.</p>'
      + '<div style="flex:1;display:flex;flex-direction:column;justify-content:center;gap:18px"><div style="display:grid;grid-template-columns:repeat(5,1fr);gap:12px;padding:0 8px">' + Array.from({ length: 10 }, (x, k) => '<span style="display:flex;justify-content:center;animation:fcPop .4s ' + (k * .05) + 's both">' + I(P.user, 46, k === 0 ? '#12805C' : '#D1D1D6', 2.4) + '</span>').join('') + '</div>'
      + '<div style="display:flex;gap:10px"><div style="flex:1;border-radius:16px;background:#0F3B2E;color:#FFF;padding:14px"><b style="font-size:26px;color:#3DDC97">$42B</b><span style="display:block;font-size:13.5px;color:#CFE9DD;margin-top:2px">in class action settlements in 2024</span></div><div style="flex:1;border-radius:16px;background:#E6F4EE;padding:14px"><b style="font-size:26px;color:#12805C">9%</b><span style="display:block;font-size:13.5px;color:#3C3C43;margin-top:2px">of eligible people file, in a typical settlement</span></div></div>'
      + '<span style="font-size:11.5px;color:#8E8E93;line-height:1.4">Sources: Talli 2025 class action statistics; Duane Morris Class Action Review 2025; FTC study of 149 consumer class action settlements, 2019.</span></div></div>' + foot(btn('Continue', 'next')));
    S.rev = () => chrome('<div class="bd" style="padding-bottom:4px"><div style="flex:1;display:flex;flex-direction:column;gap:10px;min-height:0">'
      + __REVIEWS__.slice(0, 4).map((r, k) => '<div style="flex:1;min-height:0;border-radius:20px;padding:14px 16px;display:flex;flex-direction:column;justify-content:center;gap:8px;background:' + (k % 2 ? '#0F3B2E' : '#F2F2F7') + ';color:' + (k % 2 ? '#FFF' : '#000') + '"><span style="display:flex;align-items:center;gap:10px"><img src="' + r.img + '" style="width:36px;height:36px;border-radius:99px"><span style="display:flex;flex-direction:column;flex:1"><b style="font-size:15px">' + r.n + '</b><span style="font-size:12px;opacity:.65">' + r.p + '</span></span><span style="font-size:13px;font-weight:800;color:' + (k % 2 ? '#3DDC97' : '#12805C') + '">+$' + r.amt + '</span></span><span style="color:#FF9500;font-size:13px;letter-spacing:1px">★★★★★</span><span style="font-size:15px;line-height:1.38">“' + r.q + '”</span></div>').join('')
      + '</div><span style="font-size:11.5px;color:#8E8E93;text-align:center;margin-top:8px">Example reviews. Real member reviews coming soon.</span></div>' + foot(btn('Continue', 'next')));
    S.w2 = () => chrome('<div class="bd"><h1 class="t1">We find the payouts. <em>You keep the cash.</em></h1><p class="sub">Answer a few quick questions and we match you to the settlements you likely qualify for.</p>'
      + '<div style="flex:1;display:flex;flex-direction:column;gap:12px;margin-top:22px;padding:4px 2px">' + [D[0], D[2], D[4]].map((d, i) => '<div class="card" style="padding:14px 16px;display:flex;flex-direction:column;gap:8px;transform:rotate(' + [-1.2, .8, -.6][i] + 'deg)"><span style="display:flex;align-items:center;gap:10px">' + T(d, 30) + '<b style="font-size:15px;flex:1">' + d.co + '</b><span style="font-size:13px;color:var(--sec)">' + daysL(d.dl) + ' days left</span></span><span style="display:flex;align-items:flex-end"><span style="display:flex;flex-direction:column"><span style="font-size:12.5px;color:var(--sec)">Open settlement</span><b style="font-size:26px;letter-spacing:-.6px">' + d.pay + '</b></span><span class="chip" style="margin-left:auto">' + I(P.check, 13, 'currentColor', 3) + 'Likely match</span></span></div>').join('') + '</div></div>'
      + foot(btn('Continue', 'next')));
    S.w3 = () => chrome('<div class="bd"><h1 class="t1">We file for you and <em>track every claim.</em></h1><p class="sub">We fill in each claim form, send it to the settlement and follow it until it pays. Payouts usually take 6 to 12 months.</p>'
      + '<div style="flex:1;margin-top:18px;border-radius:26px;background:linear-gradient(160deg,#1E7A55,#0F3B2E);position:relative;padding:22px 16px;display:flex;flex-direction:column;gap:10px">'
      + '<div class="card" style="padding:12px 14px"><b style="font-size:14px">Your claims</b>' + [D[0], D[2], D[4]].map((d, i) => '<div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-top:.5px solid var(--sep);margin-top:' + (i ? 0 : 8) + 'px">' + T(d, 26) + '<span style="flex:1;font-size:14px;font-weight:600">' + d.co + '</span><span class="chip" style="' + (i === 2 ? 'background:#F2F2F7;color:#6E6E73' : '') + '">' + ['Filed', 'Filed', 'Filing'][i] + '</span></div>').join('') + '</div>'
      + '<div style="background:rgba(255,255,255,.9);backdrop-filter:blur(10px);border-radius:16px;padding:10px 12px;display:flex;gap:10px;align-items:center;box-shadow:0 8px 20px rgba(0,0,0,.2);animation:fcPop .5s .4s both"><span style="width:30px;height:30px;border-radius:8px;background:#0F3B2E;display:flex;align-items:center;justify-content:center">' + I(P.check, 16, '#3DDC97', 3) + '</span><span style="font-size:13.5px;line-height:1.3"><b>Claimclub</b><br>Your Visa & Mastercard claim was filed.</span></div></div></div>'
      + foot(btn('Continue', 'next')));
    S.w4 = () => chrome('<div class="bd"><h1 class="t1">Real settlements. <em>Your money stays yours.</em></h1><p class="sub">Here is what you can count on.</p><div class="grp" style="margin-top:20px;background:var(--fill)">'
      + [[P.gavel, 'Court-approved settlements', 'Every case we list was approved by a court.'], [P.heart, 'You keep 100% of every payout', 'The settlement pays you directly. We never take a cut.'], [P.lock, 'Your details stay private', 'We only share them with the settlements you file.'], [P.x, 'Cancel anytime', 'One tap in your account.']].map((r) => '<div class="row" style="padding:14px 16px"><span style="width:36px;height:36px;border-radius:10px;background:#E6F4EE;display:flex;align-items:center;justify-content:center">' + I(r[0], 19, '#12805C') + '</span><span style="display:flex;flex-direction:column;gap:2px"><b style="font-size:16px;letter-spacing:-.2px">' + r[1] + '</b><span style="font-size:14px;color:var(--sec)">' + r[2] + '</span></span></div>').join('') + '</div>'
      + '<p style="font-size:13px;color:var(--sec);margin-top:14px;line-height:1.4">Claimclub is not a law firm. You can always file for free on the official settlement site.</p></div>' + foot(btn('Continue', 'next')));
    S.name = () => chrome('<div class="bd" style="justify-content:center;margin-top:-40px"><h1 class="t1" style="text-align:center">What should we <em>call you?</em></h1><p class="sub" style="text-align:center;margin-bottom:26px">Just your first name for now.</p>'
      + '<div class="lab">First name</div><input class="inp" data-k="name" placeholder="First name" value="' + (st.name || '') + '" autocomplete="given-name"></div>' + foot(btn('Continue', 'next', !st.name.trim())));
    S.pains = () => chrome('<div class="bd scr"><h1 class="t1">' + (st.name ? st.name + ', which' : 'Which') + ' of these <em>sound like you?</em></h1><p class="sub">Pick any that fit.</p><div style="display:flex;flex-direction:column;gap:10px;margin:20px 0 10px">'
      + PAINS.map((t, i) => '<div class="opt' + (st.pains[i] ? ' on' : '') + '" data-a="pain" data-v="' + i + '">' + t + '<span class="ck sq">' + (st.pains[i] ? I(P.check, 15, '#FFF', 3.2) : '') + '</span></div>').join('') + '</div></div>'
      + foot(btn('Continue', 'next', !Object.keys(st.pains).length)));
    S.goal = () => chrome('<div class="bd scr"><h1 class="t1">If you got paid, <em>what would it go to?</em></h1><p class="sub">Choose the one that matters most.</p><div style="display:flex;flex-direction:column;gap:10px;margin:20px 0 10px">'
      + GOALS.map((t) => '<div class="opt' + (st.goal === t ? ' on' : '') + '" data-a="goal" data-v="' + t + '">' + t + '<span class="ck">' + (st.goal === t ? I(P.check, 15, '#FFF', 3.2) : '') + '</span></div>').join('') + '</div></div>'
      + foot(btn('Continue', 'next', !st.goal)));
    S.plan = () => { const vis = [
        '<div style="display:flex;gap:6px"><span style="width:38px;height:38px;border-radius:99px;background:#FFF;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 6px rgba(0,0,0,.12)">' + I(P.x, 18, '#FF3B30', 3) + '</span><span style="width:38px;height:38px;border-radius:99px;background:#3DDC97;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 6px rgba(0,0,0,.12)">' + I(P.check, 18, '#0F3B2E', 3.2) + '</span></div>',
        '<div style="display:flex;flex-direction:column;gap:5px;width:96px">' + [0, 1].map((k) => '<span style="display:flex;align-items:center;gap:6px;background:#FFF;border-radius:9px;padding:5px 6px;box-shadow:0 2px 6px rgba(0,0,0,.1)">' + T(D[k], 18) + '<i style="flex:1;height:5px;border-radius:9px;background:#E5E5EA"></i>' + I(P.check, 12, '#12805C', 3.4) + '</span>').join('') + '</div>',
        '<div style="background:#FFF;border-radius:12px;padding:7px 9px;display:flex;gap:7px;align-items:center;box-shadow:0 2px 6px rgba(0,0,0,.12)"><span style="width:22px;height:22px;border-radius:6px;background:#0F3B2E;display:flex;align-items:center;justify-content:center">' + I(P.check, 12, '#3DDC97', 3.4) + '</span><b style="font-size:13px">+$95.00</b></div>'];
      return chrome('<div class="bd"><h1 class="t1">How you <em>get paid</em></h1><div style="flex:1;display:flex;flex-direction:column;justify-content:center;gap:14px;margin-top:-10px">'
        + [['1', 'Answer a few questions'], ['2', 'We file your claims'], ['3', 'The settlement pays you']].map((r, i) => '<div style="display:flex;align-items:center;gap:16px;border-radius:22px;background:linear-gradient(135deg,#E9F7F0,#D3EFE2);padding:18px"><div style="width:124px;height:76px;flex:none;border-radius:16px;background:linear-gradient(160deg,#1E7A55,#0F3B2E);display:flex;align-items:center;justify-content:center">' + vis[i] + '</div><span style="display:flex;flex-direction:column;gap:2px"><span style="font-size:13px;font-weight:700;color:#12805C">STEP ' + r[0] + '</span><b style="font-size:19px;letter-spacing:-.4px;line-height:1.2">' + r[1] + '</b></span></div>').join('')
        + '</div></div>' + foot(btn("Let's go", 'next'))); };
    S.qintro = () => chrome('<div class="bd" style="justify-content:center;align-items:center;text-align:center;margin-top:-30px"><img src="__ART_SEARCH__" alt="" style="width:200px;height:200px;animation:fcPop .5s both"><h1 class="t1" style="margin-top:12px">Let\'s see what <em>you may be owed.</em></h1><p class="sub">' + D.length + ' quick yes or no questions.</p></div>' + foot(btn("Let's find out", 'next')));
    D.forEach((d, i) => {
      S['q' + i] = () => chrome('<div class="bd" style="padding:6px 16px 0;background:linear-gradient(180deg,#FFFFFF,#F2F2F7)"><div style="display:flex;justify-content:flex-end;margin-bottom:10px"><span style="font-size:13px;font-weight:600;padding:6px 12px;border-radius:99px;background:#FFF;box-shadow:0 1px 3px rgba(0,0,0,.1)"><b style="color:#12805C">' + (i + 1) + '</b>/' + D.length + ' questions</span></div>'
        + '<div class="card swipe" style="flex:1;padding:24px 22px;display:flex;flex-direction:column;position:relative;transform:translateX(calc(var(--dx,0)*1px)) rotate(calc(var(--dx,0)*.05deg));touch-action:none;cursor:grab">'
        + '<span style="position:absolute;top:22px;right:20px;font-size:22px;font-weight:800;color:#12805C;border:3px solid #12805C;border-radius:10px;padding:0 10px;transform:rotate(10deg);opacity:clamp(0,calc(var(--dx,0)/90),1)">YES</span><span style="position:absolute;top:22px;right:20px;font-size:22px;font-weight:800;color:#FF3B30;border:3px solid #FF3B30;border-radius:10px;padding:0 10px;transform:rotate(10deg);opacity:clamp(0,calc(var(--dx,0)/-90),1)">NO</span>'
        + T(d, 54) + '<h2 style="font-size:28px;line-height:1.15;font-weight:700;letter-spacing:-.7px;margin:18px 0 0">' + d.q + '</h2>'
        + '<div style="flex:1;display:flex;align-items:center;justify-content:center">' + T(d, 150) + '</div></div>'
        + '<div style="display:flex;justify-content:center;gap:34px;padding:18px 0 34px"><button class="rb" data-a="ans" data-v="n" aria-label="No" style="background:#FFF;box-shadow:0 8px 20px rgba(0,0,0,.12),inset 0 0 0 1px #E5E5EA">' + I(P.x, 32, '#FF3B30', 3.2) + '</button>'
        + '<button class="rb" data-a="ans" data-v="y" aria-label="Yes" style="background:#3DDC97;box-shadow:0 8px 20px rgba(61,220,151,.45)">' + I(P.check, 34, '#0F3B2E', 3.4) + '</button></div></div>');
    });
    S.load = () => { const v = VAR('load'), m = matched().length ? matched() : D.slice(0, 4), steps = ['Reviewing your answers', 'Matching open settlements', 'Estimating your payouts', 'Finishing up'];
      const checks = '<div style="display:flex;flex-direction:column;gap:14px;margin-top:22px;text-align:left;width:250px">' + steps.map((t, i) => '<span style="display:flex;align-items:center;gap:12px;font-size:16px;font-weight:600;color:' + (i <= st.load ? '#000' : '#AEAEB2') + '">' + (i < st.load ? '<span style="width:24px;height:24px;border-radius:99px;background:#12805C;display:flex;align-items:center;justify-content:center">' + I(P.check, 14, '#FFF', 3.2) + '</span>' : '<span style="width:24px;height:24px;border-radius:99px;border:2.5px solid ' + (i === st.load ? '#12805C' : '#D1D1D6') + ';border-right-color:transparent;' + (i === st.load ? 'animation:fcSpin .9s linear infinite' : '') + '"></span>') + t + '</span>').join('') + '</div>';
      if (v === 'b') { return chrome('<div class="bd" style="justify-content:center"><h1 class="t1" style="text-align:center">Checking <em>' + D.length + ' settlements</em></h1><p class="sub" style="text-align:center">Matching your answers to open cases</p><div class="grp" style="margin-top:22px;background:#F2F2F7">'
          + D.slice(0, 6).map((d, i) => { const done = i < (st.load + 1) * 1.5, hit = st.yes[d.id]; return '<div class="row" style="padding:12px 14px">' + T(d, 34) + '<span style="flex:1;font-size:15px;font-weight:600;color:' + (done ? '#000' : '#AEAEB2') + '">' + d.co + '</span>' + (done ? (hit ? '<span class="chip">' + I(P.check, 12, 'currentColor', 3) + 'Match</span>' : '<span style="font-size:13px;color:#AEAEB2">No match</span>') : '<span style="width:18px;height:18px;border-radius:99px;border:2.5px solid #12805C;border-right-color:transparent;animation:fcSpin .9s linear infinite"></span>') + '</div>'; }).join('')
          + '</div><div style="height:6px;border-radius:9px;background:#E5E5EA;margin-top:18px;overflow:hidden"><b style="display:block;height:100%;width:' + Math.min(100, (st.load + 1) * 25) + '%;background:#12805C;border-radius:9px;transition:width .5s"></b></div></div>', { noBack: true }); }
      if (v === 'c') { const pc = Math.min(100, st.load * 25 + 12), cur = D[Math.min(D.length - 1, st.load * 2)]; return chrome('<div class="bd" style="justify-content:center;align-items:center;text-align:center;margin-top:-30px"><div style="position:relative;width:200px;height:200px"><svg width="200" height="200" viewBox="0 0 200 200" style="transform:rotate(-90deg)"><circle cx="100" cy="100" r="86" fill="none" stroke="#E6F4EE" stroke-width="14"/><circle cx="100" cy="100" r="86" fill="none" stroke="#12805C" stroke-width="14" stroke-linecap="round" stroke-dasharray="540" stroke-dashoffset="' + (540 - 540 * pc / 100) + '" style="transition:stroke-dashoffset .6s"/></svg><div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center"><b style="font-size:50px;letter-spacing:-2px">' + pc + '%</b></div></div>'
          + '<span style="display:flex;align-items:center;gap:10px;margin-top:24px;padding:10px 16px;border-radius:99px;background:#F2F2F7;font-size:15px;font-weight:600">' + T(cur, 26) + 'Checking ' + cur.co + '</span><h1 class="t1" style="margin-top:20px;font-size:26px">Finding your <em>matches</em></h1></div>', { noBack: true }); }
      return chrome('<div class="bd" style="justify-content:center;align-items:center;text-align:center;margin-top:-30px"><div style="position:relative;width:190px;height:190px"><div style="position:absolute;inset:14px;border-radius:99px;border:2px solid #D1E9DE"></div><div style="position:absolute;inset:14px;border-radius:99px;border:2px solid transparent;border-top-color:#12805C;animation:fcSpin 1.2s linear infinite"></div>'
        + m.slice(0, 4).map((d, i) => '<div style="position:absolute;left:' + [75, 150, 75, 0][i] + 'px;top:' + [0, 75, 150, 75][i] + 'px;padding:4px;border-radius:14px;background:#FFF;box-shadow:0 4px 12px rgba(0,0,0,.12)">' + T(d, 34) + '</div>').join('') + '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">' + I(P.search, 36, '#12805C', 2.4) + '</div></div>'
        + '<h1 class="t1" style="margin-top:24px">Checking your <em>matches</em></h1>' + checks + '</div>', { noBack: true }); };
    S.est = () => { const m = matched(), t = sum(m); return chrome('<div class="bd" style="justify-content:center;align-items:center;text-align:center;margin-top:-40px"><span style="font-size:13px;font-weight:700;letter-spacing:1px;color:#12805C">BASED ON YOUR ANSWERS</span><h1 class="t1" style="font-size:27px;margin-top:10px">You could qualify for up to</h1><b style="font-size:84px;letter-spacing:-4px;line-height:1.05;margin-top:6px;animation:fcPop .6s both">' + money(t) + '</b>'
      + '<p class="sub">From ' + m.length + ' open settlement' + (m.length === 1 ? '' : 's') + '. Next we check each one, so we only file what you qualify for.</p><div style="display:flex;gap:-8px;margin-top:20px">' + m.map((d, i) => '<span style="margin-left:' + (i ? -10 : 0) + 'px;padding:2px;border-radius:12px;background:#FFF">' + T(d, 40) + '</span>').join('') + '</div></div>' + foot(btn('Continue', 'next')), { noBack: true }); };
    S.pick = () => { const m = matched(), rest = D.filter((d) => !st.yes[d.id]); const L = m.concat(rest); const p = picked();
      return chrome('<div class="bd scr" style="background:#F2F2F7;padding:4px 16px 0"><h1 class="t1" style="font-size:28px;text-align:center">Choose your claims</h1><p class="sub" style="text-align:center;font-size:15px;margin-top:6px">You can add more until each deadline.</p><div style="display:flex;flex-direction:column;gap:10px;margin:16px 0 16px">'
        + L.map((d) => { const on = st.sel[d.id]; return '<div class="card" data-a="sel" data-v="' + d.id + '" style="padding:14px;display:flex;gap:14px;align-items:center;cursor:pointer;' + (on ? 'box-shadow:inset 0 0 0 2px #12805C' : '') + '">' + T(d, 58) + '<span style="flex:1;display:flex;flex-direction:column;gap:4px;min-width:0"><b style="font-size:16px;letter-spacing:-.2px">' + d.co + '</b><span style="font-size:13.5px;color:var(--sec);line-height:1.3">' + d.short + '</span><span style="display:flex;gap:10px;align-items:center;font-size:13px"><b style="color:#12805C">' + d.pay + '</b><span style="color:var(--sec);display:flex;gap:4px;align-items:center">' + I(P.cal, 12, '#8E8E93') + daysL(d.dl) + ' days left</span></span></span><span class="ck sq" style="' + (on ? 'background:#12805C;box-shadow:none' : '') + '">' + (on ? I(P.check, 15, '#FFF', 3.2) : '') + '</span></div>'; }).join('') + '</div></div>'
        + '<div class="ft" style="flex-direction:row;align-items:center;border-top:.5px solid var(--sep);background:rgba(255,255,255,.94);padding-top:14px"><span style="display:flex;flex-direction:column"><span style="font-size:13px;color:var(--sec)">' + p.length + ' selected</span><b style="font-size:24px;color:#12805C;letter-spacing:-.5px">' + money(sum(p)) + '</b></span><button class="btn" data-a="next" style="width:140px;margin-left:auto"' + (p.length ? '' : ' disabled') + '>Next</button></div>'); };
    S.chk = () => { const L = picked(); const d = L[st.ci] || L[0]; if (!d) return chrome('<div class="bd"></div>'); const a = st.chk[d.id] || {}; const done = d.checks.every((q, k) => a[k]); const bad = d.checks.some((q, k) => a[k] === 'n');
      return chrome('<div class="bd scr" style="padding-top:0"><div style="display:flex;align-items:center;gap:12px;padding:6px 0 14px;border-bottom:.5px solid var(--sep)">' + T(d, 50) + '<span style="display:flex;flex-direction:column"><b style="font-size:20px;letter-spacing:-.4px">Claim ' + (st.ci + 1) + ' of ' + L.length + ': ' + d.co + '</b><span style="font-size:14px;color:var(--sec)">Eligibility check · ' + d.pay + '</span></span></div>'
        + d.checks.map((q, k) => '<div style="padding:18px 0;border-bottom:.5px solid var(--sep)"><span style="font-size:12px;font-weight:700;letter-spacing:.8px;color:#12805C">QUESTION ' + (k + 1) + '</span><p style="font-size:18px;font-weight:600;letter-spacing:-.3px;line-height:1.3;margin:6px 0 14px">' + q + '</p><div style="display:flex;gap:10px"><div class="yn' + (a[k] === 'y' ? ' on' : '') + '" data-a="chk" data-k="' + k + '" data-v="y">Yes</div><div class="yn no' + (a[k] === 'n' ? ' on' : '') + '" data-a="chk" data-k="' + k + '" data-v="n">No</div></div></div>').join('')
        + (bad ? '<div style="margin-top:16px;padding:14px 16px;border-radius:14px;background:#FFF4E5;font-size:15px;line-height:1.4;color:#7A4B00">Based on that answer you probably do not qualify for this one. We will leave it out.</div>' : (done ? '<div style="margin-top:16px;padding:14px 16px;border-radius:14px;background:#E6F4EE;font-size:15px;line-height:1.4;color:#0F3B2E;display:flex;gap:10px;align-items:center">' + I(P.check, 18, '#12805C', 3) + 'You look eligible. We will file this one.</div>' : ''))
        + '<div style="height:20px"></div></div>' + '<div class="ft" style="flex-direction:row;border-top:.5px solid var(--sep)"><button class="btn ln" data-a="skip" style="flex:1">Skip for now</button><button class="btn" data-a="nextc" style="flex:1"' + (done ? '' : ' disabled') + '>' + (st.ci < L.length - 1 ? 'Next claim' : 'Finish') + '</button></div>'); };
    S.win = () => { const e = elig(), t = sum(e), v = VAR('win');
      const art = v === 'b' ? '<img src="__ART_CASH__" alt="" style="width:210px;height:190px;animation:fcPop .5s both">' : v === 'c' ? '<img src="__ART_COIN__" alt="" style="width:190px;height:190px;animation:fcPop .5s both">'
        : v === 'd' ? '<div style="position:relative;width:210px;height:180px;animation:fcPop .5s both">' + e.slice(0, 3).map((d, k) => '<div style="position:absolute;left:' + [20, 60, 100][k] + 'px;top:' + [40, 18, 40][k] + 'px;transform:rotate(' + [-12, 0, 12][k] + 'deg);padding:5px;border-radius:26px;background:rgba(255,255,255,.14)">' + T(d, 84) + '</div>').join('') + '<span style="position:absolute;right:18px;bottom:8px;width:58px;height:58px;border-radius:99px;background:#3DDC97;border:5px solid #0F3B2E;display:flex;align-items:center;justify-content:center">' + I(P.check, 28, '#0F3B2E', 3.4) + '</span></div>'
        : '<img src="__ART_BAG__" alt="" style="width:190px;height:190px;animation:fcPop .5s both">';
      return '<div style="position:absolute;inset:0;z-index:-1;background:radial-gradient(120% 90% at 50% 40%,#1E7A55,#0F3B2E 70%)"></div>' + chrome('<div class="bd" style="justify-content:center;align-items:center;text-align:center;color:#FFF;position:relative;margin-top:-30px">' + art + '<h1 class="t1" style="color:#FFF;margin-top:6px;font-size:28px">You can file for up to</h1><b style="font-size:84px;letter-spacing:-4px;line-height:1.05;color:#3DDC97;animation:fcPop .6s .1s both">' + money(t) + '</b><p class="sub" style="color:#CFE9DD">' + e.length + ' claim' + (e.length === 1 ? '' : 's') + ' checked and ready to file.</p></div>' + foot(btn('Continue', 'next', false, 'mint')), { noBack: true }).replace('<div class="sb">', '<div class="sb" style="color:#FFF">').replace('class="lg"', 'class="lg" style="color:#FFF"'); };
    S.offer = () => { const e = elig(), t = sum(e), O = st.offer || 'A';
      const perks = ['We file every claim you qualify for', 'New claims as they open', 'Track every payout in one place', 'You keep 100% of every payout'].map((x) => '<span style="display:flex;gap:8px;align-items:center;font-size:15px;margin-top:9px">' + I(P.check, 16, '#3DDC97', 3) + x + '</span>').join('');
      const trial = (price) => '<div style="border-radius:20px;background:linear-gradient(160deg,#1E7A55,#0F3B2E);color:#FFF;padding:20px;text-align:center"><span style="font-size:12px;font-weight:800;padding:4px 10px;border-radius:99px;background:#3DDC97;color:#0F3B2E">3 DAYS FREE</span><b style="display:block;font-size:34px;letter-spacing:-1.2px;margin-top:10px">Try it free</b><span style="display:block;font-size:15px;color:#CFE9DD;margin-top:2px">Then ' + price + '. Cancel anytime.</span></div>';
      const PL = [['6m', '6 MONTHS', '$9.99', '$59.94 billed now', 'SAVE 50%', '#FF9500', ['Best price per month', 'Longest savings period']], ['3m', '3 MONTHS', '$14.99', '$44.97 billed now', 'SAVE 25%', '#12805C', ['Great balance of savings and flexibility']], ['1m', '1 MONTH', '$19.99', '$19.99 billed now', '', '', ['Flexible month to month']]];
      const pk = st.pk || '6m';
      const plans = '<span style="font-size:22px;font-weight:700;letter-spacing:-.5px;text-align:center;display:block">Choose your plan</span><span style="font-size:14px;color:var(--sec);text-align:center;display:block;margin:4px 0 12px">Cancel anytime. Every plan includes everything.</span>'
        + PL.map((x) => { const on = pk === x[0]; return '<div data-a="pk" data-v="' + x[0] + '" style="cursor:pointer;margin-bottom:10px;border-radius:18px;padding:16px;background:' + (on ? 'linear-gradient(180deg,#E9F7F0,#FFFFFF)' : '#FFF') + ';box-shadow:inset 0 0 0 ' + (on ? '2px #12805C' : '1px #E5E5EA') + '"><span style="display:flex;align-items:center"><b style="font-size:13px;letter-spacing:.6px">' + x[1] + '</b>' + (x[4] ? '<span style="margin-left:auto;font-size:12px;font-weight:800;color:#FFF;background:' + x[5] + ';padding:4px 9px;border-radius:99px">' + x[4] + '</span>' : '') + '</span><span style="display:flex;align-items:baseline;gap:6px;margin-top:6px"><b style="font-size:34px;letter-spacing:-1.2px;color:' + (on ? '#12805C' : '#000') + '">' + x[2] + '</b><span style="font-size:15px;color:var(--sec)">/mo</span>' + (x[0] !== '1m' ? '<s style="font-size:15px;color:#AEAEB2">$19.99</s>' : '') + '</span><span style="font-size:13px;color:#8E8E93">' + x[3] + '</span>' + x[6].map((y) => '<span style="display:flex;gap:6px;align-items:center;font-size:13.5px;color:#3C3C43;margin-top:6px">' + I(P.check, 14, on ? '#12805C' : '#8E8E93', 3) + y + '</span>').join('') + '</div>'; }).join('');
      const box = O === 'A' ? trial('$49.99 a year') : O === 'B' ? trial('$19.99 a month') : plans;
      const fine = O === 'A' ? '$0 today. Then $49.99 a year unless you cancel before your trial ends.' : O === 'B' ? '$0 today. Then $19.99 a month unless you cancel before your trial ends.' : ({ '6m': '$59.94 today, renews every 6 months.', '3m': '$44.97 today, renews every 3 months.', '1m': '$19.99 today, renews every month.' })[pk] + ' Cancel anytime.';
      const REV = __REVIEWS__;
      const faq = [['When do I get paid?', 'Each settlement pays on its own schedule, usually 6 to 12 months after its claim deadline. The money goes straight to you.'], ['Is this a real settlement?', 'Yes. We only list court-approved settlements. You can always file for free on the official settlement site.'], ['Can I cancel?', 'Anytime, in your account. Claims we already filed stay filed.'], ['Is my information safe?', 'Your details are encrypted and only sent to the settlements you file.']];
      return chrome('<div class="bd scr" style="background:#F2F2F7;padding-top:0">'
        + '<div style="display:flex;flex-direction:column;align-items:center;text-align:center;gap:6px;padding:26px 0 20px"><span style="font-size:13px;font-weight:700;letter-spacing:1px;color:#12805C">AVAILABLE TO YOU</span><b style="font-size:76px;letter-spacing:-3.5px;line-height:1">' + money(t) + '</b><span class="sub" style="margin-top:6px">From ' + e.length + ' claims, ready to file.</span>'
        + '<div class="grp" style="width:100%;margin-top:18px;text-align:left">' + e.map((d) => '<div class="row">' + T(d, 30) + '<span style="flex:1;font-size:15px;font-weight:600">' + d.co + '</span><b style="font-size:15px;color:#12805C">' + d.pay + '</b></div>').join('') + '</div>'
        + '</div>'
        + '<div style="margin:0 -20px;padding:26px 20px 30px;background:radial-gradient(120% 100% at 0% 0%,#1E7A55,#0F3B2E 65%);color:#FFF;display:flex;flex-direction:column;align-items:center;text-align:center"><b style="font-size:22px;letter-spacing:-.5px">We file it. You get paid.</b><span style="font-size:14.5px;color:#CFE9DD;margin-top:4px">Track every claim from filed to paid.</span>'
        + '<div style="position:relative;width:240px;height:250px;margin-top:20px"><div style="position:absolute;inset:0 10px 0 10px;border-radius:32px 32px 0 0;background:#FFF;border:7px solid #1C1C1E;border-bottom:0;padding:26px 12px 0;color:#000;text-align:left;overflow:hidden"><span style="position:absolute;top:8px;left:50%;transform:translateX(-50%);width:62px;height:16px;border-radius:9px;background:#1C1C1E"></span><b style="font-size:14px">Your claims</b>'
        + e.slice(0, 4).map((d, k) => '<div style="display:flex;align-items:center;gap:8px;padding:8px 0;border-top:.5px solid #E5E5EA;margin-top:' + (k ? 0 : 8) + 'px">' + T(d, 24) + '<span style="flex:1;font-size:12.5px;font-weight:600">' + d.co.split(' ')[0] + '</span><span style="font-size:10.5px;font-weight:700;padding:2px 6px;border-radius:99px;background:' + (k < 2 ? '#E6F4EE;color:#12805C' : '#F2F2F7;color:#8E8E93') + '">' + (k < 2 ? 'Filed' : 'Filing') + '</span></div>').join('') + '</div>'
        + '<div style="position:absolute;left:-18px;right:-18px;bottom:26px;background:rgba(255,255,255,.96);border-radius:16px;padding:10px 12px;display:flex;gap:10px;align-items:center;color:#000;text-align:left;box-shadow:0 10px 24px rgba(0,0,0,.3);animation:fcFloat 3s ease-in-out infinite"><span style="width:30px;height:30px;flex:none;border-radius:8px;background:#0F3B2E;display:flex;align-items:center;justify-content:center">' + I(P.check, 16, '#3DDC97', 3) + '</span><span style="font-size:12.5px;line-height:1.3"><b>Claimclub</b><br>Your ' + (e[0] ? e[0].co : 'Apple') + ' claim was filed.</span></div></div></div>'
        + '<div style="height:20px"></div>'
        + '<div data-sec="opts">' + box + '</div>'
        + '<div class="opt' + (st.agree ? ' on' : '') + '" data-a="agree" style="margin-top:12px;background:none;padding:4px 2px;gap:10px;font-size:11.5px;font-weight:400;color:#6E6E73;line-height:1.4;align-items:flex-start;min-height:0;box-shadow:none"><span class="ck sq" style="margin:0;width:18px;height:18px;border-radius:5px;' + (st.agree ? 'background:#12805C;box-shadow:none' : '') + '">' + (st.agree ? I(P.check, 15, '#FFF', 3.2) : '') + '</span><span>My answers are true, and I agree that Claimclub can fill out and file my claims for me, as described in the Claim Filing Authorization Agreement.</span></div>'
        + '<div style="display:flex;flex-direction:column;gap:10px;margin-top:14px"><button class="btn" data-a="pay" style="background:#000;height:52px;font-size:18px"' + (st.agree ? '' : ' disabled') + '>Pay with Apple Pay</button><button class="btn" data-a="pay" style="background:#000;height:52px"' + (st.agree ? '' : ' disabled') + '>Google Pay</button><button class="btn mint" data-a="pay"' + (st.agree ? '' : ' disabled') + '>' + I(P.lock, 17, 'currentColor') + (O === 'C' ? 'Pay with card' : 'Start my free trial') + '</button><span style="font-size:12.5px;color:var(--sec);text-align:center;line-height:1.35">' + fine + '</span></div>'
        + '<div style="margin-top:18px;border-radius:18px;background:#FFF;padding:16px;display:flex;gap:12px;align-items:center"><span style="width:44px;height:44px;flex:none;border-radius:99px;background:#E6F4EE;display:flex;align-items:center;justify-content:center">' + I(P.shield, 22, '#12805C') + '</span><span style="display:flex;flex-direction:column;gap:2px"><b style="font-size:16px">30-day money-back guarantee</b><span style="font-size:14px;color:var(--sec);line-height:1.35">Not happy? Email us within 30 days for a full refund.</span></span></div>'
        + '<b style="display:block;font-size:22px;letter-spacing:-.5px;margin:26px 0 4px">Why people trust Claimclub</b><span style="font-size:12.5px;color:#8E8E93">Example reviews. Real member reviews coming soon.</span>'
        + REV.map((r) => '<div style="margin-top:10px;border-radius:16px;background:#FFF;padding:14px"><span style="display:flex;align-items:center;gap:10px"><img src="' + r.img + '" style="width:36px;height:36px;border-radius:99px"><span style="display:flex;flex-direction:column;flex:1"><b style="font-size:14.5px">' + r.n + '</b><span style="font-size:12.5px;color:#8E8E93">' + r.p + '</span></span><span class="chip">+$' + r.amt + '</span></span><span style="display:block;color:#FF9500;font-size:13px;letter-spacing:1px;margin-top:8px">★★★★★</span><span style="font-size:14.5px;line-height:1.4;display:block;margin-top:4px">“' + r.q + '”</span></div>').join('')
        + '<b style="display:block;font-size:22px;letter-spacing:-.5px;margin:26px 0 8px">Questions</b><div class="grp">' + faq.map((f, k) => '<div class="row" style="flex-direction:column;align-items:stretch;gap:6px;padding:14px 16px"><span style="display:flex;align-items:center"><b style="font-size:15.5px;flex:1">' + f[0] + '</b>' + I(k === 0 ? 'm18 15-6-6-6 6' : 'm6 9 6 6 6-6', 18, '#8E8E93') + '</span>' + (k === 0 ? '<span style="font-size:14.5px;color:var(--sec);line-height:1.4">' + f[1] + '</span>' : '') + '</div>').join('') + '</div><div style="height:30px"></div></div>'); };
    S.paid = () => chrome('<div class="bd" style="justify-content:center;align-items:center;text-align:center;margin-top:-40px"><div style="width:110px;height:110px;border-radius:99px;display:flex;align-items:center;justify-content:center;' + (st.payDone ? 'background:#12805C;animation:fcPop .45s both' : 'border:6px solid #E6F4EE;border-top-color:#12805C;animation:fcSpin .9s linear infinite') + '">' + (st.payDone ? I(P.check, 56, '#FFF', 3) : '') + '</div><h1 class="t1" style="margin-top:24px;font-size:28px">' + (st.payDone ? (st.offer === 'C' ? 'Payment confirmed' : 'Your trial has started') : 'Confirming payment') + '</h1><p class="sub">' + (st.payDone ? 'Next, your filing details.' : 'This takes a few seconds.') + '</p></div>', { noBack: true, noBar: true });
    S.profile = () => chrome('<div class="bd scr" style="background:#F2F2F7;padding-top:4px"><span class="chip" style="align-self:flex-start;margin-bottom:8px">' + I(P.check, 13, 'currentColor', 3) + 'Trial started</span><h1 class="t1" style="font-size:28px">Your filing details</h1><p class="sub" style="font-size:15px">These go on every claim form. Use your legal name and current address.</p>'
      + [['FULL NAME', [['First name', st.name || ''], ['Last name', '']]], ['CONTACT', [['Phone', ''], ['Birthday', '']]], ['ADDRESS', [['Street', ''], ['City', ''], ['State', ''], ['ZIP', '']]]].map((g) => '<div class="lab" style="margin-top:18px">' + g[0] + '</div><div class="grp">' + g[1].map((f) => '<div class="row" style="padding:0 16px;height:48px"><span style="width:120px;font-size:15px;white-space:nowrap">' + f[0] + '</span><input class="inp" style="background:none;height:48px;padding:0" placeholder="Required" value="' + f[1] + '"></div>').join('') + '</div>').join('')
      + '<p style="font-size:13px;color:var(--sec);margin:12px 4px 18px;display:flex;gap:6px">' + I(P.lock, 14, '#8E8E93') + 'Encrypted. Used only to file your claims.</p></div>' + foot(btn('Continue', 'next')), { noBack: true });
    S.done = () => chrome('<div class="bd" style="justify-content:center;align-items:center;text-align:center;margin-top:-30px"><div style="width:96px;height:96px;border-radius:99px;background:#12805C;display:flex;align-items:center;justify-content:center;animation:fcPop .5s both">' + I(P.check, 50, '#FFF', 3) + '</div><h1 class="t1" style="margin-top:22px">We\'re on it, ' + (st.name || 'Ana') + '</h1><p class="sub">We file your ' + elig().length + ' claims and email you each claim number. Opening your dashboard...</p></div>'
      + foot(btn('Start over', 'restart', false, 'ln')), { noBack: true });

    let lastK = '';
    const draw = (anim) => {
      const k = STEPS[st.s]; const ob = el.querySelector('.bd'); const keep = ob && lastK === k ? ob.scrollTop : 0; lastK = k;
      el.innerHTML = (S[k] || S.w1)();
      const nb = el.querySelector('.bd'); if (nb && keep) nb.scrollTop = keep;
      if (fixed && el.dataset.scroll && nb) { const o = nb.querySelector('[data-sec=opts]'); if (o) nb.scrollTop = o.offsetTop - nb.offsetTop - 12; }
      const b = el.querySelector('.bd'); if (anim && b && !fixed) b.classList.add('fadein');
      if (fixed) return;
      const inp = el.querySelector('input[data-k=name]'); if (inp) { inp.oninput = (e) => { st.name = e.target.value; const bt = el.querySelector('[data-a=next]'); bt.disabled = !st.name.trim(); }; }
      const sw = el.querySelector('.swipe'); if (sw) wireSwipe(sw);
    };
    const answer = (y) => { const d = D[parseInt(STEPS[st.s].slice(1))]; if (y) { st.yes[d.id] = 1; st.sel[d.id] = 1; } else { delete st.yes[d.id]; delete st.sel[d.id]; } next(); };
    const wireSwipe = (c) => {
      let x0 = null, dx = 0;
      c.addEventListener('pointerdown', (e) => { if (e.target.closest('[data-a]')) return; x0 = e.clientX; dx = 0; c.setPointerCapture(e.pointerId); c.style.transition = 'none'; });
      c.addEventListener('pointermove', (e) => { if (x0 === null) return; dx = (e.clientX - x0) / (el.getBoundingClientRect().width / 390); c.style.setProperty('--dx', dx); });
      const up = () => { if (x0 === null) return; x0 = null; if (Math.abs(dx) > 90) { c.style.transition = 'transform .2s ease'; c.style.setProperty('--dx', dx > 0 ? 500 : -500); setTimeout(() => answer(dx > 0), 170); } else { c.style.transition = 'transform .2s ease'; c.style.setProperty('--dx', 0); } };
      c.addEventListener('pointerup', up); c.addEventListener('pointercancel', up);
    };
    el.addEventListener('click', (e) => {
      if (fixed) return; const t = e.target.closest('[data-a]'); if (!t || t.disabled) return; const a = t.dataset.a, v = t.dataset.v;
      if (a === 'next') next();
      else if (a === 'back') { let n = st.s - 1; if (STEPS[n] === 'load') n -= 1; go(n); }
      else if (a === 'pain') { if (st.pains[v]) delete st.pains[v]; else st.pains[v] = 1; draw(); }
      else if (a === 'goal') { st.goal = v; draw(); }
      else if (a === 'ans') { const c = el.querySelector('.swipe'); if (c) { c.style.transition = 'transform .32s cubic-bezier(.3,.7,.4,1)'; c.style.setProperty('--dx', v === 'y' ? 520 : -520); } setTimeout(() => answer(v === 'y'), 280); }
      else if (a === 'pk') { st.pk = v; draw(); }
      else if (a === 'sel') { if (st.sel[v]) delete st.sel[v]; else st.sel[v] = 1; draw(); }
      else if (a === 'chk') { const d = picked()[st.ci]; st.chk[d.id] = Object.assign({}, st.chk[d.id], { [t.dataset.k]: v }); draw(); }
      else if (a === 'nextc' || a === 'skip') { if (a === 'skip') { const d = picked()[st.ci]; delete st.chk[d.id]; } if (st.ci < picked().length - 1) { st.ci += 1; draw(true); } else go(STEPS.indexOf('win')); }
      else if (a === 'agree') { st.agree = !st.agree; draw(); }
      else if (a === 'pay') { const sh = document.createElement('div'); sh.style.cssText = 'position:absolute;inset:0;background:rgba(0,0,0,.35);display:flex;align-items:flex-end;z-index:9'; sh.innerHTML = '<div style="background:#F2F2F7;width:100%;border-radius:22px 22px 0 0;padding:22px 20px 40px;display:flex;flex-direction:column;gap:12px;animation:fcIn .25s both"><b style="font-size:20px;text-align:center">Payment</b><div style="height:54px;border-radius:12px;background:#000;color:#FFF;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:600"> Pay</div><div style="height:120px;border-radius:12px;background:repeating-linear-gradient(45deg,#E5E5EA,#E5E5EA 8px,#ECECEF 8px,#ECECEF 16px);display:flex;align-items:center;justify-content:center;color:#8E8E93;font-size:14px;font-weight:600">Stripe card form goes here</div><button class="btn mint" data-a="paid">Start my free trial</button></div>'; el.appendChild(sh); }
      else if (a === 'paid') { next(); setTimeout(() => { st.payDone = 1; draw(); }, 1300); setTimeout(() => { if (STEPS[st.s] === 'paid') { st.payDone = 0; next(); } }, 2800); }
      else if (a === 'restart') { st = init(); draw(true); }
    });
    el._setOffer = (o) => { st.offer = o; draw(); };
    draw();
  }
"""

def build():
    data = json.dumps(D)
    revs = json.dumps(REVIEWS)
    frames = ['w1', 'gap', 'w2', 'w3', 'w4', 'rev', 'name', 'pains', 'goal', 'plan', 'qintro', 'q0', 'q4', 'load', 'est', 'pick', 'chk', 'win', 'offer', 'offerA', 'offerB', 'offerC', 'paid', 'profile', 'done']
    caps = {'w1': '1 · Why this matters', 'gap': '2 · Most money goes unclaimed', 'w2': '3 · We find payouts', 'w3': '4 · We file and track', 'w4': '5 · Trust', 'rev': '6 · Reviews (examples)', 'name': '7 · First name',
            'pains': '8 · Sounds like you', 'goal': '9 · What it is for', 'plan': '10 · How you get paid', 'qintro': '11 · Quiz intro', 'q0': '12 · Broad question (1 of 8)', 'q4': '12 · Broad question (5 of 8)',
            'load': '13 · Checking matches', 'est': '14 · Estimate', 'pick': '15 · Choose your claims', 'chk': '16 · Per-claim check', 'win': '17 · Ready to file', 'offer': '18 · Checkout, top',
            'offerA': '18 · Offer A: 3 days free, $49.99/yr', 'offerB': '18 · Offer B: 3 days free, $19.99/mo', 'offerC': '18 · Offer C: 1, 3 or 6 months', 'paid': '19 · Payment confirmed', 'profile': '20 · Details after payment', 'done': '21 · Done'}
    def fr(k):
        if k.startswith('offer') and len(k) == 6: return f'<div class="fc" data-fc data-step="offer" data-offer="{k[-1]}" data-scroll="1"></div>'
        return f'<div class="fc" data-fc data-step="{k}"></div>'
    sb = ''.join(f'<div class="mini">{fr(k)}<span class="cap">{caps[k]}</span></div>' for k in frames)
    W, H = 2440, 1920
    note = ('Explain first (why it matters, how little gets claimed, we find, we file, trust, reviews), then light personal questions, then 8 broad yes or no questions '
            '(swipe the card or tap the round buttons), a short check, the estimate, choose your claims, then each chosen claim gets its own eligibility questions. '
            'Checkout opens on the money available, then the offer (A, B or C for the test), pay buttons, a 30-day money-back guarantee, reviews and questions. Details come after payment. '
            'Reviews are the homepage placeholders and are labeled as examples.')
    page = (f'<div style="width: {W}px; height: {H}px; box-sizing: border-box; padding: 40px; background: #E9EEEB; font-family: -apple-system, BlinkMacSystemFont, Inter, sans-serif; color: #000; display: flex; gap: 70px"><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"><style>{CSS}</style>'
            f'<div style="display: flex; flex-direction: column; gap: 18px; width: 420px; flex: none"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #12805C">FLOW C · CLAIMMONEY STYLE, CLAIMCLUB THEME</span>'
            f'<span style="font-size: 15px; color: #43504A; font-weight: 500; line-height: 1.5">{note}</span>'
            f'<span style="font-size: 13px; font-weight: 800; letter-spacing: 1px; color: #6E6E73; margin-top: 10px">TRY IT · CHECKOUT OFFER</span><div style="display: flex; gap: 6px">' + ''.join(f'<button data-setoffer="{o}" style="height: 34px; padding: 0 14px; border-radius: 99px; border: 1.5px solid #0F3B2E; font: 700 13px -apple-system, Inter, sans-serif; cursor: pointer; background: {"#0F3B2E" if o == "A" else "#FFF"}; color: {"#FFF" if o == "A" else "#0F3B2E"}">{o} · {t}</button>' for o, t in [('A', '$49.99/yr'), ('B', '$19.99/mo'), ('C', 'Plans')]) + '</div><div class="fc" data-fc></div></div>'
            f'<div style="display: flex; flex-direction: column; gap: 18px"><span style="font-size: 13px; font-weight: 800; letter-spacing: 1px; color: #6E6E73">EVERY SCREEN (SAMPLE ANSWERS)</span><div class="sbd" style="width: 1880px">{sb}</div></div></div>\n</x-dc>\n')
    js = ('<script type="text/x-dc" data-dc-script data-props=\'{"$preview":{"width":%d,"height":%d}}\'>\nclass Component extends DCLogic { renderVals() { return {}; }' % (W, H)) + JSR.replace('__DATA__', data).replace('__REVIEWS__', revs).replace('__ART_SEARCH__', ART_SEARCH).replace('__ART_BAG__', ART_BAG).replace('__ART_CASH__', ART_CASH).replace('__ART_COIN__', ART_COIN).replace('__NOPEN__', str(NOPEN)) + '}\n</script>\n</body>\n</html>\n'
    open(os.path.join(OUT, 'FlowC.dc.html'), 'w').write(HEAD % 'Flow C (iOS)' + page + js)
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    if not any(pg['id'] == 'flowc' for pg in c['pages']): c['pages'].append({'id': 'flowc', 'name': 'Flow C (iOS)'})
    c['boards']['FlowC.dc.html'] = {'x': 0, 'y': 0, 'w': W, 'h': H, 'is_interactive': True, 'title': 'Flow C · ClaimMoney style', 'page': 'flowc'}
    if 'FlowC.dc.html' not in c['order']: c['order'].append('FlowC.dc.html')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w'))
    opts = [('UNCLAIMED MONEY, SCREEN 1', [('w1', 'a', 'A · Folder with floating logos (now)'), ('w1', 'b', 'B · Dark card, $40B+ and logos'), ('w1', 'c', 'C · Legal notice and envelope')]),
            ('CHECKING MATCHES, SCREEN 13', [('load', 'a', 'A · Logo orbit and checklist (now)'), ('load', 'b', 'B · Live list with matches'), ('load', 'c', 'C · Progress ring')]),
            ('READY TO FILE, SCREEN 17', [('win', 'a', 'A · Money bag (now)'), ('win', 'b', 'B · Stack of cash'), ('win', 'c', 'C · Green coin with check'), ('win', 'd', 'D · Their claim logos')])]
    W2, H2 = 2440, 2900
    rows = ''.join(f'<div style="display:flex;flex-direction:column;gap:18px"><span style="font-size:15px;font-weight:800;letter-spacing:1.2px;color:#12805C">{t}</span><div style="display:flex;gap:40px;zoom:1.7;padding-bottom:34px">' + ''.join(f'<div class="mini"><div class="fc" data-fc data-step="{k}" data-v="{v}"></div><span class="cap">{c}</span></div>' for k, v, c in fr_) + '</div></div>' for t, fr_ in opts)
    page2 = page.split('<div style="display: flex; flex-direction: column; gap: 18px; width: 420px')[0].replace(f'width: {W}px; height: {H}px', f'width: {W2}px; height: {H2}px').replace('display: flex; gap: 70px', 'display: flex; flex-direction: column; gap: 50px') + '<span style="font-size:30px;font-weight:800;letter-spacing:-.5px">Flow C options · pick one per row</span>' + rows + '</div>\n</x-dc>\n'
    js2 = js.replace('"width":%d,"height":%d' % (W, H), '"width":%d,"height":%d' % (W2, H2))
    open(os.path.join(OUT, 'FlowCOpts.dc.html'), 'w').write(HEAD % 'Flow C options' + page2 + js2)
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    c['boards']['FlowCOpts.dc.html'] = {'x': 0, 'y': H + 200, 'w': W2, 'h': H2, 'is_interactive': True, 'title': 'Flow C · options', 'page': 'flowc'}
    if 'FlowCOpts.dc.html' not in c['order']: c['order'].append('FlowCOpts.dc.html')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w'))
    print('ok', len(D), NOPEN)

if __name__ == '__main__':
    build()
