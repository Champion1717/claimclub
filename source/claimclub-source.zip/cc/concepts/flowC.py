# ClaimMoney-style claim flow, Claimclub theme, iOS look (Nov 22 2026, canvas only, not live).
# Henry: ClaimMoney explains the whole process first, then asks broad questions that apply to almost everyone,
# then checks each chosen claim with its own questions. Build the same kind of flow for Claimclub, iOS styling,
# iOS system font (SF Pro on Apple devices, Inter elsewhere). Canvas page "Flow C (iOS)".
# Board FlowC: one playable phone plus a storyboard of every screen. All rendering is in the JS below (render()).
import os, json, base64
from how4 import HEAD, OUT

HERE = os.path.dirname(os.path.abspath(__file__)); CC = os.path.join(HERE, '..')
SETS = {s['id']: s for s in json.load(open(os.path.join(HERE, 'sets.json')))}
SPEC = {x['id']: x for x in json.load(open(os.path.join(CC, 'data', 'filing_specs.json')))}
def tile(i):
    return 'data:image/svg+xml;base64,' + base64.b64encode(open(os.path.join(CC, 'tiles', i + '.svg'), 'rb').read()).decode()

# Broad questions: short, apply to most people. Each maps to one settlement; that settlement's own questions come later.
BROAD = [('apple', 'Do you own an iPhone?'), ('amazon', 'Have you ever returned something to Amazon?'), ('visa', 'Have you ever paid a fee to use an ATM?'),
         ('googleplay', 'Have you bought an app on an Android phone?'), ('realpage', 'Have you rented an apartment since 2018?'),
         ('fleatick', 'Do you have a dog or a cat?'), ('toyota', 'Have you owned or leased a Toyota?'), ('seatgeek', 'Have you bought tickets on SeatGeek?')]
D = []
for i, q in BROAD:
    s, p = SETS[i], SPEC.get(i, {})
    mx = s.get('max') or s.get('amt') or 0
    D.append({'id': i, 'co': s['co'], 'title': s['title'], 'q': q, 'max': mx, 'pay': ('Up to $' + f'{mx:,}') if mx else 'Refund owed',
              'dl': s.get('dl'), 'who': s.get('who', ''), 'proof': s.get('proof', ''), 'tile': tile(i),
              'checks': [x['q'] for x in (p.get('qualify') or [])][:3] or ['Does this sound like you? ' + s.get('who', '')]})
NOPEN = sum(1 for s in SETS.values() if not s.get('st') and (s.get('dl') or '9') >= '2026-11-22')

CSS = r"""
.fc{--ink:#000000;--sec:#6E6E73;--sep:rgba(60,60,67,.14);--fill:#F2F2F7;--brand:#12805C;--dark:#0F3B2E;--mint:#3DDC97;
 font-family:-apple-system,BlinkMacSystemFont,Inter,"Helvetica Neue",Arial,sans-serif;color:var(--ink);-webkit-font-smoothing:antialiased;
 width:390px;height:844px;flex:none;border-radius:50px;overflow:hidden;position:relative;background:#FFFFFF;isolation:isolate;display:flex;flex-direction:column;box-shadow:0 0 0 11px #1C1C1E,0 0 0 12px #3A3A3C,0 30px 60px rgba(0,0,0,.25);user-select:none}
.fc *{box-sizing:border-box}
.fc .sb{height:50px;flex:none;display:flex;align-items:center;justify-content:space-between;padding:6px 30px 0 36px;font-weight:600;font-size:16px;letter-spacing:-.2px}
.fc .di{position:absolute;top:11px;left:50%;transform:translateX(-50%);width:122px;height:35px;border-radius:20px;background:#000}
.fc .nav{height:44px;flex:none;display:flex;align-items:center;gap:10px;padding:0 18px}
.fc .nav .bk{width:30px;height:30px;display:flex;align-items:center;justify-content:center;margin-left:-6px;cursor:pointer;color:var(--brand)}
.fc .lg{font-weight:700;font-size:19px;letter-spacing:-.4px}.fc .lg i{font-style:normal;color:var(--brand)}
.fc .pr{margin-left:auto;width:112px;height:5px;border-radius:9px;background:#E5E5EA;overflow:hidden}.fc .pr b{display:block;height:100%;background:var(--brand);border-radius:9px;transition:width .3s}
.fc .bd{flex:1;min-height:0;display:flex;flex-direction:column;padding:8px 20px 0;overflow:hidden}
.fc .t1{font-size:32px;line-height:1.1;font-weight:700;letter-spacing:-.8px;margin:6px 0 0}
.fc .t1 em{font-style:normal;color:var(--brand)}
.fc .sub{font-size:17px;line-height:1.4;color:var(--sec);margin-top:10px;letter-spacing:-.2px}
.fc .ft{flex:none;padding:12px 20px 34px;display:flex;flex-direction:column;gap:10px}
.fc .btn{height:54px;border-radius:15px;border:0;background:var(--dark);color:#FFF;font:inherit;font-size:17px;font-weight:600;letter-spacing:-.2px;display:flex;align-items:center;justify-content:center;gap:8px;cursor:pointer;width:100%}
.fc .btn:disabled{background:#D1D1D6;color:#FFF;cursor:default}
.fc .btn.ln{background:#FFF;color:var(--ink);box-shadow:inset 0 0 0 1.5px #D1D1D6}
.fc .btn.mint{background:var(--mint);color:var(--dark)}
.fc .lk{background:none;border:0;font:inherit;font-size:16px;color:var(--brand);font-weight:600;cursor:pointer;height:34px}
.fc .opt{display:flex;align-items:center;gap:12px;min-height:60px;padding:14px 16px;border-radius:14px;background:var(--fill);font-size:17px;font-weight:600;letter-spacing:-.3px;cursor:pointer;line-height:1.25}
.fc .opt.on{background:#E6F4EE;box-shadow:inset 0 0 0 2px var(--brand)}
.fc .ck{margin-left:auto;width:24px;height:24px;flex:none;border-radius:99px;box-shadow:inset 0 0 0 1.75px #C7C7CC;display:flex;align-items:center;justify-content:center}
.fc .ck.sq{border-radius:7px}
.fc .on .ck{background:var(--brand);box-shadow:none}
.fc .grp{background:#FFF;border-radius:14px;overflow:hidden}
.fc .row{display:flex;align-items:center;gap:12px;padding:12px 16px;position:relative}
.fc .row+.row:before{content:"";position:absolute;left:16px;right:0;top:0;height:.5px;background:var(--sep)}
.fc .chip{display:inline-flex;align-items:center;gap:4px;font-size:12.5px;font-weight:600;padding:3px 8px;border-radius:99px;background:#E6F4EE;color:var(--brand)}
.fc .card{background:#FFF;border-radius:18px;box-shadow:0 1px 2px rgba(0,0,0,.06),0 8px 24px rgba(0,0,0,.08)}
.fc .yn{height:54px;border-radius:15px;background:#FFF;box-shadow:inset 0 0 0 1.5px #D1D1D6;font-size:17px;font-weight:600;display:flex;align-items:center;justify-content:center;cursor:pointer;flex:1}
.fc .yn.on{background:var(--dark);color:#FFF;box-shadow:none}
.fc .yn.no.on{background:#3A3A3C}
.fc .seg{display:flex;background:#E9E9EB;border-radius:10px;padding:2px;gap:2px}
.fc .seg span{flex:1;height:34px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:15px;font-weight:600;cursor:pointer;color:#3C3C43}
.fc .seg span.on{background:#FFF;box-shadow:0 1px 3px rgba(0,0,0,.12)}
.fc .emo{font-size:76px;line-height:1;text-align:center}
.fc .inp{height:52px;border-radius:12px;background:var(--fill);border:0;font:inherit;font-size:17px;padding:0 16px;width:100%;outline:none;color:var(--ink)}
.fc .lab{font-size:13px;color:var(--sec);font-weight:500;margin:0 4px 6px;text-transform:uppercase;letter-spacing:.2px}
.fc .scr>*{flex-shrink:0}.fc .scr{overflow:auto;scrollbar-width:none}.fc .scr::-webkit-scrollbar{display:none}
.fc .fadein{animation:fcIn .22s ease-out both}
@keyframes fcIn{from{opacity:0;transform:translateX(14px)}to{opacity:1;transform:none}}
@keyframes fcSpin{to{transform:rotate(360deg)}}
@keyframes fcPop{0%{transform:scale(.6);opacity:0}70%{transform:scale(1.06);opacity:1}100%{transform:scale(1)}}
@keyframes fcFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}
@media (prefers-reduced-motion: reduce){.fc *{animation:none !important;transition:none !important}}
.sbd{display:flex;flex-wrap:wrap;gap:34px 26px}
.mini{width:195px;height:422px;position:relative;flex:none}
.mini .fc{transform:scale(.5);transform-origin:0 0;position:absolute;left:0;top:0;pointer-events:none}
.mini span.cap{position:absolute;top:432px;left:0;width:195px;text-align:center;font:600 13px/1.3 -apple-system,BlinkMacSystemFont,Inter,sans-serif;color:#43504A}
"""

JSR = r"""
  componentDidMount() {
    const roots = [document]; document.querySelectorAll('*').forEach((el) => { if (el.shadowRoot) roots.push(el.shadowRoot); });
    roots.forEach((root) => root.querySelectorAll('[data-fc]').forEach((el) => { if (!el._fc) { el._fc = 1; this.boot(el); } }));
  }
  boot(el) {
    const D = __DATA__, NOPEN = __NOPEN__;
    const STEPS = ['w1', 'w2', 'w3', 'w4', 'name', 'pains', 'goal', 'plan', 'qintro'].concat(D.map((d, i) => 'q' + i)).concat(['load', 'est', 'pick', 'chk', 'win', 'offer', 'profile', 'done']);
    const money = (n) => '$' + Math.round(n).toLocaleString('en-US');
    const fmtD = (iso) => { if (!iso) return 'No deadline'; const d = new Date(iso + 'T12:00:00'); return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }); };
    const daysL = (iso) => iso ? Math.max(0, Math.round((new Date(iso + 'T12:00:00') - new Date('2026-11-22T12:00:00')) / 864e5)) : null;
    const I = (p, s, c, w) => '<svg width="' + (s || 20) + '" height="' + (s || 20) + '" viewBox="0 0 24 24" fill="none" stroke="' + (c || 'currentColor') + '" stroke-width="' + (w || 2.2) + '" stroke-linecap="round" stroke-linejoin="round" style="flex:none;display:block"><path d="' + p + '"/></svg>';
    const P = { back: 'm15 18-6-6 6-6', check: 'M20 6 9 17l-5-5', x: 'M18 6 6 18 M6 6l12 12', cal: 'M8 2v4 M16 2v4 M3 10h18 M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z',
      user: 'M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2 M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z', tag: 'M12.6 2.6A2 2 0 0 0 11.2 2H4a2 2 0 0 0-2 2v7.2a2 2 0 0 0 .6 1.4l8.7 8.7a2.4 2.4 0 0 0 3.4 0l6.6-6.6a2.4 2.4 0 0 0 0-3.4z M7.5 7.5h.01',
      lock: 'M5 11h14a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2z M7 11V7a5 5 0 0 1 10 0v4', bell: 'M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9 M10.3 21a1.94 1.94 0 0 0 3.4 0',
      send: 'm22 2-7 20-4-9-9-4Z M22 2 11 13', search: 'm21 21-4.34-4.34 M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z', coins: 'M8 14a6 6 0 1 0 0-12 6 6 0 0 0 0 12z M18.09 10.37A6 6 0 1 1 10.34 18 M7 6h1v4',
      shield: 'M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z', gavel: 'm14 13-7.5 7.5a2.12 2.12 0 0 1-3-3L11 10 m5 6 6-6 m-8-8 6 6', heart: 'M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z' };
    const T = (d, s) => '<img src="' + d.tile + '" alt="" draggable="false" style="width:' + s + 'px;height:' + s + 'px;border-radius:' + Math.round(s * .24) + 'px;flex:none;display:block">';
    const PAINS = ["I'm not sure what I qualify for", "I don't have time to find and file claims", 'I miss claim deadlines', 'I lose track of claims and payouts', 'A little extra money would help'];
    const GOALS = ['Cover everyday bills', 'Handle a surprise cost', 'Pay down debt', 'Build my savings', 'Treat myself', 'Just see what I may be owed'];
    const init = () => ({ s: 0, name: '', pains: {}, goal: '', yes: {}, sel: {}, chk: {}, ci: 0, agree: false, plan: 'yearly', load: 0, p: {} });
    let st = init();
    const fixed = el.dataset.step;
    if (fixed) { // storyboard: sample answers so each frame shows real content
      st = Object.assign(init(), { s: STEPS.indexOf(fixed), name: 'Ana', pains: { 0: 1, 2: 1 }, goal: GOALS[3], yes: { apple: 1, visa: 1, realpage: 1, fleatick: 1, amazon: 1 }, load: 4 });
      st.sel = { apple: 1, visa: 1, realpage: 1 }; if (fixed === 'chk') st.chk = { apple: { 0: 'y' } }; if (['win', 'offer', 'profile', 'done'].includes(fixed)) D.forEach((d) => { if (st.sel[d.id]) st.chk[d.id] = Object.fromEntries(d.checks.map((q, k) => [k, 'y'])); });
    }
    const matched = () => D.filter((d) => st.yes[d.id]);
    const picked = () => D.filter((d) => st.sel[d.id]);
    const elig = () => picked().filter((d) => d.checks.every((q, k) => (st.chk[d.id] || {})[k] === 'y'));
    const sum = (L) => L.reduce((t, d) => t + (d.max || 0), 0);
    const go = (n) => { st.s = Math.max(0, Math.min(STEPS.length - 1, n)); draw(true); if (STEPS[st.s] === 'load') runLoad(); };
    const next = () => go(st.s + 1);
    let lt;
    const runLoad = () => { st.load = 0; clearInterval(lt); lt = setInterval(() => { st.load += 1; draw(); if (st.load >= 4) { clearInterval(lt); setTimeout(() => { if (STEPS[st.s] === 'load') next(); }, 500); } }, 650); };

    const chrome = (inner, o) => {
      o = o || {};
      const pct = Math.round(((st.s + 1) / STEPS.length) * 100);
      return '<div class="di"></div><div class="sb"><span>9:41</span><span style="display:flex;gap:6px;align-items:center"><svg width="18" height="12" viewBox="0 0 18 12"><rect x="0" y="8" width="3" height="4" rx="1" fill="#000"/><rect x="5" y="5" width="3" height="7" rx="1" fill="#000"/><rect x="10" y="2.5" width="3" height="9.5" rx="1" fill="#000"/><rect x="15" y="0" width="3" height="12" rx="1" fill="#000"/></svg><svg width="26" height="13" viewBox="0 0 26 13"><rect x=".5" y=".5" width="22" height="12" rx="3.5" fill="none" stroke="#000" opacity=".4"/><rect x="2" y="2" width="19" height="9" rx="2" fill="#000"/><rect x="24" y="4.5" width="1.5" height="4" rx=".75" fill="#000" opacity=".4"/></svg></span></div>'
        + (o.noNav ? '' : '<div class="nav">' + (st.s > 0 && !o.noBack ? '<span class="bk" data-a="back">' + I(P.back, 26, 'currentColor', 2.6) + '</span>' : '') + '<span class="lg">claimclub<i>.io</i></span>' + (o.noBar ? '' : '<span class="pr"><b style="width:' + pct + '%"></b></span>') + (o.pill || '') + '</div>')
        + inner;
    };
    const foot = (b) => '<div class="ft">' + b + '</div>';
    const btn = (t, a, dis, cls) => '<button class="btn ' + (cls || '') + '" data-a="' + a + '"' + (dis ? ' disabled' : '') + '>' + t + '</button>';

    const S = {};
    // 1 to 4: explain the whole thing before asking anything
    S.w1 = () => chrome('<div class="bd"><h1 class="t1">Companies owe people <em>money</em>. Most never claim it.</h1><p class="sub">When a company settles a class action, the court sets money aside for everyone affected. You only get paid if you file a claim.</p>'
      + '<div style="flex:1;position:relative;margin-top:14px">' + D.slice(0, 6).map((d, i) => '<div style="position:absolute;left:' + [30, 150, 250, 60, 190, 110][i] + 'px;top:' + [20, 0, 40, 120, 110, 60][i] + 'px;transform:rotate(' + [-10, 6, 12, -4, 8, -14][i] + 'deg);animation:fcFloat ' + (3 + i * .4) + 's ease-in-out infinite">' + T(d, 74) + '</div>').join('')
      + '<div style="position:absolute;left:0;right:0;bottom:12px;height:190px;border-radius:26px;background:linear-gradient(160deg,#1E7A55,#0F3B2E);display:flex;align-items:flex-end;padding:22px"><b style="color:#FFF;font-size:30px;line-height:1;letter-spacing:-.5px">UNCLAIMED<br>MONEY</b><span style="margin-left:auto;color:#3DDC97;font-weight:700;font-size:15px">' + NOPEN + ' open cases</span></div></div></div>'
      + foot(btn('Continue', 'next')), { noBack: true });
    S.w2 = () => chrome('<div class="bd"><h1 class="t1">We find the payouts. <em>You keep the cash.</em></h1><p class="sub">Answer a few quick questions and we match you to the settlements you likely qualify for.</p>'
      + '<div style="flex:1;display:flex;flex-direction:column;gap:12px;margin-top:22px;padding:4px 2px">' + [D[0], D[2], D[4]].map((d, i) => '<div class="card" style="padding:14px 16px;display:flex;flex-direction:column;gap:8px;transform:rotate(' + [-1.2, .8, -.6][i] + 'deg)"><span style="display:flex;align-items:center;gap:10px">' + T(d, 30) + '<b style="font-size:15px;flex:1">' + d.co + '</b><span style="font-size:13px;color:var(--sec)">' + daysL(d.dl) + ' days left</span></span><span style="display:flex;align-items:flex-end"><span style="display:flex;flex-direction:column"><span style="font-size:12.5px;color:var(--sec)">Open settlement</span><b style="font-size:26px;letter-spacing:-.6px">' + d.pay + '</b></span><span class="chip" style="margin-left:auto">' + I(P.check, 13, 'currentColor', 3) + 'Likely match</span></span></div>').join('') + '</div></div>'
      + foot(btn('Continue', 'next')));
    S.w3 = () => chrome('<div class="bd"><h1 class="t1">We file for you and <em>track every claim.</em></h1><p class="sub">We fill in each claim form, send it to the settlement and follow it until it pays. Payouts usually take 6 to 12 months.</p>'
      + '<div style="flex:1;margin-top:18px;border-radius:26px;background:linear-gradient(160deg,#1E7A55,#0F3B2E);position:relative;padding:22px 16px;display:flex;flex-direction:column;gap:10px">'
      + '<div class="card" style="padding:12px 14px"><b style="font-size:14px">Your claims</b>' + [D[0], D[2], D[4]].map((d, i) => '<div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-top:.5px solid var(--sep);margin-top:' + (i ? 0 : 8) + 'px">' + T(d, 26) + '<span style="flex:1;font-size:14px;font-weight:600">' + d.co + '</span><span class="chip" style="' + (i === 2 ? 'background:#F2F2F7;color:#6E6E73' : '') + '">' + ['Filed', 'Filed', 'Filing'][i] + '</span></div>').join('') + '</div>'
      + '<div style="background:rgba(255,255,255,.9);backdrop-filter:blur(10px);border-radius:16px;padding:10px 12px;display:flex;gap:10px;align-items:center;box-shadow:0 8px 20px rgba(0,0,0,.2);animation:fcPop .5s .4s both"><span style="width:30px;height:30px;border-radius:8px;background:#0F3B2E;display:flex;align-items:center;justify-content:center">' + I(P.check, 16, '#3DDC97', 3) + '</span><span style="font-size:13.5px;line-height:1.3"><b>Claimclub</b><br>Your Visa & Mastercard claim was filed.</span></div></div></div>'
      + foot(btn('Continue', 'next')));
    S.w4 = () => chrome('<div class="bd"><h1 class="t1">Real settlements. <em>Your money stays yours.</em></h1><p class="sub">Here is what you can count on.</p><div class="grp" style="margin-top:20px;background:var(--fill)">'
      + [[P.gavel, 'Court-approved settlements', 'Every case we list was approved by a court.'], [P.heart, 'You keep 100% of every payout', 'The settlement pays you directly. We never take a cut.'], [P.lock, 'Your details stay private', 'We only share them with the settlements you file.'], [P.x, 'Cancel anytime', 'One tap in your account.']].map((r) => '<div class="row" style="padding:14px 16px"><span style="width:36px;height:36px;border-radius:10px;background:#E6F4EE;display:flex;align-items:center;justify-content:center">' + I(r[0], 19, '#12805C') + '</span><span style="display:flex;flex-direction:column;gap:2px"><b style="font-size:16px;letter-spacing:-.2px">' + r[1] + '</b><span style="font-size:14px;color:var(--sec)">' + r[2] + '</span></span></div>').join('') + '</div>'
      + '<p style="font-size:13px;color:var(--sec);margin-top:14px;line-height:1.4">Claimclub is not a law firm. You can always file for free on the official settlement site.</p></div>' + foot(btn('Continue', 'next')));
    S.name = () => chrome('<div class="bd" style="justify-content:center;margin-top:-40px"><h1 class="t1" style="text-align:center">What should we <em>call you?</em></h1><p class="sub" style="text-align:center;margin-bottom:26px">Just your first name for now.</p>'
      + '<div class="lab">First name</div><input class="inp" data-k="name" placeholder="First name" value="' + (st.name || '') + '" autocomplete="given-name"></div>' + foot(btn('Continue', 'next', !st.name.trim())));
    S.pains = () => chrome('<div class="bd scr"><h1 class="t1">' + (st.name ? st.name + ', which' : 'Which') + ' of these <em>sound like you?</em></h1><p class="sub">Pick any that fit.</p><div style="display:flex;flex-direction:column;gap:10px;margin:20px 0 10px">'
      + PAINS.map((t, i) => '<div class="opt' + (st.pains[i] ? ' on' : '') + '" data-a="pain" data-v="' + i + '">' + t + '<span class="ck sq">' + (st.pains[i] ? I(P.check, 15, '#FFF', 3.2) : '') + '</span></div>').join('') + '</div></div>'
      + foot(btn('Continue', 'next', !Object.keys(st.pains).length)));
    S.goal = () => chrome('<div class="bd scr"><h1 class="t1">If you got paid, <em>what would it go to?</em></h1><p class="sub">Choose the one that matters most.</p><div style="display:flex;flex-direction:column;gap:10px;margin:20px 0 10px">'
      + GOALS.map((t) => '<div class="opt' + (st.goal === t ? ' on' : '') + '" data-a="goal" data-v="' + t + '">' + t + '<span class="ck">' + (st.goal === t ? I(P.check, 15, '#FFF', 3.2) : '') + '</span></div>').join('') + '</div></div>'
      + foot(btn('Continue', 'next', !st.goal)));
    S.plan = () => chrome('<div class="bd"><h1 class="t1">Here is how we <em>get you paid.</em></h1><p class="sub">' + (st.goal && st.goal !== GOALS[5] ? 'Money for ' + st.goal.toLowerCase().replace('build my', 'your').replace('pay down', 'paying down').replace('cover', 'covering').replace('handle', 'handling').replace('treat myself', 'something for you') + ' starts with a few quick answers.' : 'It starts with a few quick answers.') + '</p>'
      + '<div style="margin-top:26px;display:flex;flex-direction:column">' + [[P.search, 'Find your matches', 'Yes or no questions about brands you have used.'], [P.check, 'Check each claim', 'A few questions per claim so we only file what you qualify for.'], [P.send, 'We file and track', 'We submit every claim and tell you when money is on the way.']].map((r, i) => '<div style="display:flex;gap:14px;position:relative;padding-bottom:' + (i < 2 ? 26 : 0) + 'px">' + (i < 2 ? '<i style="position:absolute;left:21px;top:46px;bottom:4px;width:2px;background:#D1E9DE"></i>' : '') + '<span style="width:44px;height:44px;border-radius:99px;background:#12805C;display:flex;align-items:center;justify-content:center;flex:none">' + I(r[0], 21, '#FFF') + '</span><span style="display:flex;flex-direction:column;gap:3px;padding-top:2px"><b style="font-size:17px;letter-spacing:-.3px">' + r[1] + '</b><span style="font-size:15px;color:var(--sec);line-height:1.35">' + r[2] + '</span></span></div>').join('') + '</div></div>'
      + foot(btn('See what I may qualify for', 'next')));
    S.qintro = () => chrome('<div class="bd" style="justify-content:center;align-items:center;text-align:center;margin-top:-30px"><div class="emo" style="animation:fcPop .5s both">🗓️</div><h1 class="t1" style="margin-top:20px">Let\'s see what <em>you may be owed.</em></h1><p class="sub">' + D.length + ' quick yes or no questions. Swipe or tap.</p></div>' + foot(btn("Let's find out", 'next')));
    D.forEach((d, i) => {
      S['q' + i] = () => chrome('<div class="bd" style="padding:6px 16px 0;background:linear-gradient(180deg,#FFFFFF,#F2F2F7)"><div style="display:flex;justify-content:flex-end;margin-bottom:10px"><span style="font-size:13px;font-weight:600;padding:6px 12px;border-radius:99px;background:#FFF;box-shadow:0 1px 3px rgba(0,0,0,.1)"><b style="color:#12805C">' + (i + 1) + '</b>/' + D.length + ' questions</span></div>'
        + '<div class="card swipe" style="flex:1;margin-bottom:6px;padding:24px 22px;display:flex;flex-direction:column;position:relative;transform:translateX(calc(var(--dx,0)*1px)) rotate(calc(var(--dx,0)*.05deg));touch-action:none;cursor:grab">'
        + '<span style="position:absolute;top:20px;right:20px;font-size:22px;font-weight:800;color:#12805C;border:3px solid #12805C;border-radius:10px;padding:0 10px;transform:rotate(10deg);opacity:clamp(0,calc(var(--dx,0)/90),1)">YES</span><span style="position:absolute;top:20px;right:20px;font-size:22px;font-weight:800;color:#FF3B30;border:3px solid #FF3B30;border-radius:10px;padding:0 10px;transform:rotate(10deg);opacity:clamp(0,calc(var(--dx,0)/-90),1)">NO</span>'
        + T(d, 54) + '<h2 style="font-size:28px;line-height:1.15;font-weight:700;letter-spacing:-.7px;margin:18px 0 0">' + d.q.replace(d.co.split(' ')[0], '<em style="font-style:normal;color:#12805C">' + d.co.split(' ')[0] + '</em>') + '</h2>'
        + '<div style="flex:1;display:flex;align-items:center;justify-content:center">' + T(d, 150) + '</div>'
        + '<div style="display:flex;flex-direction:column;gap:10px"><div class="yn" data-a="ans" data-v="y" style="flex:none">Yes</div><div class="yn" data-a="ans" data-v="n" style="flex:none">No</div></div></div>'
        + '<p style="text-align:center;font-size:13px;color:var(--sec);margin:8px 0 26px">Swipe right for yes, left for no</p></div>', { noBar: false });
    });
    S.load = () => chrome('<div class="bd" style="justify-content:center;align-items:center;text-align:center;margin-top:-30px"><div style="position:relative;width:190px;height:190px"><div style="position:absolute;inset:14px;border-radius:99px;border:2px solid #D1E9DE"></div><div style="position:absolute;inset:14px;border-radius:99px;border:2px solid transparent;border-top-color:#12805C;animation:fcSpin 1.2s linear infinite"></div>'
      + matched().slice(0, 4).map((d, i) => '<div style="position:absolute;left:' + [75, 150, 75, 0][i] + 'px;top:' + [0, 75, 150, 75][i] + 'px;padding:4px;border-radius:14px;background:#FFF;box-shadow:0 4px 12px rgba(0,0,0,.12)">' + T(d, 34) + '</div>').join('') + '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">' + I(P.search, 36, '#12805C', 2.4) + '</div></div>'
      + '<h1 class="t1" style="margin-top:24px">Checking your <em>matches</em></h1><div style="display:flex;flex-direction:column;gap:14px;margin-top:22px;text-align:left;width:250px">'
      + ['Reviewing your answers', 'Matching open settlements', 'Estimating your payouts', 'Finishing up'].map((t, i) => '<span style="display:flex;align-items:center;gap:12px;font-size:16px;font-weight:600;color:' + (i <= st.load ? '#000' : '#AEAEB2') + '">' + (i < st.load ? '<span style="width:24px;height:24px;border-radius:99px;background:#12805C;display:flex;align-items:center;justify-content:center">' + I(P.check, 14, '#FFF', 3.2) + '</span>' : '<span style="width:24px;height:24px;border-radius:99px;border:2.5px solid ' + (i === st.load ? '#12805C' : '#D1D1D6') + ';border-right-color:transparent;' + (i === st.load ? 'animation:fcSpin .9s linear infinite' : '') + '"></span>') + t + '</span>').join('') + '</div></div>', { noBack: true });
    S.est = () => { const m = matched(), t = sum(m); return chrome('<div class="bd" style="justify-content:center;align-items:center;text-align:center;margin-top:-40px"><span style="font-size:13px;font-weight:700;letter-spacing:1px;color:#12805C">BASED ON YOUR ANSWERS</span><h1 class="t1" style="font-size:27px;margin-top:10px">You could qualify for up to</h1><b style="font-size:84px;letter-spacing:-4px;line-height:1.05;margin-top:6px;animation:fcPop .6s both">' + money(t) + '</b>'
      + '<p class="sub">From ' + m.length + ' open settlement' + (m.length === 1 ? '' : 's') + '. Next we check each one, so we only file what you qualify for.</p><div style="display:flex;gap:-8px;margin-top:20px">' + m.map((d, i) => '<span style="margin-left:' + (i ? -10 : 0) + 'px;padding:2px;border-radius:12px;background:#FFF">' + T(d, 40) + '</span>').join('') + '</div></div>' + foot(btn('Continue', 'next')), { noBack: true }); };
    S.pick = () => { const m = matched(), rest = D.filter((d) => !st.yes[d.id]); const L = m.concat(rest); const p = picked();
      return chrome('<div class="bd scr" style="background:#F2F2F7;padding:4px 16px 0"><h1 class="t1" style="font-size:28px;text-align:center">Choose your claims</h1><p class="sub" style="text-align:center;font-size:15px;margin-top:6px">We picked the ones your answers matched. You can add more until each deadline.</p><div style="display:flex;flex-direction:column;gap:10px;margin:16px 0 16px">'
        + L.map((d) => { const on = st.sel[d.id]; return '<div class="card" data-a="sel" data-v="' + d.id + '" style="padding:14px;display:flex;gap:14px;align-items:center;cursor:pointer;' + (on ? 'box-shadow:inset 0 0 0 2px #12805C' : '') + '">' + T(d, 62) + '<span style="flex:1;display:flex;flex-direction:column;gap:3px;min-width:0"><b style="font-size:16px;letter-spacing:-.2px">' + d.co + '</b><span style="font-size:13px;color:var(--sec);display:flex;gap:5px;align-items:center">' + I(P.cal, 13, '#8E8E93') + (daysL(d.dl) !== null ? daysL(d.dl) + ' days left' : 'Open') + '</span><span style="font-size:13px;color:var(--sec);display:flex;gap:5px;align-items:flex-start;line-height:1.3">' + I(P.user, 13, '#8E8E93') + '<span style="display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden">' + d.who + '</span></span><span style="font-size:13px;font-weight:600;color:#12805C">' + d.pay + (st.yes[d.id] ? ' · matched' : '') + '</span></span><span class="ck sq" style="' + (on ? 'background:#12805C;box-shadow:none' : '') + '">' + (on ? I(P.check, 15, '#FFF', 3.2) : '') + '</span></div>'; }).join('') + '</div></div>'
        + '<div class="ft" style="flex-direction:row;align-items:center;border-top:.5px solid var(--sep);background:rgba(255,255,255,.94);padding-top:14px"><span style="display:flex;flex-direction:column"><span style="font-size:13px;color:var(--sec)">' + p.length + ' selected</span><b style="font-size:24px;color:#12805C;letter-spacing:-.5px">' + money(sum(p)) + '</b></span><button class="btn" data-a="next" style="width:140px;margin-left:auto"' + (p.length ? '' : ' disabled') + '>Next</button></div>', { noBack: false }); };
    S.chk = () => { const L = picked(); const d = L[st.ci] || L[0]; if (!d) return chrome('<div class="bd"></div>'); const a = st.chk[d.id] || {}; const done = d.checks.every((q, k) => a[k]); const bad = d.checks.some((q, k) => a[k] === 'n');
      return chrome('<div class="bd scr" style="padding-top:0"><div style="display:flex;align-items:center;gap:12px;padding:6px 0 14px;border-bottom:.5px solid var(--sep)">' + T(d, 50) + '<span style="display:flex;flex-direction:column"><b style="font-size:20px;letter-spacing:-.4px">Claim ' + (st.ci + 1) + ' of ' + L.length + ': ' + d.co + '</b><span style="font-size:14px;color:var(--sec)">Eligibility check · ' + d.pay + '</span></span></div>'
        + d.checks.map((q, k) => '<div style="padding:18px 0;border-bottom:.5px solid var(--sep)"><span style="font-size:12px;font-weight:700;letter-spacing:.8px;color:#12805C">QUESTION ' + (k + 1) + '</span><p style="font-size:18px;font-weight:600;letter-spacing:-.3px;line-height:1.3;margin:6px 0 14px">' + q + '</p><div style="display:flex;gap:10px"><div class="yn' + (a[k] === 'y' ? ' on' : '') + '" data-a="chk" data-k="' + k + '" data-v="y">Yes</div><div class="yn no' + (a[k] === 'n' ? ' on' : '') + '" data-a="chk" data-k="' + k + '" data-v="n">No</div></div></div>').join('')
        + (bad ? '<div style="margin-top:16px;padding:14px 16px;border-radius:14px;background:#FFF4E5;font-size:15px;line-height:1.4;color:#7A4B00">Based on that answer you probably do not qualify for this one. We will leave it out.</div>' : (done ? '<div style="margin-top:16px;padding:14px 16px;border-radius:14px;background:#E6F4EE;font-size:15px;line-height:1.4;color:#0F3B2E;display:flex;gap:10px;align-items:center">' + I(P.check, 18, '#12805C', 3) + 'You look eligible. We will file this one.</div>' : ''))
        + '<div style="height:20px"></div></div>' + '<div class="ft" style="flex-direction:row;border-top:.5px solid var(--sep)"><button class="btn ln" data-a="skip" style="flex:1">Skip for now</button><button class="btn" data-a="nextc" style="flex:1"' + (done ? '' : ' disabled') + '>' + (st.ci < L.length - 1 ? 'Next claim' : 'Finish') + '</button></div>'); };
    S.win = () => { const e = elig(), t = sum(e); return '<div style="position:absolute;inset:0;z-index:-1;background:radial-gradient(120% 90% at 50% 40%,#1E7A55,#0F3B2E 70%)"></div>' + chrome('<div class="bd" style="justify-content:center;align-items:center;text-align:center;color:#FFF;position:relative;margin-top:-30px"><div class="emo" style="animation:fcPop .5s both">💰</div><h1 class="t1" style="color:#FFF;margin-top:16px;font-size:28px">You can file for up to</h1><b style="font-size:84px;letter-spacing:-4px;line-height:1.05;color:#3DDC97;animation:fcPop .6s .1s both">' + money(t) + '</b><p class="sub" style="color:#CFE9DD">' + e.length + ' claim' + (e.length === 1 ? '' : 's') + ' checked and ready to file. Let\'s get them in before the deadlines.</p></div>' + foot(btn('Continue', 'next', false, 'mint')), { noBack: true }).replace('<div class="sb">', '<div class="sb" style="color:#FFF">').replace('class="lg"', 'class="lg" style="color:#FFF"'); };
    S.offer = () => { const e = elig(), t = sum(e);
      return chrome('<div class="bd scr" style="background:#F2F2F7;padding-top:4px"><h1 class="t1" style="font-size:28px">Your ' + money(t) + ' is <em>ready to file</em></h1><p class="sub" style="font-size:15px">Start your membership and we file all ' + e.length + ' claims for you.</p>'
        + '<div class="grp" style="margin-top:16px">' + e.map((d) => '<div class="row">' + T(d, 30) + '<span style="flex:1;font-size:15px;font-weight:600">' + d.co + '</span><b style="font-size:15px;color:#12805C">' + d.pay + '</b></div>').join('') + '</div>'
        + '<div style="margin-top:14px;border-radius:18px;background:linear-gradient(160deg,#1E7A55,#0F3B2E);color:#FFF;padding:18px"><span style="display:flex;align-items:center"><span style="font-size:12.5px;font-weight:700;letter-spacing:1px;color:#CFE9DD">CLAIMCLUB MEMBERSHIP</span><span style="margin-left:auto;font-size:12px;font-weight:700;padding:4px 9px;border-radius:99px;background:#3DDC97;color:#0F3B2E">3 DAYS FREE</span></span>'
        + '<span style="display:flex;align-items:baseline;gap:8px;margin-top:10px"><b style="font-size:40px;letter-spacing:-1.4px">Free</b><span style="font-size:15px;color:#CFE9DD">for 3 days, then $49.99 a year ($4.17/mo)</span></span>'
        + ['We file every claim you qualify for', 'New claims as they open', 'Track every payout in one place', 'You keep 100% of every payout'].map((x) => '<span style="display:flex;gap:8px;align-items:center;font-size:15px;margin-top:9px">' + I(P.check, 16, '#3DDC97', 3) + x + '</span>').join('') + '</div>'
        + '<div class="opt' + (st.agree ? ' on' : '') + '" data-a="agree" style="margin-top:14px;background:#FFF;font-size:14px;font-weight:500;line-height:1.35;align-items:flex-start;min-height:0"><span class="ck sq" style="margin:0;' + (st.agree ? 'background:#12805C;box-shadow:none' : '') + '">' + (st.agree ? I(P.check, 15, '#FFF', 3.2) : '') + '</span><span>My answers are true, and I agree that Claimclub can fill out and file my claims for me, as described in the Claim Filing Authorization Agreement.</span></div><div style="height:16px"></div></div>'
        + '<div class="ft" style="background:#F2F2F7;padding-top:8px"><button class="btn mint" data-a="pay"' + (st.agree ? '' : ' disabled') + '>' + I(P.lock, 17, 'currentColor') + 'Start my free trial</button><span style="font-size:12.5px;color:var(--sec);text-align:center;line-height:1.35">$0 today. Then $49.99 a year unless you cancel before your trial ends. Apple Pay, Google Pay or card on the next screen.</span></div>'); };
    S.profile = () => chrome('<div class="bd scr" style="background:#F2F2F7;padding-top:4px"><span class="chip" style="align-self:flex-start;margin-bottom:8px">' + I(P.check, 13, 'currentColor', 3) + 'Trial started</span><h1 class="t1" style="font-size:28px">Your filing details</h1><p class="sub" style="font-size:15px">These go on every claim form. Use your legal name and current address.</p>'
      + [['FULL NAME', [['First name', st.name || ''], ['Last name', '']]], ['CONTACT', [['Phone', ''], ['Birthday', '']]], ['ADDRESS', [['Street', ''], ['City', ''], ['State', ''], ['ZIP', '']]]].map((g) => '<div class="lab" style="margin-top:18px">' + g[0] + '</div><div class="grp">' + g[1].map((f) => '<div class="row" style="padding:0 16px;height:48px"><span style="width:120px;font-size:15px;white-space:nowrap">' + f[0] + '</span><input class="inp" style="background:none;height:48px;padding:0" placeholder="Required" value="' + f[1] + '"></div>').join('') + '</div>').join('')
      + '<p style="font-size:13px;color:var(--sec);margin:12px 4px 18px;display:flex;gap:6px">' + I(P.lock, 14, '#8E8E93') + 'Encrypted. Used only to file your claims.</p></div>' + foot(btn('Continue', 'next')), { noBack: true });
    S.done = () => chrome('<div class="bd" style="justify-content:center;align-items:center;text-align:center;margin-top:-30px"><div style="width:96px;height:96px;border-radius:99px;background:#12805C;display:flex;align-items:center;justify-content:center;animation:fcPop .5s both">' + I(P.check, 50, '#FFF', 3) + '</div><h1 class="t1" style="margin-top:22px">We\'re on it, ' + (st.name || 'Ana') + '</h1><p class="sub">We file your ' + elig().length + ' claims and email you each claim number. Opening your dashboard...</p></div>'
      + foot(btn('Start over', 'restart', false, 'ln')), { noBack: true });

    const draw = (anim) => {
      const k = STEPS[st.s];
      el.innerHTML = (S[k] || S.w1)();
      const b = el.querySelector('.bd'); if (anim && b && !fixed) b.classList.add('fadein');
      if (fixed) return;
      const inp = el.querySelector('input[data-k=name]'); if (inp) { inp.oninput = (e) => { st.name = e.target.value; const bt = el.querySelector('[data-a=next]'); bt.disabled = !st.name.trim(); }; }
      const sw = el.querySelector('.swipe'); if (sw) wireSwipe(sw);
    };
    const answer = (y) => { const d = D[parseInt(STEPS[st.s].slice(1))]; if (y) { st.yes[d.id] = 1; st.sel[d.id] = 1; } else { delete st.yes[d.id]; delete st.sel[d.id]; } next(); };
    const wireSwipe = (c) => {
      let x0 = null, dx = 0;
      c.addEventListener('pointerdown', (e) => { if (e.target.closest('[data-a]')) return; x0 = e.clientX; dx = 0; c.setPointerCapture(e.pointerId); c.style.transition = 'none'; });
      c.addEventListener('pointermove', (e) => { if (x0 === null) return; dx = (e.clientX - x0) / (el.getBoundingClientRect().width / 390); c.style.setProperty('--dx', dx); });
      const up = () => { if (x0 === null) return; x0 = null; if (Math.abs(dx) > 90) { c.style.transition = 'transform .2s ease'; c.style.setProperty('--dx', dx > 0 ? 500 : -500); setTimeout(() => answer(dx > 0), 170); } else { c.style.transition = 'transform .2s ease'; c.style.setProperty('--dx', 0); } };
      c.addEventListener('pointerup', up); c.addEventListener('pointercancel', up);
    };
    el.addEventListener('click', (e) => {
      if (fixed) return; const t = e.target.closest('[data-a]'); if (!t || t.disabled) return; const a = t.dataset.a, v = t.dataset.v;
      if (a === 'next') next();
      else if (a === 'back') { let n = st.s - 1; if (STEPS[n] === 'load') n -= 1; go(n); }
      else if (a === 'pain') { if (st.pains[v]) delete st.pains[v]; else st.pains[v] = 1; draw(); }
      else if (a === 'goal') { st.goal = v; draw(); }
      else if (a === 'ans') { t.classList.add('on'); setTimeout(() => answer(v === 'y'), 160); }
      else if (a === 'sel') { if (st.sel[v]) delete st.sel[v]; else st.sel[v] = 1; draw(); }
      else if (a === 'chk') { const d = picked()[st.ci]; st.chk[d.id] = Object.assign({}, st.chk[d.id], { [t.dataset.k]: v }); draw(); }
      else if (a === 'nextc' || a === 'skip') { if (a === 'skip') { const d = picked()[st.ci]; delete st.chk[d.id]; } if (st.ci < picked().length - 1) { st.ci += 1; draw(true); } else go(STEPS.indexOf('win')); }
      else if (a === 'agree') { st.agree = !st.agree; draw(); }
      else if (a === 'pay') { const sh = document.createElement('div'); sh.style.cssText = 'position:absolute;inset:0;background:rgba(0,0,0,.35);display:flex;align-items:flex-end;z-index:9'; sh.innerHTML = '<div style="background:#F2F2F7;width:100%;border-radius:22px 22px 0 0;padding:22px 20px 40px;display:flex;flex-direction:column;gap:12px;animation:fcIn .25s both"><b style="font-size:20px;text-align:center">Payment</b><div style="height:54px;border-radius:12px;background:#000;color:#FFF;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:600"> Pay</div><div style="height:120px;border-radius:12px;background:repeating-linear-gradient(45deg,#E5E5EA,#E5E5EA 8px,#ECECEF 8px,#ECECEF 16px);display:flex;align-items:center;justify-content:center;color:#8E8E93;font-size:14px;font-weight:600">Stripe card form goes here</div><button class="btn mint" data-a="paid">Start my free trial</button></div>'; el.appendChild(sh); }
      else if (a === 'paid') next();
      else if (a === 'restart') { st = init(); draw(true); }
    });
    draw();
  }
"""

def build():
    data = json.dumps(D)
    frames = ['w1', 'w2', 'w3', 'w4', 'name', 'pains', 'goal', 'plan', 'qintro', 'q0', 'q4', 'load', 'est', 'pick', 'chk', 'win', 'offer', 'profile', 'done']
    caps = {'w1': '1 · Why this matters', 'w2': '2 · We find payouts', 'w3': '3 · We file and track', 'w4': '4 · Trust', 'name': '5 · First name', 'pains': '6 · Sounds like you', 'goal': '7 · What it is for',
            'plan': '8 · How we get you paid', 'qintro': '9 · Quiz intro', 'q0': '10 · Broad question (1 of 8)', 'q4': '10 · Broad question (5 of 8)', 'load': '11 · Checking matches', 'est': '12 · Estimate',
            'pick': '13 · Choose your claims', 'chk': '14 · Per-claim check', 'win': '15 · Ready to file', 'offer': '16 · Offer (H) + I agree', 'profile': '17 · Details after payment', 'done': '18 · Done'}
    sb = ''.join(f'<div class="mini"><div class="fc" data-fc data-step="{k}"></div><span class="cap">{caps[k]}</span></div>' for k in frames)
    W, H = 2440, 1480
    note = ('Explain first (4 screens), then light personal questions, then 8 broad yes or no questions with big logos (swipe or tap), a short check, '
            'the estimate, choose your claims, then each chosen claim gets its own eligibility questions before the offer. Details come after payment. '
            'iOS look: system font (SF Pro on iPhone and Mac, Inter elsewhere), large titles, grouped lists, iOS checkmarks and segmented buttons. '
            'Unlike ClaimMoney we show no member counts, payout totals or reviews we cannot back up.')
    page = (f'<div style="width: {W}px; height: {H}px; box-sizing: border-box; padding: 40px; background: #E9EEEB; font-family: -apple-system, BlinkMacSystemFont, Inter, sans-serif; color: #000; display: flex; gap: 70px"><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"><style>{CSS}</style>'
            f'<div style="display: flex; flex-direction: column; gap: 18px; width: 420px; flex: none"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #12805C">FLOW C · CLAIMMONEY STYLE, CLAIMCLUB THEME</span>'
            f'<span style="font-size: 15px; color: #43504A; font-weight: 500; line-height: 1.5">{note}</span>'
            f'<span style="font-size: 13px; font-weight: 800; letter-spacing: 1px; color: #6E6E73; margin-top: 10px">TRY IT</span><div class="fc" data-fc></div></div>'
            f'<div style="display: flex; flex-direction: column; gap: 18px"><span style="font-size: 13px; font-weight: 800; letter-spacing: 1px; color: #6E6E73">EVERY SCREEN (SAMPLE ANSWERS)</span><div class="sbd" style="width: 1880px">{sb}</div></div></div>\n</x-dc>\n')
    js = ('<script type="text/x-dc" data-dc-script data-props=\'{"$preview":{"width":%d,"height":%d}}\'>\nclass Component extends DCLogic { renderVals() { return {}; }' % (W, H)) + JSR.replace('__DATA__', data).replace('__NOPEN__', str(NOPEN)) + '}\n</script>\n</body>\n</html>\n'
    open(os.path.join(OUT, 'FlowC.dc.html'), 'w').write(HEAD % 'Flow C (iOS)' + page + js)
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    if not any(pg['id'] == 'flowc' for pg in c['pages']): c['pages'].append({'id': 'flowc', 'name': 'Flow C (iOS)'})
    c['boards']['FlowC.dc.html'] = {'x': 0, 'y': 0, 'w': W, 'h': H, 'is_interactive': True, 'title': 'Flow C · ClaimMoney style', 'page': 'flowc'}
    if 'FlowC.dc.html' not in c['order']: c['order'].append('FlowC.dc.html')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w'))
    print('ok', len(D), NOPEN)

if __name__ == '__main__':
    build()
