# Swipe-first question drafts for phones (Nov 22 2026, canvas only, not live).
# Henry: the claim flow's yes/no questions can already be swiped on phones, but nobody can tell.
# SwipeA (card stack with YES / NO stamps and a one-time wiggle), SwipeB (glowing screen edges plus a one-time
# "how to answer" coach), SwipeC (slide control under the card). Each board: a playable phone (drag the card, or tap)
# plus two frozen phones showing a drag to the right (Yes) and to the left (No). Canvas page "Swipe questions".
import os, json, base64
from how4 import HEAD, OUT

HERE = os.path.dirname(os.path.abspath(__file__)); CC = os.path.join(HERE, '..')
INK, MUTE, LINE, MINT, GREEN, DARK, RED = '#0A0F0D', '#5B6862', '#E3EAE6', '#3DDC97', '#12805C', '#0F3B2E', '#D23B43'
QS = [('apple', 'Apple', 'Did you buy an iPhone 15 Pro, 15 Pro Max or any iPhone 16?', 'Bought in the U.S. in 2024 or 2025.', 'Up to $95', 95),
      ('visa', 'Visa & Mastercard', "Have you paid a fee to use another bank's ATM?", 'Any out-of-network ATM fee in the U.S.', 'Up to $1,000', 1000),
      ('googleplay', 'Google Play', 'Have you bought apps or in-app items on Google Play?', 'On any Android phone or tablet.', 'Up to $100', 100),
      ('amazon', 'Amazon', 'Have you ever returned something to Amazon?', 'Any return since 2017.', 'Refund owed', 0),
      ('cvs', 'CVS', 'Have you used the CVS website or app?', 'To shop, fill prescriptions or book a visit.', 'Up to $10', 10)]
P = {  # Lucide paths
    'x': 'M18 6 6 18 M6 6l12 12', 'check': 'M20 6 9 17l-5-5', 'left': 'm15 18-6-6 6-6', 'right': 'm9 18 6-6-6-6', 'back': 'm12 19-7-7 7-7 M19 12H5',
    'pointer': 'M22 14a8 8 0 0 1-8 8 M18 11v-1a2 2 0 0 0-2-2a2 2 0 0 0-2 2 M14 10V9a2 2 0 0 0-2-2a2 2 0 0 0-2 2v1 M10 9.5V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v10 M18 11a2 2 0 1 1 4 0v3a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15',
    'skip': 'M5 12h14 M12 5l7 7-7 7',
}
def ic(k, s=20, c='currentColor', w=2.2):
    return f'<svg width="{s}" height="{s}" viewBox="0 0 24 24" fill="none" stroke="{c}" stroke-width="{w}" stroke-linecap="round" stroke-linejoin="round" style="flex: none; display: block"><path d="{P[k]}"/></svg>'
def tile(k, s=56):
    u = 'data:image/svg+xml;base64,' + base64.b64encode(open(os.path.join(CC, 'tiles', k + '.svg'), 'rb').read()).decode()
    return f'<img src="{u}" alt="" draggable="false" style="width: {s}px; height: {s}px; border-radius: {s * .26:.0f}px; flex: none">'

def topbar(i=0):
    bars = ''.join(f'<span class="pb" style="flex: 1; height: 5px; border-radius: 99px; background: {GREEN if k <= i else LINE}"></span>' for k in range(len(QS)))
    return (f'<div style="padding: 54px 16px 10px; display: flex; flex-direction: column; gap: 12px; background: #FFFFFF">'
            f'<div style="display: flex; align-items: center; gap: 10px">{ic("back", 22, INK, 2.4)}<b style="font-size: 19px; letter-spacing: -.4px">claimclub<span style="color: {GREEN}">.io</span></b>'
            f'<span class="tot" style="margin-left: auto; background: {DARK}; color: #FFFFFF; font-size: 13px; font-weight: 800; padding: 6px 10px; border-radius: 10px">$0</span></div>'
            f'<div style="display: flex; align-items: center; gap: 10px"><div style="flex: 1; display: flex; gap: 4px">{bars}</div><span class="pbN" style="font-size: 12.5px; font-weight: 800; color: {MUTE}">{i + 1} of {len(QS)}</span></div></div>')

def qbody(q, big=True):
    k, brand, t, sub, amt, v = q
    return (f'<div style="display: flex; align-items: center; gap: 12px">{tile(k, 52)}<span style="display: flex; flex-direction: column; gap: 4px"><b style="font-size: 15px">{brand}</b>'
            f'<span style="align-self: flex-start; font-size: 12.5px; font-weight: 800; color: {GREEN}; background: #E3F6EC; padding: 3px 9px; border-radius: 99px">{amt}</span></span></div>'
            f'<b style="font-size: {25 if big else 23}px; letter-spacing: -.6px; line-height: 1.18">{t}</b><span style="font-size: 15px; color: {MUTE}; font-weight: 600; line-height: 1.45">{sub}</span>')

def phone(inner, cls='', dx=None, note=''):
    st = f'--dx: {dx};' if dx is not None else '--dx: 0;'
    lab = f'<span style="font-size: 13px; font-weight: 800; letter-spacing: 1px; color: {MUTE}; text-align: center">{note}</span>' if note else ''
    return (f'<div style="display: flex; flex-direction: column; gap: 12px; align-items: center">'
            f'<div class="qf {cls}" style="{st} width: 390px; height: 844px; flex: none; background: #F3F6F4; border-radius: 46px; overflow: hidden; position: relative; display: flex; flex-direction: column; box-shadow: 0 0 0 10px #1C2420, 0 30px 60px rgba(10,15,13,.25); touch-action: none; user-select: none">{inner}</div>{lab}</div>')

DONE = (f'<div class="qdone" style="display: none; flex: 1; flex-direction: column; align-items: center; justify-content: center; gap: 12px; padding: 24px; text-align: center">'
        f'<span style="font-size: 13px; font-weight: 800; letter-spacing: 1.2px; color: {GREEN}">YOU COULD GET</span><b class="estBig" style="font-size: 56px; letter-spacing: -2px; color: {GREEN}">$0</b>'
        f'<span class="estN" style="font-size: 15px; color: {MUTE}; font-weight: 700">0 settlements matched</span>'
        f'<span data-a="restart" style="margin-top: 14px; height: 50px; padding: 0 26px; border-radius: 99px; background: {DARK}; color: #FFFFFF; display: flex; align-items: center; font-weight: 800; cursor: pointer">Try again</span></div>')

# ---------- A: card stack with stamps ----------
def stampA():
    return (f'<span style="position: absolute; top: 22px; left: 20px; transform: rotate(-12deg); font-size: 26px; font-weight: 900; letter-spacing: 2px; color: {GREEN}; border: 4px solid {GREEN}; border-radius: 12px; padding: 2px 12px; opacity: clamp(0, calc(var(--dx) / 90), 1)">YES</span>'
            f'<span style="position: absolute; top: 22px; right: 20px; transform: rotate(12deg); font-size: 26px; font-weight: 900; letter-spacing: 2px; color: {RED}; border: 4px solid {RED}; border-radius: 12px; padding: 2px 12px; opacity: clamp(0, calc(var(--dx) / -90), 1)">NO</span>')
def A(i=0, play=True, dx=None):
    views = ''
    for n, q in enumerate(QS if play else [QS[i]]):
        tilt = '' if not play else ''
        card = (f'<div class="swipe" style="position: absolute; inset: 0; background: #FFFFFF; border-radius: 28px; padding: 74px 22px 24px; display: flex; flex-direction: column; gap: 14px; box-shadow: 0 18px 40px rgba(10,15,13,.12), inset 0 0 0 1px {LINE}; cursor: grab;'
                f' transform: translateX(calc(var(--dx) * 1px)) rotate(calc(var(--dx) * .06deg)); {"animation: wiggle 1.6s ease-in-out .9s 1 both;" if play and n == 0 else ""}">{stampA()}{qbody(q)}</div>')
        stack = (f'<div style="position: relative; height: 430px; margin: 0 18px">'
                 f'<div style="position: absolute; inset: 0; transform: translateY(24px) scale(.9); background: #FFFFFF; border-radius: 28px; box-shadow: inset 0 0 0 1px {LINE}; opacity: .55"></div>'
                 f'<div style="position: absolute; inset: 0; transform: translateY(12px) scale(.95); background: #FFFFFF; border-radius: 28px; box-shadow: inset 0 0 0 1px {LINE}; opacity: .85"></div>{card}</div>')
        btns = (f'<div style="display: flex; align-items: center; justify-content: center; gap: 30px; margin-top: 38px">'
                f'<span data-a="no" style="width: 74px; height: 74px; border-radius: 99px; background: #FFFFFF; box-shadow: 0 10px 24px rgba(10,15,13,.12), inset 0 0 0 1.5px {LINE}; display: flex; align-items: center; justify-content: center; cursor: pointer; transform: scale(calc(1 + clamp(0, var(--dx) / -900, .12)))">{ic("x", 32, RED, 3)}</span>'
                f'<span data-a="yes" style="width: 74px; height: 74px; border-radius: 99px; background: {MINT}; box-shadow: 0 10px 24px rgba(61,220,151,.4); display: flex; align-items: center; justify-content: center; cursor: pointer; transform: scale(calc(1 + clamp(0, var(--dx) / 900, .12)))">{ic("check", 34, DARK, 3)}</span></div>'
                f'<div style="display: flex; justify-content: center; gap: 48px; margin-top: 10px; font-size: 13px; font-weight: 800; color: {MUTE}"><span>No</span><span>Yes</span></div>')
        hint = (f'<div style="display: flex; align-items: center; justify-content: center; gap: 8px; margin-top: 18px; font-size: 13.5px; font-weight: 700; color: {MUTE}">'
                f'{ic("left", 16, RED, 2.6)}<span>Swipe the card or tap a button</span>{ic("right", 16, GREEN, 2.6)}</div>')
        views += f'<div class="qv" data-k="{q[0]}" data-v="{q[5]}" style="display: {"flex" if n == 0 else "none"}; flex-direction: column; padding-top: 26px">{stack}{btns}{hint}</div>'
    return phone(topbar(i) + f'<div style="flex: 1; display: flex; flex-direction: column">{views}{DONE if play else ""}</div>', 'play' if play else '', dx,
                 'TRY IT: DRAG THE CARD' if play else ('DRAGGING RIGHT' if dx and dx > 0 else 'DRAGGING LEFT'))

# ---------- B: glowing edges + one-time coach ----------
def edges():
    return (f'<div style="position: absolute; left: 0; top: 0; bottom: 0; z-index: 2; width: calc(54px + clamp(0px, var(--dx) * -1.4px, 110px)); background: linear-gradient(90deg, rgba(210,59,67,calc(.12 + clamp(0, var(--dx) / -120, .5))), rgba(210,59,67,0)); display: flex; align-items: center; padding-left: 8px; pointer-events: none">'
            f'<span style="display: flex; flex-direction: column; align-items: center; gap: 4px; color: {RED}; font-size: 12px; font-weight: 900; letter-spacing: 1px; animation: nudgeL 1.8s ease-in-out infinite">{ic("left", 22, RED, 3)}NO</span></div>'
            f'<div style="position: absolute; right: 0; top: 0; bottom: 0; z-index: 2; width: calc(54px + clamp(0px, var(--dx) * 1.4px, 110px)); background: linear-gradient(270deg, rgba(61,220,151,calc(.18 + clamp(0, var(--dx) / 120, .6))), rgba(61,220,151,0)); display: flex; align-items: center; justify-content: flex-end; padding-right: 8px; pointer-events: none">'
            f'<span style="display: flex; flex-direction: column; align-items: center; gap: 4px; color: {GREEN}; font-size: 12px; font-weight: 900; letter-spacing: 1px; animation: nudgeR 1.8s ease-in-out infinite">{ic("right", 22, GREEN, 3)}YES</span></div>')
def coach():
    return (f'<div class="coach" data-a="coach" style="position: absolute; inset: 0; background: rgba(10,15,13,.88); display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 18px; color: #FFFFFF; text-align: center; padding: 30px; cursor: pointer; z-index: 5">'
            f'<div style="position: relative; width: 220px; height: 120px"><div style="position: absolute; left: 70px; top: 10px; width: 80px; height: 100px; border-radius: 16px; background: #FFFFFF; box-shadow: 0 0 0 3px rgba(61,220,151,.6); animation: coachCard 2.2s ease-in-out infinite"></div>'
            f'<div style="position: absolute; left: 96px; top: 64px; animation: coachHand 2.2s ease-in-out infinite">{ic("pointer", 44, "#FFFFFF", 2)}</div></div>'
            f'<b style="font-size: 24px; letter-spacing: -.5px">Swipe to answer</b>'
            f'<span style="display: flex; gap: 22px; font-size: 15px; font-weight: 800"><span style="display: flex; align-items: center; gap: 6px; color: #FF9EA3">{ic("left", 18, "#FF9EA3", 3)}No</span><span style="display: flex; align-items: center; gap: 6px; color: {MINT}">Yes{ic("right", 18, MINT, 3)}</span></span>'
            f'<span style="margin-top: 8px; height: 50px; padding: 0 30px; border-radius: 99px; background: {MINT}; color: {DARK}; display: flex; align-items: center; font-weight: 800; font-size: 16px">Got it</span></div>')
def B(i=0, play=True, dx=None, show_coach=False):
    views = ''
    for n, q in enumerate(QS if play else [QS[i]]):
        card = (f'<div class="swipe" style="margin: 0 62px; background: #FFFFFF; border-radius: 28px; padding: 26px 20px; display: flex; flex-direction: column; gap: 14px; cursor: grab; min-height: 380px;'
                f' box-shadow: 0 18px 40px rgba(10,15,13,.12), inset 0 0 0 1px {LINE}; transform: translateX(calc(var(--dx) * 1px)) rotate(calc(var(--dx) * .05deg))">{qbody(q, False)}</div>')
        foot = (f'<div style="display: flex; gap: 10px; margin: 26px 18px 0">'
                f'<span data-a="no" style="flex: 1; height: 54px; border-radius: 16px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; align-items: center; justify-content: center; gap: 8px; font-weight: 800; font-size: 16px; cursor: pointer">{ic("x", 18, RED, 2.8)}No</span>'
                f'<span data-a="yes" style="flex: 1; height: 54px; border-radius: 16px; background: {MINT}; color: {DARK}; display: flex; align-items: center; justify-content: center; gap: 8px; font-weight: 800; font-size: 16px; cursor: pointer">{ic("check", 18, DARK, 3)}Yes</span></div>')
        views += f'<div class="qv" data-k="{q[0]}" data-v="{q[5]}" style="display: {"flex" if n == 0 else "none"}; flex-direction: column; justify-content: center; flex: 1">{card}{foot}</div>'
    body = f'<div style="flex: 1; display: flex; flex-direction: column; position: relative">{edges()}{views}{DONE if play else ""}</div>'
    return phone(topbar(i) + body + (coach() if (play or show_coach) else ''), 'play' if play else '', dx,
                 'TRY IT: COACH SHOWS ONCE, THEN DRAG' if play else ('FIRST VISIT: COACH' if show_coach else ('DRAGGING RIGHT' if dx and dx > 0 else 'DRAGGING LEFT')))

# ---------- C: slide control ----------
def track():
    return (f'<div class="track" style="position: relative; height: 72px; margin: 0 18px; border-radius: 99px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}, 0 10px 24px rgba(10,15,13,.08); display: flex; align-items: center; justify-content: space-between; padding: 0 24px; overflow: hidden">'
            f'<i style="position: absolute; left: 0; top: 0; bottom: 0; width: 50%; background: rgba(210,59,67,clamp(0, var(--dx) / -400, .22))"></i><i style="position: absolute; right: 0; top: 0; bottom: 0; width: 50%; background: rgba(61,220,151,clamp(0, var(--dx) / 300, .35))"></i>'
            f'<span data-a="no" style="position: relative; display: flex; align-items: center; gap: 4px; color: {RED}; font-weight: 900; font-size: 16px; cursor: pointer">{ic("left", 18, RED, 3)}<span style="animation: nudgeL 1.8s ease-in-out infinite; display: flex">{ic("left", 18, RED, 3)}</span>No</span>'
            f'<span data-a="yes" style="position: relative; display: flex; align-items: center; gap: 4px; color: {GREEN}; font-weight: 900; font-size: 16px; cursor: pointer">Yes<span style="animation: nudgeR 1.8s ease-in-out infinite; display: flex">{ic("right", 18, GREEN, 3)}</span>{ic("right", 18, GREEN, 3)}</span>'
            f'<span class="thumb" style="position: absolute; left: calc(50% - 30px); top: 6px; width: 60px; height: 60px; border-radius: 99px; background: {DARK}; display: flex; align-items: center; justify-content: center; gap: 0; cursor: grab;'
            f' transform: translateX(clamp(-120px, calc(var(--dx) * 1px), 120px)); box-shadow: 0 6px 16px rgba(15,59,46,.35)">{ic("left", 16, "#FFFFFF", 3)}{ic("right", 16, "#FFFFFF", 3)}</span></div>')
def C(i=0, play=True, dx=None):
    views = ''
    for n, q in enumerate(QS if play else [QS[i]]):
        card = (f'<div class="swipe" style="margin: 0 18px; background: #FFFFFF; border-radius: 28px; padding: 26px 22px; display: flex; flex-direction: column; gap: 14px; min-height: 360px; cursor: grab; position: relative;'
                f' box-shadow: 0 18px 40px rgba(10,15,13,.12), inset 0 0 0 1px {LINE}; transform: translateX(calc(var(--dx) * .5px)) rotate(calc(var(--dx) * .03deg))">'
                f'<span style="position: absolute; inset: 0; border-radius: 28px; box-shadow: inset 0 0 0 3px rgba(61,220,151,clamp(0, var(--dx) / 80, 1)), inset 0 0 0 0 transparent; pointer-events: none"></span>'
                f'<span style="position: absolute; inset: 0; border-radius: 28px; box-shadow: inset 0 0 0 3px rgba(210,59,67,clamp(0, var(--dx) / -80, 1)); pointer-events: none"></span>{qbody(q)}</div>')
        views += (f'<div class="qv" data-k="{q[0]}" data-v="{q[5]}" style="display: {"flex" if n == 0 else "none"}; flex-direction: column; justify-content: center; flex: 1; gap: 26px">{card}{track()}'
                  f'<span style="text-align: center; font-size: 13.5px; font-weight: 700; color: {MUTE}">Slide the button, swipe the card or tap a side</span></div>')
    return phone(topbar(i) + f'<div style="flex: 1; display: flex; flex-direction: column">{views}{DONE if play else ""}</div>', 'play' if play else '', dx,
                 'TRY IT: SLIDE OR DRAG' if play else ('SLIDING RIGHT' if dx and dx > 0 else 'SLIDING LEFT'))

CSS = """<style>
@keyframes wiggle { 0%,100% { --dx: 0; transform: translateX(0) rotate(0) } 25% { transform: translateX(46px) rotate(3deg) } 60% { transform: translateX(-46px) rotate(-3deg) } }
@keyframes nudgeL { 0%,100% { transform: translateX(0) } 50% { transform: translateX(-5px) } }
@keyframes nudgeR { 0%,100% { transform: translateX(0) } 50% { transform: translateX(5px) } }
@keyframes coachCard { 0%,15% { transform: translateX(0) rotate(0) } 45% { transform: translateX(70px) rotate(10deg); opacity: 1 } 55% { opacity: 0 } 60% { transform: translateX(0); opacity: 0 } 75%,100% { opacity: 1 } }
@keyframes coachHand { 0%,15% { transform: translateX(0) } 45% { transform: translateX(70px) } 60%,100% { transform: translateX(0) } }
@media (prefers-reduced-motion: reduce) { * { animation: none !important } }
</style>"""

PLAY = r"""
  componentDidMount() {
    const roots = [document]; document.querySelectorAll('*').forEach((el) => { if (el.shadowRoot) roots.push(el.shadowRoot); });
    roots.forEach((root) => root.querySelectorAll('.qf.play').forEach((f) => { if (!f._p) { f._p = 1; this.wire(f); } }));
  }
  wire(f) {
    const views = [...f.querySelectorAll('.qv')], N = views.length; let i = 0, yes = {};
    const money = (n) => '$' + n.toLocaleString('en-US');
    const setDx = (v) => f.style.setProperty('--dx', v);
    const paint = () => {
      const tot = views.filter((v) => yes[v.dataset.k]).reduce((t, v) => t + Number(v.dataset.v), 0);
      f.querySelectorAll('.tot,.estBig').forEach((e) => { e.textContent = money(tot); });
      f.querySelectorAll('.estN').forEach((e) => { const k = Object.keys(yes).length; e.textContent = k + (k === 1 ? ' settlement' : ' settlements') + ' matched'; });
      f.querySelectorAll('.pb').forEach((p, k) => { p.style.background = k <= i ? '#12805C' : '#E3EAE6'; });
      f.querySelectorAll('.pbN').forEach((e) => { e.textContent = Math.min(i + 1, N) + ' of ' + N; });
    };
    const answer = (y) => {
      const v = views[i]; if (!v) return; if (y) yes[v.dataset.k] = true;
      const c = v.querySelector('.swipe'); f.style.transition = 'none';
      let t = 0; const to = y ? 460 : -460, st = parseFloat(getComputedStyle(f).getPropertyValue('--dx')) || 0;
      const step = () => { t += 1; setDx(st + (to - st) * Math.min(1, t / 10)); if (t < 10) requestAnimationFrame(step); else { v.style.display = 'none'; i += 1; setDx(0); if (views[i]) views[i].style.display = 'flex'; else { const d = f.querySelector('.qdone'); if (d) d.style.display = 'flex'; } paint(); } };
      requestAnimationFrame(step);
    };
    f.addEventListener('click', (e) => {
      const b = e.target.closest('[data-a]'); if (!b) return; const a = b.dataset.a;
      if (a === 'coach') { b.remove(); return; }
      if (a === 'restart') { i = 0; yes = {}; views.forEach((v, k) => { v.style.display = k ? 'none' : 'flex'; }); f.querySelector('.qdone').style.display = 'none'; setDx(0); paint(); return; }
      if (a === 'yes' || a === 'no') answer(a === 'yes');
    });
    let x0 = null, dx = 0;
    f.addEventListener('pointerdown', (e) => {
      if (!e.target.closest('.swipe,.thumb')) return; const cn = e.target.closest('.swipe'); if (cn) cn.style.animation = 'none';
      x0 = e.clientX; dx = 0; f.setPointerCapture(e.pointerId);
    });
    f.addEventListener('pointermove', (e) => { if (x0 === null) return; dx = e.clientX - x0; setDx(dx); });
    const up = () => {
      if (x0 === null) return; x0 = null;
      if (Math.abs(dx) > 90) { answer(dx > 0); return; }
      let t = 0; const st = dx; const back = () => { t += 1; setDx(st * (1 - t / 8)); if (t < 8) requestAnimationFrame(back); }; requestAnimationFrame(back);
    };
    f.addEventListener('pointerup', up); f.addEventListener('pointercancel', up);
    paint();
  }
"""

BOARDS = [
    ('SwipeA', 'Swipe questions · A · Card stack', 'The question sits on the top card of a small stack, so it looks like something you can throw. The first card wiggles left and right once when the page opens. Dragging shows a big YES or NO stamp on the card, and the round buttons grow on the side you are heading to.', A),
    ('SwipeB', 'Swipe questions · B · Glowing edges', 'Both screen edges stay tinted with arrows, red NO on the left and green YES on the right, and the side you drag toward lights up. On the first question only, a short "Swipe to answer" coach plays a hand dragging a card, then goes away for good.', B),
    ('SwipeC', 'Swipe questions · C · Slide control', 'A slide-to-answer control under the card, like slide to unlock: drag the dark button toward No or Yes, or swipe the card itself. Arrows on each side nudge outward, and the card outline turns green or red as you go.', C),
]

def build():
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    if not any(pg['id'] == 'swp' for pg in c['pages']): c['pages'].append({'id': 'swp', 'name': 'Swipe questions'})
    for k, (name, title, note, fn) in enumerate(BOARDS):
        frames = fn(0, True) + (fn(1, False, 70) if fn is not B else fn(0, False, None, True)) + (fn(1, False, -70) if fn is not B else fn(1, False, 70))
        if fn is B: frames += fn(2, False, -70)
        W = 40 + (4 if fn is B else 3) * 470
        page = (f'<div style="width: {W}px; height: 1100px; box-sizing: border-box; padding: 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: {INK}; display: flex; flex-direction: column; gap: 30px">{CSS}'
                f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: {GREEN}">{title.upper()}</span>'
                f'<span style="font-size: 16px; color: #43504A; font-weight: 600; max-width: {W - 120}px; line-height: 1.45">{note}</span></div>'
                f'<div style="display: flex; gap: 70px; align-items: flex-start; padding: 0 10px">{frames}</div></div>\n</x-dc>\n')
        js = ('<script type="text/x-dc" data-dc-script data-props=\'{"$preview":{"width":%d,"height":1100}}\'>\nclass Component extends DCLogic { renderVals() { return {}; }' % W) + PLAY + '}\n</script>\n</body>\n</html>\n'
        open(os.path.join(OUT, name + '.dc.html'), 'w').write(HEAD % title + page + js)
        c['boards'][name + '.dc.html'] = {'x': k * 2100, 'y': 0, 'w': W, 'h': 1100, 'is_interactive': True, 'title': title, 'page': 'swp'}
        if name + '.dc.html' not in c['order']: c['order'].append(name + '.dc.html')
    c['notes']['tSwp'] = {'x': 0, 'y': -300, 'page': 'swp', 'text': 'Swipe questions on phones · 3 directions (drag the first phone on each board)', 'kind': 'title1', 'maxW': 6000, 'w': 240}
    if 'tSwp' not in c['noteOrder']: c['noteOrder'].append('tSwp')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w'))
    print('ok')

if __name__ == '__main__':
    build()
