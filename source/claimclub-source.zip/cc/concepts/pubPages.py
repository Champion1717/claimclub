# Public pages LIVE (Nov 22 2026): /settlements (directory), /settlements/<id> (design A), /how-it-works, /about.
# Built from the canvas generators (setD.py, aboutD.py) with their helpers patched to output real links instead of
# mock spans and plain page wrappers instead of the browser and phone frames. Called by site/build.py: build(OUT, head).
# SetA, HowP and AboutP render a desktop block (.dk) and a phone block (.mb); the directory is one responsive block.
import os, re, json, html, shutil, datetime, base64
import setD, aboutD, artIcons
from setD import INK, MUTE, LINE, MINT, GREEN, DARK, BG, CAT, SPEC, ic

SITE = 'https://www.claimclub.io'
TODAY = datetime.date.today()
setD.TODAY = TODAY
NAT = [s for s in setD.SETS if not s.get('st') and s['id'] not in setD.CLOSED and s['cat'] != 'arb' and (s.get('dl') or '9') >= TODAY.isoformat() and s.get('dl')]
NAT.sort(key=lambda s: (setD.TOP.index(s['id']) if s['id'] in setD.TOP else 999, s.get('dl') or '9'))
setD.NAT[:] = NAT; aboutD.NAT[:] = NAT
NAT_IDS = [s['id'] for s in NAT]
TILES = os.path.join(setD.CC, 'tiles')
CUR = {'id': None}

def tile(i, sz=44):
    r = f'{sz * .26:.0f}px'
    if os.path.exists(os.path.join(TILES, i + '.svg')):
        return f'<img src="/tiles/{i}.svg" alt="" width="{sz}" height="{sz}" loading="lazy" style="width: {sz}px; height: {sz}px; flex: none; border-radius: {r}">'
    return f'<span style="width: {sz}px; height: {sz}px; flex: none; border-radius: {r}; background: #E3F6EC; color: {GREEN}; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: {sz * .42:.0f}px">{setD.BY[i]["co"][0]}</span>'
setD.tile = aboutD.tile = tile

_btn = setD.btn
def btn(t, kind='mint', h=52, full=False, icon=None):
    out = _btn(t, kind, h, full, icon)
    href = {'Get started': '/claim', 'Check what I qualify for': '/claim', 'See open settlements': '/settlements',
            'Check if I qualify': f'/claim/{CUR["id"]}' if CUR['id'] else '/claim'}.get(t)
    if href and out.startswith('<span ') and out.endswith('</span>'):
        out = f'<a href="{href}" ' + out[6:-7].replace('style="', 'style="text-decoration: none; ', 1) + '</a>'
    return out
setD.btn = aboutD.btn = btn

LOGO = lambda fg, dot, sz=20: f'<a href="/" aria-label="Claimclub home" style="text-decoration: none"><b style="font-size: {sz}px; letter-spacing: -.5px; color: {fg}">claimclub<span style="color: {dot}">.io</span></b></a>'
def nav(m=False, dark=False, on='Settlements'):
    fg = '#FFFFFF' if dark else INK
    logo = LOGO(fg, MINT if dark else GREEN, 18 if m else 20)
    links = [('Settlements', '/settlements'), ('How it works', '/how-it-works'), ('About', '/about')]
    if m:
        menu = (f'<details class="mnav"><summary aria-label="Menu" style="list-style: none; cursor: pointer; display: flex">{ic("menu", 24, fg, 2.2)}</summary>'
                f'<div class="mnavp">' + ''.join(f'<a href="{u}">{t}</a>' for t, u in links) + '<a href="/login">Log in</a></div></details>')
        return (f'<div style="height: 60px; flex: none; display: flex; align-items: center; gap: 10px; padding: 0 16px; position: relative; z-index: 20; {"" if dark else "background: #FFFFFF; border-bottom: 1px solid " + LINE}">{logo}'
                f'<span style="margin-left: auto">{btn("Get started", "mint", 38)}</span>{menu}</div>')
    l = lambda t, u, here=False: f'<a href="{u}" class="nl{" on" if here else ""}" style="--ul: {MINT if dark else GREEN}; text-decoration: none; font-size: 15px; font-weight: 700; color: {fg}">{t}</a>'
    return (f'<div style="height: 72px; flex: none; display: flex; align-items: center; gap: 30px; padding: 0 48px; {"" if dark else "background: #FFFFFF; border-bottom: 1px solid " + LINE}">{logo}'
            f'<nav style="display: flex; gap: 28px; margin-left: 24px">' + ''.join(l(t, u, on == t) for t, u in links) + '</nav>'
            f'<span style="margin-left: auto; display: flex; align-items: center; gap: 22px">{l("Log in", "/login")}{btn("Get started", "mint", 44)}</span></div>')
setD.nav = aboutD.nav = nav

def foot(m=False):
    L = [('Settlements', '/settlements'), ('How it works', '/how-it-works'), ('About', '/about'), ('Terms', '/terms'), ('Privacy', '/privacy'), ('Security', '/security'), ('support@mail.claimclub.io', 'mailto:support@mail.claimclub.io')]
    return (f'<div style="background: {DARK}; color: #B9D3C7; padding: {"28px 16px" if m else "36px 48px"}; display: flex; flex-direction: column; gap: 10px; font-size: 13px; line-height: 1.5; font-weight: 600">'
            f'{LOGO("#FFFFFF", MINT, 17)}'
            '<span>Claimclub is not a law firm and is not part of any settlement or its administrator. You can always file for free on the official settlement site. Payout amounts are estimates, not guaranteed.</span>'
            '<span style="display: flex; flex-wrap: wrap; gap: 6px 16px">' + ''.join(f'<a href="{u}" style="color: #FFFFFF; opacity: .85; text-decoration: none">{t}</a>' for t, u in L) + '</span></div>')
setD.foot = aboutD.foot = foot

setD.desk = aboutD.desk = lambda body, h, top=None: f'<div class="dk">{body}</div>'
setD.phone = aboutD.phone = lambda body, h: f'<div class="mb">{body}</div>'

_card = setD.card
def card(s, m=False):
    out = _card(s, m)
    out = re.sub(r'(\d+) days left</span>', lambda mo: f'<span data-left="{s.get("dl") or ""}">{mo.group(1)} days left</span></span>', out)
    q = html.escape((s['co'] + ' ' + s['title'] + ' ' + s.get('who', '')).lower(), quote=True)
    return (f'<a href="/settlements/{s["id"]}" class="scard" data-cat="{s["cat"]}" data-proof="{1 if s.get("proof") == "No proof" else 0}" data-dl="{s.get("dl") or ""}" data-q="{q}" '
            + out[5:].replace('style="', 'style="text-decoration: none; color: inherit; ', 1)[:-6] + '</a>')
setD.card = card

_qcard = setD.qcard
def qcard(s, m=False, dark=False, tight=False, fancy=False):
    out = _qcard(s, m, dark, tight, fancy)
    def a(mo):
        href = f'/claim/{s["id"]}' if mo.group(3) == 'Yes' else '/settlements'
        return f'<a href="{href}" style="text-decoration: none; color: inherit; {mo.group(1)[7:-1]}">{mo.group(2)}{mo.group(3)}</a>'
    return re.sub(r'<span (style="flex: 1; height: 54px[^"]*")>(.*?)(No|Yes)</span>', a, out)
setD.qcard = qcard

_how = setD.how_file
def how_file(s, m=False, fancy=False):
    out = _how(s, m, fancy)
    url = SPEC.get(s['id'], {}).get('form_url') or ''
    out = out.replace('margin-top: auto">Check if I qualify</span>', f'margin-top: auto"><a href="/claim/{s["id"]}" style="color: inherit">Check if I qualify</a></span>')
    if url:
        out = re.sub(r'margin-top: auto">(Official site[^<]*)</span>', lambda mo: f'margin-top: auto"><a href="{html.escape(url)}" target="_blank" rel="noopener nofollow" style="color: inherit">{mo.group(1)}</a></span>', out)
    return out
setD.how_file = how_file

def _faq_html(qs, m, big=False):
    return ''.join(f'<details class="fq"{" open" if i == 0 else ""}><summary><b style="font-size: {(16 if m else 18) if big else (15 if m else 16)}px; flex: 1">{q}</b>{ic("down", 18, MUTE, 2.2)}</summary>'
                   f'<span style="display: block; font-size: {15.5 if big else 14.5}px; color: #43504A; font-weight: 600; line-height: 1.55; max-width: 760px; padding-top: 6px">{a}</span></details>' for i, (q, a) in enumerate(qs))
def faq(s, m=False):
    qs = [(f'Is the {s["co"]} settlement real?', 'Yes. It was approved by a court and is run by a settlement administrator. Claimclub is not part of the case.'),
          ('Do I need proof?', 'No proof is needed. You confirm under oath that you qualify.' if s.get('proof') == 'No proof' else 'Yes. Keep receipts or account records that show you qualify.'),
          ('When will I get paid?', 'After the deadline and any appeals, usually 6 to 12 months. The settlement pays you directly.')]
    return _faq_html(qs, m)
setD.faq = faq
def faqs(qs, m=False):
    return f'<div style="display: flex; flex-direction: column; gap: 14px">{aboutD.h2("Questions people ask", m)}<div style="display: flex; flex-direction: column">{_faq_html(qs, m, True)}</div></div>'
aboutD.faqs = faqs

def crumbs(s, dark=False):
    c = '#B9D3C7' if dark else MUTE
    return (f'<nav aria-label="Breadcrumb" style="font-size: 13.5px; font-weight: 700; color: {c}"><a href="/settlements" style="color: inherit; text-decoration: none">Settlements</a>  ›  '
            f'<a href="/settlements?cat={s["cat"]}" style="color: inherit; text-decoration: none">{CAT[s["cat"]]}</a>  ›  <span style="color: {"#FFFFFF" if dark else INK}">{s["co"]}</span></nav>')
setD.crumbs = crumbs
_back = setD.back_btn
setD.back_btn = lambda m=False: '<a href="/settlements" ' + _back(m)[6:-7].replace('style="', 'style="text-decoration: none; ', 1) + '</a>'
_rel = setD.related
setD.related = lambda s, m=False, n=3: _rel(s, m, n).replace(f'<b style="font-size: 14px; color: {GREEN}">See all</b>', f'<a href="/settlements?cat={s["cat"]}" style="font-size: 14px; font-weight: 800; color: {GREEN}; text-decoration: none">See all</a>')

# How it works: honest cost section (no plan names; the offer test decides the price shown in the flow).
def plans(m=False):
    P = [('check', 'Free to check', 'Answer a few questions and see what you could get. No account or card needed.'),
         ('hundred', 'You keep 100%', 'Membership is a flat price, shown before you pay. We never take a cut of a payout.'),
         ('cancel', 'Cancel anytime', 'One tap in your account. Claims we already filed stay filed.')]
    cards = ''.join(f'<div style="flex: 1; border-radius: 20px; padding: 22px; display: flex; flex-direction: column; gap: 10px; background: #FFFFFF; box-shadow: inset 0 0 0 1px {LINE}">{artIcons.art(k, 52)}'
                    f'<b style="font-size: 18px">{t}</b><span style="font-size: 14.5px; font-weight: 600; color: #43504A; line-height: 1.5">{b}</span></div>' for k, t, b in P)
    return (f'<div style="display: flex; flex-direction: column; gap: 18px">{aboutD.kick("WHAT IT COSTS")}{aboutD.h2("Checking is free. Every payout is yours.", m)}'
            f'<div style="display: flex; gap: 14px; {"flex-direction: column" if m else ""}">{cards}</div></div>')
aboutD.plans = lambda m=False: ''  # the cost cards repeated 'Your money stays yours'; prices live in the claim flow

def fix_desktop(h):
    # side padding grows on wide screens so content keeps a 1184px column while backgrounds run full width
    return re.sub(r'padding: (\d+px) 48px(?=[ ;"])', r'padding: \1 var(--gx)', h).replace('padding: 0 48px;', 'padding: 0 var(--gx);')

DL_JS = ('<script>(function(){var t=new Date();t.setHours(0,0,0,0);document.querySelectorAll("[data-left]").forEach(function(e){var d=new Date(e.getAttribute("data-left")+"T00:00:00");'
         'var n=Math.round((d-t)/864e5);e.textContent=n>1?n+" days left":n===1?"1 day left":n===0?"Closes today":"Closed"})})()</script>')

def page_a(s):
    CUR['id'] = s['id']
    d = setD.days(s)
    dk = setD.setA_d(s); mb = setD.setA_m(s)
    dk = fix_desktop(dk).replace('width: 340px; flex: none; display: flex; flex-direction: column; gap: 14px', 'width: 340px; flex: none; display: flex; flex-direction: column; gap: 14px; position: sticky; top: 24px')
    mb = mb.replace('<div style="flex: 1; overflow: hidden; position: relative">', '<div>')
    mb = mb.replace('<div style="position: sticky; bottom: 0;', '<div style="position: sticky; bottom: 0; z-index: 10;') + ''
    mb = mb[:-6] + foot(True) + '</div>'
    for x in (d,):
        dk = dk.replace(f'{x} days left</span>', f'<span data-left="{s["dl"]}">{x} days left</span></span>')
        mb = mb.replace(f'{x} days left</span>', f'<span data-left="{s["dl"]}">{x} days left</span></span>')
    CUR['id'] = None
    return dk + mb

def page_how():
    fix = lambda h: (h.replace('You check and pick a plan', 'You check and join').replace('Within 24 hours to 30 days', 'Soon after you join')
                     .replace('Filing faster gets your claim in early, but no plan makes a settlement pay sooner. Here is the usual path.', 'We file soon after you join, but the court and the settlement decide when money goes out. Here is the usual path.'))
    dk = fix_desktop(fix(aboutD.how_d()))
    mb = fix(aboutD.how_m())
    extra = f'<div style="padding: 0 16px 40px; display: flex; flex-direction: column; gap: 48px">{aboutD.promises(True)}{faqs(aboutD.HOWQ, True)}{aboutD.cta_band(True)}</div>'
    mb = mb[:-6] + extra + foot(True) + '</div>'
    return dk + mb

def page_about():
    fix = lambda h: h.replace(' Some arbitration claims are handled by independent partner law firms, and we always tell you before a referral.', '')
    dk = fix_desktop(fix(aboutD.about_d()))
    mb = fix(aboutD.about_m())
    mb = mb[:-6] + foot(True) + '</div>'
    return dk + mb

def page_dir():
    cats = [k for k in ('apps', 'bank', 'privacy', 'products', 'auto', 'invest', 'health') if any(s['cat'] == k for s in NAT)]
    chips = [('all', 'All'), ('noproof', 'No proof needed'), ('soon', 'Closing soon')] + [('c:' + k, CAT[k]) for k in cats]
    chiprow = ''.join(f'<button type="button" class="chip{" on" if i == 0 else ""}" data-f="{k}">{t} <span class="n"></span></button>' for i, (k, t) in enumerate(chips))
    hero = (f'<div class="dhero"><span style="font-size: 12.5px; font-weight: 800; letter-spacing: 1.2px; color: {GREEN}">UPDATED {TODAY.strftime("%b").upper()} {TODAY.day}, {TODAY.year}</span>'
            f'<h1>Open class action settlements</h1>'
            f'<p>{len(NAT)} nationwide settlements you can claim right now. See who qualifies, how much each one pays and when it closes.</p>'
            f'<div class="srow"><label class="search">{ic("search", 19, MUTE, 2.3)}<input id="q" type="search" placeholder="Search a company, like Apple or Visa" aria-label="Search settlements"></label>{btn("Check what I qualify for", "mint", 58)}</div>'
            f'<div class="chips" role="group" aria-label="Filter settlements">{chiprow}</div></div>')
    grid = f'<div class="dgrid" id="grid">{"".join(card(s) for s in NAT)}</div><div class="empty" id="empty" hidden>No open settlements match that search.</div><div class="pager" id="pager"></div>'
    js = r'''<script>(function(){var g=document.getElementById('grid'),cs=[].slice.call(g.children),q=document.getElementById('q'),pg=document.getElementById('pager'),em=document.getElementById('empty'),f='all',page=1,PER=12;
var t=new Date();t.setHours(0,0,0,0);var soon=function(c){var d=c.getAttribute('data-dl');if(!d)return false;var n=(new Date(d+'T00:00:00')-t)/864e5;return n>=0&&n<=21};
var ok=function(c,k){if(k==='noproof')return c.getAttribute('data-proof')==='1';if(k==='soon')return soon(c);if(k.indexOf('c:')===0)return c.getAttribute('data-cat')===k.slice(2);return true};
document.querySelectorAll('.chip').forEach(function(b){var k=b.getAttribute('data-f');b.querySelector('.n').textContent=cs.filter(function(c){return ok(c,k)}).length;b.onclick=function(){f=k;page=1;document.querySelectorAll('.chip').forEach(function(x){x.classList.toggle('on',x===b)});draw(true)}});
function draw(scroll){var s=(q.value||'').toLowerCase().trim(),m=cs.filter(function(c){return ok(c,f)&&(!s||c.getAttribute('data-q').indexOf(s)>-1)}),n=Math.max(1,Math.ceil(m.length/PER));if(page>n)page=n;
cs.forEach(function(c){c.hidden=true});m.slice((page-1)*PER,page*PER).forEach(function(c){c.hidden=false});em.hidden=m.length>0;
var h='';if(n>1){var ps=[];for(var i=1;i<=n;i++){if(i===1||i===n||Math.abs(i-page)<=1)ps.push(i);else if(ps[ps.length-1]!=='…')ps.push('…')}ps.forEach(function(p){h+=p==='…'?'<span class="pg gap">…</span>':'<button type="button" class="pg'+(p===page?' on':'')+'" data-p="'+p+'">'+p+'</button>'})}
pg.innerHTML=h;pg.querySelectorAll('[data-p]').forEach(function(b){b.onclick=function(){page=+b.getAttribute('data-p');draw(true)}});if(scroll){var y=g.getBoundingClientRect().top+scrollY-120;if(scrollY>y)scrollTo({top:y,behavior:'smooth'})}}
q.addEventListener('input',function(){page=1;draw()});var u=new URLSearchParams(location.search).get('cat');if(u){var b=document.querySelector('.chip[data-f="c:'+u+'"]');if(b)b.click()}draw();})()</script>'''
    return ('<div class="ddk">' + fix_desktop(nav()) + '</div><div class="dmb">' + nav(True) + '</div><div class="dwrap">' + hero + grid + '</div>'
            + '<div class="ddk">' + fix_desktop(foot()) + '</div><div class="dmb">' + foot(True) + '</div>' + js)

CSS = (f'*,*:before,*:after{{box-sizing:border-box}}html,body{{margin:0}}body{{font-family:Manrope,system-ui,sans-serif;color:{INK};background:#FFFFFF;-webkit-font-smoothing:antialiased}}'
       ':root{--gx:max(48px,calc((100vw - 1184px)/2))}a{color:inherit}h1,h2{font-family:inherit}img{max-width:100%}'
       '.nl{position:relative;opacity:.72;transition:opacity .2s ease}.nl::after{content:"";position:absolute;left:0;right:0;bottom:-6px;height:2px;border-radius:2px;background:var(--ul);transform:scaleX(0);transform-origin:left center;transition:transform .28s cubic-bezier(.2,.8,.2,1)}'
       '.nl:hover,.nl:focus-visible,.nl.on{opacity:1}.nl:hover::after,.nl:focus-visible::after,.nl.on::after{transform:scaleX(1)}@media (prefers-reduced-motion:reduce){.nl::after{transition:none}}'
       '.mb{display:none}@media (max-width:819px){.dk{display:none}.mb{display:block}}'
       '.mb [style*="width: 300px"]{max-width:100%}.mb [style*="grid-template-columns: repeat(2, 1fr)"]{grid-template-columns:repeat(2,minmax(0,1fr))!important}.mb b,.mb span{overflow-wrap:anywhere}'
       'details summary::-webkit-details-marker{display:none}'
       f'.fq{{border-top:1px solid {LINE};padding:16px 0}}.fq summary{{list-style:none;display:flex;align-items:center;gap:12px;cursor:pointer}}.fq[open] summary svg{{transform:rotate(180deg)}}.fq summary svg{{transition:transform .2s}}'
       '.mnav{position:relative}.mnavp{position:absolute;right:0;top:40px;background:#FFFFFF;border-radius:16px;box-shadow:0 16px 40px rgba(10,15,13,.18);padding:8px;display:flex;flex-direction:column;min-width:180px}'
       f'.mnavp a{{padding:12px 14px;font-weight:800;font-size:15px;color:{INK};text-decoration:none;border-radius:10px}}.mnavp a:hover{{background:{BG}}}'
       # directory
       f'.dwrap{{background:{BG}}}.dhero{{background:linear-gradient(180deg,#E9F6EF,{BG});padding:48px var(--gx) 26px;display:flex;flex-direction:column;gap:18px}}'
       '.dhero h1{margin:0;font-size:52px;letter-spacing:-1.6px;line-height:1.05;max-width:760px}.dhero p{margin:0;font-size:18px;color:#43504A;font-weight:600;max-width:720px;line-height:1.5}'
       '.srow{display:flex;gap:12px;max-width:900px;margin-top:6px}.search{height:58px;flex:1;border-radius:99px;background:#FFFFFF;box-shadow:0 1px 0 #E3EAE6,0 8px 24px rgba(10,15,13,.06);display:flex;align-items:center;gap:10px;padding:0 20px}'
       '.search input{border:0;outline:0;font:inherit;font-size:15.5px;font-weight:600;flex:1;min-width:0;background:transparent;color:#0A0F0D}.search input::placeholder{color:#8A968F}'
       '.chips{display:flex;flex-wrap:nowrap;gap:6px;margin-top:6px;overflow-x:auto;scrollbar-width:none;-ms-overflow-style:none}.chips::-webkit-scrollbar{display:none}'
       f'.chip{{flex:none;white-space:nowrap;font:inherit;font-size:13px;font-weight:800;padding:8px 11px;border-radius:99px;border:0;cursor:pointer;background:#FFFFFF;box-shadow:inset 0 0 0 1px {LINE};color:#2A3530}}'
       f'.chip .n{{opacity:.55}}.chip.on{{background:{DARK};color:#FFFFFF;box-shadow:none}}'
       '.dgrid{padding:10px var(--gx) 24px;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.dgrid>[hidden]{display:none!important}'
       '.empty{padding:20px var(--gx) 40px;font-weight:700;color:#5B6862}'
       '.pager{padding:4px var(--gx) 44px;display:flex;justify-content:center;gap:8px}'
       f'.pg{{width:40px;height:40px;border-radius:12px;display:flex;align-items:center;justify-content:center;font:inherit;font-weight:800;font-size:14px;border:0;cursor:pointer;background:#FFFFFF;box-shadow:inset 0 0 0 1px {LINE};color:{INK}}}'
       f'.pg.on{{background:{DARK};color:#FFFFFF;box-shadow:none}}.pg.gap{{background:none;box-shadow:none;cursor:default}}'
       '@media (max-width:1000px){.dgrid{grid-template-columns:repeat(2,minmax(0,1fr))}}'
       '@media (max-width:819px){:root{--gx:16px}.dhero{padding:22px 16px 12px;gap:12px}.dhero h1{font-size:32px;letter-spacing:-1px}.dhero p{font-size:15px}.srow{flex-direction:column}.srow a{display:none!important}.search{height:52px;flex:none}'
       '.chips{margin:0 -16px;padding:0 16px}.dgrid{grid-template-columns:minmax(0,1fr);gap:12px;padding-top:6px}.ddk{display:none}}'
       '.ddk{display:block}.dmb{display:none}@media (max-width:819px){.ddk{display:none}.dmb{display:block}}')

def wrap(title, desc, path, body, head):
    t = html.escape(title); d = html.escape(desc)
    return (f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{t}</title>'
            f'<meta name="description" content="{d}"><link rel="canonical" href="{SITE}{path}"><meta property="og:type" content="website"><meta property="og:site_name" content="Claimclub">'
            f'<meta property="og:title" content="{t}"><meta property="og:description" content="{d}"><meta property="og:url" content="{SITE}{path}"><meta property="og:image" content="{SITE}/og.png"><meta name="twitter:card" content="summary_large_image">'
            '<link rel="icon" href="/favicon-48.png" type="image/png" sizes="48x48"><link rel="icon" href="/favicon-96.png" type="image/png" sizes="96x96"><link rel="icon" href="/favicon.svg" type="image/svg+xml"><link rel="apple-touch-icon" href="/apple-touch-icon.png">'
            '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap">'
            f'<style>{CSS}</style>{head}</head><body>{body}{DL_JS}</body></html>')

def build(out, head=''):
    os.makedirs(out + '/pages/s', exist_ok=True); os.makedirs(out + '/tiles', exist_ok=True)
    for s in NAT:
        p = os.path.join(TILES, s['id'] + '.svg')
        if os.path.exists(p): shutil.copy(p, out + '/tiles/' + s['id'] + '.svg')
    body = page_dir()
    open(out + '/pages/settlements.html', 'w').write(wrap('Open class action settlements you can claim · Claimclub',
         f'{len(NAT)} open nationwide class action settlements. See who qualifies, how much each one pays and the claim deadline.', '/settlements', body, head))
    for s in NAT:
        dl = setD.dfmt(s['dl'])
        open(out + f'/pages/s/{s["id"]}.html', 'w').write(wrap(f'{s["co"]} settlement: who qualifies, payout and deadline · Claimclub',
             f'{s["who"]}. {setD.pay(s)}. Claim deadline {dl}. See if you qualify and how to file.', f'/settlements/{s["id"]}', page_a(s), head))
    open(out + '/pages/how-it-works.html', 'w').write(wrap('How Claimclub works · Claimclub', 'We find the class action settlements you qualify for, file the claims for you and follow each one until it pays. Checking is free.', '/how-it-works', page_how(), head))
    open(out + '/pages/about.html', 'w').write(wrap('About Claimclub', 'Claimclub finds class action settlements you qualify for and files the claims for you. Every payout goes straight to you.', '/about', page_about(), head))
    return [s['id'] for s in NAT]

if __name__ == '__main__':
    print(len(build('/tmp/pubtest')))
