# Builds five "Choose your plan" design iterations as canvas boards: PlanV1..PlanV5.dc.html
# Each board shows the same variant at desktop (1280x800) and mobile (390x844).
import json, os

OUT = os.path.join(os.path.dirname(__file__), '..', 'project')
G = dict(dk='#0F3B2E', gr='#12805C', mint='#3DDC97', lt='#E9F6EF', ink='#0A0F0D', mut='#5B6862', ln='#DDE5E0', bg='#F6F8F7')
MATCH, MATCHN, POT, OPEN = '$1,245', '4 settlements matched', '$53,031', 81
PLANS = [
    dict(id='1m', name='1 month', short='1 mo', first='$7.99', full='$29.99', per='$29.99', perL='/mo', every='every month', firstL='first month', save=''),
    dict(id='3m', name='3 months', short='3 mo', first='$18.99', full='$74.99', per='$24.99', perL='/mo', every='every 3 months', firstL='first 3 months', save='Save 17%'),
    dict(id='6m', name='6 months', short='6 mo', first='$29.99', full='$119.99', per='$19.99', perL='/mo', every='every 6 months', firstL='first 6 months', save='Save 33%'),
]
LOGO = '<svg width="{s}" height="{s}" viewBox="0 0 100 100" aria-hidden="true"><path fill="#0F3B2E" d="M81.4 83.6A46 46 0 0 1 51.6 96.0L51.2 83.0A33 33 0 0 0 72.5 74.1Z"></path><path fill="#0F3B2E" d="M48.4 96.0A46 46 0 0 1 18.6 83.6L27.5 74.1A33 33 0 0 0 48.8 83.0Z"></path><path fill="#0F3B2E" d="M16.4 81.4A46 46 0 0 1 4.0 51.6L17.0 51.2A33 33 0 0 0 25.9 72.5Z"></path><path fill="#0F3B2E" d="M4.0 48.4A46 46 0 0 1 16.4 18.6L25.9 27.5A33 33 0 0 0 17.0 48.8Z"></path><path fill="#0F3B2E" d="M18.6 16.4A46 46 0 0 1 48.4 4.0L48.8 17.0A33 33 0 0 0 27.5 25.9Z"></path><path fill="#3DDC97" d="M51.6 4.0A46 46 0 0 1 81.4 16.4L72.5 25.9A33 33 0 0 0 51.2 17.0Z"></path></svg>'
WORD = '<span style="font-size: {f}px; font-weight: 800; letter-spacing: -0.5px; color: #0F3B2E">claim<span style="font-weight: 500">club</span><span style="font-size: 0.72em; font-weight: 600; color: #000000; margin-left: -0.06em">.io</span></span>'

# Lucide icon paths (ISC license)
IC = {
    'check': '<path d="M20 6 9 17l-5-5"></path>',
    'back': '<path d="m15 18-6-6 6-6"></path>',
    'shield': '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path><path d="m9 12 2 2 4-4"></path>',
    'zap': '<path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"></path>',
    'bell': '<path d="M10.27 21a2 2 0 0 0 3.46 0"></path><path d="M3.26 15.33A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.67C19.41 13.96 18 12.5 18 8A6 6 0 0 0 6 8c0 4.5-1.41 5.96-2.74 7.33"></path>',
    'search': '<circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.3-4.3"></path>',
    'file': '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"></path><path d="M14 2v4a2 2 0 0 0 2 2h4"></path><path d="m9 15 2 2 4-4"></path>',
    'star': '<path d="M11.53 2.3a.53.53 0 0 1 .94 0l2.31 4.68a2.12 2.12 0 0 0 1.6 1.16l5.16.76a.53.53 0 0 1 .3.9l-3.74 3.64a2.12 2.12 0 0 0-.61 1.88l.88 5.14a.53.53 0 0 1-.77.56l-4.62-2.43a2.12 2.12 0 0 0-1.97 0L6.4 21.01a.53.53 0 0 1-.77-.56l.88-5.14a2.12 2.12 0 0 0-.61-1.88L2.16 9.8a.53.53 0 0 1 .3-.9l5.16-.76a2.12 2.12 0 0 0 1.6-1.16z"></path>',
    'x': '<path d="M18 6 6 18"></path><path d="m6 6 12 12"></path>',
    'gift': '<rect x="3" y="8" width="18" height="4" rx="1"></rect><path d="M12 8v13"></path><path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"></path><path d="M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5"></path>',
}
def ic(k, s=16, w=2.4, c='currentColor', st=''):
    fill = c if k == 'star' else 'none'
    return f'<svg width="{s}" height="{s}" viewBox="0 0 24 24" fill="{fill}" stroke="{c}" stroke-width="{w}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex: none;{st}">{IC[k]}</svg>'

FEATS = [('file', 'We file every claim for you'), ('search', f'All {OPEN} open settlements, checked for you'), ('bell', 'Alerts when new settlements match'), ('zap', 'Keep 100% of every payout')]

def stars(n=5, s=13, c='#3DDC97'):
    return '<span style="display: inline-flex; gap: 1px">' + ''.join(ic('star', s, 0, c) for _ in range(n)) + '</span>'

def cta(mobile):
    h = 54 if mobile else 56
    return (f'<button style="height: {h}px; width: 100%; border-radius: 999px; background: #3DDC97; color: #0F3B2E; font-size: 17px; font-weight: 800; box-shadow: 0 10px 24px rgba(61,220,151,.35)">Start getting paid · {{{{ firstNow }}}} today</button>'
            f'<span style="font-size: 11.5px; line-height: 1.45; color: #5B6862">{{{{ renew }}}}</span>'
            '<div style="display: flex; justify-content: center; gap: 22px; font-size: 12px; font-weight: 600; color: #43504A"><a href="#" style="color: inherit">Terms</a><a href="#" style="color: inherit">Privacy</a></div>')

# ---------------------------------------------------------------- variants
# Each variant returns (body_html, footer_html) for one viewport. Selection-dependent styles
# come from renderVals: {{ sel.<id> }} etc. Variant dicts give the style strings.

def v1(m):
    """Clean cards: matches hero, radio cards showing intro price with the regular price struck out."""
    pad = '18px' if m else '0'
    hero = (f'<div style="display: flex; flex-direction: column; align-items: center; gap: 4px; padding: {"18px 16px" if m else "18px 24px"}; border-radius: 22px; background: linear-gradient(180deg,#E9F6EF 0%,#FFFFFF 100%); box-shadow: inset 0 0 0 1px #D3EBDD">'
            f'<span style="display: flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 800; letter-spacing: 1.2px; color: #12805C">{ic("check", 14, 3)}YOUR MATCHES SO FAR</span>'
            f'<span style="font-size: {48 if m else 54}px; line-height: 1; font-weight: 800; letter-spacing: -2px; color: #12805C">{MATCH}</span>'
            f'<span style="font-size: 13px; font-weight: 700; color: #43504A">{MATCHN}</span>'
            f'<span style="font-size: 12px; font-weight: 600; color: #5B6862">Potential claim value across all {OPEN} open offers: {POT}</span></div>')
    head = (f'<div style="display: flex; flex-direction: column; align-items: center; gap: 4px; padding-top: 6px"><h1 style="margin: 0; font-size: {26 if m else 30}px; line-height: 1.1; font-weight: 800; letter-spacing: -0.8px">Choose your plan</h1>'
            '<span style="font-size: 13.5px; color: #5B6862">Every plan includes unlimited filing. Intro price on your first billing period.</span></div>')
    cards = ''
    for p in PLANS:
        i = p['id']
        tag = '<span style="position: absolute; top: -10px; right: 16px; padding: 4px 10px; border-radius: 99px; background: #0F3B2E; color: #FFFFFF; font-size: 10.5px; font-weight: 800; letter-spacing: 1.2px">BEST VALUE</span>' if i == '6m' else ''
        save = f'<span style="font-size: 11px; font-weight: 800; color: #12805C; background: #E9F6EF; padding: 3px 8px; border-radius: 99px">{p["save"]}</span>' if p['save'] else ''
        cards += (f'<button onClick="{{{{ pick{i} }}}}" role="radio" aria-checked="{{{{ on{i} }}}}" style="{{{{ card{i} }}}}">{tag}'
                  f'<span style="{{{{ radio{i} }}}}">{ic("check", 12, 3.4, "#FFFFFF")}</span>'
                  f'<span style="flex-grow: 1; display: flex; flex-direction: column; gap: 3px; min-width: 0"><span style="display: flex; align-items: center; gap: 8px; font-size: 16px; font-weight: 800">{p["name"]}{save}</span>'
                  f'<span style="font-size: 12.5px; font-weight: 600; color: #5B6862">Then {p["full"]} {p["every"]}</span></span>'
                  f'<span style="display: flex; flex-direction: column; align-items: flex-end; gap: 1px; flex: none"><span style="font-size: 12px; font-weight: 700; color: #9AA8A0; text-decoration: line-through">{p["full"]}</span><span style="font-size: 24px; line-height: 1; font-weight: 800; letter-spacing: -0.6px">{p["first"]}</span><span style="font-size: 11px; font-weight: 700; color: #5B6862">{p["firstL"]}</span></span></button>')
    feats = '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px 14px; padding: 4px 4px 0">' + ''.join(f'<span style="display: flex; align-items: center; gap: 7px; font-size: 12.5px; font-weight: 700; color: #43504A; text-align: left">{ic(k, 15, 2.2, "#12805C")}{t}</span>' for k, t in FEATS) + '</div>'
    body = hero + head + f'<div style="display: flex; flex-direction: column; gap: 12px; padding-top: 6px">{cards}</div>' + feats
    return body, cta(m)

def v1_styles():
    base = 'position: relative; display: flex; align-items: center; gap: 14px; width: 100%; text-align: left; padding: 16px 18px; border-radius: 18px; color: #0A0F0D; transition: box-shadow .15s, background .15s;'
    return dict(cardOn=base + 'background: #F3FAF6; box-shadow: inset 0 0 0 2px #0F3B2E, 0 12px 26px rgba(15,59,46,.10)', cardOff=base + 'background: #FFFFFF; box-shadow: inset 0 0 0 1px #DDE5E0',
                radioOn='width: 22px; height: 22px; flex: none; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: #0F3B2E', radioOff='width: 22px; height: 22px; flex: none; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: #FFFFFF; box-shadow: inset 0 0 0 2px #C9D3CD; color: transparent')

def v2(m):
    """Dark hero with a segmented plan switch and one detailed price card."""
    hero = (f'<div style="position: relative; overflow: hidden; display: flex; flex-direction: column; align-items: center; gap: 6px; padding: {"22px 16px 20px" if m else "28px 24px 26px"}; border-radius: 24px; color: #FFFFFF; background: radial-gradient(120% 120% at 100% 0%, #1F7A57 0%, rgba(31,122,87,0) 55%), linear-gradient(165deg,#134A39 0%,#0F3B2E 50%,#0A2C22 100%)">'
            '<div style="position: absolute; width: 260px; height: 260px; border-radius: 50%; left: 50%; top: 50%; margin: -130px 0 0 -130px; background: radial-gradient(circle, rgba(61,220,151,.30), rgba(61,220,151,0) 65%)"></div>'
            '<span style="position: relative; font-size: 12px; font-weight: 800; letter-spacing: 1.6px; color: #9FE8C6">YOUR MATCHES SO FAR</span>'
            f'<span style="position: relative; font-size: {54 if m else 68}px; line-height: 1; font-weight: 800; letter-spacing: -2.4px; color: #3DDC97">{MATCH}</span>'
            f'<span style="position: relative; font-size: 13px; font-weight: 700; color: #D7E3DC">{MATCHN}</span>'
            f'<span style="position: relative; margin-top: 6px; padding: 6px 12px; border-radius: 99px; background: rgba(255,255,255,.10); font-size: 12px; font-weight: 700; color: #D7E3DC">Potential across all {OPEN} open offers: {POT}</span></div>')
    head = f'<h1 style="margin: 4px 0 0; font-size: {24 if m else 28}px; line-height: 1.1; font-weight: 800; letter-spacing: -0.8px">Choose your plan</h1>'
    seg = '<div role="radiogroup" style="display: grid; grid-template-columns: repeat(3,1fr); gap: 4px; padding: 4px; border-radius: 16px; background: #EEF2EF">'
    for p in PLANS:
        i = p['id']
        seg += f'<button onClick="{{{{ pick{i} }}}}" role="radio" aria-checked="{{{{ on{i} }}}}" style="{{{{ seg{i} }}}}"><span style="font-size: 14px; font-weight: 800">{p["name"]}</span><span style="font-size: 11px; font-weight: 800; color: {{{{ segSub{i} }}}}">{p["save"] or "Flexible"}</span></button>'
    seg += '</div>'
    card = ('<div style="display: flex; flex-direction: column; gap: 12px; padding: 18px; border-radius: 20px; background: #FFFFFF; box-shadow: inset 0 0 0 2px #0F3B2E, 0 14px 30px rgba(15,59,46,.08); text-align: left">'
            '<div style="display: flex; align-items: flex-end; justify-content: space-between; gap: 10px"><span style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 12px; font-weight: 800; letter-spacing: 1.2px; color: #12805C">INTRO PRICE</span>'
            '<span style="display: flex; align-items: baseline; gap: 8px"><span style="font-size: 40px; line-height: 1; font-weight: 800; letter-spacing: -1.4px">{{ firstNow }}</span><span style="font-size: 16px; font-weight: 700; color: #9AA8A0; text-decoration: line-through">{{ fullNow }}</span></span>'
            '<span style="font-size: 13px; font-weight: 700; color: #5B6862">{{ firstLNow }}, then {{ fullNow }} {{ everyNow }}</span></span>'
            '<span style="flex: none; display: flex; flex-direction: column; align-items: center; padding: 8px 12px; border-radius: 14px; background: #E9F6EF; color: #0F3B2E"><span style="font-size: 18px; font-weight: 800">{{ perNow }}</span><span style="font-size: 10.5px; font-weight: 800">PER MONTH</span></span></div>'
            '<div style="height: 1px; background: #E8EEEA"></div>'
            + ''.join(f'<span style="display: flex; align-items: center; gap: 10px; font-size: 14px; font-weight: 700; color: #0A0F0D"><span style="width: 24px; height: 24px; border-radius: 8px; background: #E9F6EF; display: flex; align-items: center; justify-content: center; flex: none">{ic(k, 14, 2.4, "#12805C")}</span>{t}</span>' for k, t in FEATS) + '</div>')
    return hero + head + seg + card, cta(m)

def v2_styles():
    b = 'display: flex; flex-direction: column; align-items: center; gap: 1px; padding: 9px 4px; border-radius: 12px; transition: all .15s;'
    return dict(segOn=b + 'background: #0F3B2E; color: #FFFFFF; box-shadow: 0 6px 14px rgba(15,59,46,.25)', segOff=b + 'background: transparent; color: #0A0F0D', segSubOn='#3DDC97', segSubOff='#12805C')

def v3(m):
    """Three columns (stacked tiles on mobile) with the 6-month plan raised in the middle."""
    hero = (f'<div style="display: flex; {"flex-direction: column; align-items: center; gap: 2px" if m else "align-items: center; justify-content: center; gap: 18px"}; padding: 14px 18px; border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #DDE5E0">'
            f'<span style="display: flex; flex-direction: column; align-items: {"center" if m else "flex-end"}"><span style="font-size: 13px; font-weight: 700; color: #5B6862">Your matches so far</span><span style="font-size: 12px; font-weight: 600; color: #9AA8A0">{MATCHN}</span></span>'
            f'<span style="font-size: {46 if m else 52}px; line-height: 1; font-weight: 800; letter-spacing: -2px; color: #12805C">{MATCH}</span>'
            f'<span style="{"" if m else "max-width: 190px; "}font-size: 12px; font-weight: 600; color: #5B6862; text-align: {"center" if m else "left"}">Potential claim value across all {OPEN} open offers: <b style="color: #0A0F0D">{POT}</b></span></div>')
    head = f'<h1 style="margin: 8px 0 2px; font-size: {24 if m else 30}px; line-height: 1.1; font-weight: 800; letter-spacing: -0.8px">Choose your plan</h1>'
    order = PLANS if m else [PLANS[0], PLANS[2], PLANS[1]]
    cols = f'<div style="display: {"flex; flex-direction: column" if m else "grid; grid-template-columns: 1fr 1.12fr 1fr; align-items: center"}; gap: {10 if m else 14}px; padding-top: 10px">'
    for p in order:
        i = p['id']; best = i == '6m'
        top = '<span style="position: absolute; top: -12px; left: 50%; transform: translateX(-50%); white-space: nowrap; padding: 5px 12px; border-radius: 99px; background: #3DDC97; color: #0F3B2E; font-size: 10.5px; font-weight: 800; letter-spacing: 1.2px">MOST POPULAR</span>' if best else ''
        if m:
            cols += (f'<button onClick="{{{{ pick{i} }}}}" role="radio" aria-checked="{{{{ on{i} }}}}" style="{{{{ tile{i} }}}}">{top.replace("left: 50%; transform: translateX(-50%)", "right: 14px")}'
                     f'<span style="display: flex; flex-direction: column; align-items: flex-start; gap: 2px"><span style="font-size: 15px; font-weight: 800">{p["name"]}</span><span style="font-size: 12px; font-weight: 700; opacity: .75">{p["first"]} {p["firstL"]}</span></span>'
                     f'<span style="display: flex; align-items: baseline; gap: 2px"><span style="font-size: 26px; font-weight: 800; letter-spacing: -0.8px">{p["per"]}</span><span style="font-size: 12px; font-weight: 700; opacity: .75">/mo</span></span></button>')
        else:
            cols += (f'<button onClick="{{{{ pick{i} }}}}" role="radio" aria-checked="{{{{ on{i} }}}}" style="{{{{ col{i} }}}}">{top}'
                     f'<span style="font-size: 13px; font-weight: 800; letter-spacing: 1.2px; opacity: .8">{p["name"].upper()}</span>'
                     f'<span style="display: flex; align-items: baseline; justify-content: center; gap: 2px"><span style="font-size: {40 if best else 34}px; line-height: 1; font-weight: 800; letter-spacing: -1.4px">{p["per"]}</span><span style="font-size: 13px; font-weight: 700; opacity: .75">/mo</span></span>'
                     f'<span style="font-size: 12.5px; font-weight: 700; opacity: .8">{p["full"]} {p["every"]}</span>'
                     f'<span style="margin-top: 4px; padding: 6px 10px; border-radius: 10px; background: {{{{ chip{i} }}}}; font-size: 12px; font-weight: 800">{p["first"]} {p["firstL"]}</span>'
                     + (f'<span style="font-size: 11.5px; font-weight: 800; color: {{{{ save{i} }}}}">{p["save"]}</span>' if p['save'] else '<span style="font-size: 11.5px; font-weight: 800; opacity: .6">Most flexible</span>') + '</button>')
    cols += '</div>'
    feats = '<div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 8px; padding-top: 12px">' + ''.join(f'<span style="display: flex; align-items: center; gap: 6px; padding: 7px 11px; border-radius: 99px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #DDE5E0; font-size: 12px; font-weight: 700; color: #43504A">{ic(k, 13, 2.4, "#12805C")}{t}</span>' for k, t in FEATS) + '</div>'
    return hero + head + cols + feats, cta(m)

def v3_styles():
    c = 'position: relative; display: flex; flex-direction: column; align-items: center; gap: 6px; padding: 26px 14px 20px; border-radius: 22px; text-align: center; transition: all .15s;'
    t = 'position: relative; display: flex; align-items: center; justify-content: space-between; gap: 12px; width: 100%; padding: 16px 18px; border-radius: 18px; text-align: left; transition: all .15s;'
    return dict(colOn=c + 'background: #0F3B2E; color: #FFFFFF; box-shadow: 0 22px 44px rgba(15,59,46,.28)', colOff=c + 'background: #FFFFFF; color: #0A0F0D; box-shadow: inset 0 0 0 1px #DDE5E0',
                tileOn=t + 'background: #0F3B2E; color: #FFFFFF; box-shadow: 0 14px 30px rgba(15,59,46,.24)', tileOff=t + 'background: #FFFFFF; color: #0A0F0D; box-shadow: inset 0 0 0 1px #DDE5E0',
                chipOn='rgba(61,220,151,.18); color: #3DDC97', chipOff='#E9F6EF; color: #12805C', saveOn='#3DDC97', saveOff='#12805C')

def v4(m):
    """Receipt: the matches total at the top, a compact plan list, and a 'due today' line that does the math."""
    w = '100%'
    zig = '<div style="height: 10px; background: linear-gradient(-45deg, transparent 6px, #FFFFFF 0) 0 0 / 12px 10px repeat-x, linear-gradient(45deg, transparent 6px, #FFFFFF 0) 0 0 / 12px 10px repeat-x; transform: rotate(180deg)"></div>'
    rows = ''
    for p in PLANS:
        i = p['id']
        save = f' <span style="color: #12805C">· {p["save"]}</span>' if p['save'] else ''
        best = '<span style="padding: 2px 7px; border-radius: 6px; background: #0F3B2E; color: #FFFFFF; font-size: 10px; font-weight: 800; letter-spacing: .8px">BEST</span>' if i == '6m' else ''
        rows += (f'<button onClick="{{{{ pick{i} }}}}" role="radio" aria-checked="{{{{ on{i} }}}}" style="{{{{ row{i} }}}}"><span style="{{{{ dot{i} }}}}"></span>'
                 f'<span style="flex-grow: 1; display: flex; flex-direction: column; gap: 1px; text-align: left"><span style="display: flex; align-items: center; gap: 6px; font-size: 15px; font-weight: 800">{p["name"]}{best}</span><span style="font-size: 12px; font-weight: 600; color: #5B6862">{p["per"]}/mo{save}</span></span>'
                 f'<span style="font-family: \'Courier New\', monospace; font-size: 15px; font-weight: 700">{p["first"]}</span></button>')
    rec = (f'<div style="width: {w}; filter: drop-shadow(0 18px 30px rgba(10,15,13,.10))">'
           '<div style="background: #FFFFFF; border-radius: 18px 18px 0 0; padding: 20px 20px 8px; display: flex; flex-direction: column; gap: 12px; text-align: left">'
           '<div style="display: flex; justify-content: space-between; align-items: center"><span style="font-family: \'Courier New\', monospace; font-size: 11px; font-weight: 700; letter-spacing: 1.4px; color: #5B6862">CLAIMCLUB · MEMBERSHIP</span>'
           f'<span style="display: flex; align-items: center; gap: 4px; font-size: 11px; font-weight: 800; color: #12805C">{ic("shield", 13, 2.4)}Secure</span></div>'
           '<div style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 13px; font-weight: 700; color: #5B6862">Your matches so far</span>'
           f'<span style="font-size: {46 if m else 54}px; line-height: 1; font-weight: 800; letter-spacing: -2px; color: #12805C">{MATCH}</span>'
           f'<span style="font-size: 12px; font-weight: 600; color: #5B6862">{MATCHN} · Potential across all {OPEN} open offers: {POT}</span></div>'
           '<div style="border-top: 1.5px dashed #DDE5E0; margin: 2px 0"></div>'
           '<span style="font-size: 12px; font-weight: 800; letter-spacing: 1.2px; color: #0A0F0D">CHOOSE YOUR PLAN</span>'
           f'<div style="display: flex; flex-direction: column; gap: 6px">{rows}</div>'
           '<div style="border-top: 1.5px dashed #DDE5E0; margin: 4px 0 0"></div>'
           '<div style="display: flex; justify-content: space-between; align-items: baseline"><span style="font-size: 14px; font-weight: 800">Due today</span><span style="display: flex; align-items: baseline; gap: 8px"><span style="font-size: 13px; font-weight: 700; color: #9AA8A0; text-decoration: line-through">{{ fullNow }}</span><span style="font-size: 28px; font-weight: 800; letter-spacing: -0.8px">{{ firstNow }}</span></span></div>'
           '<div style="display: flex; justify-content: space-between; font-size: 12.5px; font-weight: 600; color: #5B6862; padding-bottom: 6px"><span>Then</span><span>{{ fullNow }} {{ everyNow }}</span></div>'
           '</div>' + zig + '</div>')
    note = f'<span style="display: flex; align-items: center; justify-content: center; gap: 6px; font-size: 12.5px; font-weight: 700; color: #43504A">{ic("check", 14, 3, "#12805C")}We file every claim for you and you keep 100% of every payout</span>'
    head = f'<h1 style="margin: 0; font-size: {24 if m else 28}px; line-height: 1.1; font-weight: 800; letter-spacing: -0.8px">You\'re almost in</h1>'
    return head + rec + note, cta(m)

def v4_styles():
    r = 'display: flex; align-items: center; gap: 12px; width: 100%; padding: 11px 12px; border-radius: 12px; color: #0A0F0D; transition: all .15s;'
    d = 'width: 18px; height: 18px; flex: none; border-radius: 50%; box-sizing: border-box;'
    return dict(rowOn=r + 'background: #F3FAF6; box-shadow: inset 0 0 0 1.5px #0F3B2E', rowOff=r + 'background: #F6F8F7; box-shadow: none',
                dotOn=d + 'border: 5.5px solid #0F3B2E; background: #FFFFFF', dotOff=d + 'border: 2px solid #C9D3CD; background: #FFFFFF')

def v5(m):
    """Mint-forward: members strip and stars, big matches number, horizontal plan chips with a savings meter."""
    trust = (f'<div style="display: flex; align-items: center; justify-content: center; gap: 10px; font-size: 12.5px; font-weight: 700; color: #43504A">'
             '<span style="display: flex"><span style="width: 26px; height: 26px; border-radius: 50%; background: #3DDC97; border: 2px solid #FFFFFF"></span><span style="width: 26px; height: 26px; border-radius: 50%; background: #12805C; border: 2px solid #FFFFFF; margin-left: -8px"></span><span style="width: 26px; height: 26px; border-radius: 50%; background: #0F3B2E; border: 2px solid #FFFFFF; margin-left: -8px"></span></span>'
             f'<span style="display: flex; flex-direction: column; align-items: flex-start; line-height: 1.2">{stars(5, 12, "#12805C")}<span>148,000+ members</span></span></div>')
    hero = ('<div style="display: flex; flex-direction: column; align-items: center; gap: 2px">'
            '<span style="font-size: 14px; font-weight: 700; color: #43504A">Your matches so far</span>'
            f'<span style="font-size: {58 if m else 72}px; line-height: 1; font-weight: 800; letter-spacing: -2.6px; color: #12805C; text-shadow: 0 10px 30px rgba(61,220,151,.35)">{MATCH}</span>'
            f'<span style="font-size: 12.5px; font-weight: 600; color: #5B6862">Potential claim value across all {OPEN} open offers: {POT}</span></div>')
    chips = '<div role="radiogroup" style="display: grid; grid-template-columns: repeat(3,1fr); gap: 8px; padding-top: 6px">'
    for p in PLANS:
        i = p['id']
        chips += (f'<button onClick="{{{{ pick{i} }}}}" role="radio" aria-checked="{{{{ on{i} }}}}" style="{{{{ chip{i} }}}}">'
                  + ('<span style="position: absolute; top: -9px; left: 50%; transform: translateX(-50%); white-space: nowrap; padding: 3px 8px; border-radius: 99px; background: #0F3B2E; color: #3DDC97; font-size: 9.5px; font-weight: 800; letter-spacing: 1px">BEST VALUE</span>' if i == '6m' else '')
                  + f'<span style="font-size: 13px; font-weight: 800">{p["name"]}</span><span style="font-size: {22 if m else 26}px; line-height: 1.05; font-weight: 800; letter-spacing: -0.6px">{p["per"]}</span><span style="font-size: 11px; font-weight: 700; opacity: .7">per month</span></button>')
    chips += '</div>'
    meter = ('<div style="display: flex; flex-direction: column; gap: 6px; padding: 14px 16px; border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #DDE5E0; text-align: left">'
             '<div style="display: flex; justify-content: space-between; align-items: baseline"><span style="font-size: 13px; font-weight: 800">{{ saveLabel }}</span><span style="font-size: 13px; font-weight: 800; color: #12805C">{{ firstNow }} {{ firstLNow }}</span></div>'
             '<div style="height: 8px; border-radius: 99px; background: #EEF2EF; overflow: hidden"><div style="{{ meter }}"></div></div>'
             '<span style="font-size: 12px; font-weight: 600; color: #5B6862">Then {{ fullNow }} {{ everyNow }}. Cancel anytime from your dashboard.</span></div>')
    guar = (f'<div style="display: flex; align-items: center; gap: 12px; padding: 12px 14px; border-radius: 16px; background: #E9F6EF; text-align: left">'
            f'<span style="width: 36px; height: 36px; flex: none; border-radius: 12px; background: #3DDC97; display: flex; align-items: center; justify-content: center">{ic("shield", 19, 2.2, "#0F3B2E")}</span>'
            '<span style="display: flex; flex-direction: column; gap: 1px"><span style="font-size: 13.5px; font-weight: 800; color: #0F3B2E">We file, you keep 100%</span><span style="font-size: 12px; font-weight: 600; color: #43504A">No cut of your payouts, ever. Unlimited filing on every plan.</span></span></div>')
    head = f'<h1 style="margin: 6px 0 0; font-size: {24 if m else 28}px; line-height: 1.1; font-weight: 800; letter-spacing: -0.8px">Choose your plan</h1>'
    return trust + hero + head + chips + meter + guar, cta(m)

def v5_styles():
    c = 'position: relative; display: flex; flex-direction: column; align-items: center; gap: 3px; padding: 16px 6px 13px; border-radius: 18px; transition: all .15s;'
    return dict(chipOn=c + 'background: #3DDC97; color: #0F3B2E; box-shadow: 0 12px 26px rgba(61,220,151,.4), inset 0 0 0 2px #0F3B2E', chipOff=c + 'background: #FFFFFF; color: #0A0F0D; box-shadow: inset 0 0 0 1px #DDE5E0')

VARIANTS = [
    ('PlanV1', 'Plan page V1 · Clean cards, intro price with regular price struck out', v1, v1_styles, 'radio,card'),
    ('PlanV2', 'Plan page V2 · Dark matches hero, plan switch, one detailed price card', v2, v2_styles, 'seg,segSub'),
    ('PlanV3', 'Plan page V3 · Three columns, 6 months raised in the middle', v3, v3_styles, 'col,tile,chip,save'),
    ('PlanV4', 'Plan page V4 · Receipt with a due-today line', v4, v4_styles, 'row,dot'),
    ('PlanV5', 'Plan page V5 · Mint chips, savings meter and a keep-100% promise', v5, v5_styles, 'chip'),
]

def desktop(body, foot):
    return ('<div style="position: relative; width: 1280px; height: 800px; flex: none; background: #FFFFFF; border-radius: 18px; overflow: hidden; box-shadow: 0 30px 70px rgba(10,15,13,.14); display: flex; flex-direction: column">'
            '<header style="display: flex; align-items: center; justify-content: space-between; padding: 18px 36px; border-bottom: 1px solid #E8EEEA">'
            f'<div style="display: flex; align-items: center; gap: 16px"><button aria-label="Back" style="width: 44px; height: 44px; border-radius: 12px; background: #F3F6F4; color: #0A0F0D; display: flex; align-items: center; justify-content: center">{ic("back", 20)}</button><div style="display: flex; align-items: center; gap: 8px">{LOGO.format(s=28)}{WORD.format(f=20)}</div></div>'
            '<div style="display: flex; align-items: center; gap: 14px; font-size: 13px; font-weight: 600; color: #5B6862"><span>Not a law firm · Free to check</span><div style="display: flex; gap: 2px; padding: 3px; border-radius: 99px; background: #F3F6F4"><span style="padding: 7px 12px; border-radius: 99px; background: #0F3B2E; color: #FFFFFF; font-weight: 800">EN</span><span style="padding: 7px 12px; font-weight: 800">ES</span></div></div></header>'
            '<div style="flex-grow: 1; min-height: 0; display: flex">'
            '<aside class="mesh" style="flex: 0 0 400px; box-sizing: border-box; padding: 36px; color: #FFFFFF; display: flex; flex-direction: column; gap: 18px">'
            f'<div style="display: flex; flex-direction: column; gap: 4px"><div style="font-size: 12px; font-weight: 700; letter-spacing: 1.4px; color: #C9D6CF">YOUR ESTIMATE SO FAR</div><div style="font-size: 52px; font-weight: 800; letter-spacing: -2px; line-height: 1.05">{MATCH}</div><div style="font-size: 15px; font-weight: 600; color: #D7E3DC">{MATCHN}</div></div>'
            + ''.join(f'<div style="display: flex; align-items: center; gap: 10px; font-size: 15px; font-weight: 700"><span style="width: 7px; height: 7px; border-radius: 50%; background: #3DDC97"></span>{t}</div>' for t in ['Every settlement is court-approved', 'We pre-fill and submit your claims', 'Payouts come straight from the settlement', 'Cancel anytime'])
            + '<div style="margin-top: auto; font-size: 12px; line-height: 1.6; color: #C9D6CF">Amounts are caps or estimates from each settlement notice and are not guaranteed.</div></aside>'
            '<div style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; background: #F6F8F7">'
            f'<div class="scroll" style="flex-grow: 1; min-height: 0; overflow-y: auto; display: flex; justify-content: center"><div class="col" style="width: 100%; max-width: {640}px; box-sizing: border-box; padding: 26px 0 18px; display: flex; flex-direction: column; gap: 14px; text-align: center">{body}</div></div>'
            f'<div style="flex: none; display: flex; justify-content: center; padding: 12px 0 16px; border-top: 1px solid #E8EEEA; background: #FFFFFF"><div style="width: 100%; max-width: 560px; display: flex; flex-direction: column; gap: 6px; text-align: center">{foot}</div></div>'
            '</div></div></div>')

def mobile(body, foot):
    return ('<div style="position: relative; width: 390px; height: 844px; flex: none; background: #F6F8F7; border-radius: 28px; overflow: hidden; box-shadow: 0 30px 70px rgba(10,15,13,.14); display: flex; flex-direction: column">'
            f'<header style="display: flex; align-items: center; justify-content: space-between; padding: 16px 18px 10px; background: #FFFFFF"><div style="display: flex; align-items: center; gap: 12px"><span style="color: #0A0F0D; display: flex">{ic("back", 22)}</span><div style="display: flex; align-items: center; gap: 7px">{LOGO.format(s=26)}{WORD.format(f=18)}</div></div>'
            '<div style="display: flex; gap: 2px; padding: 3px; border-radius: 99px; background: #F3F6F4; font-size: 12px"><span style="padding: 7px 11px; border-radius: 99px; background: #0F3B2E; color: #FFFFFF; font-weight: 800">EN</span><span style="padding: 7px 11px; font-weight: 800; color: #5B6862">ES</span></div></header>'
            f'<div class="scroll col" style="flex-grow: 1; min-height: 0; overflow-y: auto; padding: 14px 18px 16px; display: flex; flex-direction: column; gap: 12px; text-align: center">{body}</div>'
            f'<div style="flex: none; padding: 10px 18px 16px; border-top: 1px solid #E8EEEA; background: #FFFFFF; display: flex; flex-direction: column; gap: 6px; text-align: center">{foot}</div></div>')

HEAD = '''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>%s</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
body{margin:0}
button{font-family:inherit;cursor:pointer;border:0;color:inherit}
button:focus-visible{outline:3px solid #3DDC97;outline-offset:2px}
.mesh{background:radial-gradient(140%% 100%% at 100%% 0%%, #1F7A57 0%%, rgba(31,122,87,0) 55%%),radial-gradient(120%% 120%% at 0%% 100%%, #05211A 0%%, rgba(5,33,26,0) 60%%),linear-gradient(165deg, #134A39 0%%, #0F3B2E 45%%, #0A2C22 100%%)}
.col>*{flex-shrink:0}
.scroll{scrollbar-width:thin;scrollbar-color:#C9D3CD transparent}
</style>
</helmet>
'''

JS = '''<script type="text/x-dc" data-dc-script data-props='{"$preview":{"width":1766,"height":940}}'>
class Component extends DCLogic {
  constructor(p) { super(p); this.state = { plan: '6m' }; }
  renderVals() {
    const s = this.state, P = %s, S = %s, K = %s;
    const p = P.find(x => x.id === s.plan), v = {};
    P.forEach(x => {
      const on = x.id === s.plan;
      v['on' + x.id] = on;
      v['pick' + x.id] = () => this.setState({ plan: x.id });
      K.forEach(k => { v[k + x.id] = on ? S[k + 'On'] : S[k + 'Off']; });
    });
    const pct = { '1m': 0, '3m': 17, '6m': 33 }[s.plan];
    return Object.assign(v, {
      firstNow: p.first, fullNow: p.full, everyNow: p.every, firstLNow: p.firstL, perNow: p.per,
      renew: 'You pay ' + p.first + ' today. Then it auto-renews at ' + p.full + ' ' + p.every + ' until you cancel.',
      saveLabel: pct ? 'You save ' + pct + '%% vs monthly' : 'Monthly, most flexible',
      meter: 'height:100%%;border-radius:99px;background:linear-gradient(90deg,#12805C,#3DDC97);transition:width .3s ease;width:' + Math.max(6, pct * 3) + '%%'
    });
  }
}
</script>
</body>
</html>
'''

def build():
    made = []
    for name, title, fn, sty, keys in VARIANTS:
        db, df = fn(False); mb, mf = fn(True)
        page = (f'<div style="width: 1766px; height: 940px; box-sizing: border-box; padding: 24px; background: #E7ECE9; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 14px">'
                f'<div style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #43504A">{title.upper()}</div>'
                f'<div style="display: flex; gap: 48px; align-items: flex-start">{desktop(db, df)}{mobile(mb, mf)}</div></div>\n</x-dc>\n')
        js = JS % (json.dumps(PLANS), json.dumps(sty()), json.dumps(keys.split(',')))
        open(os.path.join(OUT, name + '.dc.html'), 'w').write(HEAD % title + page + js)
        made.append((name, title))
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    y0 = 7560
    c['notes']['tP'] = {'x': 0, 'y': y0, 'text': 'Choose your plan · 5 iterations (desktop and mobile). Click a plan to try it.', 'kind': 'title1', 'maxW': 3600}
    for k, (name, title) in enumerate(made):
        c['boards'][name + '.dc.html'] = {'x': (k % 2) * 1846, 'y': y0 + 220 + (k // 2) * 1020, 'w': 1766, 'h': 940, 'is_interactive': True, 'title': title}
        if name + '.dc.html' not in c['order']: c['order'].append(name + '.dc.html')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w'))
    print('built', [m[0] for m in made])

if __name__ == '__main__':
    build()
