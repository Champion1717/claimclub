# Offer + filing fee drafts (Nov 21 2026, design only, not live).
# Henry: each of the 3 live offers (B $2 trial, C free 7 days, D free 3 days then weekly) should also show a
# $19.99 one-time filing fee as the other choice. 3 layouts for each offer = 9 boards on the canvas page "Offers":
#   1 Link: the offer page stays as it is, with a quiet "pay $19.99 once" line under the main button
#   2 Two cards: the membership card, then a smaller white "File once" card with its own button
#   3 Switch: a Membership | File once switch on top of one card (desktop shows Membership, phone shows File once)
# Writes OfferB1..3, OfferC1..3, OfferD1..3 into ../project. Sample claims and member.
import os, io, contextlib
from how4 import HEAD, JS, OUT
from perksD import ic, INK, MUTE, LINE, MINT, GREEN, DARK
from choiceD import mint_btn
with contextlib.redirect_stdout(io.StringIO()):
    from flowB import h, sub, chip, summary, desk, mob

FEE = '$19.99'
OFFERS = {
    'B': dict(big='$2', was='$49.99', badge='96% OFF TODAY', first='for your first 7 days', then='Then $49.99 a year, just $4.17 a month. Cancel anytime.',
              head='File your 6 claims for $2', subh='Try membership for 7 days. We start filing today.', cta='Start my 7-day trial · $2', ctaM='Start my trial · $2',
              seg='Membership · $2 today', fine='Your trial ends Nov 28, 2026. Then $49.99 a year unless you cancel before then.', name='$2 for 7 days, then $49.99 a year'),
    'C': dict(big='Free', was='$49.99', badge='7 DAYS FREE', first='for your first 7 days', then='Then $49.99 a year, just $4.17 a month. Cancel anytime.',
              head='File your 6 claims free', subh='Try membership free for 7 days. We start filing today.', cta='Start my free 7-day trial', ctaM='Start my free trial',
              seg='Membership · free 7 days', fine='$0 today. Your trial ends Nov 28, 2026. Then $49.99 a year unless you cancel before then.', name='free for 7 days, then $49.99 a year'),
    'D': dict(big='Free', was='$4.99/wk', badge='3 DAYS FREE', first='for your first 3 days', then='Then $4.99 a week. Cancel anytime.',
              head='File your 6 claims free', subh='Try membership free for 3 days. We start filing today.', cta='Start my free 3-day trial', ctaM='Start my free trial',
              seg='Membership · free 3 days', fine='$0 today. Your trial ends Nov 24, 2026. Then $4.99 a week unless you cancel before then.', name='free for 3 days, then $4.99 a week'),
}
PERKS = ['Files your 6 claims, no filing fee', 'Every new claim you qualify for, filed for you', 'An alert the day a new claim opens',
         'All 279 settlements, plus local ones near you', 'Track every claim in one dashboard']
# what the one-time fee gets you vs not
FEE_YES = ['Files your 6 claims', 'Track them in your dashboard', 'No subscription, nothing renews']
FEE_NO = ['New claims you qualify for later', 'Alerts when new claims open']

def ok(t, c=MINT, fg='#FFFFFF', sz=14):
    return (f'<div style="display: flex; align-items: center; gap: 10px; font-size: {sz}px; font-weight: 700; color: {fg}">'
            f'<span style="width: 22px; height: 22px; flex: none; border-radius: 99px; background: {"rgba(61,220,151,.18)" if fg == "#FFFFFF" else "#E9F6EF"}; display: flex; align-items: center; justify-content: center">{ic("check", 13, c, 3)}</span>{t}</div>')
def no(t, sz=14):
    return (f'<div style="display: flex; align-items: center; gap: 10px; font-size: {sz}px; font-weight: 600; color: #8A968F; text-decoration: line-through">'
            f'<span style="width: 22px; height: 22px; flex: none; border-radius: 99px; background: #F1F4F2; display: flex; align-items: center; justify-content: center">{ic("x", 12, "#A3AEA8", 2.6)}</span>{t}</div>')

def mem_card(o, m=False, perks=5, best=False):
    pk = ''.join(ok(p, sz=14 if m else 15) for p in PERKS[:perks])
    top = chip('BEST VALUE', MINT, DARK) if best else chip(o['badge'], MINT, DARK)
    return (f'<div style="position: relative; border-radius: 24px; padding: {18 if m else 24}px; background: radial-gradient(120% 90% at 100% 0%, rgba(61,220,151,.25), transparent 55%), linear-gradient(165deg, #1B5A44, #0A2A20); color: #FFFFFF; display: flex; flex-direction: column; gap: {12 if m else 13}px; box-shadow: 0 20px 44px rgba(10,42,32,.28)">'
            f'<div style="display: flex; justify-content: space-between; align-items: center; gap: 8px"><span style="font-size: 12px; font-weight: 800; letter-spacing: 1.3px; color: #CFE9DD">CLAIMCLUB MEMBERSHIP</span>{top}</div>'
            f'<div style="display: flex; align-items: flex-end; gap: 12px"><b style="font-size: {50 if m else 58}px; letter-spacing: -2.5px; line-height: .9">{o["big"]}</b>'
            f'<span style="display: flex; flex-direction: column; padding-bottom: 4px"><span style="font-size: 15px; font-weight: 700; color: #9FC3B4; text-decoration: line-through">{o["was"]}</span><span style="font-size: {14 if m else 15}px; font-weight: 800">{o["first"]}</span></span></div>'
            f'<span style="font-size: {13 if m else 14}px; font-weight: 600; color: #CFE9DD; margin-top: -4px">{o["then"]}</span>'
            + (f'<div style="height: 1px; background: rgba(255,255,255,.12)"></div><div style="display: flex; flex-direction: column; gap: {8 if m else 10}px">{pk}</div>' if perks else '')
            + '</div>')

def cta(t, hh=56, fs=17):
    return mint_btn(f'{ic("lock", 16, DARK, 2.4)}{t}', hh, fs)
def ghost(t, hh=52):
    return (f'<div style="height: {hh}px; flex: none; border-radius: 99px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px #C9D3CD; color: {INK}; display: flex; align-items: center; justify-content: center; gap: 8px; font-size: 16px; font-weight: 800">{t}</div>')
def fine(t, center=True):
    return f'<span style="font-size: 12px; line-height: 1.45; color: {MUTE}; font-weight: 600; text-align: {"center" if center else "left"}">{t}</span>'

# ---------- 1: link under the button ----------
def fee_link(m=False):
    if m:
        return (f'<div style="display: flex; align-items: center; justify-content: center; gap: 6px; font-size: 13.5px; font-weight: 700; color: {INK}">'
                f'Only these 6 claims? <span style="color: {GREEN}; text-decoration: underline; text-underline-offset: 3px">Pay {FEE} once</span>{ic("right", 14, GREEN, 2.6)}</div>')
    return (f'<div style="display: flex; align-items: center; justify-content: space-between; gap: 14px; padding: 14px 18px; border-radius: 16px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}">'
            f'<span style="display: flex; flex-direction: column; gap: 2px"><b style="font-size: 15px">Just want these 6 claims filed?</b><span style="font-size: 13px; font-weight: 600; color: {MUTE}">Pay {FEE} once. No subscription, nothing renews.</span></span>'
            f'<span style="display: flex; align-items: center; gap: 6px; font-size: 14.5px; font-weight: 800; color: {GREEN}; white-space: nowrap">Pay {FEE} once{ic("right", 15, GREEN, 2.6)}</span></div>')
def v1(o):
    d = desk(h(o['head']) + sub(o['subh']) + summary() + mem_card(o) + cta(o['cta']) + fine(o['fine']) + fee_link())
    m = mob(h(o['head'], 26, False) + sub(o['subh'], False, 14.5) + summary(True) + mem_card(o, True, 4),
            cta(o['ctaM'], 54) + fine(o['fine']) + fee_link(True))
    return d, m

# ---------- 2: two cards ----------
def fee_card(m=False, compact=False):
    lst = ''.join(ok(t, GREEN, INK, 13.5 if m else 14) for t in (FEE_YES[:2] if m else FEE_YES[:2])) + ''.join(no(t, 13.5 if m else 14) for t in (FEE_NO[:1] if m else FEE_NO))
    return (f'<div style="border-radius: 22px; padding: {16 if m else 20}px {18 if m else 22}px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; flex-direction: column; gap: {10 if m else 12}px">'
            f'<div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 10px"><span style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 12px; font-weight: 800; letter-spacing: 1.3px; color: #8A968F">FILE ONCE</span>'
            f'<span style="display: flex; align-items: baseline; gap: 6px"><b style="font-size: {28 if m else 32}px; letter-spacing: -1px">{FEE}</b><span style="font-size: 14px; font-weight: 700; color: {MUTE}">one time</span></span></span>'
            + ('' if m else ghost(f'Pay {FEE} once', 46).replace('height: 46px; flex: none', 'height: 46px; flex: none; padding: 0 22px')) + '</div>'
            f'<div style="display: {"flex" if m else "grid"}; {"flex-direction: column" if m else "grid-template-columns: 1fr 1fr"}; gap: 8px">{lst}</div>'
            + (ghost(f'Pay {FEE} once', 46) if m else '') + '</div>')
def v2(o):
    d = desk(h(o['head']) + summary() + mem_card(o, perks=3, best=True) + cta(o['cta']) + fine(o['fine']) + fee_card(), w=660)
    m = mob(h(o['head'], 26, False) + summary(True) + mem_card(o, True, 1, best=True) + fee_card(True, True),
            cta(o['ctaM'], 54) + fine(o['fine']))
    return d, m

# ---------- 3: switch ----------
def seg(o, on, m=False):
    def b(t, sel):
        return (f'<span style="flex: 1; height: {44 if m else 46}px; border-radius: 99px; display: flex; align-items: center; justify-content: center; text-align: center; font-size: {13 if m else 14.5}px; font-weight: 800; '
                + (f'background: #FFFFFF; color: {INK}; box-shadow: 0 2px 8px rgba(10,15,13,.12)' if sel else f'color: {MUTE}') + f'">{t}</span>')
    return f'<div style="display: flex; padding: 4px; border-radius: 99px; background: #E4EAE6">{b(o["seg"], on == "mem")}{b("File once · " + FEE, on == "fee")}</div>'
def fee_dark(m=False):
    lst = ''.join(ok(t, sz=14 if m else 15) for t in FEE_YES) + ''.join(
        f'<div style="display: flex; align-items: center; gap: 10px; font-size: {14 if m else 15}px; font-weight: 600; color: #8FB5A5; text-decoration: line-through"><span style="width: 22px; height: 22px; flex: none; border-radius: 99px; background: rgba(255,255,255,.08); display: flex; align-items: center; justify-content: center">{ic("x", 12, "#8FB5A5", 2.6)}</span>{t}</div>' for t in FEE_NO)
    return (f'<div style="border-radius: 24px; padding: {18 if m else 24}px; background: linear-gradient(165deg, #2A3A33, #121A16); color: #FFFFFF; display: flex; flex-direction: column; gap: 13px; box-shadow: 0 20px 44px rgba(10,15,13,.25)">'
            f'<div style="display: flex; justify-content: space-between; align-items: center"><span style="font-size: 12px; font-weight: 800; letter-spacing: 1.3px; color: #C9D6CF">FILING FEE</span>{chip("NO SUBSCRIPTION", "#3A4A43", "#E3ECE7")}</div>'
            f'<div style="display: flex; align-items: flex-end; gap: 10px"><b style="font-size: {50 if m else 58}px; letter-spacing: -2.5px; line-height: .9">{FEE}</b><span style="font-size: 15px; font-weight: 800; padding-bottom: 4px">one time</span></div>'
            f'<span style="font-size: {13 if m else 14}px; font-weight: 600; color: #C9D6CF; margin-top: -4px">We file the 6 claims on your receipt. Nothing renews.</span>'
            f'<div style="height: 1px; background: rgba(255,255,255,.12)"></div><div style="display: flex; flex-direction: column; gap: 10px">{lst}</div></div>')
def v3(o):
    d = desk(h(o['head']) + sub('Pick how you want to pay. You keep 100% of every payout either way.') + summary() + seg(o, 'mem') + mem_card(o) + cta(o['cta']) + fine(o['fine']))
    m = mob(h('File your 6 claims', 26, False) + summary(True) + seg(o, 'fee', True) + fee_dark(True),
            cta(f'File my 6 claims · {FEE}', 54) + fine('One payment. No subscription. You keep 100% of every payout.'))
    return d, m

LAYOUT = {
    1: ('LINK UNDER THE BUTTON', 'The offer page stays as it is. Under the main button, a quiet line offers the 6 claims alone for {fee} once. Membership stays the obvious choice; the fee is there for people who would otherwise leave.', v1),
    2: ('TWO CARDS', 'The membership card (marked Best value) comes first with the main button. Under it, a smaller white File once card at {fee} with its own button, showing what it covers and what it leaves out (crossed out).', v2),
    3: ('SWITCH', 'One card with a Membership | File once switch on top. Desktop shows Membership (picked when the page opens); the phone shows File once, which swaps the card and button to the {fee} fee.', v3),
}

BOARDS = {}
for ok_ in 'BCD':
    for n in (1, 2, 3):
        BOARDS[f'Offer{ok_}{n}'] = (ok_, n)

if __name__ == '__main__':
    for name, (k, n) in BOARDS.items():
        o = OFFERS[k]; title, desc, fn = LAYOUT[n]
        d, m = fn(o)
        hgt = 1080
        page = ('<div data-board style="width: 1840px; height: %dpx; box-sizing: border-box; padding: 36px 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 26px">' % hgt
                + f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #12805C">OFFER {k} · {o["name"].upper()} · {n} {title}</span>'
                f'<span style="font-size: 16px; color: #43504A; max-width: 1640px; line-height: 1.5; font-weight: 600">{desc.format(fee=FEE)}</span>'
                f'<span style="font-size: 13px; color: #8A968F; font-weight: 600">Draft, not live. Adds a {FEE} one-time filing fee next to offer {k} ({o["name"]}). Sample member and claims.</span></div>'
                f'<div style="display: flex; gap: 46px; align-items: flex-start">{d}{m}</div></div>\n</x-dc>\n')
        open(os.path.join(OUT, f'{name}.dc.html'), 'w').write(HEAD % f'Offer {k} {n} {title.title()}' + page + JS.replace('"width":1926,"height":980', '"width":1840,"height":%d' % hgt))
    print('ok', len(BOARDS))
