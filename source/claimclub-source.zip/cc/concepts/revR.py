# Draft (placeholder content, not for the live site): reviews with a profile photo and the amount each person received. Board RevR1..3.dc.html (desktop 1440 + mobile 390).
import json, os, sys, base64
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from how4 import ic, HEAD, JS, OUT

MINT, DARK, GREEN = '#3DDC97', '#0F3B2E', '#12805C'
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
def logo(p):
    b = open(os.path.join(ROOT, p), 'rb').read(); t = 'image/svg+xml' if p.endswith('.svg') else 'image/png'
    return f'data:{t};base64,' + base64.b64encode(b).decode()
_F = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'faces.txt')).read().split()  # 88px Unsplash portraits (free license), same order as R
_IDS = ['photo-1507003211169-0a1dd7228f2d', 'photo-1580489944761-15a19d654956', 'photo-1494790108377-be9c29b29330', 'photo-1595152772835-219674b2a8a6', 'photo-1599566219227-2efe0c9b7f5f', 'photo-1566753323558-f4e0952af115']
PH = lambda pid: 'data:image/webp;base64,' + _F[_IDS.index(pid)]
# (name, place, photo, amount, settlement, logo, quote)
R = [('Marcus T.', 'Austin, TX', 'photo-1507003211169-0a1dd7228f2d', 95, 'Apple Siri', 'logos/apple.svg', 'I had no idea I was part of the Apple Siri settlement. The claim was filed before I finished my coffee.'),
     ('Priya S.', 'Columbus, OH', 'photo-1580489944761-15a19d654956', 212, 'Columbia + 3 more', 'logos/columbia.png', "Found four settlements I qualified for, including a data breach letter I'd totally forgotten about."),
     ('Danielle R.', 'Tampa, FL', 'photo-1494790108377-be9c29b29330', 64, 'GoodRx', 'logos/goodrx.png', "Easier than any form I've ever filled out. I like that it tells you up front which ones need proof."),
     ('Jordan M.', 'Denver, CO', 'photo-1595152772835-219674b2a8a6', 310, 'Bank of America', 'logos/bofa.svg', 'I tried filing on my own once and gave up halfway. This did it in a few taps.'),
     ('Alicia P.', 'Sacramento, CA', 'photo-1599566219227-2efe0c9b7f5f', 48, 'Netflix', 'logos2/netflix.svg', 'Got an email that my payout was sent and it was just there in my PayPal. Zero effort.'),
     ('Kevin L.', 'Raleigh, NC', 'photo-1566753323558-f4e0952af115', 137, 'Google', 'logos2/google.png', 'Honestly thought it was too good to be true. Two claims paid so far, a third one pending.')]
STAR = '<svg width="15" height="15" viewBox="0 0 24 24" fill="#F5B400"><path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"/></svg>'
stars = lambda: f'<span style="display: inline-flex; gap: 2px">{STAR * 5}</span>'
av = lambda r, s=52, ring='#FFFFFF': f'<img src="{PH(r[2])}" alt="" style="width: {s}px; height: {s}px; flex: none; border-radius: 50%; object-fit: cover; box-shadow: 0 0 0 3px {ring}, 0 6px 14px rgba(10,15,13,.16)">'
chip = lambda r, dark=False: (f'<span style="display: inline-flex; align-items: center; gap: 6px; padding: 4px 10px 4px 4px; border-radius: 99px; background: {"rgba(255,255,255,.1)" if dark else "#F3F6F4"}; font-size: 12px; font-weight: 700; color: {"#C9D6CF" if dark else "#43504A"}">'
                              f'<img src="{logo(r[5])}" alt="" style="width: 20px; height: 20px; border-radius: 50%; object-fit: contain; background: #FFFFFF">{r[4]}</span>')
money = lambda n: f'${n:,}'
HEADER = lambda m, c=DARK: (f'<div style="display: flex; {"flex-direction: column; gap: 10px" if m else "justify-content: space-between; align-items: flex-end"}; margin-bottom: {22 if m else 36}px">'
                            f'<h2 style="margin: 0; font-size: {30 if m else 46}px; letter-spacing: -1.4px; line-height: 1.08; color: {c}">Real people. Real payouts.</h2>'
                            f'<span style="display: inline-flex; align-items: center; gap: 8px; font-size: 15px; font-weight: 700; color: {c}">{stars()}4.8 · 2,317 reviews</span></div>')
row = lambda m, cards, w: (f'<div style="display: flex; gap: 12px; overflow-x: auto; scroll-snap-type: x mandatory; margin: 0 -16px; padding: 4px 16px 20px; scrollbar-width: none">'
                           + ''.join(f'<div style="flex: 0 0 {w}px; scroll-snap-align: center; display: flex">{c}</div>' for c in cards) + '</div>') if m else None

# ---------- R1: white cards, photo + name, mint "Received" pill ----------
def r1card(r, m):
    return (f'<div style="flex: 1; display: flex; flex-direction: column; gap: 16px; padding: 24px; border-radius: 24px; background: #FFFFFF; box-shadow: 0 1px 0 #E3EAE6, 0 14px 34px rgba(10,15,13,.07); box-sizing: border-box">'
            f'<div style="display: flex; align-items: center; gap: 12px">{av(r)}<div style="flex: 1; display: flex; flex-direction: column"><b style="font-size: 16px">{r[0]}</b><span style="font-size: 13px; color: #5B6862; font-weight: 600">{r[1]}</span></div>'
            f'<span style="display: inline-flex; align-items: center; gap: 5px; padding: 7px 11px; border-radius: 99px; background: #E3F8EE; color: {GREEN}; font-size: 14px; font-weight: 800">{ic("check", 14, 3)}{money(r[3])}</span></div>'
            f'{stars()}<p style="margin: 0; font-size: 16px; line-height: 1.55; color: #26302B; flex: 1">{r[6]}</p>'
            f'<div style="display: flex; justify-content: space-between; align-items: center">{chip(r)}<span style="font-size: 12px; color: #8A968F; font-weight: 700">Received</span></div></div>')
def v1(m):
    cards = [r1card(r, m) for r in R]
    body = row(m, cards, 300) if m else '<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px">' + ''.join(f'<div style="display: flex">{c}</div>' for c in cards) + '</div>'
    return f'<section style="background: #F3F6F4; padding: {44 if m else 80}px {16 if m else 64}px; min-height: 100%; box-sizing: border-box">{HEADER(m)}{body}</section>'

# ---------- R2: amount first, dark green cards ----------
def r2card(r, m):
    return (f'<div class="meshDark" style="flex: 1; display: flex; flex-direction: column; gap: 14px; padding: 24px; border-radius: 26px; color: #FFFFFF; box-sizing: border-box; min-height: {360 if m else 380}px">'
            f'<span style="font-size: 12px; font-weight: 800; letter-spacing: 1px; color: {MINT}">RECEIVED</span>'
            f'<span style="font-size: 54px; font-weight: 800; letter-spacing: -2px; line-height: 1">{money(r[3])}</span>{chip(r, True)}'
            f'<p style="margin: 6px 0 0; font-size: 15.5px; line-height: 1.55; color: #DCE7E1; flex: 1">"{r[6]}"</p>'
            f'<div style="display: flex; align-items: center; gap: 12px; padding-top: 14px; border-top: 1px solid rgba(255,255,255,.12)">{av(r, 44, "rgba(255,255,255,.25)")}<div style="display: flex; flex-direction: column"><b style="font-size: 15px">{r[0]}</b><span style="font-size: 12.5px; color: #A9BDB3; font-weight: 600">{r[1]}</span></div><span style="margin-left: auto">{stars()}</span></div></div>')
def v2(m):
    cards = [r2card(r, m) for r in R]
    body = row(m, cards, 300) if m else ('<div style="display: flex; gap: 16px; overflow-x: auto; padding-bottom: 8px; scrollbar-width: thin">' + ''.join(f'<div style="flex: 0 0 316px; display: flex">{c}</div>' for c in cards) + '</div>')
    tot = sum(r[3] for r in R)
    strip = f'<div style="margin-top: {8 if m else 24}px; display: flex; align-items: center; gap: 10px; font-size: 14px; font-weight: 700; color: #43504A">{ic("check", 16, 3, GREEN)}Amounts shown are what each member was paid by the settlement.</div>'
    return f'<section style="background: #FFFFFF; padding: {44 if m else 80}px {16 if m else 64}px; min-height: 100%; box-sizing: border-box">{HEADER(m)}{body}{strip}</section>'

# ---------- R3: payout notification on top of each review ----------
def r3card(r, m):
    note = (f'<div style="display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 16px; background: rgba(255,255,255,.75); backdrop-filter: blur(10px); box-shadow: 0 10px 26px rgba(10,15,13,.12)">'
            f'<span style="width: 34px; height: 34px; flex: none; border-radius: 9px; background: {DARK}; color: {MINT}; display: flex; align-items: center; justify-content: center">{ic("check", 18, 3)}</span>'
            f'<div style="flex: 1; display: flex; flex-direction: column; min-width: 0"><span style="display: flex; justify-content: space-between; font-size: 12px; color: #5B6862; font-weight: 700"><span>Claimclub</span><span>now</span></span>'
            f'<b style="font-size: 13.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{money(r[3])} sent from {r[4]}</b></div></div>')
    return (f'<div style="flex: 1; display: flex; flex-direction: column; gap: 16px; padding: 18px; border-radius: 26px; background: linear-gradient(160deg, #E3F8EE, #F3F6F4 60%); box-sizing: border-box">{note}'
            f'<p style="margin: 4px 6px 0; font-size: 17px; line-height: 1.5; font-weight: 600; color: #1A231F; flex: 1">"{r[6]}"</p>'
            f'<div style="display: flex; align-items: center; gap: 12px; margin: 0 6px 4px">{av(r, 46)}<div style="display: flex; flex-direction: column"><b style="font-size: 15px">{r[0]}</b><span style="font-size: 12.5px; color: #5B6862; font-weight: 600">{r[1]} · {stars()}</span></div></div></div>')
def v3(m):
    cards = [r3card(r, m) for r in R]
    if m: body = row(m, cards, 310)
    else:
        cols = [cards[0::3], cards[1::3], cards[2::3]]
        body = '<div style="display: flex; gap: 16px; align-items: flex-start">' + ''.join(f'<div style="flex: 1; display: flex; flex-direction: column; gap: 16px; margin-top: {k * 34}px">{"".join(cs)}</div>' for k, cs in enumerate(cols)) + '</div>'
    return f'<section style="background: #FFFFFF; padding: {44 if m else 80}px {16 if m else 64}px; min-height: 100%; box-sizing: border-box">{HEADER(m)}{body}</section>'

VARIANTS = [('RevR1', 'Reviews draft · 1 · Photo, name and a mint payout pill', v1), ('RevR2', 'Reviews draft · 2 · Payout amount first, dark cards', v2),
            ('RevR3', 'Reviews draft · 3 · Payout notification on top of each review', v3)]

def build():
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    y0 = max(b['y'] + b['h'] for k, b in c['boards'].items() if not k.startswith('RevR')) + 260
    c['notes']['tRV'] = {'x': 0, 'y': y0, 'text': 'Reviews · 3 designs with photo and payout (placeholder people and amounts, not for the live site)', 'kind': 'title1', 'maxW': 3900, 'w': 240}
    if 'tRV' not in c['noteOrder']: c['noteOrder'].append('tRV')
    for k, (name, title, fn) in enumerate(VARIANTS):
        page = (f'<div style="width: 1926px; height: 980px; box-sizing: border-box; padding: 24px; background: #E7ECE9; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 14px">'
                f'<div style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #43504A">{title.upper()}</div><div style="display: flex; gap: 48px; align-items: flex-start">'
                f'<div class="scroll" style="width: 1440px; height: 900px; flex: none; overflow-y: auto; border-radius: 18px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{fn(False)}</div>'
                f'<div class="scroll" style="width: 390px; height: 844px; flex: none; overflow-y: auto; border-radius: 28px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{fn(True)}</div></div></div>\n</x-dc>\n')
        open(os.path.join(OUT, name + '.dc.html'), 'w').write(HEAD % title + page + JS)
        c['boards'][name + '.dc.html'] = {'x': (k % 2) * 2006, 'y': y0 + 220 + (k // 2) * 1060, 'w': 1926, 'h': 980, 'is_interactive': True, 'title': title}
        if name + '.dc.html' not in c['order']: c['order'].append(name + '.dc.html')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w'))
    print('built', [v[0] for v in VARIANTS], 'y0', y0)

if __name__ == '__main__':
    build()
