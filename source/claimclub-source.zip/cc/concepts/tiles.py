# Square settlement icons for the member app lists (Nov 15 2026), built from the same brand data as the homepage cards
# (cardArt() in src/landing.js, written by cardart.py): Simple Icons mark on the brand gradient, brand initial on the
# brand gradient, or the Lucide category icon on the category color. Writes cc/tiles/<id>.svg, registers them in
# /tmp/blobmap.json and writes the tiles() table into make.py; logo() in make.py uses it before the old logo files.
import json, re, hashlib, os
CC = '/home/claude/cc'; BLOBMAP = '/tmp/blobmap.json'
land = open(f'{CC}/src/landing.js').read()
ART = json.loads(re.search(r'  cardArt\(\) \{ return (\{.*?\}); \}\n', land, re.S).group(1))
P = dict(re.findall(r"\n\s+(\w+): '(<.*?)',?(?=\n)", land[land.index('  catIcon(cat, white) {'):land.index("    if (white) return")]))
SETS = {d['id']: d for d in json.load(open(f'{CC}/concepts/sets.json'))}
WORD = {}
exec(re.search(r'^WORD = \{.*?^\}', open(f'{CC}/concepts/cardart.py').read(), re.S | re.M).group(0), {}, ns := {}); WORD = {k: v for k, v in ns['WORD'].items() if v}
stops = lambda bg: re.findall(r'(#[0-9A-Fa-f]{6}) (\d+)%', bg)
def grad(bg, gid='g'):
    st = ''.join(f'<stop offset="{p}%" stop-color="{c}"/>' for c, p in stops(bg))
    return f'<defs><radialGradient id="{gid}" cx=".15" cy="0" r="1.35">{st}</radialGradient></defs><rect width="64" height="64" rx="16" fill="url(#{gid})"/>'
def initials(t):
    w = [x for x in re.split(r'[\s&.\-]+', t) if x and x[0].isalnum()]
    return (w[0][0] + w[1][0]).upper() if len(w) > 1 and len(w[0]) <= 3 else w[0][0].upper() if w else '?'
CATC = {'privacy': '#3B4BD8', 'health': '#C9375F', 'products': '#D9681A', 'apps': '#7340E0', 'bank': '#0E6B5C', 'auto': '#1F64B0', 'invest': '#12805C', 'arb': '#475166'}
def rgb(h): h = h.lstrip('#'); return [int(h[i:i + 2], 16) for i in (0, 2, 4)]
def mix(a, b, t): A, B = rgb(a), rgb(b); return '#' + ''.join(f'{max(0, min(255, round(A[i] + (B[i] - A[i]) * t))):02X}' for i in range(3))
for k, d in SETS.items():  # local settlements are not on the homepage, so cardArt() has none: category tile
    if k not in ART: c = CATC.get(d.get('cat'), '#475166'); ART[k] = {'k': 'c', 'bg': f'radial-gradient(x, {mix(c, "#FFFFFF", .18)} 0%, {c} 52%, {mix(c, "#000000", .28)} 100%)'}
out = {}
for k, a in ART.items():
    if a['k'] == 'm':
        f = open(f'{CC}/marks/{k}.svg').read()
        vb = [float(x) for x in re.search(r'viewBox="([^"]+)"', f).group(1).split()]; inner = re.search(r'<svg[^>]*>(.*)</svg>', f, re.S).group(1)
        box = 38 if vb[2] / vb[3] < 1.6 else 46  # wide wordmarks get more width
        body = f'<svg x="{(64 - box) / 2}" y="{(64 - box) / 2}" width="{box}" height="{box}" viewBox="{" ".join(map(str, vb))}" preserveAspectRatio="xMidYMid meet">{inner}</svg>'
        svg = grad(a['bg']) + body
    elif a['k'] == 't':
        base, text, tc = WORD[k]; ch = initials(text); fs = 30 if len(ch) == 1 else 24
        svg = grad(a['bg']) + f'<text x="32" y="{32 + fs * .36:.1f}" text-anchor="middle" font-family="Helvetica Neue,Helvetica,Arial,sans-serif" font-weight="800" font-size="{fs}" letter-spacing="-0.5" fill="{tc}">{ch}</text>'
    else:
        ic = P.get(SETS[k].get('cat'), P['products'])
        svg = grad(a['bg']) + f'<g transform="translate(17 17) scale(1.25)" fill="none" stroke="#FFFFFF" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">{ic}</g>'
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">{svg}</svg>'
    fn = f'tiles/{k}.svg'; open(f'{CC}/{fn}', 'w').write(svg); out[k] = (fn, hashlib.md5(svg.encode()).hexdigest(), a['k'])
bm = json.load(open(BLOBMAP))
for b_ in [b_ for b_, f in bm.items() if f.startswith('tiles/')]: del bm[b_]
for k, (fn, h, _) in out.items(): bm[h] = fn
json.dump(bm, open(BLOBMAP, 'w'))
# Use a tile when: the brand has a vector mark (matches the homepage cards), there is no real logo file (the old
# green letter placeholder), or the logo file is weak (tiny wordmark, blurry photo). Other real logo files stay.
mk0 = open(f'{CC}/concepts/make.py').read(); li = mk0.index('  logos() {'); lj = mk0.index('\n  }', li)
HAVE = set(re.findall(r"['\"]?([\w-]+)['\"]?\s*:\s*['\"]/_blob/", mk0[li:lj]))
WEAK = {'equifax', 'equifax_inq', 'equinox', 'venetian', 'squatch'}
T = {k: '/_blob/' + h + '?t' for k, (fn, h, kind) in out.items() if kind == 'm' or k not in HAVE or k in WEAK}  # ?t lets CSS drop the white logo frame
print('tiles used', len(T), 'real logos kept', len(HAVE - set(T)))
mk = f'{CC}/concepts/make.py'; s = open(mk).read()
line = '  tiles() { return ' + json.dumps(T, separators=(',', ':')) + '; }\n'
if '  tiles() {' in s: s = re.sub(r'  tiles\(\) \{ return .*?; \}\n', lambda m: line, s, count=1)
else: s = s.replace('  logos() {', line + '  logos() {', 1)
open(mk, 'w').write(s)
from collections import Counter; print(Counter(v[2] for v in out.values()), len(out))
