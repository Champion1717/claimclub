# Homepage canvas page (Nov 22 2026): HomeD / HomeM are 1:1 copies of the live homepage source (project/LandingG2*.dc.html,
# which site/build.py turns into d/ and m/index.html). /tiles/<id>.svg paths are inlined so the logos show on the canvas.
# Rerun after every homepage rebuild, then publish project/HomeD.dc.html and HomeM.dc.html.
import re, os, base64
P = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'project'); T = os.path.join(P, '..', 'tiles')
def inline(h):
    return re.sub(r'/tiles/([\w-]+)\.svg', lambda m: 'data:image/svg+xml;base64,' + base64.b64encode(open(os.path.join(T, m.group(1) + '.svg'), 'rb').read()).decode(), h)
for src, dst, t in (('LandingG2', 'HomeD', 'Homepage · desktop (live)'), ('LandingG2M', 'HomeM', 'Homepage · mobile (live)')):
    h = inline(open(os.path.join(P, src + '.dc.html')).read())
    h = re.sub(r'<title>[^<]*</title>', f'<title>Claimclub · {t}</title>', h, 1)
    open(os.path.join(P, dst + '.dc.html'), 'w').write(h)
print('ok')
