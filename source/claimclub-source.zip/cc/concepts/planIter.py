# Three plan iterations for offer E (Nov 21 2026, design only). Same three-card layout (tierE e1), different packaging:
#   OfferP1 Free / Plus / Priority (the plan as proposed)
#   OfferP2 Pay once / Plus / Priority ($19.99 one time as the entry tier)
#   OfferP3 Speed tiers: every tier files everything, they differ by filing speed and extras
import os
import tierE as E
from tierE import HEAD, JS, OUT, h, sub, summary, desk, mob, mint_btn, ic, MUTE, DARK

IT = {
 'OfferP1': dict(title='FREE, PLUS, PRIORITY', desc='The plan as proposed. Basic is free (guides, you file it yourself) to catch people who would leave; Plus is the main sale; Priority sells speed plus Claim refunds, subscriptions and notice code finding.',
   head='Pick how we file your 6 claims', subh='Start free. Upgrade or cancel anytime.',
   T=[dict(k='basic', name='Basic', price='Free', per='', sub='Check and file it yourself', btn='Continue free', icon='book', short='Guides, you file it yourself'),
      dict(k='plus', name='Plus', price='$49.99', per='/year', sub='7 days free, then $4.17 a month', btn='Start free trial', icon='check', pop=True),
      dict(k='pri', name='Priority', price='$99.99', per='/year', sub='7 days free, then $8.33 a month', btn='Start Priority free', icon='zap', short='Filed in 24 hours, refunds, notice codes')],
   ROWS=[('Your 6 matched claims', 'Guides, you file', 'We file them', 'We file them'), ('New claims as they open', 'Alert only', 'Filed for you', 'Filed for you'),
         ('All 279 settlements + local', 'Preview', True, True), ('Filing time', False, 'Within 7 days', 'Within 24 hours'),
         ('Claim refunds + subscriptions', False, False, True), ('We find your notice codes', False, False, True), ('Support', 'Email', 'Email', 'Priority')],
   cta='Start my free 7-day trial', fine='$0 today. Then $49.99 a year unless you cancel.'),
 'OfferP2': dict(title='PAY ONCE, PLUS, PRIORITY', desc='No free tier. The entry option is $19.99 once to file just these 6 claims, so every buyer pays something. Plus and Priority stay the same. Good if free users would only cost filing time and never upgrade.',
   head='Pick how we file your 6 claims', subh='You keep 100% of every payout on every plan.',
   T=[dict(k='basic', name='File once', price='$19.99', per=' once', sub='These 6 claims, nothing renews', btn='Pay $19.99 once', icon='book', short='These 6 claims, nothing renews'),
      dict(k='plus', name='Plus', price='$49.99', per='/year', sub='7 days free, then $4.17 a month', btn='Start free trial', icon='check', pop=True),
      dict(k='pri', name='Priority', price='$99.99', per='/year', sub='7 days free, then $8.33 a month', btn='Start Priority free', icon='zap', short='Filed in 24 hours, refunds, notice codes')],
   ROWS=[('Your 6 matched claims', 'We file them', 'We file them', 'We file them'), ('New claims as they open', False, 'Filed for you', 'Filed for you'),
         ('All 279 settlements + local', False, True, True), ('Filing time', 'Within 14 days', 'Within 7 days', 'Within 24 hours'),
         ('Claim refunds + subscriptions', False, False, True), ('We find your notice codes', False, False, True), ('Support', 'Email', 'Email', 'Priority')],
   cta='Start my free 7-day trial', fine='$0 today. Then $49.99 a year unless you cancel.'),
 'OfferP3': dict(title='SPEED TIERS', desc='Every plan files all your claims and every new one. The tiers differ only in how fast we file and the extras. Cheapest yearly entry ($29.99), so the trial looks easy, and the upgrade story is simple: faster.',
   head='How fast should we file?', subh='Every plan files all 6 claims and every new one you qualify for.',
   T=[dict(k='basic', name='Standard', price='$29.99', per='/year', sub='7 days free, then $2.50 a month', btn='Start Standard free', icon='book', short='Filed within 14 days'),
      dict(k='plus', name='Fast', price='$49.99', per='/year', sub='7 days free, then $4.17 a month', btn='Start free trial', icon='check', pop=True),
      dict(k='pri', name='Instant', price='$99.99', per='/year', sub='7 days free, then $8.33 a month', btn='Start Instant free', icon='zap', short='Filed in 24 hours, refunds, notice codes')],
   ROWS=[('Your 6 matched claims', 'We file them', 'We file them', 'We file them'), ('New claims as they open', 'Filed for you', 'Filed for you', 'Filed for you'),
         ('Filing time', 'Within 14 days', 'Within 3 days', 'Within 24 hours'), ('All 279 settlements + local', 'Nationwide only', True, True),
         ('Claim refunds + subscriptions', False, False, True), ('We find your notice codes', False, True, True), ('Support', 'Email', 'Email', 'Priority')],
   cta='Start my free 7-day trial', fine='$0 today. Then $49.99 a year unless you cancel.'),
}

def build(v):
    E.T, E.ROWS = v['T'], v['ROWS']
    T = v['T']
    d = desk(h(v['head']) + sub(v['subh']) + summary()
             + f'<div style="display: flex; gap: 14px; align-items: stretch; margin-top: 8px">{"".join(E.card(t, i) for i, t in enumerate(T))}</div>'
             + f'<span style="font-size: 12px; font-weight: 600; color: {MUTE}; text-align: center">{E.FINE}</span>', w=780)
    m = mob(h(v['head'], 25, False) + summary(True) + E.mrow(T[1], True) + E.mrow(T[2]) + E.mrow(T[0]),
            mint_btn(f'{ic("lock", 16, DARK, 2.4)}{v["cta"]}', 54) + f'<span style="font-size: 12px; font-weight: 600; color: {MUTE}; text-align: center">{v["fine"]}</span>')
    return d, m

if __name__ == '__main__':
    for i, (name, v) in enumerate(IT.items(), 1):
        d, m = build(v)
        prices = ' · '.join(f'{t["name"]} {t["price"]}{t["per"]}' for t in v['T'])
        page = ('<div data-board style="width: 1840px; height: 1080px; box-sizing: border-box; padding: 36px 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 26px">'
                f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #12805C">OFFER E · PLAN ITERATION {i} · {v["title"]}</span>'
                f'<span style="font-size: 16px; color: #43504A; max-width: 1640px; line-height: 1.5; font-weight: 600">{v["desc"]}</span>'
                f'<span style="font-size: 13px; color: #8A968F; font-weight: 600">Draft, not live. {prices}. Sample member and claims.</span></div>'
                f'<div style="display: flex; gap: 46px; align-items: flex-start">{d}{m}</div></div>\n</x-dc>\n')
        open(os.path.join(OUT, f'{name}.dc.html'), 'w').write(HEAD % f'Offer E plan {i}' + page + JS.replace('"width":1926,"height":980', '"width":1840,"height":1080'))
    print('ok')
