# Offer E: three plans (Basic free, Plus $49.99/yr Most popular, Priority $99.99/yr), design only (Nov 21 2026).
# Writes OfferE1 (three cards), OfferE2 (comparison table), OfferE3 (plan list, picked plan opens) into ../project.
import os, io, contextlib
from how4 import HEAD, JS, OUT
from perksD import ic, LU, INK, MUTE, LINE, MINT, GREEN, DARK
from choiceD import mint_btn
with contextlib.redirect_stdout(io.StringIO()):
    from flowB import h, sub, chip, summary, desk, mob

LU.update({'zap': 'M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z',
           'book': 'M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20',
           'star': 'M11.5 2.3a.5.5 0 0 1 .9 0l2.3 4.7a2 2 0 0 0 1.6 1.1l5.2.8a.5.5 0 0 1 .3.9l-3.8 3.7a2 2 0 0 0-.6 1.8l.9 5.2a.5.5 0 0 1-.8.5l-4.6-2.5a2 2 0 0 0-1.9 0l-4.6 2.5a.5.5 0 0 1-.8-.5l.9-5.2a2 2 0 0 0-.6-1.8L2.4 9.8a.5.5 0 0 1 .3-.9l5.2-.8a2 2 0 0 0 1.6-1.1z'})

# feature rows: (label, basic, plus, priority); True/False or text
ROWS = [('Your 6 matched claims', 'Guides, you file', 'We file them', 'We file them'),
        ('New claims as they open', 'Alert only', 'Filed for you', 'Filed for you'),
        ('All 279 settlements + local', 'Preview', True, True),
        ('Filing time', False, 'Within 7 days', 'Within 24 hours'),
        ('Claim refunds + subscriptions', False, False, True),
        ('We find your notice codes', False, False, True),
        ('Support', 'Email', 'Email', 'Priority')]
T = [dict(k='basic', name='Basic', price='Free', per='', sub='Check and file it yourself', btn='Continue free', icon='book'),
     dict(k='plus', name='Plus', price='$49.99', per='/year', sub='7 days free, then $4.17 a month', btn='Start my free 7-day trial', icon='check', pop=True),
     dict(k='pri', name='Priority', price='$99.99', per='/year', sub='7 days free, then $8.33 a month', btn='Start Priority free', icon='zap')]
FINE = 'Faster filing gets your claims in before deadlines. Payouts still come when each settlement pays out.'

def val(v, dark=False, sz=14):
    if v is True: return ic('check', 18, MINT if dark else GREEN, 3)
    if v is False: return ic('x', 15, '#8FB5A5' if dark else '#B5BFBA', 2.6)
    return f'<span style="font-size: {sz}px; font-weight: 700">{v}</span>'
def row(label, v, dark=False, sz=14):
    off = v is False
    col = ('#8FB5A5' if dark else '#A3AEA8') if off else ('#FFFFFF' if dark else INK)
    mark = ic('x', 12, '#8FB5A5' if dark else '#A3AEA8', 2.6) if off else ic('check', 13, MINT if dark else GREEN, 3)
    bg = ('rgba(255,255,255,.08)' if dark else '#F1F4F2') if off else ('rgba(61,220,151,.18)' if dark else '#E9F6EF')
    txt = label if v is True or v is False else f'{label}: <b style="font-weight: 800">{v}</b>'
    return (f'<div style="display: flex; align-items: flex-start; gap: 9px; font-size: {sz}px; font-weight: 600; line-height: 1.35; color: {col}; {"text-decoration: line-through" if off else ""}">'
            f'<span style="width: 20px; height: 20px; flex: none; border-radius: 99px; background: {bg}; display: flex; align-items: center; justify-content: center">{mark}</span><span>{txt}</span></div>')
def btn(t, kind, hh=48, fs=15):
    if kind == 'plus': return mint_btn(t, hh, fs)
    if kind == 'pri': return f'<div style="height: {hh}px; flex: none; border-radius: 99px; background: #FFFFFF; color: {INK}; display: flex; align-items: center; justify-content: center; font-size: {fs}px; font-weight: 800">{t}</div>'
    return f'<div style="height: {hh}px; flex: none; border-radius: 99px; box-shadow: inset 0 0 0 1.5px #C9D3CD; background: #FFFFFF; color: {INK}; display: flex; align-items: center; justify-content: center; font-size: {fs}px; font-weight: 800">{t}</div>'
def style(t):
    if t['k'] == 'pri': return 'background: linear-gradient(165deg, #23302B, #0E1512); color: #FFFFFF; box-shadow: 0 18px 40px rgba(10,15,13,.25)', True
    if t['k'] == 'plus': return f'background: #FFFFFF; color: {INK}; box-shadow: inset 0 0 0 2.5px {MINT}, 0 18px 40px rgba(18,128,92,.18)', False
    return f'background: #FFFFFF; color: {INK}; box-shadow: inset 0 0 0 1.5px {LINE}', False
def head(t, dark, big=36):
    tag = chip('MOST POPULAR', MINT, DARK) if t.get('pop') else (chip('FASTEST', '#3A4A43', '#E3ECE7') if t['k'] == 'pri' else '')
    return (f'<div style="display: flex; justify-content: space-between; align-items: center; gap: 8px"><span style="display: flex; align-items: center; gap: 8px; font-size: 15px; font-weight: 800">'
            f'<span style="width: 28px; height: 28px; border-radius: 9px; background: {"rgba(61,220,151,.16)" if dark else "#E9F6EF"}; display: flex; align-items: center; justify-content: center">{ic(t["icon"], 16, MINT if dark else GREEN, 2.4)}</span>{t["name"]}</span>{tag}</div>'
            f'<div style="display: flex; align-items: baseline; gap: 4px"><b style="font-size: {big}px; letter-spacing: -1.5px">{t["price"]}</b><span style="font-size: 15px; font-weight: 700; color: {"#9FC3B4" if dark else MUTE}">{t["per"]}</span></div>'
            f'<span style="font-size: 13px; font-weight: 600; color: {"#C9D6CF" if dark else MUTE}; margin-top: -6px">{t["sub"]}</span>')

# ---------- E1: three cards ----------
def card(t, i, m=False):
    st, dark = style(t)
    lst = ''.join(row(r[0], r[i + 1], dark, 13) for r in ROWS)
    return (f'<div style="flex: 1; min-width: 0; border-radius: 22px; padding: 20px; display: flex; flex-direction: column; gap: 12px; {st}{"; transform: translateY(-10px)" if t.get("pop") and not m else ""}">'
            + head(t, dark) + f'<div style="height: 1px; background: {"rgba(255,255,255,.12)" if dark else LINE}"></div><div style="display: flex; flex-direction: column; gap: 9px; flex: 1">{lst}</div>'
            + btn(t['btn'] if t['k'] != 'plus' else 'Start free trial', t['k'], 46, 14) + '</div>')
def mrow(t, sel=False):
    st, dark = style(t)
    i = [x['k'] for x in T].index(t['k'])
    body = ''
    if sel: body = f'<div style="height: 1px; background: {LINE}"></div><div style="display: flex; flex-direction: column; gap: 8px">' + ''.join(row(r[0], r[i + 1], dark, 13) for r in ROWS[:5]) + '</div>'
    if not sel:
        return (f'<div style="border-radius: 18px; padding: 14px 16px; display: flex; align-items: center; gap: 12px; {st}">'
                f'<span style="width: 22px; height: 22px; flex: none; border-radius: 99px; box-shadow: inset 0 0 0 2px {"#5E6E67" if dark else "#C9D3CD"}"></span>'
                f'<span style="flex: 1; display: flex; flex-direction: column"><b style="font-size: 15px">{t["name"]}</b><span style="font-size: 12.5px; font-weight: 600; color: {"#C9D6CF" if dark else MUTE}">{"Filed in 24 hours, refunds, notice codes" if t["k"] == "pri" else "Guides, you file it yourself"}</span></span>'
                f'<b style="font-size: 17px">{t["price"]}<span style="font-size: 12px; color: {"#9FC3B4" if dark else MUTE}">{t["per"]}</span></b></div>')
    return (f'<div style="border-radius: 20px; padding: 16px; display: flex; flex-direction: column; gap: 10px; {st}">'
            f'<div style="display: flex; align-items: center; gap: 12px"><span style="width: 22px; height: 22px; flex: none; border-radius: 99px; background: {GREEN}; display: flex; align-items: center; justify-content: center">{ic("check", 13, "#FFFFFF", 3.2)}</span>'
            f'<span style="flex: 1; display: flex; flex-direction: column"><span style="display: flex; align-items: center; gap: 6px"><b style="font-size: 15px">{t["name"]}</b>{chip("MOST POPULAR", MINT, DARK)}</span><span style="font-size: 12.5px; font-weight: 600; color: {MUTE}">{t["sub"]}</span></span>'
            f'<b style="font-size: 17px">{t["price"]}<span style="font-size: 12px; color: {MUTE}">{t["per"]}</span></b></div>' + body + '</div>')
def e1():
    d = desk(h('Pick how we file your 6 claims') + sub('Start free. Upgrade or cancel anytime.') + summary()
             + f'<div style="display: flex; gap: 14px; align-items: stretch; margin-top: 8px">{"".join(card(t, i) for i, t in enumerate(T))}</div>'
             + f'<span style="font-size: 12px; font-weight: 600; color: {MUTE}; text-align: center">{FINE}</span>', w=780)
    m = mob(h('Pick how we file your 6 claims', 25, False) + summary(True) + mrow(T[1], True) + mrow(T[2]) + mrow(T[0]),
            mint_btn(f'{ic("lock", 16, DARK, 2.4)}Start my free 7-day trial', 54) + f'<span style="font-size: 12px; font-weight: 600; color: {MUTE}; text-align: center">$0 today. Then $49.99 a year unless you cancel.</span>')
    return d, m

# ---------- E2: comparison table ----------
def e2():
    cols = '1.5fr 1fr 1.15fr 1fr'
    def cell(v, k):
        bg = '#F2FBF6' if k == 1 else ('#16201C' if k == 2 else 'transparent')
        c = '#FFFFFF' if k == 2 else INK
        return f'<div style="padding: 9px 10px; background: {bg}; color: {c}; display: flex; align-items: center; justify-content: center; text-align: center">{val(v, k == 2, 13)}</div>'
    hd = '<div></div>' + ''.join(
        f'<div style="padding: 14px 10px 10px; display: flex; flex-direction: column; align-items: center; gap: 4px; border-radius: 16px 16px 0 0; background: {"#F2FBF6" if i == 1 else ("#16201C" if i == 2 else "transparent")}; color: {"#FFFFFF" if i == 2 else INK}">'
        + (chip('MOST POPULAR', MINT, DARK) if i == 1 else (chip('FASTEST', '#3A4A43', '#E3ECE7') if i == 2 else '<span style="height: 23px"></span>'))
        + f'<b style="font-size: 15px">{t["name"]}</b><b style="font-size: 26px; letter-spacing: -1px">{t["price"]}<span style="font-size: 12px; color: {MUTE if i != 2 else "#9FC3B4"}">{t["per"]}</span></b></div>' for i, t in enumerate(T))
    body = ''.join(f'<div style="padding: 9px 4px; font-size: 13.5px; font-weight: 700; display: flex; align-items: center; border-top: 1px solid {LINE}">{r[0]}</div>' + ''.join(cell(r[k + 1], k) for k in range(3)) for r in ROWS)
    foot = '<div></div>' + ''.join(f'<div style="padding: 12px 8px 14px; background: {"#F2FBF6" if i == 1 else ("#16201C" if i == 2 else "transparent")}; border-radius: 0 0 16px 16px">{btn(["Continue free", "Start free trial", "Go Priority"][i], t["k"], 42, 13.5)}</div>' for i, t in enumerate(T))
    tbl = f'<div style="display: grid; grid-template-columns: {cols}; background: #FFFFFF; border-radius: 20px; padding: 6px 14px; box-shadow: inset 0 0 0 1.5px {LINE}">{hd}{body}{foot}</div>'
    d = desk(h('Compare plans') + summary() + tbl + f'<span style="font-size: 12px; font-weight: 600; color: {MUTE}; text-align: center">Plus and Priority start with 7 days free. {FINE}</span>', w=760)
    # phone: tabs, picked tier shows its rows
    tabs = f'<div style="display: flex; padding: 4px; border-radius: 99px; background: #E4EAE6">' + ''.join(
        f'<span style="flex: 1; height: 40px; border-radius: 99px; display: flex; align-items: center; justify-content: center; font-size: 13.5px; font-weight: 800; {"background: #FFFFFF; box-shadow: 0 2px 8px rgba(10,15,13,.12); color: " + INK if t["k"] == "pri" else "color: " + MUTE}">{t["name"]}</span>' for t in T) + '</div>'
    st, _ = style(T[2])
    pc = (f'<div style="border-radius: 22px; padding: 18px; display: flex; flex-direction: column; gap: 12px; {st}">' + head(T[2], True, 40)
          + '<div style="height: 1px; background: rgba(255,255,255,.12)"></div><div style="display: flex; flex-direction: column; gap: 9px">' + ''.join(row(r[0], r[3], True, 13.5) for r in ROWS) + '</div></div>')
    m = mob(h('Compare plans', 25, False) + tabs + pc,
            f'<div style="height: 54px; flex: none; border-radius: 99px; background: {INK}; color: #FFFFFF; display: flex; align-items: center; justify-content: center; gap: 8px; font-size: 16px; font-weight: 800">{ic("zap", 16, MINT, 2.4)}Start Priority free for 7 days</div>'
            + f'<span style="font-size: 12px; font-weight: 600; color: {MUTE}; text-align: center">$0 today. Then $99.99 a year unless you cancel.</span>')
    return d, m

# ---------- E3: one plan list, picked plan opens, upgrade nudge ----------
def e3():
    def li(t, sel, m=False):
        st, dark = style(t) if sel else (f'background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}', False)
        i = [x['k'] for x in T].index(t['k'])
        dot = (f'<span style="width: 22px; height: 22px; flex: none; border-radius: 99px; background: {GREEN}; display: flex; align-items: center; justify-content: center">{ic("check", 13, "#FFFFFF", 3.2)}</span>' if sel
               else f'<span style="width: 22px; height: 22px; flex: none; border-radius: 99px; box-shadow: inset 0 0 0 2px #C9D3CD"></span>')
        tag = chip('MOST POPULAR', MINT, DARK) if t.get('pop') else (chip('FASTEST', '#FFF4DB', '#8A5A00') if t['k'] == 'pri' else '')
        out = (f'<div style="border-radius: 18px; padding: {14 if m else 16}px {16 if m else 18}px; display: flex; flex-direction: column; gap: 10px; {st}">'
               f'<div style="display: flex; align-items: center; gap: 12px">{dot}<span style="flex: 1; display: flex; flex-direction: column"><span style="display: flex; align-items: center; gap: 6px"><b style="font-size: 16px">{t["name"]}</b>{tag}</span>'
               f'<span style="font-size: 12.5px; font-weight: 600; color: {MUTE}">{t["sub"]}</span></span><b style="font-size: 19px">{t["price"]}<span style="font-size: 12px; color: {MUTE}">{t["per"]}</span></b></div>')
        if sel:
            out += f'<div style="height: 1px; background: {LINE}"></div><div style="display: {"flex" if m else "grid"}; {"flex-direction: column" if m else "grid-template-columns: 1fr 1fr"}; gap: 8px">' + ''.join(row(r[0], r[i + 1], False, 13) for r in ROWS[:6 if not m else 4]) + '</div>'
        return out + '</div>'
    nudge = (f'<div style="display: flex; align-items: center; gap: 12px; padding: 12px 14px; border-radius: 16px; background: #FFF8E6; box-shadow: inset 0 0 0 1.5px #F4E2B0">'
             f'<span style="width: 32px; height: 32px; flex: none; border-radius: 10px; background: #FFE9A8; display: flex; align-items: center; justify-content: center">{ic("zap", 17, "#8A5A00", 2.4)}</span>'
             f'<span style="flex: 1; font-size: 13px; font-weight: 600; color: #5C4300; line-height: 1.4"><b>2 of your claims close in under 30 days.</b> Priority files them within 24 hours. +$4.17 a month.</span>'
             f'<span style="font-size: 13.5px; font-weight: 800; color: #8A5A00; white-space: nowrap">Switch{ic("right", 14, "#8A5A00", 2.6)}</span></div>')
    d = desk(h('Choose your plan') + summary() + li(T[1], True) + li(T[2], False) + li(T[0], False) + nudge
             + mint_btn(f'{ic("lock", 16, DARK, 2.4)}Start my free 7-day trial', 56)
             + f'<span style="font-size: 12px; font-weight: 600; color: {MUTE}; text-align: center">$0 today. Then $49.99 a year unless you cancel.</span>', w=660)
    m = mob(h('Choose your plan', 25, False) + li(T[1], True, True) + li(T[2], False, True) + li(T[0], False, True) + nudge.replace('Switch' + ic("right", 14, "#8A5A00", 2.6), ''),
            mint_btn(f'{ic("lock", 16, DARK, 2.4)}Start my free 7-day trial', 54) + f'<span style="font-size: 12px; font-weight: 600; color: {MUTE}; text-align: center">$0 today. Then $49.99 a year unless you cancel.</span>')
    return d, m

BOARDS = {
    'OfferE1': ('THREE CARDS', 'Basic, Plus and Priority side by side; Plus is raised and marked Most popular, Priority is the dark card. Phones: Plus open on top, Priority and Basic folded under it.', e1),
    'OfferE2': ('COMPARISON TABLE', 'One table with every feature by plan and a button under each column. Phones: a Basic | Plus | Priority switch over one card (Priority shown).', e2),
    'OfferE3': ('PLAN LIST WITH NUDGE', 'One list, Plus picked and open. A yellow nudge uses the member\'s own claims ("2 close in under 30 days") to suggest Priority.', e3),
}
if __name__ == '__main__':
    for name, (title, desc, fn) in BOARDS.items():
        d, m = fn()
        hgt = 1080
        page = ('<div data-board style="width: 1840px; height: %dpx; box-sizing: border-box; padding: 36px 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 26px">' % hgt
                + f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #12805C">OFFER E · THREE PLANS · {name[-1]} {title}</span>'
                f'<span style="font-size: 16px; color: #43504A; max-width: 1640px; line-height: 1.5; font-weight: 600">{desc}</span>'
                f'<span style="font-size: 13px; color: #8A968F; font-weight: 600">Draft, not live. Basic free (guides, you file), Plus $49.99 a year (7 days free), Priority $99.99 a year (7 days free, filed in 24 hours, refunds and subscriptions, notice codes). Sample member and claims.</span></div>'
                f'<div style="display: flex; gap: 46px; align-items: flex-start">{d}{m}</div></div>\n</x-dc>\n')
        open(os.path.join(OUT, f'{name}.dc.html'), 'w').write(HEAD % f'Offer E {name[-1]} {title.title()}' + page + JS.replace('"width":1926,"height":980', '"width":1840,"height":%d' % hgt))
    print('ok')
