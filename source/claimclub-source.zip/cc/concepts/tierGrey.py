# Plan page, Standard toned down (Nov 21 2026, design only). Henry: default to Fast, and make Standard grey and less appealing.
# Board OfferGrey: Fast picked (default), Standard picked, Priority picked. Standard moves to the bottom as a small grey card.
import os, json
from tierGm2 import P, FOOT, li, price, pill, radio, board
from tierGm4 import lic, SUB
from tierE import mob, h, ic, INK, MUTE, LINE, MINT, GREEN, DARK, OUT

GREY, GTXT = '#8A968F', '#6B7671'
FE = {'fast': ['All 184 nationwide claims', 'All 5 of your claims', 'Reminders on new claims', 'Notified when you get paid'],
      'pri': ['All 279 claims, incl. local', 'New claims filed for you', 'First look at new claims', 'Claim refunds', 'Subscription Manager']}
ICN = {'std': 'calendar-days', 'fast': 'gauge', 'pri': 'rocket'}

def big(k, pick):
    p = P[k]; dark = k == 'pri'; sel = k == pick
    ring = (f'inset 0 0 0 2px {MINT}, 0 12px 26px rgba(18,128,92,.16)' if sel and not dark else f'inset 0 0 0 2px {MINT}, 0 12px 26px rgba(10,15,13,.22)' if sel
            else ('0 12px 26px rgba(10,15,13,.18)' if dark else f'inset 0 0 0 1px {LINE}'))
    fg = '#FFFFFF' if dark else INK; mu = '#9FC3B4' if dark else MUTE
    num, unit = p['speed'].split(' ')
    blk = ('background: ' + MINT + '; color: ' + DARK) if sel else ('background: rgba(61,220,151,.16); color: #FFFFFF' if dark else 'background: #F1F4F2; color: ' + INK)
    tag = pill(p['tag'], MINT, DARK) if k == 'fast' else pill(p['tag'], 'rgba(61,220,151,.18)', MINT)
    feats = ''.join(li(f, MINT if dark else GREEN, '#E6EEEA' if dark else INK, 12.5) for f in FE[k])
    return (f'<div style="border-radius: 18px; padding: 12px; background: {DARK if dark else "#FFFFFF"}; box-shadow: {ring}; color: {fg}; display: flex; gap: 12px; align-items: stretch">'
            f'<div style="width: 76px; flex: none; border-radius: 12px; {blk}; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 1px">'
            f'{lic(ICN[k], 22, DARK if sel else (MINT if dark else MUTE))}<b style="font-size: 27px; letter-spacing: -1px; line-height: 1.1">{num}</b><span style="font-size: 10.5px; font-weight: 800; opacity: .8">{unit.upper()}</span></div>'
            f'<div style="flex: 1; display: flex; flex-direction: column; gap: 6px; padding: 2px 0"><div style="display: flex; align-items: center; gap: 7px">{radio(sel, dark)}<b style="font-size: 16px">{p["name"]}</b>{tag}<span style="flex: 1"></span>{price(p, fg, mu, 18)}</div>'
            + feats + '</div></div>')

def std(pick):
    sel = pick == 'std'
    r = (f'<span style="width: 20px; height: 20px; flex: none; border-radius: 99px; background: #43504A; display: flex; align-items: center; justify-content: center">{ic("check", 12, "#FFFFFF", 3.4)}</span>' if sel
         else f'<span style="width: 20px; height: 20px; flex: none; border-radius: 99px; box-shadow: inset 0 0 0 2px #B8C1BC"></span>')
    line = lambda t: f'<span style="display: flex; align-items: center; gap: 8px; font-size: 12.5px; font-weight: 600; color: #5B6862">{ic("check", 13, "#9AA5A0", 3)}{t}</span>'
    return (f'<div style="border-radius: 16px; padding: 12px; background: #F6F8F7; box-shadow: inset 0 0 0 {"2px #43504A" if sel else "1px #DDE3E0"}; display: flex; gap: 12px; align-items: stretch">'
            f'<div style="width: 76px; flex: none; border-radius: 12px; background: #E9EDEB; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 1px; color: #5B6862">'
            f'{lic(ICN["std"], 20, "#7B8781")}<b style="font-size: 24px; letter-spacing: -1px; line-height: 1.1">30</b><span style="font-size: 10.5px; font-weight: 800">DAYS</span></div>'
            f'<div style="flex: 1; display: flex; flex-direction: column; gap: 6px; padding: 2px 0"><div style="display: flex; align-items: center; gap: 7px">{r}<b style="font-size: 16px; color: #26302B">Standard</b><span style="flex: 1"></span><b style="font-size: 18px; letter-spacing: -.5px; color: #26302B">Free</b></div>'
            f'{line("Only 55 claims")}{line("1 of your 5 claims")}{line("No reminders")}</div></div>')

AGREE = (f'<div style="display: flex; gap: 10px; align-items: flex-start"><span style="width: 18px; height: 18px; flex: none; border-radius: 5px; box-shadow: inset 0 0 0 2px #C9D3CD; margin-top: 1px"></span>'
         f'<span style="font-size: 11px; font-weight: 600; color: {MUTE}; line-height: 1.45">My answers are true, and I agree that Claimclub can fill out and file my claims for me, as described in the <u>Claim Filing Authorization Agreement</u>.</span></div>')
def screen(pick):
    body = h('How fast should we file?', 23, False) + SUB + big('pri', pick) + big('fast', pick) + std(pick)
    if pick == 'std':
        foot = (AGREE + f'<div style="height: 52px; border-radius: 99px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px #C9D3CD; display: flex; align-items: center; justify-content: center; font-size: 16px; font-weight: 800; color: #26302B">Continue with Standard</div>'
                f'<span style="font-size: 11px; font-weight: 600; color: {MUTE}; text-align: center; line-height: 1.4">Free. Only 1 of your 5 claims gets filed. You can upgrade later.</span>')
    elif pick == 'pri':
        foot = FOOT('Start Priority · $30 today', '$30 today, renews monthly. Cancel anytime. Payouts take 6 to 12 months on every plan.')
    else:
        foot = FOOT()
    return mob(body, foot)

if __name__ == '__main__':
    board('OfferGrey', 'PLAN PAGE · STANDARD TONED DOWN', [
        ('FAST PICKED (DEFAULT)', 'The page always opens on Fast. Fast and Priority sit on top as the two real choices.', screen('fast')),
        ('STANDARD PICKED', 'Quieter card at the bottom: light grey, grey checks, no tag, but still a clear option. Picking it gives a grey outline button and says only 1 of 5 claims gets filed.', screen('std')),
        ('PRIORITY PICKED', 'Same as today: mint ring on Priority and "Start Priority · $30 today".', screen('pri'))])
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    ys = [b['y'] + b['h'] for b in c['boards'].values() if b.get('page') == 'offers']
    y = 12480
    c['boards']['OfferGrey.dc.html'] = {'x': 0, 'y': y + 300, 'w': 1840, 'h': 1080, 'title': 'Plan page · Standard toned down', 'page': 'offers', 'is_interactive': False}
    if 'OfferGrey.dc.html' not in c['order']: c['order'].append('OfferGrey.dc.html')
    c['notes']['tGrey'] = {'x': 0, 'y': y, 'page': 'offers', 'text': 'Plan page · Fast by default, Standard toned down', 'kind': 'title1', 'maxW': 1840, 'w': 240}
    if 'tGrey' not in c['noteOrder']: c['noteOrder'].append('tGrey')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w')); print('ok', y)
