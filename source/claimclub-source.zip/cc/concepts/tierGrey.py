# Plan page, Standard toned down (Nov 21 2026, design only). Henry: default to Fast, and make Standard grey and less appealing.
# Board OfferGrey: Fast picked (default), Standard picked, Priority picked. Standard moves to the bottom as a small grey card.
import os, json
from tierGm2 import P, FOOT, li, price, pill, radio, board
from tierGm4 import lic, SUB
from tierE import mob, h, ic, INK, MUTE, LINE, MINT, GREEN, DARK, OUT

GREY, GTXT = '#8A968F', '#6B7671'
FE = {'fast': ['All 184 nationwide claims', 'All 5 of your claims', 'Reminders on new claims', 'Notified when you get paid'],
      'pri': ['All 279 claims, incl. local', 'New claims filed for you', 'First look at new claims', 'Claim refunds', 'Subscription Manager']}
ICN = {'std': 'calendar-days', 'fast': 'gauge', 'pri': 'rocket'}

def big(k, pick):
    p = P[k]; dark = k == 'pri'; sel = k == pick
    ring = (f'inset 0 0 0 2px {MINT}, 0 12px 26px rgba(18,128,92,.16)' if sel and not dark else f'inset 0 0 0 2px {MINT}, 0 12px 26px rgba(10,15,13,.22)' if sel
            else ('0 12px 26px rgba(10,15,13,.18)' if dark else f'inset 0 0 0 1px {LINE}'))
    fg = '#FFFFFF' if dark else INK; mu = '#9FC3B4' if dark else MUTE
    num, unit = p['speed'].split(' ')
    blk = ('background: ' + MINT + '; color: ' + DARK) if sel else ('background: rgba(61,220,151,.16); color: #FFFFFF' if dark else 'background: #F1F4F2; color: ' + INK)
    tag = pill(p['tag'], MINT, DARK) if k == 'fast' else pill(p['tag'], 'rgba(61,220,151,.18)', MINT)
    feats = ''.join(li(f, MINT if dark else GREEN, '#E6EEEA' if dark else INK, 12.5) for f in FE[k])
    return (f'<div style="border-radius: 18px; padding: 12px; background: {DARK if dark else "#FFFFFF"}; box-shadow: {ring}; color: {fg}; display: flex; gap: 12px; align-items: stretch">'
            f'<div style="width: 76px; flex: none; border-radius: 12px; {blk}; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 1px">'
            f'{lic(ICN[k], 22, DARK if sel else (MINT if dark else MUTE))}<b style="font-size: 27px; letter-spacing: -1px; line-height: 1.1">{num}</b><span style="font-size: 10.5px; font-weight: 800; opacity: .8">{unit.upper()}</span></div>'
            f'<div style="flex: 1; display: flex; flex-direction: column; gap: 6px; padding: 2px 0"><div style="display: flex; align-items: center; gap: 7px">{radio(sel, dark)}<b style="font-size: 16px">{p["name"]}</b>{tag}<span style="flex: 1"></span>{price(p, fg, mu, 18)}</div>'
            + feats + '</div></div>')

def std(pick):
    sel = pick == 'std'
    r = (f'<span style="width: 18px; height: 18px; flex: none; border-radius: 99px; background: {GTXT}; display: flex; align-items: center; justify-content: center">{ic("check", 11, "#FFFFFF", 3.4)}</span>' if sel
         else f'<span style="width: 18px; height: 18px; flex: none; border-radius: 99px; box-shadow: inset 0 0 0 2px #C9D3CD"></span>')
    line = lambda t: f'<span style="display: flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 600; color: {GREY}"><span style="width: 4px; height: 4px; border-radius: 99px; background: #B8C1BC"></span>{t}</span>'
    return (f'<div style="border-radius: 14px; padding: 10px 12px; background: #EEF1EF; box-shadow: {"inset 0 0 0 2px " + GTXT if sel else "none"}; display: flex; gap: 10px; align-items: center">'
            f'<div style="width: 46px; height: 46px; flex: none; border-radius: 10px; background: #E2E7E4; display: flex; flex-direction: column; align-items: center; justify-content: center; color: {GREY}">'
            f'<b style="font-size: 16px; line-height: 1">30</b><span style="font-size: 8.5px; font-weight: 800; letter-spacing: .4px">DAYS</span></div>'
            f'<div style="flex: 1; display: flex; flex-direction: column; gap: 3px"><div style="display: flex; align-items: center; gap: 7px">{r}<b style="font-size: 14px; color: {GTXT}">Standard</b><span style="flex: 1"></span><b style="font-size: 14px; color: {GTXT}">Free</b></div>'
            f'<div style="display: flex; flex-wrap: wrap; gap: 2px 12px">{line("Only 55 claims")}{line("1 of your 5 claims")}{line("No reminders")}</div></div></div>')

AGREE = (f'<div style="display: flex; gap: 10px; align-items: flex-start"><span style="width: 18px; height: 18px; flex: none; border-radius: 5px; box-shadow: inset 0 0 0 2px #C9D3CD; margin-top: 1px"></span>'
         f'<span style="font-size: 11px; font-weight: 600; color: {MUTE}; line-height: 1.45">My answers are true, and I agree that Claimclub can fill out and file my claims for me, as described in the <u>Claim Filing Authorization Agreement</u>.</span></div>')
def screen(pick):
    body = h('How fast should we file?', 23, False) + SUB + big('fast', pick) + big('pri', pick) + std(pick)
    if pick == 'std':
        foot = (AGREE + f'<div style="height: 52px; border-radius: 99px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px #C9D3CD; display: flex; align-items: center; justify-content: center; font-size: 16px; font-weight: 800; color: {GTXT}">Continue with Standard</div>'
                f'<span style="font-size: 11px; font-weight: 600; color: {MUTE}; text-align: center; line-height: 1.4">Free. Only 1 of your 5 claims gets filed. You can upgrade later.</span>')
    elif pick == 'pri':
        foot = FOOT('Start Priority · $30 today', '$30 today, renews monthly. Cancel anytime. Payouts take 6 to 12 months on every plan.')
    else:
        foot = FOOT()
    return mob(body, foot)

if __name__ == '__main__':
    board('OfferGrey', 'PLAN PAGE · STANDARD TONED DOWN', [
        ('FAST PICKED (DEFAULT)', 'The page always opens on Fast. Fast and Priority sit on top as the two real choices.', screen('fast')),
        ('STANDARD PICKED', 'Small grey card at the bottom: no green checks, no tag. Picking it gives a grey outline button and says only 1 of 5 claims gets filed.', screen('std')),
        ('PRIORITY PICKED', 'Same as today: mint ring on Priority and "Start Priority · $30 today".', screen('pri'))])
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    ys = [b['y'] + b['h'] for b in c['boards'].values() if b.get('page') == 'offers']
    y = 12480
    c['boards']['OfferGrey.dc.html'] = {'x': 0, 'y': y + 300, 'w': 1840, 'h': 1080, 'title': 'Plan page · Standard toned down', 'page': 'offers', 'is_interactive': False}
    if 'OfferGrey.dc.html' not in c['order']: c['order'].append('OfferGrey.dc.html')
    c['notes']['tGrey'] = {'x': 0, 'y': y, 'page': 'offers', 'text': 'Plan page · Fast by default, Standard toned down', 'kind': 'title1', 'maxW': 1840, 'w': 240}
    if 'tGrey' not in c['noteOrder']: c['noteOrder'].append('tGrey')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w')); print('ok', y)
