# Offer E, Henry's tiers (Nov 21 2026, design only): Standard free / Fast $15 a month / Priority $30 a month.
# 3 designs (1 cards, 2 table, 3 list) x 3 billing views (m monthly, y yearly, s monthly/yearly switch) = 9 boards OfferG<design><view>.
# Yearly = 2 months free: Fast $150 a year ($12.50 a month), Priority $300 a year ($25 a month).
import os
import tierE as E
from tierE import HEAD, JS, OUT, h, sub, summary, desk, mob, mint_btn, ic, chip, INK, MUTE, LINE, MINT, GREEN, DARK

PRICE = {'m': {'fast': ('$15', '/month', 'Billed monthly. Cancel anytime.'), 'pri': ('$30', '/month', 'Billed monthly. Cancel anytime.')},
         'y': {'fast': ('$150', '/year', '$12.50 a month, 2 months free'), 'pri': ('$300', '/year', '$25 a month, 2 months free')}}
ROWS = [('Filing time', 'Within 30 days', 'Within 3 days', 'Within 24 hours'),
        ('Settlements you can claim', 'Auto-filed only', 'All 173 nationwide', 'All 270, incl. local'),
        ('Your 6 matched claims', '3 of 6 filed', 'All 6 filed', 'All 6 filed'),
        ('New claims', False, 'Reminders when they open', 'Filed for you automatically'),
        ('First look at new claims', False, False, 'The day we find them'),
        ('Claim refunds + Subscription Manager', False, False, True),
        ('Expected payout', '6 to 12 months', '6 to 12 months', '6 to 12 months')]
NOTE = 'Payout timing depends on each settlement, not your plan. Faster filing gets claims in before deadlines close.'

def tiers(b):
    f, p = PRICE[b]['fast'], PRICE[b]['pri']
    return [dict(k='basic', name='Standard', price='Free', per='', sub='Auto-filed claims only', icon='book', short='Filed within 30 days, auto-filed only'),
            dict(k='plus', name='Fast', price=f[0], per=f[1], sub=f[2], icon='check', pop=True, short='Filed within 3 days, all nationwide'),
            dict(k='pri', name='Priority', price=p[0], per=p[1], sub=p[2], icon='zap', short='Filed in 24 hours, every claim, refunds')]
def cta(b, k='plus'):
    t = {x['k']: x for x in tiers(b)}[k]
    return f'Start {t["name"]} · {t["price"]} today'
def fine(b, k='plus'):
    t = {x['k']: x for x in tiers(b)}[k]
    return f'{t["price"]} today, renews every {"month" if b == "m" else "year"}. Cancel anytime.'

def switch(on, m=False):
    def s(t, sel, extra=''):
        return (f'<span style="flex: 1; height: {38 if m else 40}px; padding: 0 {10 if m else 18}px; border-radius: 99px; display: flex; align-items: center; justify-content: center; gap: 6px; font-size: {13.5 if m else 14}px; font-weight: 800; white-space: nowrap; '
                + (f'background: #FFFFFF; color: {INK}; box-shadow: 0 2px 8px rgba(10,15,13,.12)' if sel else f'color: {MUTE}') + f'">{t}{extra}</span>')
    return (f'<div style="align-self: center; display: flex; padding: 4px; border-radius: 99px; background: #E4EAE6; {"width: 100%; box-sizing: border-box" if m else "width: 360px"}">'
            + s('Monthly', on == 'm') + s('Yearly', on == 'y', chip('2 MONTHS FREE', MINT, DARK).replace('padding: 5px 10px', 'padding: 3px 7px').replace('font-size: 12px', 'font-size: 10px')) + '</div>')

def btxt(t, b):
    return {'basic': 'Start free', 'plus': f'Start Fast · {t["price"]}', 'pri': f'Start Priority · {t["price"]}'}[t['k']]

# ---------- 1: cards ----------
def d1(b, sw=None):
    E.ROWS = ROWS; T = tiers(b); E.T = T
    cards = ''.join(E.card(dict(t, btn=btxt(t, b)), i).replace('Start free trial', btxt(t, b)) for i, t in enumerate(T))
    return desk(h('How fast should we file?') + (switch(sw) if sw else sub('Upgrade, downgrade or cancel anytime.')) + summary()
                + f'<div style="display: flex; gap: 14px; align-items: stretch; margin-top: 8px">{cards}</div>'
                + f'<span style="font-size: 12px; font-weight: 600; color: {MUTE}; text-align: center">{NOTE}</span>', w=800)
def m1(b, sw=None, nudge=''):
    E.ROWS = ROWS; T = tiers(b); E.T = T
    return mob(h('How fast should we file?', 25, False) + (switch(sw, True) if sw else '') + E.mrow(T[1], True) + E.mrow(T[2]) + E.mrow(T[0]) + nudge,
               mint_btn(f'{ic("lock", 16, DARK, 2.4)}{cta(b)}', 54) + f'<span style="font-size: 12px; font-weight: 600; color: {MUTE}; text-align: center">{fine(b)}</span>')

# ---------- 2: table ----------
def d2(b, sw=None):
    T = tiers(b); cols = '1.45fr 1fr 1.1fr 1.1fr'
    def bg(i): return '#F2FBF6' if i == 1 else ('#16201C' if i == 2 else 'transparent')
    def cell(v, k): return f'<div style="padding: 8px 8px; background: {bg(k)}; color: {"#FFFFFF" if k == 2 else INK}; display: flex; align-items: center; justify-content: center; text-align: center">{E.val(v, k == 2, 12.5)}</div>'
    hd = '<div></div>' + ''.join(
        f'<div style="padding: 12px 8px 10px; display: flex; flex-direction: column; align-items: center; gap: 3px; border-radius: 16px 16px 0 0; background: {bg(i)}; color: {"#FFFFFF" if i == 2 else INK}">'
        + (chip('MOST POPULAR', MINT, DARK) if i == 1 else (chip('FASTEST', '#3A4A43', '#E3ECE7') if i == 2 else '<span style="height: 23px"></span>'))
        + f'<b style="font-size: 15px">{t["name"]}</b><b style="font-size: 25px; letter-spacing: -1px">{t["price"]}<span style="font-size: 12px; color: {"#9FC3B4" if i == 2 else MUTE}">{t["per"]}</span></b>'
        + f'<span style="font-size: 11.5px; font-weight: 600; color: {"#9FC3B4" if i == 2 else MUTE}; min-height: 15px">{t["sub"] if b == "y" and i else ("" if i else "")}</span></div>' for i, t in enumerate(T))
    body = ''.join(f'<div style="padding: 8px 4px; font-size: 13px; font-weight: 700; display: flex; align-items: center; border-top: 1px solid {LINE}">{r[0]}</div>' + ''.join(cell(r[k + 1], k) for k in range(3)) for r in ROWS)
    foot = '<div></div>' + ''.join(f'<div style="padding: 10px 8px 12px; background: {bg(i)}; border-radius: 0 0 16px 16px">{E.btn(btxt(t, b), t["k"], 40, 13)}</div>' for i, t in enumerate(T))
    tbl = f'<div style="display: grid; grid-template-columns: {cols}; background: #FFFFFF; border-radius: 20px; padding: 6px 12px; box-shadow: inset 0 0 0 1.5px {LINE}">{hd}{body}{foot}</div>'
    return desk(h('Compare plans', 30) + (switch(sw) if sw else '') + tbl + f'<span style="font-size: 12px; font-weight: 600; color: {MUTE}; text-align: center">{NOTE}</span>', w=780)
def m2(b, sw=None):
    T = tiers(b); t = T[1]
    tabs = f'<div style="display: flex; padding: 4px; border-radius: 14px; background: #E4EAE6">' + ''.join(
        f'<span style="flex: 1; height: 44px; border-radius: 11px; display: flex; flex-direction: column; align-items: center; justify-content: center; {"background: #FFFFFF; box-shadow: 0 2px 8px rgba(10,15,13,.12); color: " + INK if x["k"] == "plus" else "color: " + MUTE}"><b style="font-size: 13px">{x["name"]}</b><span style="font-size: 11px; font-weight: 700">{x["price"]}{x["per"].replace("/month", "/mo").replace("/year", "/yr")}</span></span>' for x in T) + '</div>'
    st, dark = E.style(t)
    pc = (f'<div style="border-radius: 22px; padding: 18px; display: flex; flex-direction: column; gap: 11px; {st}">' + E.head(t, dark, 38)
          + f'<div style="height: 1px; background: {LINE}"></div><div style="display: flex; flex-direction: column; gap: 9px">' + ''.join(E.row(r[0], r[2], False, 13.5) for r in ROWS) + '</div></div>')
    return mob(h('Compare plans', 25, False) + (switch(sw, True) if sw else '') + tabs + pc,
               mint_btn(f'{ic("lock", 16, DARK, 2.4)}{cta(b)}', 54) + f'<span style="font-size: 12px; font-weight: 600; color: {MUTE}; text-align: center">{fine(b)}</span>')

# ---------- 3: list with nudge ----------
def li(t, sel, m=False):
    st, dark = E.style(t) if sel else (f'background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}', False)
    i = ['basic', 'plus', 'pri'].index(t['k'])
    dot = (f'<span style="width: 22px; height: 22px; flex: none; border-radius: 99px; background: {GREEN}; display: flex; align-items: center; justify-content: center">{ic("check", 13, "#FFFFFF", 3.2)}</span>' if sel
           else f'<span style="width: 22px; height: 22px; flex: none; border-radius: 99px; box-shadow: inset 0 0 0 2px #C9D3CD"></span>')
    tag = chip('MOST POPULAR', MINT, DARK) if t.get('pop') else (chip('FASTEST', '#FFF4DB', '#8A5A00') if t['k'] == 'pri' else '')
    out = (f'<div style="border-radius: 18px; padding: {13 if m else 15}px {16 if m else 18}px; display: flex; flex-direction: column; gap: 10px; {st}">'
           f'<div style="display: flex; align-items: center; gap: 12px">{dot}<span style="flex: 1; display: flex; flex-direction: column"><span style="display: flex; align-items: center; gap: 6px"><b style="font-size: 16px">{t["name"]}</b>{tag}</span>'
           f'<span style="font-size: 12.5px; font-weight: 600; color: {MUTE}">{t["short"] if not sel else t["sub"]}</span></span><b style="font-size: 19px; white-space: nowrap">{t["price"]}<span style="font-size: 12px; color: {MUTE}">{t["per"]}</span></b></div>')
    if sel:
        out += f'<div style="height: 1px; background: {LINE}"></div><div style="display: {"flex" if m else "grid"}; {"flex-direction: column" if m else "grid-template-columns: 1fr 1fr"}; gap: 8px">' + ''.join(E.row(r[0], r[i + 1], False, 13) for r in ROWS[:(4 if m else 6)]) + '</div>'
    return out + '</div>'
def nudge(b, m=False):
    diff = '+$15 a month' if b == 'm' else '+$150 a year'
    return (f'<div style="display: flex; align-items: center; gap: 12px; padding: 12px 14px; border-radius: 16px; background: #FFF8E6; box-shadow: inset 0 0 0 1.5px #F4E2B0">'
            f'<span style="width: 32px; height: 32px; flex: none; border-radius: 10px; background: #FFE9A8; display: flex; align-items: center; justify-content: center">{ic("zap", 17, "#8A5A00", 2.4)}</span>'
            f'<span style="flex: 1; font-size: 13px; font-weight: 600; color: #5C4300; line-height: 1.4"><b>2 of your claims close in under 30 days.</b> Priority files them within 24 hours. {diff}.</span>'
            + ('' if m else f'<span style="display: flex; align-items: center; font-size: 13.5px; font-weight: 800; color: #8A5A00; white-space: nowrap">Switch{ic("right", 14, "#8A5A00", 2.6)}</span>') + '</div>')
def d3(b, sw=None):
    T = tiers(b)
    return desk(h('Choose your plan') + (switch(sw) if sw else '') + summary() + li(T[1], True) + li(T[2], False) + li(T[0], False) + nudge(b)
                + mint_btn(f'{ic("lock", 16, DARK, 2.4)}{cta(b)}', 56) + f'<span style="font-size: 12px; font-weight: 600; color: {MUTE}; text-align: center">{fine(b)}</span>', w=660)
def m3(b, sw=None):
    T = tiers(b)
    return mob(h('Choose your plan', 25, False) + (switch(sw, True) if sw else '') + li(T[1], True, True) + li(T[2], False, True) + li(T[0], False, True) + nudge(b, True),
               mint_btn(f'{ic("lock", 16, DARK, 2.4)}{cta(b)}', 54) + f'<span style="font-size: 12px; font-weight: 600; color: {MUTE}; text-align: center">{fine(b)}</span>')

DES = {1: ('CARDS', d1, m1), 2: ('TABLE', d2, m2), 3: ('LIST WITH NUDGE', d3, m3)}
VIEW = {'m': ('MONTHLY', 'Monthly prices only: Fast $15 a month, Priority $30 a month.'),
        'y': ('YEARLY', 'Yearly prices only: Fast $150 a year ($12.50 a month), Priority $300 a year ($25 a month). Two months free versus monthly.'),
        's': ('MONTHLY / YEARLY SWITCH', 'A Monthly | Yearly switch on top. Desktop shows Yearly picked, the phone shows Monthly picked, so both states are visible.')}

if __name__ == '__main__':
    for n, (dname, df, mf) in DES.items():
        for v, (vname, vdesc) in VIEW.items():
            if v == 's': d, m = df('y', 'y'), mf('m', 'm')
            else: d, m = df(v), mf(v)
            name = f'OfferG{n}{v}'
            page = ('<div data-board style="width: 1840px; height: 1080px; box-sizing: border-box; padding: 36px 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 26px">'
                    f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #12805C">STANDARD · FAST · PRIORITY · {n} {dname} · {vname}</span>'
                    f'<span style="font-size: 16px; color: #43504A; max-width: 1640px; line-height: 1.5; font-weight: 600">{vdesc}</span>'
                    f'<span style="font-size: 13px; color: #8A968F; font-weight: 600">Draft, not live. Standard free (filed within 30 days, auto-filed settlements only), Fast (3 days, all nationwide, new claim reminders), Priority (24 hours, every claim incl. local, new claims auto-filed and seen first, refunds and Subscription Manager). Sample member and claims.</span></div>'
                    f'<div style="display: flex; gap: 46px; align-items: flex-start">{d}{m}</div></div>\n</x-dc>\n')
            open(os.path.join(OUT, f'{name}.dc.html'), 'w').write(HEAD % f'Plans {n}{v}' + page + JS.replace('"width":1926,"height":980', '"width":1840,"height":1080'))
    print('ok')
