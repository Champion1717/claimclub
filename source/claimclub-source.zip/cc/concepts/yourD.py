# Your claims, row dropdown drafts (Nov 21 2026, canvas only). Today a claim opens a centered popup; these open it
# in place like Find claims. Y1 tracker first, Y2 timeline with a money card, Y3 receipt card. Each board: desktop
# Your claims with a Filed claim open, phone with a Needs info claim open, and the other states (Ready, Filing, Paid).
import os, json
from tierE import HEAD, JS, OUT
from perksD import ic, LU
from findD import T, logo
from upgradeD import desk, phone, INK, MUTE, LINE, MINT, GREEN, DARK, BG

LU.update({'ok': 'M20 6 9 17l-5-5', 'up': 'm18 15-6-6-6 6', 'down': 'm6 9 6 6 6-6', 'copy': 'M8 8h12v12H8z M4 16V4h12',
           'ext': 'M15 3h6v6 M10 14 21 3 M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6',
           'msg': 'M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z', 'wallet': 'M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2 M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4',
           'clock': 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20z M12 6v6l4 2', 'file': 'M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z M14 2v4a2 2 0 0 0 2 2h4'})
RED = '#B8333A'
def lab(k):
    return {'CLAIM ID': 'Claim ID'}.get(k, k[0] + k[1:].lower())
PILL = {'ready': ('Ready to file', '#FFF4DB', '#8A5A00'), 'filing': ('Filing', '#EEF2F0', '#43504A'), 'filed': ('Filed', '#E8EEFB', '#2C4FA8'),
        'needs': ('Action needed', '#FDECEC', RED), 'paid': ('Paid $95', '#E3F6EC', GREEN)}
C = {'apple': ('apple', 'Apple', 'Up to $95', 'Siri privacy settlement', 'filed'),
     'visa': ('visa', 'Visa and Mastercard', 'Up to $1,000', 'ATM fee settlement', 'needs'),
     'googleplay': ('googleplay', 'Google Play', 'Up to $100', 'App store pricing settlement', 'ready'),
     'cvs': ('cvs', 'CVS', '$5 or more', 'Generic drug pricing settlement', 'filing'),
     'amazon': ('amazon', 'Amazon', 'Varies', 'Returns refund settlement', 'paid'),
     'realpage': ('realpage', 'RealPage', 'Up to $100', 'Rent pricing settlement', 'filing')}
ORDER = ['visa', 'googleplay', 'apple', 'cvs', 'realpage', 'amazon']
SUB = {'filed': 'Filed Nov 18 · claim ID APL-48213', 'needs': 'We need one answer from you', 'ready': 'Ready to file · closes in 21 days', 'filing': 'We are submitting it now', 'paid': 'Paid Nov 2 to PayPal'}

def pill(st, sz=12.5):
    t, bg, fg = PILL[st]
    dot = f'<span style="width: 7px; height: 7px; border-radius: 99px; background: currentColor"></span>' if st in ('filing', 'needs') else ''
    return f'<span style="display: inline-flex; align-items: center; gap: 6px; flex: none; font-size: {sz}px; font-weight: 800; padding: 6px 11px; border-radius: 99px; white-space: nowrap; background: {bg}; color: {fg}">{dot}{t}</span>'
def head(cid, st, open_=False, m=False):
    i, co, amt, ttl, _ = C[cid]
    return (f'<div style="display: flex; align-items: center; gap: 12px; padding: {11 if m else 12}px {12 if m else 14}px">{logo(i, 38 if m else 42)}'
            f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><b style="font-size: {14.5 if m else 15.5}px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{co} <span style="color: {GREEN}">{amt}</span></b>'
            f'<span style="font-size: 13px; font-weight: 600; color: {MUTE}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{SUB[st]}</span></span>{"" if m and open_ else pill(st)}'
            f'<span style="color: {MUTE}; display: flex">{ic("up" if open_ else "down", 16, MUTE, 2.4)}</span></div>')
def card(inner, open_=False):
    return f'<div style="background: #FFFFFF; border-radius: 16px; {"box-shadow: inset 0 0 0 1.5px " + GREEN + ", 0 12px 28px rgba(10,15,13,.07)" if open_ else "box-shadow: inset 0 0 0 1px " + LINE}">{inner}</div>'
def btn(t, kind='mint', icon='', m=False):
    st = {'mint': f'background: {MINT}; color: {DARK}', 'dark': f'background: {DARK}; color: #FFFFFF', 'ghost': f'background: #FFFFFF; color: #26332C; box-shadow: inset 0 0 0 1.5px {LINE}', 'red': f'background: {RED}; color: #FFFFFF'}[kind]
    return f'<span style="display: inline-flex; align-items: center; justify-content: center; gap: 7px; min-height: 42px; padding: 0 18px; border-radius: 99px; font-size: 14px; font-weight: 800; {st}; {"flex: 1" if m else ""}">{icon}{t}</span>'
def txt(t, c=MUTE, sz=13.5, w=600):
    return f'<span style="font-size: {sz}px; font-weight: {w}; color: {c}; line-height: 1.5">{t}</span>'
def kick(t, c='#8A968F'):
    return f'<span style="font-size: 11.5px; font-weight: 800; letter-spacing: .9px; color: {c}">{t}</span>'
def facts(items, cols=4):
    return (f'<div style="display: grid; grid-template-columns: repeat({cols}, minmax(0, 1fr)); gap: 8px">' + ''.join(
        f'<div style="background: {BG}; border-radius: 12px; padding: 10px 12px; display: flex; flex-direction: column; gap: 2px; min-width: 0">{kick(k)}<span style="font-size: 13.5px; font-weight: 800">{v}</span></div>' for k, v in items) + '</div>')

# per-state content shared by the designs
S = {
 'filed': dict(step=2, next='The court decides on the settlement, then everyone gets paid at once. Expected around June 2027.', facts=[('EXPECTED', 'Up to $95'), ('PAID TO', 'PayPal'), ('CLAIM ID', 'APL-48213'), ('DEADLINE', 'Jan 6, 2027')],
           acts=[('See official site', 'ghost', 'ext')], ev=[('Requested', 'Nov 16'), ('Filed by our team', 'Nov 18 · APL-48213'), ('Court approval', 'Expected Mar 2027'), ('Paid', 'Expected Jun 2027')]),
 'needs': dict(step=1, next='The administrator asked for the last 4 digits of the card you paid the ATM fee with.', facts=[('EXPECTED', 'Up to $1,000'), ('PAID TO', 'Direct deposit'), ('CLAIM ID', 'Not yet'), ('DEADLINE', 'Feb 10, 2027')],
           acts=[('Reply', 'red', 'msg')], ev=[('Requested', 'Nov 12'), ('We need your answer', 'Nov 19'), ('Filed', 'After reply'), ('Paid', 'Late 2027')]),
 'ready': dict(step=0, next='Answer 2 quick questions and sign. We file it within 24 hours.', facts=[('EXPECTED', 'Up to $100'), ('PROOF', 'None'), ('FILED BY', 'Us, for you'), ('DEADLINE', 'Dec 12 · 21 days')],
           acts=[('File now', 'mint', ''), ('Remove', 'ghost', '')], ev=[('Added to your claims', 'Nov 20'), ('File', 'Closes Dec 12'), ('Filed', ''), ('Paid', '')]),
 'filing': dict(step=1, next='We are submitting it now. You will get the claim ID by email within 24 hours.', facts=[('EXPECTED', '$5 or more'), ('PAID TO', 'PayPal'), ('CLAIM ID', 'Coming soon'), ('DEADLINE', 'Mar 3, 2027')],
           acts=[], ev=[('Requested', 'Nov 20'), ('Filing now', 'Today'), ('Filed', 'Within 24 hours'), ('Paid', 'Expected 2027')]),
 'paid': dict(step=4, next='$95 was sent to your PayPal on Nov 2.', facts=[('PAID', '$95'), ('PAID TO', 'PayPal'), ('CLAIM ID', 'AMZ-11902'), ('PAID ON', 'Nov 2, 2026')],
           acts=[], ev=[('Requested', 'Mar 4'), ('Filed', 'Mar 5 · AMZ-11902'), ('Approved', 'Sep 30'), ('Paid $95', 'Nov 2')]),
}
LABELS = ['Ready', 'Filed', 'Approved', 'Paid']

# ---------- Y1 tracker first ----------
def tracker(step, st, m=False):
    out = ''
    for n, t in enumerate(['Requested', 'Filed', 'Approved', 'Paid']):
        done, cur = n < step, n == step and st != 'paid'
        col = RED if cur and st == 'needs' else GREEN
        dot = (f'<span style="width: 22px; height: 22px; flex: none; border-radius: 99px; background: {GREEN}; display: flex; align-items: center; justify-content: center">{ic("ok", 12, "#FFFFFF", 3.4)}</span>' if done or st == 'paid' else
               f'<span style="width: 22px; height: 22px; flex: none; border-radius: 99px; box-shadow: inset 0 0 0 2px {col}; display: flex; align-items: center; justify-content: center"><span style="width: 9px; height: 9px; border-radius: 99px; background: {col}"></span></span>' if cur else
               f'<span style="width: 22px; height: 22px; flex: none; border-radius: 99px; box-shadow: inset 0 0 0 2px #C9D3CD"></span>')
        last = n == 3
        line = '' if last else f'<span style="flex: 1; height: 3px; border-radius: 99px; background: {GREEN if done or st == "paid" else "#DDE5E0"}; margin: 0 6px"></span>'
        date = S[st]['ev'][n][1].split(' · ')[0]
        out += (f'<div style="display: flex; flex-direction: column; gap: 6px; min-width: 0; {"flex: 1" if not last else "flex: none; align-items: flex-end"}"><div style="display: flex; align-items: center">{dot}{line}</div>'
                f'<span style="font-size: 12.5px; font-weight: 800; color: {INK if done or cur or st == "paid" else "#8A968F"}">{("Needs you" if cur and st == "needs" else t)}</span>'
                f'<span style="font-size: 11.5px; font-weight: 600; color: #8A968F; white-space: nowrap">{date if not m or len(date) < 12 else date[:11]}</span></div>')
    return f'<div style="display: flex">{out}</div>'
def body1(st, m=False):
    d = S[st]
    note_bg = '#FDECEC' if st == 'needs' else '#E3F6EC' if st == 'paid' else BG
    nxt = f'<div style="display: flex; gap: 10px; align-items: flex-start; padding: 12px 14px; border-radius: 14px; background: {note_bg}">{ic("msg" if st == "needs" else "ok" if st == "paid" else "clock", 17, RED if st == "needs" else GREEN, 2.2)}{txt(d["next"], INK, 13.5, 700)}</div>'
    reply = ''
    if st == 'needs':
        reply = (f'<div style="height: 44px; border-radius: 12px; box-shadow: inset 0 0 0 1.5px {LINE}; background: #FFFFFF; display: flex; align-items: center; padding: 0 14px; font-size: 14px; font-weight: 600; color: #8A968F">Last 4 digits of the card</div>')
    acts = ''.join(btn(t, k, ic(i, 15, '#FFFFFF' if k in ('red', 'dark') else DARK, 2.4) if i else '', m and k != 'ghost') for t, k, i in d['acts'])
    acts += f'<span style="font-size: 13.5px; font-weight: 800; color: {GREEN}; padding: 0 4px; display: inline-flex; align-items: center">Case details</span>'
    return (f'<div style="border-top: 1px solid {LINE}; padding: 16px {14 if m else 16}px; display: flex; flex-direction: column; gap: 14px">{tracker(d["step"], st, m)}{nxt}{reply}'
            f'{facts(d["facts"], 2 if m else 4)}<div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center">{acts}</div></div>')

# ---------- Y2 timeline with a money card ----------
def body2(st, m=False):
    d = S[st]; ev = ''
    for n, (t, dt) in enumerate(d['ev']):
        done, cur = n < d['step'] or st == 'paid', n == d['step'] and st != 'paid'
        col = RED if cur and st == 'needs' else GREEN
        dot = (f'<span style="width: 18px; height: 18px; border-radius: 99px; background: {GREEN}; display: flex; align-items: center; justify-content: center">{ic("ok", 10, "#FFFFFF", 3.6)}</span>' if done else
               f'<span style="width: 18px; height: 18px; border-radius: 99px; background: {col}; box-shadow: 0 0 0 5px {"#FDECEC" if st == "needs" else "#E3F6EC"}"></span>' if cur else
               '<span style="width: 18px; height: 18px; border-radius: 99px; box-shadow: inset 0 0 0 2px #C9D3CD; background: #FFFFFF"></span>')
        rail = '' if n == 3 else f'<span style="flex: 1; width: 2px; min-height: 18px; background: {GREEN if n < d["step"] or st == "paid" else "#DDE5E0"}; margin: 3px 0"></span>'
        extra = ''
        if cur and st == 'needs': extra = f'<div style="margin-top: 8px; display: flex; flex-direction: column; gap: 8px; padding: 12px; border-radius: 12px; background: #FDECEC">{txt(d["next"], INK, 13, 700)}<div style="display: flex; gap: 8px"><div style="flex: 1; height: 40px; border-radius: 10px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #F2C9CC; display: flex; align-items: center; padding: 0 12px; font-size: 13px; font-weight: 600; color: #8A968F">Last 4 digits</div>{btn("Send", "red")}</div></div>'
        if cur and st == 'ready': extra = f'<div style="margin-top: 8px; display: flex; gap: 8px">{btn("File now", "mint")}{btn("Remove", "ghost")}</div>'
        ev += (f'<div style="display: flex; gap: 12px"><div style="display: flex; flex-direction: column; align-items: center; width: 18px; flex: none">{dot}{rail}</div>'
               f'<div style="flex: 1; min-width: 0; padding-bottom: {14 if n < 3 else 0}px; display: flex; flex-direction: column; gap: 1px"><b style="font-size: 14px; color: {INK if done or cur else "#8A968F"}">{t}</b>{txt(dt, "#8A968F", 12.5) if dt else ""}{extra}</div></div>')
    big = d['facts'][0][1]
    money = (f'<div style="width: {"auto" if m else "250px"}; flex: none; border-radius: 16px; background: {DARK}; color: #FFFFFF; padding: 16px; display: flex; flex-direction: column; gap: 12px">'
             f'{kick("PAID" if st == "paid" else "COMING TO YOU", "#9FD9BE")}<b style="font-size: 26px; letter-spacing: -.5px">{big}</b>'
             + ''.join(f'<div style="display: flex; justify-content: space-between; gap: 10px; font-size: 13px"><span style="color: #B9D3C7; font-weight: 600">{lab(k)}</span><b>{v}</b></div>' for k, v in d['facts'][1:])
             + f'<span style="font-size: 13px; font-weight: 800; color: {MINT}">Case details and official site</span></div>')
    tl = f'<div style="flex: 1; min-width: 0">{ev}</div>'
    return f'<div style="border-top: 1px solid {LINE}; padding: 16px; display: flex; {"flex-direction: column" if m else ""}; gap: 18px">{tl}{money}</div>'

# ---------- Y3 receipt card ----------
def body3(st, m=False):
    d = S[st]; pct = {0: 8, 1: 38, 2: 62, 3: 86, 4: 100}[d['step']]
    col = RED if st == 'needs' else GREEN
    head_ = (f'<div style="display: flex; align-items: flex-end; justify-content: space-between; gap: 12px"><div style="display: flex; flex-direction: column; gap: 2px">{kick("PAID" if st == "paid" else "EXPECTED PAYOUT")}'
             f'<b style="font-size: {28 if m else 32}px; letter-spacing: -.8px">{d["facts"][0][1]}</b></div>{pill(st) if m else ""}</div>')
    bar = (f'<div style="display: flex; flex-direction: column; gap: 8px"><span style="height: 8px; border-radius: 99px; background: #E6ECE8; overflow: hidden; display: block"><span style="display: block; height: 100%; width: {pct}%; border-radius: 99px; background: {col}"></span></span>'
           f'<div style="display: flex; justify-content: space-between; font-size: 11.5px; font-weight: 800; color: #8A968F; letter-spacing: .4px">' + ''.join(f'<span>{x.upper()}</span>' for x in ['Requested', 'Filed', 'Approved', 'Paid']) + '</div></div>')
    rows = ''.join(f'<div style="display: flex; justify-content: space-between; gap: 12px; padding: 9px 0; border-top: 1px dashed #D5DDD8; font-size: 13.5px"><span style="color: {MUTE}; font-weight: 600">{lab(k)}</span>'
                   f'<b style="display: inline-flex; align-items: center; gap: 6px">{v}{ic("copy", 13, "#8A968F", 2.2) if k == "CLAIM ID" and v[0].isupper() and "-" in v else ""}</b></div>' for k, v in d['facts'][1:])
    rec = (f'<div style="border-radius: 14px; background: #FBFCFB; box-shadow: inset 0 0 0 1px {LINE}; padding: 14px 16px; display: flex; flex-direction: column; gap: 12px">{head_}{bar}'
           f'{txt(d["next"], INK, 13.5, 700)}<div>{rows}</div></div>')
    acts = ''.join(btn(t, k, ic(i, 15, '#FFFFFF', 2.4) if i else '', m) for t, k, i in d['acts'] if k != 'ghost' or st == 'ready')
    more = (f'<div style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; border-radius: 12px; background: {BG}">'
            f'<span style="display: flex; align-items: center; gap: 8px; font-size: 13.5px; font-weight: 800">{ic("file", 16, GREEN, 2.2)}Case details: who qualifies, fund, how it gets filed</span>{ic("down", 16, MUTE, 2.4)}</div>')
    return (f'<div style="border-top: 1px solid {LINE}; padding: 16px; display: flex; flex-direction: column; gap: 12px">{rec}'
            f'{"<div style=\"display: flex; gap: 8px; flex-wrap: wrap\">" + acts + "</div>" if acts else ""}{more}</div>')

# ---------- page ----------
def page(body, open_id, m=False):
    top = (f'<div style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 14px; font-weight: 700; color: {MUTE}">Coming to you</span>'
           f'<b style="font-size: {38 if m else 48}px; letter-spacing: -1.6px; line-height: 1.05">Up to $1,305</b><span style="font-size: 13.5px; font-weight: 700; color: {MUTE}">from 6 claims</span></div>'
           f'<b style="font-size: 19px; margin-top: 6px">Your claims</b>')
    rows = ''
    for cid in ORDER[: 5 if m else 6]:
        st = C[cid][4]; o = cid == open_id
        rows += card(head(cid, st, o, m) + (body(st, m) if o else ''), o)
    return top + f'<div style="display: flex; flex-direction: column; gap: 8px">{rows}</div>'

def board(name, label, note, body, H=1280):
    dk = desk(page(body, 'apple'), 'Your claims', 1080, True)
    ph = phone(page(body, 'visa', True), 'Claims', 1080, True)
    states = ''.join(f'<div style="display: flex; flex-direction: column; gap: 8px">{kick(t.upper(), GREEN)}{card(head(cid, st, True) + body(st), True)}</div>'
                     for t, cid, st in [('Ready to file', 'googleplay', 'ready'), ('Filing', 'cvs', 'filing'), ('Paid', 'amazon', 'paid')])
    html = (f'<div data-board style="width: 2300px; height: {H}px; box-sizing: border-box; padding: 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: {INK}; display: flex; flex-direction: column; gap: 26px">'
            f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: {GREEN}">{label}</span>'
            f'<span style="font-size: 16px; color: #43504A; font-weight: 600; max-width: 1400px; line-height: 1.45">{note}</span></div>'
            f'<div style="display: flex; gap: 50px; align-items: flex-start">{dk}{ph}<div style="width: 600px; flex: none; display: flex; flex-direction: column; gap: 22px">'
            f'{kick("OTHER STATES", "#43504A")}{states}</div></div></div>\n</x-dc>\n')
    open(os.path.join(OUT, f'{name}.dc.html'), 'w').write(HEAD % label.title() + html + JS.replace('"width":1926,"height":980', f'"width":2300,"height":{H}'))
    return H

if __name__ == '__main__':
    B = [('YourY1', 'YOUR CLAIMS DROPDOWN · 1 · TRACKER FIRST', 'Tapping a claim opens it in place (no popup). A 4-step tracker with dates leads, then one line on what happens next (red when we need you, with the reply box right there), the key facts and the actions. Case details sit behind a link.', body1),
         ('YourY2', 'YOUR CLAIMS DROPDOWN · 2 · TIMELINE AND MONEY CARD', 'A vertical timeline of what happened and what comes next, with dates. Actions (File now, reply) appear on the current step. A dark money card on the right says how much, where it goes and the claim ID.', body2),
         ('YourY3', 'YOUR CLAIMS DROPDOWN · 3 · RECEIPT', 'The claim opens as a receipt: expected payout big, a slim progress bar, one sentence on what is next, then paid to, claim ID (copy) and deadline. Case details fold away underneath.', body3)]
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    if not any(pg['id'] == 'yourc' for pg in c['pages']): c['pages'].append({'id': 'yourc', 'name': 'Your claims dropdown'})
    for n, (nm, lb, note, fn) in enumerate(B):
        H = board(nm, lb, note, fn, 1620 if nm == 'YourY3' else 1280)
        c['boards'][nm + '.dc.html'] = {'x': 0, 'y': [0, 1400, 2800][n], 'w': 2300, 'h': H, 'title': lb.split(' · ', 1)[1].title(), 'page': 'yourc', 'is_interactive': False}
        if nm + '.dc.html' not in c['order']: c['order'].append(nm + '.dc.html')
    c['notes']['tYour'] = {'x': 0, 'y': -300, 'page': 'yourc', 'text': 'Your claims · 3 dropdown drafts (open in place, no popup)', 'kind': 'title1', 'maxW': 2300, 'w': 240}
    if 'tYour' not in c['noteOrder']: c['noteOrder'].append('tYour')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w')); print('ok')
