/* Flow C production hooks (Nov 22 2026). Loaded only on /demo/flow-c, never on the canvas.
   Real Stripe payment (Express Checkout + Payment Element through /api/checkout ui 'elements'),
   blanket authorization through /api/sign, the claim-flow session for the member app, and the
   hand-off to the real dashboard (email code sign-in there links the Stripe purchase).
   Card details are only ever typed into Stripe's own fields. */
(function () {
  var SJS = 'https://js.stripe.com/endive/stripe.js', sjsP = null;
  var OFF = { A: { plan: '1y', flow: 'j', todayN: 0, ltv: 49.99, today: '$0.00', label: 'Start my free trial', line: 'Free for 3 days, then $49.99 a year' },
    B: { plan: '1mt', flow: 'k', todayN: 0, ltv: 59.97, today: '$0.00', label: 'Start my free trial', line: 'Free for 3 days, then $19.99 a month' } };
  var CP = { '1m': { plan: 'c1', todayN: 19.99, today: '$19.99', line: '$19.99 a month' }, '3m': { plan: 'c3', todayN: 44.97, today: '$44.97', line: '$44.97 every 3 months' }, '6m': { plan: 'c6', todayN: 59.94, today: '$59.94', line: '$59.94 every 6 months' } };
  var ST = { Alabama: 'AL', Alaska: 'AK', Arizona: 'AZ', Arkansas: 'AR', California: 'CA', Colorado: 'CO', Connecticut: 'CT', Delaware: 'DE', 'District of Columbia': 'DC', Florida: 'FL', Georgia: 'GA', Hawaii: 'HI', Idaho: 'ID', Illinois: 'IL', Indiana: 'IN', Iowa: 'IA', Kansas: 'KS', Kentucky: 'KY', Louisiana: 'LA', Maine: 'ME', Maryland: 'MD', Massachusetts: 'MA', Michigan: 'MI', Minnesota: 'MN', Mississippi: 'MS', Missouri: 'MO', Montana: 'MT', Nebraska: 'NE', Nevada: 'NV', 'New Hampshire': 'NH', 'New Jersey': 'NJ', 'New Mexico': 'NM', 'New York': 'NY', 'North Carolina': 'NC', 'North Dakota': 'ND', Ohio: 'OH', Oklahoma: 'OK', Oregon: 'OR', Pennsylvania: 'PA', 'Rhode Island': 'RI', 'South Carolina': 'SC', 'South Dakota': 'SD', Tennessee: 'TN', Texas: 'TX', Utah: 'UT', Vermont: 'VT', Virginia: 'VA', Washington: 'WA', 'West Virginia': 'WV', Wisconsin: 'WI', Wyoming: 'WY' };
  var AGREE = 'My answers are true, and I agree that Claimclub can fill out and file my claims for me, as described in the Claim Filing Authorization Agreement.';
  var KEY = 'fc_state';
  var APPEAR = { theme: 'stripe', variables: { colorPrimary: '#12805C', colorBackground: '#FFFFFF', colorText: '#000000', colorDanger: '#FF3B30', fontFamily: '-apple-system, BlinkMacSystemFont, Inter, system-ui, sans-serif', fontSizeBase: '16px', borderRadius: '12px', spacingUnit: '4px' } };
  function offerOf(st) { if (st.offer === 'C') { var c = CP[st.pk || '6m'] || CP['6m']; return { plan: c.plan, flow: 'i', todayN: c.todayN, ltv: c.todayN, today: c.today, label: 'Pay ' + c.today, line: c.line }; } return OFF[st.offer] || OFF.A; }
  function loadStripe() {
    if (window.Stripe) return Promise.resolve(window.Stripe);
    if (sjsP) return sjsP;
    sjsP = new Promise(function (ok, no) { var t = document.createElement('script'); t.src = SJS; t.async = true; t.onload = function () { window.Stripe ? ok(window.Stripe) : no(new Error('no Stripe')); }; t.onerror = function () { sjsP = null; no(new Error('Stripe.js did not load')); }; document.head.appendChild(t); });
    return sjsP;
  }
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function post(u, b) { return fetch(u, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) }).then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { j._ok = r.ok; return j; }); }); }
  function okEmail(e) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e || ''); }
  function sid() { try { var s = sessionStorage.getItem('fc_sid'); if (s) return s; s = 'fc-' + Math.random().toString(36).slice(2, 12) + Date.now().toString(36); sessionStorage.setItem('fc_sid', s); return s; } catch (e) { return 'fc-' + Date.now().toString(36); } }
  function toast(api, m) { var t = document.createElement('div'); t.textContent = m; t.style.cssText = 'position:absolute;left:50%;top:60px;transform:translateX(-50%);z-index:40;max-width:86%;padding:10px 16px;border-radius:14px;background:#1C1C1E;color:#FFF;font-size:14px;font-weight:600;box-shadow:0 10px 24px rgba(0,0,0,.25);text-align:center'; api.el.appendChild(t); setTimeout(function () { t.remove(); }, 3200); }
  function css() {
    if (document.getElementById('fcPayCss')) return;
    var s = document.createElement('style'); s.id = 'fcPayCss';
    s.textContent = '.fcp{position:absolute;inset:0;z-index:30;background:rgba(0,0,0,.38);display:flex;align-items:flex-end;justify-content:center;animation:fcIn .2s both}'
      + '.fcp-s{background:#F2F2F7;width:100%;max-width:520px;max-height:92%;overflow:auto;border-radius:22px 22px 0 0;padding:16px 18px 30px;display:flex;flex-direction:column;gap:12px;box-sizing:border-box}'
      + '.dkc .fcp{align-items:center}.dkc .fcp-s{border-radius:22px;max-width:460px}'
      + '.fcp-h{display:flex;align-items:center;gap:8px}.fcp-h b{flex:1;font-size:20px;letter-spacing:-.4px}.fcp-x{width:32px;height:32px;flex:none;padding:0;display:flex;align-items:center;justify-content:center;border-radius:99px;border:0;background:#E5E5EA;color:#3C3C43;cursor:pointer;transition:background-color .14s,transform .14s}.fcp-x:hover{background:#D6D6DC}.fcp-x:active{transform:scale(.94)}@media (hover:hover){.fcp .fcp-pay:not(:disabled):hover{filter:brightness(1.1);transform:translateY(-1px);box-shadow:0 8px 18px rgba(18,128,92,.28)}}.fcp .fcp-pay{transition:filter .14s,transform .14s,box-shadow .14s,opacity .14s}.fcp .fcp-pay.off{opacity:.45;box-shadow:none!important;transform:none!important;filter:none!important}.fcp-ag{display:flex;gap:10px;align-items:flex-start;font-size:12.5px;line-height:1.4;color:#6E6E73;cursor:pointer;padding:2px 2px}.fcp-ag input{width:20px;height:20px;margin:0;flex:none;accent-color:#12805C;cursor:pointer}.fcp-ag a{color:inherit}.fcp .fcp-pay:not(:disabled):active{transform:scale(.98)}'
      + '.fcp-r{display:flex;align-items:center;justify-content:space-between;background:#FFF;border-radius:14px;padding:12px 14px;font-size:14.5px}.fcp-r span{color:#6E6E73}.fcp-r b{font-size:16px}'
      + '.fcp .fcp-e{height:52px!important;min-height:52px;border-radius:12px;border:1px solid #D1D1D6;background:#FFF;padding:0 14px;font-size:16px;font-family:inherit;outline:none;width:100%;box-sizing:border-box}.fcp-e:focus{border-color:#12805C;box-shadow:0 0 0 3px rgba(18,128,92,.15)}'
      + '.fcp-l{font-size:12.5px;font-weight:600;color:#6E6E73;margin:2px 4px -6px}.fcp-or{display:flex;align-items:center;gap:10px;color:#8E8E93;font-size:13px}.fcp-or:before,.fcp-or:after{content:"";flex:1;height:1px;background:#D1D1D6}'
      + '.fcp-err{color:#FF3B30;font-size:14px;font-weight:600;text-align:center}.fcp .fcp-pay{height:56px!important;min-height:56px;border:0;border-radius:16px;background:#12805C;color:#FFF;font-size:18px!important;font-weight:700;font-family:inherit;cursor:pointer}.fcp-pay:disabled{opacity:.55}'
      + '.fcp-f{font-size:12px;color:#8E8E93;text-align:center;line-height:1.4}.fcp-ld{padding:28px 0;text-align:center;color:#8E8E93;font-size:14px}.fcp-ld i{display:block;margin:0 auto 10px;width:28px;height:28px;border-radius:50%;border:3px solid #DDE5E0;border-top-color:#12805C;animation:fcSpin .8s linear infinite}';
    document.head.appendChild(s);
  }
  function verify(id) { return fetch('/api/session?id=' + encodeURIComponent(id)).then(function (r) { return r.json(); }).catch(function () { return { paid: false }; }); }

  function finish(api, j, o) {
    try { sessionStorage.removeItem(KEY); } catch (e) {}
    var email = (j && j.email) || api.st.email || '';
    api.set({ email: email, paidPlan: o.plan, paidFlow: o.flow });
    api.doPaid();
  }

  // Enter presses the screen's main button (desktop keyboards), unless focus is in a field that needs Enter or a sheet is open.
  function enterKey(api, e) {
    if (e.key !== 'Enter' || e.shiftKey || e.altKey || e.metaKey || e.ctrlKey || e.isComposing) return;
    var t = e.target, tag = (t && t.tagName) || '';
    if (tag === 'TEXTAREA' || tag === 'BUTTON' || tag === 'A' || (t && t.closest && t.closest('.whl'))) return;
    if (/^q\d+$/.test(api.step())) return; // questions are answered with Yes / No, not Enter
    var sheet = api.el.querySelector('.fcp');
    if (sheet) { if (tag === 'INPUT') { var pb = sheet.querySelector('.fcp-pay'); if (pb && !pb.disabled) { e.preventDefault(); pb.click(); } } return; }
    var btns = [].slice.call(api.el.querySelectorAll('.ft .btn, .ft button')).filter(function (b) { return !b.disabled && b.offsetParent !== null; });
    var b = btns.filter(function (x) { return x.dataset.a === 'next' || x.dataset.a === 'pay' || x.dataset.a === 'nextc'; })[0] || btns[btns.length - 1];
    if (api.step() === 'offer') { var m = api.el.querySelector('[data-a="pay"].mint') || api.el.querySelector('[data-a="pay"]'); b = m && !m.disabled ? m : null; }
    if (!b) return;
    if (api.st.pick) { api.set({ pick: '' }); }
    e.preventDefault(); b.click();
  }
  // Each screen has its own URL (/demo/flow-c/<screen>) and the answers live in sessionStorage, so a refresh or the
  // browser's back button keeps your place. Paid screens can't be reached without paying, and you can't go back into payment.
  var PROG = 'fc_prog', BASE = '/check', last = null, popping = false;
  var SLUG = { w1: 'welcome', gap: 'unclaimed', w2: 'we-find', w3: 'we-file', w4: 'trust', rev: 'reviews', name: 'name', pains: 'about-you', goal: 'goal', plan: 'how-you-get-paid', qintro: 'quiz',
    load: 'checking', est: 'estimate', pick: 'choose-claims', chk: 'check-claims', win: 'ready', offer: 'checkout', paid: 'confirming', profile: 'details', bank: 'bank', open: 'opening', dash: 'dashboard' };
  var POST = { paid: 1, profile: 1, bank: 1, open: 1, dash: 1 };
  function slugOf(step) { return /^q\d+$/.test(step) ? 'question-' + (+step.slice(1) + 1) : SLUG[step] || step; }
  function stepOf(slug) { var m = /^question-(\d+)$/.exec(slug || ''); if (m) return 'q' + (m[1] - 1); for (var k in SLUG) if (SLUG[k] === slug) return k; return ''; }
  function urlFor(step) { var q = new URLSearchParams(location.search); ['sid', 'paid', 'canceled'].forEach(function (k) { q.delete(k); }); var qs = q.toString(); return BASE + (step === 'w1' ? '' : '/' + slugOf(step)) + (qs ? '?' + qs : ''); }
  function saveProg(api) { try { var c = JSON.parse(JSON.stringify(api.st)); delete c.pick; delete c.menu; c.payDone = 0; sessionStorage.setItem(PROG, JSON.stringify(c)); } catch (e) {} }
  function allowed(api, step) { // where a request for <step> may land
    var paid = !!api.st.paidPlan;
    if (paid && !POST[step]) return 'profile';
    if (!paid && POST[step]) { var cur = api.step(); return POST[cur] ? 'offer' : cur; }
    if (step === 'load') return 'est';
    if (step === 'paid') return 'profile';
    if (/^q\d+$/.test(step) || ['est', 'pick', 'chk', 'win', 'offer'].indexOf(step) >= 0) { if (step !== 'q0' && /^q/.test(step) && !api.st.name) return 'name'; }
    return step;
  }
  function jump(api, step) { api.set({ pick: '', menu: 0, payDone: 0 }); api.at(step); if (step === 'open') FC.open(api); }

  var SESS = null, WAL = null, PREVIEW = !!window.__fcPreview;
  // Funnel tracking (/api/track, same table as the claim flow; Flow C steps keep their own names, 'offer' counts as reaching the offer).
  function track(api, step) {
    if (PREVIEW || !/^(www\.)?claimclub\.io$|\.vercel\.app$|^localhost$|^127\./.test(location.hostname)) return;
    var src = ''; try { src = sessionStorage.getItem('cc_src') || ''; } catch (e) {}
    try { fetch('/api/track', { method: 'POST', keepalive: true, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sid: sid(), step: step, idx: api.st.s, device: document.body.classList.contains('d') ? 'd' : 'm', lang: 'en', flow: offerOf(api.st).flow, source: src }) }).catch(function () {}); } catch (e) {}
  }
  // Ad events (Meta Pixel, Google Ads), never on preview links. Purchase uses the Checkout Session ID as the event ID (the webhook sends the same one server side).
  function ck(n) { var m = document.cookie.match(new RegExp('(?:^|; )' + n + '=([^;]*)')); return m ? decodeURIComponent(m[1]) : ''; }
  function fbc() { var c = ck('_fbc'); if (c) return c; var id = new URLSearchParams(location.search).get('fbclid'); if (id) { try { sessionStorage.setItem('cc_fbclid', id); } catch (e) {} } else { try { id = sessionStorage.getItem('cc_fbclid'); } catch (e) {} } return id ? 'fb.1.' + Date.now() + '.' + id : ''; }
  function attr() { return { fbp: ck('_fbp'), fbc: fbc(), gpc: navigator.globalPrivacyControl ? 1 : 0, source_url: location.href }; }
  function initCheckout(o) { if (PREVIEW || typeof window.fbq !== 'function') return; try { fbq('track', 'InitiateCheckout', { value: o.todayN, currency: 'USD' }, { eventID: 'ic-' + Date.now() + '-' + Math.random().toString(36).slice(2) }); } catch (e) {} }
  function purchased(o, id) {
    if (PREVIEW || !id) return;
    try { if (sessionStorage.getItem('st_' + id)) return; sessionStorage.setItem('st_' + id, '1'); } catch (e) {}
    try { if (typeof window.fbq === 'function') fbq('track', 'Purchase', { value: o.todayN, currency: 'USD', predicted_ltv: o.ltv }, { eventID: id }); } catch (e) {}
    try { if (typeof window.gtag === 'function') gtag('event', 'conversion', { send_to: 'AW-18562196705/m4kHCID10LsdEOHJkpNF', value: o.todayN, currency: 'USD', transaction_id: id }); } catch (e) {}
  }
  function saveRedirect(api, o, email) { try { var c = JSON.parse(JSON.stringify(api.st)); if (email) c.email = email; sessionStorage.setItem(KEY, JSON.stringify({ st: c, o: o })); } catch (e) {} }
  function paidOk(api, res, s, o, fail, done) {
    var id = (res.session && res.session.id) || s.secret.split('_secret_')[0];
    verify(id).then(function (j) { if (j.paid) { purchased(o, id); if (done) done(); SESS = null; finish(api, j, o); } else if (fail) fail('We could not confirm that payment yet. Please try again.'); else toast(api, 'We could not confirm that payment yet.'); });
  }
  var FC = {
    onStep: function (api) {
      var step = api.step(); saveProg(api);
      if (step === 'offer') FC.wallet(api);
      if (step === last) return;
      var u = urlFor(step);
      track(api, step);
      if (location.pathname + location.search !== u) { if (last && !popping) history.pushState({ fc: step }, '', u); else history.replaceState({ fc: step }, '', u); }
      last = step; popping = false;
    },
    attach: function (api) {
      // Restore the saved answers and the screen named in the URL.
      var saved = null; try { saved = JSON.parse(sessionStorage.getItem(PROG) || 'null'); } catch (e) {}
      var want = stepOf(location.pathname.replace(BASE, '').replace(/^\/|\/$/g, ''));
      if (saved && !new URLSearchParams(location.search).get('sid')) {
        var off = api.st.offer; Object.assign(api.st, saved); api.st.offer = off;
        var target = allowed(api, want || 'w1'); jump(api, target);
      } else if (want && want !== 'w1') { history.replaceState(null, '', urlFor('w1')); }
      window.addEventListener('popstate', function (e) {
        var s = (e.state && e.state.fc) || stepOf(location.pathname.replace(BASE, '').replace(/^\/|\/$/g, '')) || 'w1';
        var t = allowed(api, s); popping = true; jump(api, t);
        if (t !== s) history.replaceState({ fc: t }, '', urlFor(t));
      });
      document.addEventListener('keydown', function (e) { enterKey(api, e); });

      if (/^(localhost|127\.)/.test(location.hostname)) window.__fcApi = api; // local tests
      var q = new URLSearchParams(location.search), id = q.get('sid');
      if (q.get('canceled')) history.replaceState(null, '', location.pathname + (q.get('offer') ? '?offer=' + q.get('offer') : ''));
      if (!id) return;
      var saved = null; try { saved = JSON.parse(sessionStorage.getItem(KEY) || 'null'); } catch (e) {}
      history.replaceState(null, '', location.pathname);
      if (!saved) return;
      api.set(saved.st); api.at('offer');
      verify(id).then(function (j) { if (j.paid) { purchased(saved.o, id); finish(api, j, saved.o); } else toast(api, 'That payment did not go through. Please try again.'); });
    },
    // One Stripe Checkout Session per plan, shared by the wallet buttons on the page and the card form in the popup.
    session: function (api) {
      var o = offerOf(api.st), key = o.plan + ':' + o.flow;
      if (SESS && SESS.key === key) return SESS.p;
      var ids = api.elig().map(function (d) { return d.id; });
      var body = { kind: 'member', plan: o.plan, flow: o.flow, consent: true, ids: ids, sid: sid(), ui: 'elements', back: 'flow-c', path: '/check' }, at = attr();
      for (var k0 in at) body[k0] = at[k0];
      if (okEmail(api.st.email)) body.email = api.st.email;
      var p = Promise.all([post('/api/checkout', body), loadStripe().catch(function () { return null; })]).then(function (r) {
        var j = r[0], S = r[1];
        if (j.clientSecret && S) { var stripe = S(j.publishableKey), checkout = stripe.initCheckoutElementsSdk({ clientSecret: j.clientSecret, elementsOptions: { appearance: APPEAR } }); return { o: o, secret: j.clientSecret, checkout: checkout, actionsP: checkout.loadActions() }; }
        if (j.url) return { o: o, url: j.url };
        throw new Error(j.error || 'no session');
      });
      p.catch(function () { if (SESS && SESS.p === p) SESS = null; });
      SESS = { key: key, p: p };
      return p;
    },
    // Real Apple Pay / Google Pay buttons (Stripe Express Checkout) in place of the page's pay buttons. Gated on the I agree box.
    wallet: function (api) {
      var box = api.el.querySelector('[data-wallet]');
      if (!box || box.dataset.m || api.st.paidPlan) return;
      box.dataset.m = '1';
      if (WAL) { try { WAL.destroy(); } catch (e) {} WAL = null; }
      FC.session(api).then(function (s) {
        if (!s.checkout || !document.contains(box)) return;
        var o = s.o, ex = s.checkout.createExpressCheckoutElement({ buttonHeight: 52, buttonTheme: { applePay: 'black', googlePay: 'black' }, buttonType: { applePay: 'plain', googlePay: 'plain' }, layout: { maxColumns: 1, overflow: 'never' }, paymentMethodOrder: ['apple_pay', 'google_pay'], paymentMethods: { applePay: 'always', googlePay: 'always', link: 'never', paypal: 'never', amazonPay: 'never', klarna: 'never' } });
        WAL = ex;
        ex.on('click', function (ev) { api.st.agree = true; initCheckout(o); ev.resolve(); }); // tapping a wallet button is the agreement (line under the buttons)
        ex.on('confirm', function (ev) {
          saveRedirect(api, o, api.st.email);
          s.actionsP.then(function (r) { if (r.type !== 'success') throw new Error('Payment could not start. Try paying with a card.'); return r.actions.confirm({ expressCheckoutConfirmEvent: ev, redirect: 'if_required' }); })
            .then(function (res) { if (res.type === 'success') paidOk(api, res, s, o); else toast(api, (res.error && res.error.message) || 'That payment did not go through.'); })
            .catch(function (x) { toast(api, x.message || 'Something went wrong. Please try again.'); });
        });
        ex.mount(box);
      }).catch(function () {});
    },
    changed: function (api, a) { if (a === 'pk') { var b = api.el.querySelector('[data-wallet]'); if (b) { delete b.dataset.m; b.innerHTML = ''; } FC.wallet(api); } },
    pay: function (api) {
      var st = api.st;
      css();
      var sh = document.createElement('div'); sh.className = 'fcp';
      sh.innerHTML = '<div class="fcp-s"><div class="fcp-h"><b>Pay with card</b><button class="fcp-x" aria-label="Close"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg></button></div>'
        + '<div class="fcp-l">EMAIL</div><input class="fcp-e" type="email" autocomplete="email" inputmode="email" placeholder="you@example.com" value="' + esc(st.email || '') + '">'
        + '<div class="fcp-ld"><i></i>Loading secure payment</div><div class="fcp-card"></div>'
        + '<label class="fcp-ag"><input type="checkbox"><span>My answers are true, and I agree that Claimclub can fill out and file my claims for me, as described in the <a href="/authorization" target="_blank">Claim Filing Authorization Agreement</a>.</span></label>'
        + '<div class="fcp-err" hidden></div><button class="fcp-pay off" disabled></button>'
        + '<div class="fcp-f"></div></div>';
      api.el.appendChild(sh);
      var Q = function (q) { return sh.querySelector(q); }, err = Q('.fcp-err'), btn = Q('.fcp-pay'), em = Q('.fcp-e'), ag = Q('.fcp-ag input'), card = null, cardOk = false;
      // The pay button stays faded until the email, the card and the agreement box are all done.
      function missing() { return !okEmail(em.value.trim()) ? 'Enter your email.' : !cardOk ? 'Finish your card details.' : !ag.checked ? 'Tick the box to agree.' : ''; }
      function update() { btn.classList.toggle('off', !!missing()); if (!missing()) showErr(null); }
      em.addEventListener('input', update); ag.addEventListener('change', update);
      function close() { try { card && card.destroy(); } catch (e) {} sh.remove(); }
      function showErr(m) { err.textContent = m || ''; err.hidden = !m; }
      Q('.fcp-x').onclick = close; sh.addEventListener('click', function (e) { if (e.target === sh) close(); });
      FC.session(api).then(function (s) {
        var o = s.o; initCheckout(o);
        btn.textContent = o.label; Q('.fcp-f').textContent = 'Processed securely by Stripe. ' + (o.flow === 'i' ? 'Renews at ' + o.line + ' until you cancel.' : o.line + '. You will not be charged until your trial ends. Cancel anytime.');
        if (s.url) { saveRedirect(api, o, em.value.trim()); location.href = s.url; return; }
        card = s.checkout.createPaymentElement({ layout: { type: 'tabs' }, paymentMethodOrder: ['card'], wallets: { applePay: 'never', googlePay: 'never', link: 'never' }, terms: { card: 'never' } });
        card.on('ready', function () { var l = Q('.fcp-ld'); if (l) l.remove(); btn.disabled = false; });
        card.on('change', function (ev) { cardOk = !!(ev && ev.complete); update(); });
        card.mount(Q('.fcp-card'));
        var label = o.label;
        btn.onclick = function () {
          var e = em.value.trim(), m = missing();
          if (btn.disabled) return;
          if (m) { showErr(m); if (m === 'Enter your email.') em.focus(); return; }
          api.st.agree = true;
          showErr(null); btn.disabled = true; btn.textContent = 'Processing'; saveRedirect(api, o, e);
          var reset = function (m) { btn.disabled = false; btn.textContent = label; showErr(m); };
          s.actionsP.then(function (r) { if (r.type !== 'success') throw new Error('Payment could not start. Close this and try again.'); return r.actions.updateEmail ? r.actions.updateEmail(e).then(function (u) { if (u && u.type === 'error') throw new Error((u.error && u.error.message) || 'Check your email address.'); return r; }) : r; })
            .then(function (r) { return r.actions.confirm({ redirect: 'if_required' }); })
            .then(function (res) { if (res.type === 'success') { api.st.email = e; btn.textContent = 'Confirming payment'; paidOk(api, res, s, o, function (m) { reset(m); }, close); } else reset((res.error && res.error.message) || 'That card did not go through. Check the details or try another card.'); })
            .catch(function (x) { reset(x.message || 'Something went wrong. Please try again.'); });
        };
      }).catch(function () { var l = Q('.fcp-ld'); if (l) l.textContent = 'Payment could not load. Close this and try again.'; });
    },
    profile: function (api) {
      var st = api.st, f = {}; [].slice.call(api.el.querySelectorAll('.bd input.inp')).forEach(function (i) { f[i.dataset.f] = i.value.trim(); });
      var p = { first: f['First name'], last: f['Last name'], phone: f.Phone, street: f.Street, city: f.City, zip: f.ZIP };
      var bd = st.bd || [], dob = bd.length === 3 ? bd[0] + '/' + bd[1] + '/' + bd[2] : '', state = ST[st.stt] || '';
      if (!p.first || !p.last) return toast(api, 'Enter your first and last name.');
      if (String(p.phone || '').replace(/\D/g, '').length < 10) return toast(api, 'Enter a 10-digit phone number.');
      if (!dob) return toast(api, 'Pick your birthday.');
      if (!p.street || !p.city || !state) return toast(api, 'Enter your full address.');
      if (!/^\d{5}$/.test(p.zip || '')) return toast(api, 'Enter a 5-digit ZIP code.');
      var name = p.first + ' ' + p.last, ids = api.elig().map(function (d) { return d.id; }), now = new Date().toISOString();
      st.p = p;
      try {
        localStorage.setItem('claimclub_session', JSON.stringify({ ids: ids, signed: ids, bank: false, plan: st.paidPlan || '', paid: 'member', flow: st.paidFlow || '',
          p: { name: name, email: st.email || '', phone: p.phone, street: p.street, city: p.city, st: state, zip: p.zip, dob: dob } }));
        localStorage.setItem('claimclub_tour', '1');
      } catch (e) {}
      if (okEmail(st.email) && ids.length) post('/api/sign', { email: st.email, lang: 'en', page: '/demo/flow-c', method: 'blanket', records: api.elig().map(function (d) {
        return { settlement_id: d.id, settlement_title: d.co, signer_name: name, signature_text: name, details: { street: p.street, city: p.city, state: state, zip: p.zip, phone: p.phone, dob: dob }, answers: st.chk[d.id] || {},
          statements: { attestation: AGREE, consent: 'Agreed at checkout', agreement_url: 'https://www.claimclub.io/authorization' }, agreement_version: '2026-11-21', client_signed_at: now };
      }) }).catch(function () {});
      api.next();
    },
    bank: function (api) {
      // Plaid opens in the dashboard after sign-in (same hand-off as the claim flow).
      try { localStorage.setItem('claimclub_connect', '1'); } catch (e) {}
      api.set({ bank: 'done' }); setTimeout(function () { if (api.step() === 'bank') api.next(); }, 700);
    },
    open: function (api) {
      var e = api.st.email || '';
      location.href = '/login' + (okEmail(e) ? '?email=' + encodeURIComponent(e) : '');
    }
  };
  window.ccFC = FC;
})();
