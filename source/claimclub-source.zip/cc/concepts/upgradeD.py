# Upgrade (paywall) pages for Claim refunds and Manage subscriptions, 3 drafts (Nov 21 2026, canvas only).
# Henry: the live lock card is bland. Each draft uses the same format on both pages and shows what the member
# would get (a sample of the feature, steps, trust line) in the brand greens. Writes UpgA/UpgB/UpgC.dc.html on the
# canvas page "Upgrade pages". Sample data is labelled Example.
import os, re, json
from tierE import HEAD, JS, OUT
from perksD import ic, LU

LU.update({
    'card': 'M4 5h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z M2 10h20',
    'undo': 'M9 14 4 9l5-5 M4 9h10.5a5.5 5.5 0 0 1 0 11H11',
    'repeat': 'm17 2 4 4-4 4 M3 11v-1a4 4 0 0 1 4-4h14 m-14 16-4-4 4-4 M21 13v1a4 4 0 0 1-4 4H3',
    'xc': 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20z m3 7-6 6 m0-6 6 6',
    'shield': 'M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z m-11 -1 2 2 4-4',
    'trend': 'M22 7 13.5 15.5 8.5 10.5 2 17 M16 7h6v6',
    'cal': 'M8 2v4 M16 2v4 M3 10h18 M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z',
    'alert': 'm21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3 M12 9v4 M12 17h.01',
    'zap': 'M13 2 3 14h9l-1 8 10-12h-9z',
    'sparkle': 'M12 3l1.9 5.8L20 10l-6.1 1.9L12 18l-1.9-6.1L4 10l6.1-1.2z',
    'bank': 'M3 21h18 M5 21V10 M19 21V10 M9 21V10 M15 21V10 M12 2 3 7h18z',
})
INK, MUTE, LINE, MINT, GREEN, DARK, BG = '#0A0F0D', '#5B6862', '#E3EAE6', '#3DDC97', '#12805C', '#0F3B2E', '#F3F6F4'
RED, AMB, BLU = ('#B8333A', '#FDECEC'), ('#8A5A00', '#FFF4DB'), ('#2453A6', '#EAF1FF')

src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'simpleD.py')).read()
A = re.search(r"_A='([^']+)'", src).group(1).split(); N = re.search(r"_N='([^']+)'", src).group(1).split()
T = {n: '/_blob/' + a for n, a in zip(N, A)}

def logo(i, sz=36):
    r = f'{sz * .28:.0f}px'
    if i in T: return f'<img src="{T[i]}" alt="" style="width: {sz}px; height: {sz}px; flex: none; border-radius: {r}; object-fit: contain">'
    k, bg, fg = {'fee': ('bank', '#FFF4DB', '#8A5A00'), 'unk': ('card', '#EAF1FF', '#2453A6')}[i]
    return f'<span style="width: {sz}px; height: {sz}px; flex: none; border-radius: {r}; background: {bg}; display: flex; align-items: center; justify-content: center">{ic(k, sz * .5, fg, 2.2)}</span>'
def chip(t, c, icon=''):
    return f'<span style="display: inline-flex; align-items: center; gap: 5px; font-size: 12px; font-weight: 800; padding: 4px 9px; border-radius: 99px; background: {c[1]}; color: {c[0]}; white-space: nowrap">{icon}{t}</span>'
def ex(dark=False):
    return f'<span style="font-size: 11px; font-weight: 800; letter-spacing: 1px; padding: 4px 8px; border-radius: 99px; background: {"rgba(255,255,255,.14)" if dark else "#EEF2F0"}; color: {"#CFE9DD" if dark else "#8A968F"}">EXAMPLE</span>'

# ---------- sample data ----------
CHG = [('netflix', 'Netflix', 'Nov 3', '$15.49', None),
       ('netflix', 'Netflix', 'Nov 3', '$15.49', ('Charged twice', RED)),
       ('doordash', 'DoorDash', 'Nov 6', '$32.10', None),
       ('fee', 'Overdraft fee', 'Nov 9', '$35.00', ('Surprise fee', AMB)),
       ('unk', 'SQ *BLUFFTON 4471', 'Nov 12', '$68.00', ('Do you know this?', BLU))]
SUB = [('netflix', 'Netflix', 'Renews Dec 3', '$15.49', None),
       ('peloton', 'Peloton', 'Renews Dec 1', '$44.00', ('Price went up $5', AMB)),
       ('audible', 'Audible', 'Renews in 2 days', '$14.95', ('Renews soon', BLU)),
       ('spotify', 'Spotify', 'Renews Dec 9', '$11.99', None),
       ('max', 'Max', 'Renews Dec 14', '$16.99', None)]

PAGES = {
 'ref': dict(tab='Claim refunds', ptab='Refunds', title='Get your money back from bad charges',
   sub='Connect a card and we read your charges for you. When something looks wrong, we ask the company for your money back.',
   steps=[('card', 'Connect a card', 'Read-only, through Plaid. Takes a minute.'),
          ('search', 'We spot the bad ones', 'Double charges, surprise fees and charges you do not know.'),
          ('undo', 'We ask for it back', 'You tap Fight it. We handle the company and track the refund.')],
   rows=CHG, head='Your card · November', foot=('Asked for $50.49 back', 'Netflix double charge and the overdraft fee'), footic='undo',
   plain='Charges look normal at a glance', found='Priority finds what is worth fighting'),
 'sub': dict(tab='Manage subscriptions', ptab='Subscriptions', title='Every subscription, in one place',
   sub='See what you pay for each month, get a heads up before anything renews or gets pricier, and let us cancel the ones you do not want.',
   steps=[('card', 'Connect a card', 'Read-only, through Plaid. Takes a minute.'),
          ('repeat', 'We find every repeat charge', 'One list with prices, renewal dates and price changes.'),
          ('xc', 'Tap Cancel for me', 'We cancel it with the company and confirm when it is done.')],
   rows=SUB, head='$103.42 a month', foot=('Audible cancelled for you', 'Saves $179.40 a year'), footic='ok',
   plain='Spread across your statement', found='Priority puts them in one list'),
}
LU['ok'] = 'M20 6 9 17l-5-5'
PRICE = 'Upgrade to Priority · $30/mo'
FINE = 'Priority also files every claim within 24 hours, including local ones. Cancel anytime.'

# ---------- frames ----------
def topbar(on):
    t = lambda s: f'<span style="font-size: 14px; font-weight: 800; padding: 8px 14px; border-radius: 99px; display: inline-flex; align-items: center; gap: 6px; {"background: #E9F6EF; color: " + GREEN if s == on else "color: #43504A"}">{s}{ic("lock", 13, GREEN if s == on else "#8A968F", 2.2) if s in ("Claim refunds", "Manage subscriptions") else ""}</span>'
    return (f'<div style="height: 64px; flex: none; background: #FFFFFF; border-bottom: 1px solid {LINE}; display: flex; align-items: center; padding: 0 24px; gap: 8px">'
            f'<b style="font-size: 19px; letter-spacing: -.5px; margin-right: auto">claimclub<span style="color: {GREEN}">.io</span></b>'
            + t('Your claims') + t('Find claims') + t('Claim refunds') + t('Manage subscriptions')
            + f'<span style="margin-left: auto; width: 34px; height: 34px; border-radius: 99px; background: {DARK}; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 14px">A</span></div>')
def desk(body, on, h=980, pad=True):
    inner = f'<div style="width: 900px; margin: 0 auto; padding: 32px 0; display: flex; flex-direction: column; gap: 22px">{body}</div>' if pad else body
    return (f'<div style="width: 1120px; height: {h}px; flex: none; border-radius: 18px; overflow: hidden; background: {BG}; box-shadow: 0 20px 50px rgba(10,15,13,.14); display: flex; flex-direction: column">'
            + topbar(on) + f'<div style="flex: 1; overflow: hidden">{inner}</div></div>')
def phone(body, on, h=980, pad=True):
    nav = ''.join(f'<span style="flex: 1; text-align: center; font-size: 11px; font-weight: 800; color: {GREEN if t == on else "#8A968F"}">{t}</span>' for t in ('Claims', 'Find', 'Refunds', 'Subscriptions'))
    inner = f'<div style="padding: 6px 16px 16px; display: flex; flex-direction: column; gap: 16px">{body}</div>' if pad else body
    return (f'<div style="width: 390px; height: {h}px; flex: none; border-radius: 40px; overflow: hidden; background: {BG}; box-shadow: 0 0 0 10px #1C2420, 0 24px 50px rgba(10,15,13,.25); display: flex; flex-direction: column">'
            f'<div style="height: 44px; flex: none"></div><div style="flex: 1; overflow: hidden">{inner}</div>'
            f'<div style="height: 64px; flex: none; background: #FFFFFF; border-top: 1px solid {LINE}; display: flex; align-items: center; padding-bottom: 8px">{nav}</div></div>')

def cta(m=False, kind='mint', full=True):
    st = f'background: {MINT}; color: {DARK}' if kind == 'mint' else f'background: {DARK}; color: #FFFFFF'
    return (f'<div style="display: flex; flex-direction: column; gap: 10px; {"align-items: stretch" if full or m else "align-items: flex-start"}">'
            f'<span style="height: {54 if m else 56}px; padding: 0 28px; border-radius: 99px; {st}; display: flex; align-items: center; justify-content: center; gap: 8px; font-size: 16px; font-weight: 800">{ic("zap", 17, DARK if kind == "mint" else MINT, 2.4)}{PRICE}</span></div>')
def fine(dark=False, center=False):
    c = '#B9D3C7' if dark else MUTE
    return f'<span style="font-size: 13px; font-weight: 600; color: {c}; line-height: 1.45; {"text-align: center" if center else ""}">{FINE}</span>'
def trust(dark=False):
    c = '#CFE9DD' if dark else '#43504A'
    return (f'<span style="display: inline-flex; align-items: center; gap: 7px; font-size: 13px; font-weight: 700; color: {c}">{ic("shield", 16, MINT if dark else GREEN, 2.2)}'
            'Read-only connection through Plaid. We never see your bank login.</span>')

# ---------- the sample feature UI (shared) ----------
def rows_ui(p, m=False, flags=True, dim=False, cap=5):
    out = ''
    for i, (lg, nm, d, amt, fl) in enumerate(p['rows'][:cap]):
        hot = flags and fl
        right = f'<b style="font-size: {14 if m else 15}px; {"color: " + INK}">{amt}{"<span style=\"font-size: 11.5px; color: " + MUTE + "\">/mo</span>" if p is PAGES["sub"] else ""}</b>'
        tag = chip(fl[0], fl[1]) if hot else ''
        out += (f'<div style="display: flex; align-items: center; gap: 11px; padding: {10 if m else 11}px {12 if m else 14}px; {"border-top: 1px solid " + LINE if i else ""}; {"background: " + fl[1][1] + "66" if hot else ""}; {"opacity: .55" if dim else ""}">'
                f'{logo(lg, 32 if m else 36)}<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 3px">'
                f'<b style="font-size: {13.5 if m else 14.5}px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{nm}</b>'
                f'<span style="display: flex; align-items: center; gap: 6px; flex-wrap: wrap"><span style="font-size: 12px; font-weight: 600; color: {MUTE}">{d}</span>{tag}</span></span>{right}</div>')
    return out
def feature(p, m=False, flags=True, head=True, cap=5):
    h = (f'<div style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; border-bottom: 1px solid {LINE}">'
         f'<b style="font-size: 13px; letter-spacing: .4px; color: #43504A">{p["head"].upper()}</b>{ex()}</div>') if head else ''
    return f'<div style="background: #FFFFFF; border-radius: 18px; overflow: hidden; box-shadow: 0 18px 40px rgba(10,15,13,.12), inset 0 0 0 1px {LINE}">{h}{rows_ui(p, m, flags, cap=cap)}</div>'
def win(p, m=False, dark=False):
    t, s = p['foot']
    return (f'<div style="display: flex; align-items: center; gap: 12px; padding: 12px 14px; border-radius: 16px; background: {DARK if dark else "#FFFFFF"}; box-shadow: 0 16px 36px rgba(10,15,13,.18){", inset 0 0 0 1.5px " + MINT if not dark else ""}">'
            f'<span style="width: 36px; height: 36px; flex: none; border-radius: 99px; background: {MINT}; display: flex; align-items: center; justify-content: center">{ic(p["footic"], 18, DARK, 2.6)}</span>'
            f'<span style="display: flex; flex-direction: column; gap: 2px; min-width: 0"><b style="font-size: {14 if m else 15}px; color: {"#FFFFFF" if dark else INK}">{t}</b>'
            f'<span style="font-size: 12.5px; font-weight: 600; color: {"#B9D3C7" if dark else MUTE}">{s}</span></span></div>')
def kick(dark=False):
    return (f'<span style="display: inline-flex; align-self: flex-start; align-items: center; gap: 6px; font-size: 12px; font-weight: 800; letter-spacing: 1px; padding: 6px 11px; border-radius: 99px; '
            f'background: {"rgba(61,220,151,.16)" if dark else "#E3F6EC"}; color: {MINT if dark else GREEN}">{ic("sparkle", 13, MINT if dark else GREEN, 2.2)}PRIORITY MEMBERS</span>')
def head_txt(p, m=False, dark=False, center=False):
    c, s = ('#FFFFFF', '#CFE9DD') if dark else (INK, '#43504A')
    al = 'align-items: center; text-align: center' if center else ''
    return (f'<div style="display: flex; flex-direction: column; gap: 10px; {al}">{kick(dark)}'
            f'<b style="font-size: {28 if m else 38}px; line-height: 1.1; letter-spacing: {-.6 if m else -1.2}px; color: {c}">{p["title"]}</b>'
            f'<span style="font-size: {15 if m else 17}px; font-weight: 600; line-height: 1.5; color: {s}; {"max-width: 620px" if center else ""}">{p["sub"]}</span></div>')
def steps_row(p, m=False, num=False, dark=False):
    cells = ''
    for n, (k, t, d) in enumerate(p['steps']):
        badge = (f'<span style="width: 42px; height: 42px; flex: none; border-radius: 13px; background: {"rgba(61,220,151,.16)" if dark else "#E3F6EC"}; display: flex; align-items: center; justify-content: center">{ic(k, 20, MINT if dark else GREEN, 2.2)}</span>')
        if num: badge = f'<span style="font-size: 13px; font-weight: 800; color: {GREEN}; letter-spacing: 1px">0{n + 1}</span>' + badge
        cells += (f'<div style="flex: 1; min-width: 0; display: flex; {"flex-direction: row; gap: 12px; align-items: flex-start" if m else "flex-direction: column; gap: 12px"}; {"background: #FFFFFF; border-radius: 16px; padding: 16px; box-shadow: inset 0 0 0 1px " + LINE if num else ""}">'
                  f'<div style="display: flex; align-items: center; gap: 10px">{badge}</div><div style="display: flex; flex-direction: column; gap: 3px">'
                  f'<b style="font-size: 15.5px; color: {"#FFFFFF" if dark else INK}">{t}</b><span style="font-size: 13.5px; font-weight: 600; line-height: 1.45; color: {"#B9D3C7" if dark else MUTE}">{d}</span></div></div>')
    return f'<div style="display: flex; {"flex-direction: column; gap: 12px" if m else "gap: 18px"}">{cells}</div>'

# ---------- A · peek: the feature itself on a soft mint stage, then 3 steps ----------
def stage(p, m=False):
    blob = 'background: radial-gradient(90% 90% at 85% 10%, #BFF0D8 0%, rgba(191,240,216,0) 60%), radial-gradient(80% 80% at 0% 100%, #D7F5E6 0%, rgba(215,245,230,0) 60%), #EEF8F2'
    if m:
        return (f'<div style="border-radius: 22px; {blob}; padding: 18px 14px 14px; display: flex; flex-direction: column; gap: 10px">{feature(p, True, cap=4)}'
                f'<div style="margin: -4px 6px 0; position: relative">{win(p, True)}</div></div>')
    return (f'<div style="border-radius: 26px; {blob}; padding: 30px 40px; display: flex; gap: 26px; align-items: center">'
            f'<div style="flex: 1; min-width: 0">{feature(p)}</div><div style="width: 270px; flex: none; display: flex; flex-direction: column; gap: 14px">{win(p)}'
            f'<span style="font-size: 13px; font-weight: 700; color: #43504A; line-height: 1.5; padding: 0 4px">This is what your {"charges" if p is PAGES["ref"] else "subscriptions"} page looks like once you upgrade.</span></div></div>')
def dA(p):
    return head_txt(p) + stage(p) + steps_row(p) + f'<div style="display: flex; align-items: center; gap: 22px"><div style="width: 380px">{cta()}</div><div style="display: flex; flex-direction: column; gap: 6px">{trust()}{fine()}</div></div>'
def mA(p):
    return head_txt(p, True) + stage(p, True) + steps_row(p, True) + cta(True) + trust() + fine()

# ---------- B · brand hero: dark green band like the homepage hero, cards pop out ----------
def bandB(p, m=False):
    if m:
        return (f'<div class="meshDark" style="padding: 18px 16px 22px; display: flex; flex-direction: column; gap: 18px">{head_txt(p, True, True)}'
                f'<div style="position: relative">{feature(p, True, cap=3)}<div style="margin: -6px 10px 0; position: relative">{win(p, True, True)}</div></div></div>')
    return (f'<div class="meshDark" style="padding: 44px 110px 46px; display: flex; gap: 46px; align-items: center">'
            f'<div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 22px">{head_txt(p, False, True)}<div style="width: 360px">{cta()}</div>{trust(True)}</div>'
            f'<div style="width: 420px; flex: none; display: flex; flex-direction: column">{feature(p, cap=4)}'
            f'<div style="margin: -10px 40px 0 -40px; position: relative">{win(p, False, True)}</div></div></div>')
def dB(p):
    return (bandB(p) + f'<div style="width: 900px; margin: 0 auto; padding: 30px 0; display: flex; flex-direction: column; gap: 18px">'
            f'<b style="font-size: 15px; letter-spacing: 1px; color: {GREEN}">HOW IT WORKS</b>{steps_row(p, num=True)}{fine()}</div>')
def mB(p):
    return (bandB(p, True) + f'<div style="padding: 18px 16px; display: flex; flex-direction: column; gap: 14px">'
            f'<b style="font-size: 13px; letter-spacing: 1px; color: {GREEN}">HOW IT WORKS</b>{steps_row(p, True, True)}{cta(True)}{trust()}{fine()}</div>')

# ---------- C · before and after: your statement today vs what Priority shows you ----------
def side(p, after, m=False):
    lab = p['found'] if after else p['plain']
    top = (f'<div style="display: flex; align-items: center; gap: 8px; padding: 0 2px">'
           f'<span style="width: 24px; height: 24px; border-radius: 99px; background: {MINT if after else "#DDE5E0"}; display: flex; align-items: center; justify-content: center">{ic("ok" if after else "card", 13, DARK if after else "#5B6862", 2.6)}</span>'
           f'<b style="font-size: {13.5 if m else 14.5}px; color: {INK if after else MUTE}">{lab}</b></div>')
    box = (f'<div style="background: #FFFFFF; border-radius: 18px; overflow: hidden; {"box-shadow: 0 16px 36px rgba(10,15,13,.12), inset 0 0 0 2px " + MINT if after else "box-shadow: inset 0 0 0 1px " + LINE}">'
           f'{rows_ui(p, m, flags=after, dim=not after, cap=(4 if after else 3) if m else 5)}</div>')
    w = win(p, m) if after else ''
    return f'<div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 10px">{top}{box}{w}</div>'
def incl(m=False):
    items = [('zap', 'Claims filed within 24 hours'), ('globe2', 'Every claim, including local ones'), ('undo', 'Claim refunds'), ('repeat', 'Subscription Manager')]
    LU['globe2'] = 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20z M2 12h20 M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z'
    return (f'<div style="display: grid; grid-template-columns: repeat({2 if m else 4}, minmax(0, 1fr)); gap: 8px">' + ''.join(
        f'<span style="display: flex; align-items: center; gap: 8px; padding: 10px 12px; border-radius: 12px; background: #FFFFFF; box-shadow: inset 0 0 0 1px {LINE}; font-size: 12.5px; font-weight: 800; color: #26332C; line-height: 1.3">{ic(k, 16, GREEN, 2.2)}{t}</span>' for k, t in items) + '</div>')
def dC(p):
    arrow = f'<span style="align-self: center; width: 40px; height: 40px; flex: none; border-radius: 99px; background: {DARK}; display: flex; align-items: center; justify-content: center">{ic("right", 20, MINT, 2.6)}</span>'
    return (head_txt(p) + f'<div style="display: flex; gap: 16px; align-items: flex-start">{side(p, False)}<div style="padding-top: 120px">{arrow}</div>{side(p, True)}</div>'
            + f'<div style="display: flex; flex-direction: column; gap: 8px"><b style="font-size: 13px; letter-spacing: 1px; color: {GREEN}">EVERYTHING IN PRIORITY</b>{incl()}</div>'
            + f'<div style="display: flex; align-items: center; gap: 22px"><div style="width: 380px">{cta(kind="dark")}</div>{trust()}</div>')
def mC(p):
    down = f'<span style="align-self: center; width: 34px; height: 34px; border-radius: 99px; background: {DARK}; display: flex; align-items: center; justify-content: center; transform: rotate(90deg)">{ic("right", 18, MINT, 2.6)}</span>'
    return (head_txt(p, True) + side(p, False, True) + down + side(p, True, True)
            + f'<b style="font-size: 12px; letter-spacing: 1px; color: {GREEN}">EVERYTHING IN PRIORITY</b>{incl(True)}' + cta(True, 'dark') + trust())

# ---------- boards ----------
def board(name, label, note, fd, fm, pad=True, h=1080, ph=1240):
    rows = ''
    for key in ('ref', 'sub'):
        p = PAGES[key]
        rows += (f'<div style="display: flex; flex-direction: column; gap: 12px"><b style="font-size: 13px; letter-spacing: 1px; color: #43504A">{p["tab"].upper()}</b>'
                 f'<div style="display: flex; gap: 60px; align-items: flex-start">{desk(fd(p), p["tab"], h, pad)}{phone(fm(p), p["ptab"], ph, pad)}</div></div>')
    H = 2 * (max(h, ph) + 40) + 180
    page = (f'<div data-board style="width: 1720px; height: {H}px; box-sizing: border-box; padding: 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: {INK}; display: flex; flex-direction: column; gap: 26px">'
            f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: {GREEN}">{label}</span>'
            f'<span style="font-size: 16px; color: #43504A; font-weight: 600; max-width: 1200px; line-height: 1.45">{note}</span></div>{rows}</div>\n</x-dc>\n')
    open(os.path.join(OUT, f'{name}.dc.html'), 'w').write(HEAD % label.title() + page + JS.replace('"width":1926,"height":980', f'"width":1720,"height":{H}'))
    return H

if __name__ == '__main__':
    hs = [board('UpgA', 'UPGRADE PAGES · A · PEEK AT THE FEATURE', 'The page shows the feature itself (example charges or subscriptions) on a soft mint stage, with the win card beside it. Then 3 steps, one upgrade button, the Plaid trust line.', dA, mA),
          board('UpgB', 'UPGRADE PAGES · B · BRAND HERO', 'Dark green band like the homepage hero: headline, button and trust line on the left, the example feature with a win card popping out on the right. How it works sits under the band as 3 numbered cards.', dB, mB, pad=False),
          board('UpgC', 'UPGRADE PAGES · C · BEFORE AND AFTER', 'Your statement as it looks today (faded, nothing flagged) next to what Priority shows you (flags and a win card). Then everything Priority includes, one dark upgrade button.', dC, mC)]
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    if not any(pg['id'] == 'upg' for pg in c['pages']): c['pages'].append({'id': 'upg', 'name': 'Upgrade pages'})
    y = 0
    for n, (nm, t), H in zip(range(3), [('UpgA', 'Upgrade pages · A · peek at the feature'), ('UpgB', 'Upgrade pages · B · brand hero'), ('UpgC', 'Upgrade pages · C · before and after')], hs):
        c['boards'][nm + '.dc.html'] = {'x': n * 1800, 'y': 0, 'w': 1720, 'h': H, 'title': t, 'page': 'upg', 'is_interactive': False}
        if nm + '.dc.html' not in c['order']: c['order'].append(nm + '.dc.html')
    c['notes']['tUpg'] = {'x': 0, 'y': -300, 'page': 'upg', 'text': 'Upgrade pages for Claim refunds and Manage subscriptions · 3 drafts', 'kind': 'title1', 'maxW': 5320, 'w': 240}
    if 'tUpg' not in c['noteOrder']: c['noteOrder'].append('tUpg')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w'))
    print('ok', hs)
