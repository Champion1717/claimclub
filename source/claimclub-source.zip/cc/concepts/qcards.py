# Four designs for the per-company question in the claim flow: QCard1..QCard4.dc.html (desktop 1280x800 + mobile 390x844 per board).
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from how4 import ic, LOGO, HEAD, OUT

B = {'apple': '/_blob/7fd6ec4499df609a19ab46e16342f49d', 'googleplay': '/_blob/7f4390cee228878d694a9ab5d8bd863a', 'visa': '/_blob/17d130cb2fd653ada0d1561043e8aa56',
     'amazon': '/_blob/9e823dce7e60dc8d8b58da2243d7151d', 'cvs': '/_blob/1ceb7905467ce333f9268b10d05d201d', 'tyson': '/_blob/c655327b9222899295d427826bd844fe',
     'netflix': '/_blob/6450426b362962920828f44df101d658', 'goodrx': '/_blob/20058f58cf0cc867f90794121d8fa7cd', 'realpage': None}
logo = lambda k, s=56, r=16: f'<img src="{B[k]}" alt="" style="width: {s}px; height: {s}px; flex: none; border-radius: {r}px; object-fit: contain; background: #FFFFFF; box-shadow: 0 6px 18px rgba(10,15,13,.08), inset 0 0 0 1px #E3EAE6; padding: {round(s*.17)}px; box-sizing: border-box">'
QS = [
    dict(k='apple', brand='Apple', q='Did you buy an iPhone 15 Pro, 15 Pro Max or any iPhone 16?', sub='Bought in the U.S. in 2024 or 2025.', amt='Up to $95', v=95, proof='No proof needed', dl='38 days left', short='Bought an iPhone 15 Pro or 16'),
    dict(k='googleplay', brand='Google Play', q='Have you bought apps or in-app items on Google Play?', sub='On any Android phone or tablet.', amt='Up to $100', v=100, proof='No proof needed', dl='28 days left', short='Bought apps on Google Play'),
    dict(k='visa', brand='Visa & Mastercard', q="Have you paid a fee to use another bank's ATM?", sub='Any out-of-network ATM fee in the U.S.', amt='Up to $1,000', v=1000, proof='No proof needed', dl='88 days left', short='Paid an out-of-network ATM fee'),
    dict(k='amazon', brand='Amazon', q='Have you ever returned something to Amazon?', sub='Any return since 2017. Some refunds came late, short or never.', amt='Refund owed', v=0, proof='Often automatic', dl='17 days left', short='Returned something to Amazon'),
    dict(k='cvs', brand='CVS', q='Have you used the CVS website or app?', sub='To shop, fill prescriptions or book a visit.', amt='Up to $10', v=10, proof='No proof needed', dl='3 days left', short='Used the CVS website or app'),
    dict(k='tyson', brand='Tyson & beef packers', q='Have you bought beef at a grocery store?', sub='Ground beef, steaks or roasts from a store.', amt='Up to $100', v=100, proof='No proof needed', dl='17 days left', short='Bought beef at a grocery store'),
    dict(k='goodrx', brand='GoodRx', q='Have you used GoodRx?', sub='The app or a GoodRx discount card for a prescription.', amt='Cash share', v=0, proof='No proof needed', dl='45 days left', short='Used GoodRx'),
    dict(k='netflix', brand='Netflix', q='Do you have a Netflix account?', sub='A privacy claim filed through a partner law firm.', amt='Up to $2,500', v=2500, proof='Not guaranteed', dl='60 days left', short='Have a Netflix account'),
]
Q = QS[0]
PROG = (1, len(QS))
GREEN, DARK, MINT = '#12805C', '#0F3B2E', '#3DDC97'

def progress(m=False):
    a, n = PROG
    bars = ''.join(f'<span class="pb" style="flex: 1; height: 5px; border-radius: 99px; background: {GREEN if i < a else "#E3EAE6"}"></span>' for i in range(n))
    return f'<div style="display: flex; align-items: center; gap: 12px"><div style="flex: 1; display: flex; gap: 4px">{bars}</div><span class="pbN" style="font-size: 12.5px; font-weight: 800; color: #5B6862; white-space: nowrap">{a} of {n}</span></div>'

def topbar(m):
    return (f'<div style="display: flex; align-items: center; gap: 12px; padding: {"14px 16px" if m else "18px 32px"}; background: #FFFFFF; border-bottom: 1px solid #E3EAE6">'
            f'<span style="width: 36px; height: 36px; border-radius: 11px; background: #EEF2F0; display: flex; align-items: center; justify-content: center; color: #0A0F0D">{ic("arrow", 18, 2.4).replace("<path d=\"M5 12h14\"></path><path d=\"m12 5 7 7-7 7\"></path>", "<path d=\"m15 18-6-6 6-6\"></path>")}</span>'
            f'<span style="display: flex; align-items: center; gap: 7px">{LOGO.format(s=24, c="#0A0F0D")}<b style="font-size: 17px; letter-spacing: -.4px">claim<span style="font-weight: 500">club</span><span style="font-size: .72em; color: {GREEN}">.io</span></b></span>'
            f'<div style="flex: 1; max-width: {"none" if m else "420px"}; margin-left: auto">{progress(m)}</div></div>')

def aside():
    rows = ''.join(f'<div style="display: flex; align-items: center; gap: 10px; padding: 10px; border-radius: 14px; background: rgba(255,255,255,.08)">{logo(k, 36, 10)}<b style="flex: 1; font-size: 14px">{n}</b><span style="font-size: 13px; font-weight: 800; color: {MINT}">{a}</span></div>' for k, n, a in [('googleplay', 'Google Play', 'Up to $100'), ('visa', 'Visa & Mastercard', 'Up to $1,000')])
    return (f'<aside class="meshDark" style="width: 360px; flex: none; color: #FFFFFF; padding: 36px 32px; box-sizing: border-box; display: flex; flex-direction: column; gap: 14px">'
            f'<span style="font-size: 12px; font-weight: 800; letter-spacing: 1.4px; color: #C9D6CF">YOUR ESTIMATE SO FAR</span><span class="estAmt" style="font-size: 46px; font-weight: 800; letter-spacing: -1.8px; line-height: 1">$0</span><span class="estN" style="font-size: 14px; font-weight: 700">0 settlements matched</span><div class="estList" style="display: flex; flex-direction: column; gap: 8px"></div></aside>')

yesno = lambda h=56, r=16, fs=17: (f'<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px"><button data-a="yes" style="height: {h}px; border-radius: {r}px; background: {MINT}; color: {DARK}; font-size: {fs}px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 10px 24px rgba(10,15,13,.12)">{ic("check", 18, 3)}Yes</button>'
                                    f'<button data-a="no" style="height: {h}px; border-radius: {r}px; background: #FFFFFF; box-shadow: 0 10px 24px rgba(10,15,13,.10), inset 0 0 0 1.5px #E3EAE6; color: #0A0F0D; font-size: {fs}px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px"><span style="color: #B8333A; display: flex">{ic("x", 18, 3)}</span>No</button></div>')
chip = lambda t, bg='#E9F6EF', c='#17603F': f'<span style="font-size: 12px; font-weight: 800; padding: 5px 10px; border-radius: 99px; background: {bg}; color: {c}; white-space: nowrap">{t}</span>'

# ---------- 1. Big Yes / No buttons ----------
def d1(m, Q=Q):
    return (f'<div style="width: 100%; max-width: 560px; display: flex; flex-direction: column; gap: {18 if m else 22}px">'
            f'<div style="display: flex; align-items: center; gap: 14px">{logo(Q["k"], 64, 18)}<div style="display: flex; flex-direction: column; gap: 6px"><b style="font-size: 15px; color: #43504A">{Q["brand"]}</b><div style="display: flex; gap: 6px; flex-wrap: wrap">{chip(Q["amt"])}{chip(Q["proof"], "#EEF2F0", "#43504A")}</div></div></div>'
            f'<h2 style="margin: 0; font-size: {26 if m else 34}px; line-height: 1.15; letter-spacing: -.8px">{Q["q"]}</h2><p style="margin: 0; font-size: 15px; color: #5B6862">{Q["sub"]}</p>'
            f'<div style="margin-top: 6px">{yesno(64 if m else 68, 18, 19)}</div><button data-a="no" style="align-self: center; font-size: 13.5px; font-weight: 700; color: #8A968F">Not sure? Skip</button></div>')

# ---------- 2. Swipe card stack ----------
def d2(m, Q=Q):
    w = 330 if m else 420
    card = (f'<div style="position: relative; width: {w}px; border-radius: 28px; background: #FFFFFF; box-shadow: 0 24px 60px rgba(10,15,13,.14); padding: 26px; box-sizing: border-box; display: flex; flex-direction: column; align-items: center; gap: 14px; text-align: center; transform: rotate(-1.5deg); z-index: 3; touch-action: pan-y; cursor: grab; user-select: none; -webkit-user-select: none" class="swipe">'
            f'{logo(Q["k"], 84, 22)}<b style="font-size: 14px; color: #43504A">{Q["brand"]} · {Q["amt"]}</b><h2 style="margin: 0; font-size: {22 if m else 26}px; line-height: 1.2; letter-spacing: -.6px">{Q["q"]}</h2><p style="margin: 0; font-size: 14px; color: #5B6862">{Q["sub"]}</p>{chip(Q["proof"])}</div>')
    behind = lambda r, y, s, z: f'<div style="position: absolute; left: 50%; top: 0; width: {w}px; height: 100%; margin-left: -{w//2}px; border-radius: 28px; background: #FFFFFF; box-shadow: 0 10px 30px rgba(10,15,13,.08); transform: translateY({y}px) rotate({r}deg) scale({s}); z-index: {z}"></div>'
    circ = lambda icon, bg, c, sz, a: f'<button data-a="{a}" style="width: {sz}px; height: {sz}px; border-radius: 50%; background: {bg}; color: {c}; display: flex; align-items: center; justify-content: center; box-shadow: 0 10px 24px rgba(10,15,13,.14)">{ic(icon, sz*.42, 3)}</button>'
    return (f'<div style="display: flex; flex-direction: column; align-items: center; gap: 26px">'
            f'<div style="position: relative; display: flex; justify-content: center">{behind(4, 18, .94, 1)}{behind(-5, 10, .97, 2)}{card}</div>'
            f'<div style="display: flex; align-items: center; gap: 28px">{circ("x", "#FFFFFF", "#B8333A", 68, "no")}<span style="font-size: 13px; font-weight: 700; color: #8A968F; text-align: center">Drag the card<br>or tap</span>{circ("check", MINT, DARK, 68, "yes")}</div></div>')

# ---------- 3. Brand card with color band ----------
def d3(m, Q=Q):
    return (f'<div style="width: 100%; max-width: 520px; border-radius: 28px; overflow: hidden; background: #FFFFFF; box-shadow: 0 20px 50px rgba(10,15,13,.10), 0 0 0 1px #E3EAE6">'
            f'<div style="height: {120 if m else 150}px; background: linear-gradient(135deg, #F3F6F4, #E3EAE6); display: flex; align-items: center; justify-content: center; position: relative">{logo(Q["k"], 84 if m else 96, 24)}'
            f'<span style="position: absolute; top: 14px; right: 14px">{chip(Q["dl"], "#FFFFFF", "#43504A")}</span></div>'
            f'<div style="padding: {20 if m else 28}px; display: flex; flex-direction: column; gap: 12px"><div style="display: flex; justify-content: space-between; align-items: center"><b style="font-size: 15px; color: #43504A">{Q["brand"]}</b><b style="font-size: 18px; color: {GREEN}">{Q["amt"]}</b></div>'
            f'<h2 style="margin: 0; font-size: {23 if m else 28}px; line-height: 1.18; letter-spacing: -.7px">{Q["q"]}</h2><p style="margin: 0 0 6px; font-size: 14.5px; color: #5B6862">{Q["sub"]} {Q["proof"]}.</p>{yesno(56, 999, 17)}</div></div>')

# ---------- 4. Several companies at once (fastest) ----------
def d4(m, page=0):
    items = QS[:6] if page == 0 else QS[6:]
    tile = lambda q: (f'<button data-t="{q["k"]}" class="tile" style="position: relative; text-align: left; display: flex; {"flex-direction: row; align-items: center" if m else "flex-direction: column; align-items: flex-start"}; gap: 10px; padding: {12 if m else 16}px; border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6">'
                      f'{logo(q["k"], 40 if m else 46, 12)}<div style="display: flex; flex-direction: column; gap: 3px; flex: 1"><b style="font-size: 14px; line-height: 1.3">{q["short"]}</b><span style="font-size: 12.5px; font-weight: 800; color: {GREEN}">{q["amt"]}</span></div>'
                      f'<span class="tick" style="{"position: static" if m else "position: absolute; top: 12px; right: 12px"}; width: 24px; height: 24px; flex: none; border-radius: 50%; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px #C3CEC8; color: #FFFFFF; display: flex; align-items: center; justify-content: center">{ic("check", 14, 3)}</span></button>')
    return (f'<div style="width: 100%; max-width: 760px; display: flex; flex-direction: column; gap: 16px">'
            f'<h2 style="margin: 0; font-size: {26 if m else 32}px; letter-spacing: -.8px; line-height: 1.15">Tap everything that applies to you</h2><p style="margin: 0; font-size: 15px; color: #5B6862">Page {page + 1} of 2. We match each one to an open settlement.</p>'
            f'<div style="display: grid; grid-template-columns: {"1fr" if m else "repeat(3, 1fr)"}; gap: 10px">' + ''.join(tile(q) for q in items) + '</div>'
            f'<button data-a="cont" style="height: 56px; border-radius: 999px; background: {MINT}; color: {DARK}; font-size: 17px; font-weight: 800; display: flex; align-items: center; justify-content: center; margin-top: 4px"><span class="contLbl">Continue</span></button></div>')

def done(m):
    return (f'<div style="display: flex; flex-direction: column; align-items: center; gap: 12px; text-align: center">'
            f'<span style="font-size: 13px; font-weight: 800; letter-spacing: 1.2px; color: #5B6862">BASED ON YOUR ANSWERS, YOU COULD BE OWED</span><span class="estBig" style="font-size: {48 if m else 64}px; font-weight: 800; letter-spacing: -2px; color: {GREEN}">$0</span>'
            f'<span class="estN2" style="font-size: 15px; font-weight: 700; color: #43504A">0 settlements matched</span><p style="margin: 6px 0 10px; font-size: 13px; color: #8A968F; max-width: 320px">In the live flow this is the estimate check.</p>'
            f'<button data-a="restart" style="height: 50px; padding: 0 26px; border-radius: 999px; background: {MINT}; color: {DARK}; font-size: 16px; font-weight: 800">Try again</button></div>')

VARIANTS = [('QCard1', 'Question design 1 · Big Yes / No buttons', d1), ('QCard2', 'Question design 2 · Swipe card stack (drag or tap)', d2),
            ('QCard3', 'Question design 3 · Brand card with logo band', d3), ('QCard4', 'Question design 4 · Tap all that apply (6 per page)', d4)]

def views(fn, m):
    pre = '<style>.swipe img{pointer-events:none;-webkit-user-drag:none}.qf button{border:0;font-family:inherit;cursor:pointer}.qf button.tile{background:#FFFFFF}</style>' if not m else ''
    if fn is d4:
        vs = [f'<div class="qv" data-i="{p}" data-page="1" style="display: {"flex" if p == 0 else "none"}; width: 100%; justify-content: center">{d4(m, p)}</div>' for p in (0, 1)]
    else:
        vs = [f'<div class="qv" data-i="{i}" data-k="{q["k"]}" data-name="{q["brand"]}" data-amt="{q["amt"]}" data-v="{q["v"]}" style="display: {"flex" if i == 0 else "none"}; width: 100%; justify-content: center">{fn(m, q)}</div>' for i, q in enumerate(QS)]
    meta = ''.join(f'<span class="qmeta" data-k="{q["k"]}" data-name="{q["brand"]}" data-amt="{q["amt"]}" data-v="{q["v"]}" style="display: none">{logo(q["k"], 36, 10)}</span>' for q in QS)
    return pre + ''.join(vs) + f'<div class="qv qdone" style="display: none; width: 100%; justify-content: center">{done(m)}</div>' + meta

def frame(fn, m):
    kind = 'tiles' if fn is d4 else 'yn'
    if m:
        return (f'<div class="qf" data-kind="{kind}" style="width: 390px; height: 844px; background: #F3F6F4; display: flex; flex-direction: column; overflow: hidden; border-radius: 28px; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{topbar(True)}'
                f'<div style="flex: 1; padding: 22px 16px; display: flex; flex-direction: column; align-items: center; justify-content: {"flex-start" if fn is d4 else "center"}; overflow: auto">{views(fn, True)}</div></div>')
    return (f'<div class="qf" data-kind="{kind}" style="width: 1280px; height: 800px; background: #F3F6F4; display: flex; flex-direction: column; overflow: hidden; border-radius: 18px; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{topbar(False)}'
            f'<div style="flex: 1; display: flex; min-height: 0">{aside()}<div style="flex: 1; padding: 40px; display: flex; align-items: center; justify-content: center; overflow: auto">{views(fn, False)}</div></div></div>')

PLAY = r"""
  componentDidMount() {
    const roots = [document]; document.querySelectorAll('*').forEach((el) => { if (el.shadowRoot) roots.push(el.shadowRoot); });
    roots.forEach((root) => root.querySelectorAll('.qf').forEach((f) => { if (!f._p) { f._p = 1; this.wire(f); } }));
  }
  wire(f) {
    const views = [...f.querySelectorAll('.qv')], metas = [...f.querySelectorAll('.qmeta')], N = metas.length, tiles = f.dataset.kind === 'tiles';
    let i = 0, yes = {}, sel = {};
    const money = (n) => '$' + n.toLocaleString('en-US');
    const show = (k) => views.forEach((v) => { v.style.display = v === k ? 'flex' : 'none'; });
    const paint = () => {
      const ks = metas.filter((m) => yes[m.dataset.k]); const tot = ks.reduce((t, m) => t + Number(m.dataset.v), 0);
      f.querySelectorAll('.estAmt,.estBig').forEach((e) => { e.textContent = money(tot); });
      f.querySelectorAll('.estN,.estN2').forEach((e) => { e.textContent = ks.length + (ks.length === 1 ? ' settlement' : ' settlements') + ' matched'; });
      const list = f.querySelector('.estList');
      if (list) { list.innerHTML = ''; ks.forEach((m) => { const r = document.createElement('div'); r.style.cssText = 'display:flex;align-items:center;gap:10px;padding:10px;border-radius:14px;background:rgba(255,255,255,.08)'; r.appendChild(m.firstElementChild.cloneNode(true)); const b = document.createElement('b'); b.style.cssText = 'flex:1;font-size:14px'; b.textContent = m.dataset.name; const a = document.createElement('span'); a.style.cssText = 'font-size:13px;font-weight:800;color:#3DDC97'; a.textContent = m.dataset.amt; r.append(b, a); list.appendChild(r); }); }
      const done = tiles ? (i >= 2 ? N : (i === 0 ? 0 : 6)) : Math.min(i, N);
      f.querySelectorAll('.pb').forEach((p, k) => { p.style.background = k < done + (i < (tiles ? 2 : N) ? 1 : 0) ? '#12805C' : '#E3EAE6'; });
      f.querySelectorAll('.pbN').forEach((e) => { e.textContent = Math.min(done + 1, N) + ' of ' + N; });
      f.querySelectorAll('.tile').forEach((t) => { const on = !!sel[t.dataset.t]; t.style.background = on ? '#E9F6EF' : '#FFFFFF'; t.style.boxShadow = 'inset 0 0 0 ' + (on ? 2 : 1) + 'px ' + (on ? '#12805C' : '#E3EAE6'); const tk = t.querySelector('.tick'); tk.style.background = on ? '#12805C' : '#FFFFFF'; tk.style.boxShadow = 'inset 0 0 0 1.5px ' + (on ? '#12805C' : '#C3CEC8'); });
      const cur = views.find((v) => v.style.display !== 'none'); const n = cur ? cur.querySelectorAll('.tile').length && [...cur.querySelectorAll('.tile')].filter((t) => sel[t.dataset.t]).length : 0;
      f.querySelectorAll('.contLbl').forEach((e) => { e.textContent = n ? 'Continue with ' + n + ' selected' : 'None of these, continue'; });
    };
    const next = () => { i += 1; const last = tiles ? 2 : N; show(i >= last ? f.querySelector('.qdone') : views[i]); paint(); };
    const reset = (card) => { if (card) { card.style.transition = 'transform .25s ease'; card.style.transform = 'rotate(-1.5deg)'; } };
    f.addEventListener('click', (e) => {
      const t = e.target.closest('[data-t]'); if (t) { sel[t.dataset.t] = !sel[t.dataset.t]; paint(); return; }
      const b = e.target.closest('[data-a]'); if (!b) return; const a = b.dataset.a, cur = views[i];
      if (a === 'restart') { i = 0; yes = {}; sel = {}; show(views[0]); views.forEach((v) => { const c = v.querySelector('.swipe'); reset(c); }); paint(); return; }
      if (a === 'cont') { const vk = [...cur.querySelectorAll('.tile')]; vk.forEach((t) => { if (sel[t.dataset.t]) yes[t.dataset.t] = true; }); next(); return; }
      if (a === 'yes' && cur && cur.dataset.k) yes[cur.dataset.k] = true;
      if (a === 'yes' || a === 'no') { const c = cur && cur.querySelector('.swipe'); if (c && !b.closest('.swipe')) { c.style.transition = 'transform .25s ease, opacity .25s'; c.style.transform = 'translateX(' + (a === 'yes' ? 420 : -420) + 'px) rotate(' + (a === 'yes' ? 18 : -18) + 'deg)'; setTimeout(next, 180); } else next(); }
    });
    f.querySelectorAll('.swipe').forEach((c) => {
      let x0 = null, dx = 0;
      c.addEventListener('pointerdown', (e) => { x0 = e.clientX; dx = 0; c.style.transition = 'none'; c.setPointerCapture(e.pointerId); c.style.cursor = 'grabbing'; });
      c.addEventListener('pointermove', (e) => { if (x0 === null) return; dx = e.clientX - x0; c.style.transform = 'translateX(' + dx + 'px) rotate(' + (-1.5 + dx / 18) + 'deg)'; });
      const up = () => { if (x0 === null) return; x0 = null; c.style.cursor = 'grab'; if (Math.abs(dx) > 90) { const v = c.closest('.qv'); if (dx > 0 && v.dataset.k) yes[v.dataset.k] = true; c.style.transition = 'transform .25s ease'; c.style.transform = 'translateX(' + (dx > 0 ? 420 : -420) + 'px) rotate(' + (dx > 0 ? 18 : -18) + 'deg)'; setTimeout(next, 180); } else reset(c); };
      c.addEventListener('pointerup', up); c.addEventListener('pointercancel', up);
    });
    paint();
  }
"""

def build():
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    y0 = max(b['y'] + b['h'] for k, b in c['boards'].items() if not k.startswith('QCard')) + 260
    c['notes']['tQ'] = {'x': 0, 'y': y0, 'text': 'Claim flow · 4 designs for the company questions (desktop and mobile)', 'kind': 'title1', 'maxW': 3600, 'w': 240}
    if 'tQ' not in c['noteOrder']: c['noteOrder'].append('tQ')
    for k, (name, title, fn) in enumerate(VARIANTS):
        page = (f'<div style="width: 1766px; height: 940px; box-sizing: border-box; padding: 24px; background: #E7ECE9; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 14px">'
                f'<div style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #43504A">{title.upper()}</div><div style="display: flex; gap: 48px; align-items: flex-start">{frame(fn, False)}{frame(fn, True)}</div></div>\n</x-dc>\n')
        js = '''<script type="text/x-dc" data-dc-script data-props='{"$preview":{"width":1766,"height":940}}'>
class Component extends DCLogic { renderVals() { return {}; }'''+PLAY+'''}
</script>
</body>
</html>
'''
        open(os.path.join(OUT, name + '.dc.html'), 'w').write(HEAD % title + page + js)
        c['boards'][name + '.dc.html'] = {'x': (k % 2) * 1846, 'y': y0 + 220 + (k // 2) * 1020, 'w': 1766, 'h': 940, 'is_interactive': True, 'title': title}
        if name + '.dc.html' not in c['order']: c['order'].append(name + '.dc.html')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w'))
    print('built', [v[0] for v in VARIANTS], 'y0', y0)

if __name__ == '__main__':
    build()
