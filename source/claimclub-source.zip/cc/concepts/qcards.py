# Four designs for the per-company question in the claim flow: QCard1..QCard4.dc.html (desktop 1280x800 + mobile 390x844 per board).
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from how4 import ic, LOGO, HEAD, OUT

B = {'apple': '/_blob/7fd6ec4499df609a19ab46e16342f49d', 'googleplay': '/_blob/7f4390cee228878d694a9ab5d8bd863a', 'visa': '/_blob/17d130cb2fd653ada0d1561043e8aa56',
     'amazon': '/_blob/9e823dce7e60dc8d8b58da2243d7151d', 'cvs': '/_blob/1ceb7905467ce333f9268b10d05d201d', 'tyson': '/_blob/c655327b9222899295d427826bd844fe',
     'netflix': '/_blob/6450426b362962920828f44df101d658', 'goodrx': '/_blob/20058f58cf0cc867f90794121d8fa7cd', 'realpage': None}
logo = lambda k, s=56, r=16: f'<img src="{B[k]}" alt="" style="width: {s}px; height: {s}px; flex: none; border-radius: {r}px; object-fit: contain; background: #FFFFFF; box-shadow: 0 6px 18px rgba(10,15,13,.08), inset 0 0 0 1px #E3EAE6; padding: {round(s*.17)}px; box-sizing: border-box">'
Q = dict(k='apple', brand='Apple', q='Did you buy an iPhone 15 Pro, 15 Pro Max or any iPhone 16?', sub='Bought in the U.S. in 2024 or 2025.', amt='Up to $95', proof='No proof needed', dl='38 days left')
PROG = (3, 10)
GREEN, DARK, MINT = '#12805C', '#0F3B2E', '#3DDC97'

def progress(m=False):
    a, n = PROG
    bars = ''.join(f'<span style="flex: 1; height: 5px; border-radius: 99px; background: {GREEN if i < a else "#E3EAE6"}"></span>' for i in range(n))
    return f'<div style="display: flex; align-items: center; gap: 12px"><div style="flex: 1; display: flex; gap: 4px">{bars}</div><span style="font-size: 12.5px; font-weight: 800; color: #5B6862; white-space: nowrap">{a} of {n}</span></div>'

def topbar(m):
    return (f'<div style="display: flex; align-items: center; gap: 12px; padding: {"14px 16px" if m else "18px 32px"}; background: #FFFFFF; border-bottom: 1px solid #E3EAE6">'
            f'<span style="width: 36px; height: 36px; border-radius: 11px; background: #EEF2F0; display: flex; align-items: center; justify-content: center; color: #0A0F0D">{ic("arrow", 18, 2.4).replace("<path d=\"M5 12h14\"></path><path d=\"m12 5 7 7-7 7\"></path>", "<path d=\"m15 18-6-6 6-6\"></path>")}</span>'
            f'<span style="display: flex; align-items: center; gap: 7px">{LOGO.format(s=24, c="#0A0F0D")}<b style="font-size: 17px; letter-spacing: -.4px">claim<span style="font-weight: 500">club</span><span style="font-size: .72em; color: {GREEN}">.io</span></b></span>'
            f'<div style="flex: 1; max-width: {"none" if m else "420px"}; margin-left: auto">{progress(m)}</div></div>')

def aside():
    rows = ''.join(f'<div style="display: flex; align-items: center; gap: 10px; padding: 10px; border-radius: 14px; background: rgba(255,255,255,.08)">{logo(k, 36, 10)}<b style="flex: 1; font-size: 14px">{n}</b><span style="font-size: 13px; font-weight: 800; color: {MINT}">{a}</span></div>' for k, n, a in [('googleplay', 'Google Play', 'Up to $100'), ('visa', 'Visa & Mastercard', 'Up to $1,000')])
    return (f'<aside class="meshDark" style="width: 360px; flex: none; color: #FFFFFF; padding: 36px 32px; box-sizing: border-box; display: flex; flex-direction: column; gap: 14px">'
            f'<span style="font-size: 12px; font-weight: 800; letter-spacing: 1.4px; color: #C9D6CF">YOUR ESTIMATE SO FAR</span><span style="font-size: 46px; font-weight: 800; letter-spacing: -1.8px; line-height: 1">$1,100</span><span style="font-size: 14px; font-weight: 700">2 settlements matched</span>{rows}</aside>')

yesno = lambda h=56, r=16, fs=17: (f'<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px"><span style="height: {h}px; border-radius: {r}px; background: {DARK}; color: #FFFFFF; font-size: {fs}px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px">{ic("check", 18, 3)}Yes</span>'
                                    f'<span style="height: {h}px; border-radius: {r}px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px #DDE5E0; color: #0A0F0D; font-size: {fs}px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px">{ic("x", 18, 3)}No</span></div>')
chip = lambda t, bg='#E9F6EF', c='#17603F': f'<span style="font-size: 12px; font-weight: 800; padding: 5px 10px; border-radius: 99px; background: {bg}; color: {c}; white-space: nowrap">{t}</span>'

# ---------- 1. Big Yes / No buttons ----------
def d1(m):
    return (f'<div style="width: 100%; max-width: 560px; display: flex; flex-direction: column; gap: {18 if m else 22}px">'
            f'<div style="display: flex; align-items: center; gap: 14px">{logo(Q["k"], 64, 18)}<div style="display: flex; flex-direction: column; gap: 6px"><b style="font-size: 15px; color: #43504A">{Q["brand"]}</b><div style="display: flex; gap: 6px; flex-wrap: wrap">{chip(Q["amt"])}{chip(Q["proof"], "#EEF2F0", "#43504A")}</div></div></div>'
            f'<h2 style="margin: 0; font-size: {26 if m else 34}px; line-height: 1.15; letter-spacing: -.8px">{Q["q"]}</h2><p style="margin: 0; font-size: 15px; color: #5B6862">{Q["sub"]}</p>'
            f'<div style="margin-top: 6px">{yesno(64 if m else 68, 18, 19)}</div><span style="align-self: center; font-size: 13.5px; font-weight: 700; color: #8A968F">Not sure? Skip</span></div>')

# ---------- 2. Swipe card stack ----------
def d2(m):
    w = 330 if m else 420
    card = (f'<div style="position: relative; width: {w}px; border-radius: 28px; background: #FFFFFF; box-shadow: 0 24px 60px rgba(10,15,13,.14); padding: 26px; box-sizing: border-box; display: flex; flex-direction: column; align-items: center; gap: 14px; text-align: center; transform: rotate(-1.5deg); z-index: 3">'
            f'{logo(Q["k"], 84, 22)}<b style="font-size: 14px; color: #43504A">{Q["brand"]} · {Q["amt"]}</b><h2 style="margin: 0; font-size: {22 if m else 26}px; line-height: 1.2; letter-spacing: -.6px">{Q["q"]}</h2><p style="margin: 0; font-size: 14px; color: #5B6862">{Q["sub"]}</p>{chip(Q["proof"])}</div>')
    behind = lambda r, y, s, z: f'<div style="position: absolute; left: 50%; top: 0; width: {w}px; height: 100%; margin-left: -{w//2}px; border-radius: 28px; background: #FFFFFF; box-shadow: 0 10px 30px rgba(10,15,13,.08); transform: translateY({y}px) rotate({r}deg) scale({s}); z-index: {z}"></div>'
    circ = lambda icon, bg, c, sz: f'<span style="width: {sz}px; height: {sz}px; border-radius: 50%; background: {bg}; color: {c}; display: flex; align-items: center; justify-content: center; box-shadow: 0 10px 24px rgba(10,15,13,.14)">{ic(icon, sz*.42, 3)}</span>'
    return (f'<div style="display: flex; flex-direction: column; align-items: center; gap: 26px">'
            f'<div style="position: relative; display: flex; justify-content: center">{behind(4, 18, .94, 1)}{behind(-5, 10, .97, 2)}{card}</div>'
            f'<div style="display: flex; align-items: center; gap: 28px">{circ("x", "#FFFFFF", "#B8333A", 68)}<span style="font-size: 13px; font-weight: 700; color: #8A968F; text-align: center">Swipe or tap</span>{circ("check", MINT, DARK, 68)}</div></div>')

# ---------- 3. Brand card with color band ----------
def d3(m):
    return (f'<div style="width: 100%; max-width: 520px; border-radius: 28px; overflow: hidden; background: #FFFFFF; box-shadow: 0 20px 50px rgba(10,15,13,.10), 0 0 0 1px #E3EAE6">'
            f'<div style="height: {120 if m else 150}px; background: linear-gradient(135deg, #F3F6F4, #E3EAE6); display: flex; align-items: center; justify-content: center; position: relative">{logo(Q["k"], 84 if m else 96, 24)}'
            f'<span style="position: absolute; top: 14px; right: 14px">{chip(Q["dl"], "#FFFFFF", "#43504A")}</span></div>'
            f'<div style="padding: {20 if m else 28}px; display: flex; flex-direction: column; gap: 12px"><div style="display: flex; justify-content: space-between; align-items: center"><b style="font-size: 15px; color: #43504A">{Q["brand"]}</b><b style="font-size: 18px; color: {GREEN}">{Q["amt"]}</b></div>'
            f'<h2 style="margin: 0; font-size: {23 if m else 28}px; line-height: 1.18; letter-spacing: -.7px">{Q["q"]}</h2><p style="margin: 0 0 6px; font-size: 14.5px; color: #5B6862">{Q["sub"]} {Q["proof"]}.</p>{yesno(56, 999, 17)}</div></div>')

# ---------- 4. Several companies at once (fastest) ----------
def d4(m):
    items = [('apple', 'Bought an iPhone 15 Pro or 16', 'Up to $95', True), ('googleplay', 'Bought apps on Google Play', 'Up to $100', True), ('visa', 'Paid an out-of-network ATM fee', 'Up to $1,000', False),
             ('amazon', 'Returned something to Amazon', 'Refund owed', False), ('cvs', 'Used the CVS website or app', 'Up to $10', True), ('netflix', 'Have a Netflix account', 'Up to $2,500', False)]
    tile = lambda k, t, a, on: (f'<div style="position: relative; display: flex; {"flex-direction: row; align-items: center" if m else "flex-direction: column; align-items: flex-start"}; gap: 10px; padding: {12 if m else 16}px; border-radius: 18px; background: {"#E9F6EF" if on else "#FFFFFF"}; box-shadow: inset 0 0 0 {2 if on else 1}px {GREEN if on else "#E3EAE6"}">'
                                f'{logo(k, 40 if m else 46, 12)}<div style="display: flex; flex-direction: column; gap: 3px; flex: 1"><b style="font-size: 14px; line-height: 1.3">{t}</b><span style="font-size: 12.5px; font-weight: 800; color: {GREEN}">{a}</span></div>'
                                f'<span style="{"position: static" if m else "position: absolute; top: 12px; right: 12px"}; width: 24px; height: 24px; flex: none; border-radius: 50%; background: {GREEN if on else "#FFFFFF"}; box-shadow: inset 0 0 0 1.5px {GREEN if on else "#C3CEC8"}; color: #FFFFFF; display: flex; align-items: center; justify-content: center">{ic("check", 14, 3) if on else ""}</span></div>')
    return (f'<div style="width: 100%; max-width: 760px; display: flex; flex-direction: column; gap: 16px">'
            f'<h2 style="margin: 0; font-size: {26 if m else 32}px; letter-spacing: -.8px; line-height: 1.15">Tap everything that applies to you</h2><p style="margin: 0; font-size: 15px; color: #5B6862">Page 1 of 2. We match each one to an open settlement.</p>'
            f'<div style="display: grid; grid-template-columns: {"1fr" if m else "repeat(3, 1fr)"}; gap: 10px">' + ''.join(tile(*x) for x in items) + '</div>'
            f'<span style="height: 56px; border-radius: 999px; background: {MINT}; color: {DARK}; font-size: 17px; font-weight: 800; display: flex; align-items: center; justify-content: center; margin-top: 4px">Continue with 3 selected</span></div>')

VARIANTS = [('QCard1', 'Question design 1 · Big Yes / No buttons', d1), ('QCard2', 'Question design 2 · Swipe card stack', d2),
            ('QCard3', 'Question design 3 · Brand card with logo band', d3), ('QCard4', 'Question design 4 · Tap all that apply (6 per page)', d4)]

def frame(fn, m):
    if m:
        return (f'<div style="width: 390px; height: 844px; background: #F3F6F4; display: flex; flex-direction: column; overflow: hidden; border-radius: 28px; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{topbar(True)}'
                f'<div style="flex: 1; padding: 22px 16px; display: flex; flex-direction: column; align-items: center; justify-content: {"flex-start" if fn is d4 else "center"}; overflow: auto">{fn(True)}</div></div>')
    return (f'<div style="width: 1280px; height: 800px; background: #F3F6F4; display: flex; flex-direction: column; overflow: hidden; border-radius: 18px; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{topbar(False)}'
            f'<div style="flex: 1; display: flex; min-height: 0">{aside()}<div style="flex: 1; padding: 40px; display: flex; align-items: center; justify-content: center">{fn(False)}</div></div></div>')

def build():
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    y0 = max(b['y'] + b['h'] for k, b in c['boards'].items() if not k.startswith('QCard')) + 260
    c['notes']['tQ'] = {'x': 0, 'y': y0, 'text': 'Claim flow · 4 designs for the company questions (desktop and mobile)', 'kind': 'title1', 'maxW': 3600, 'w': 240}
    if 'tQ' not in c['noteOrder']: c['noteOrder'].append('tQ')
    for k, (name, title, fn) in enumerate(VARIANTS):
        page = (f'<div style="width: 1766px; height: 940px; box-sizing: border-box; padding: 24px; background: #E7ECE9; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 14px">'
                f'<div style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #43504A">{title.upper()}</div><div style="display: flex; gap: 48px; align-items: flex-start">{frame(fn, False)}{frame(fn, True)}</div></div>\n</x-dc>\n')
        js = '''<script type="text/x-dc" data-dc-script data-props='{"$preview":{"width":1766,"height":940}}'>
class Component extends DCLogic { renderVals() { return {}; } }
</script>
</body>
</html>
'''
        open(os.path.join(OUT, name + '.dc.html'), 'w').write(HEAD % title + page + js)
        c['boards'][name + '.dc.html'] = {'x': (k % 2) * 1846, 'y': y0 + 220 + (k // 2) * 1020, 'w': 1766, 'h': 940, 'is_interactive': True, 'title': title}
        if name + '.dc.html' not in c['order']: c['order'].append(name + '.dc.html')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w'))
    print('built', [v[0] for v in VARIANTS], 'y0', y0)

if __name__ == '__main__':
    build()
