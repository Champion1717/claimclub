import re
s=open('make.py').read()
def rep(o,n):
    global s
    assert o in s,o[:100]; s=s.replace(o,n,1)
rep("Filed with {{ note.co }}","{{ note.head }}")
rep("Claim {{ note.claimId }} · We'll track it until it pays","{{ note.sub }}")
# ---------- sidebar ----------
i=s.index("def sideA():"); j=s.index("SHEET=",i)
s=s[:i]+'''def sideA():
    h=side(0)
    for t,v in [('Dashboard','Dash'),('All settlements','All'),('Your info','Info'),('Settings','Set')]:
        k=h.index(t+'</div>'); a=h.rindex('<div style=',0,k); g=h.index('>',a)+1
        h=h[:a]+'<button onClick="{{ go'+v+' }}" style="{{ nav'+('Settings' if v=='Set' else {'Dash':'Dash','All':'All','Info':'Info'}[v])+' }}">'+h[g:k]+t+'</button>'+h[k+len(t+'</div>'):]
    return h
'''+s[j:]
# ---------- mobile nav ----------
i=s.index("NAVC=NAV.replace("); j=s.index("AM=AM.replace(NAV,NAVC,1)")
s=s[:i]+'''NAVC=NAV
for t,v,m in [('Claims','Dash','mDash'),('Settlements','All','mAll'),('Your info','Info','mInfo'),('Settings','Set','mSettings')]:
    k=NAVC.index(t+'</span>'); a=NAVC.rindex('<span style=',0,k); g=NAVC.index('>',a)+1
    NAVC=NAVC[:a]+'<button onClick="{{ go'+v+' }}" style="{{ '+m+' }}">'+NAVC[g:k]+t+'</button>'+NAVC[k+len(t+'</span>'):]
'''+s[j:]
# ---------- wrapper class ----------
rep('<div style="{{ zoomSt }}">','<div class="zwrap" style="{{ zoomSt }}">')
INFO='<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="M12 16v-4 M12 8h.01"></path></svg>'
IB='width: 26px; height: 26px; flex: none; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: transparent; color: #7C8AA5'
TIPBOX='margin: 0 0 12px; padding: 10px 12px; border-radius: 12px; background: #F3F6F4; font-size: 13px; line-height: 1.5; color: #43504A'
INP='height: 42px; border-radius: 12px; border: 1.5px solid #DDE5E0; padding: 0 14px; font-size: 14px; font-family: inherit; font-weight: 600; color: #0A0F0D; background: #FFFFFF; box-sizing: border-box'
ALL=f'''
    <sc-if value="{{{{ isAll }}}}" hint-placeholder-val="{{{{ false }}}}">
      <div style="display: flex; flex-wrap: wrap; align-items: flex-end; justify-content: space-between; gap: 12px"><div style="display: flex; flex-direction: column; gap: 4px"><h1 style="margin: 0; font-size: 22px; letter-spacing: -0.5px">All settlements</h1><span style="font-size: 13px; color: #5B6862">{{{{ totalOpen }}}} open settlements, checked every day. Members see every one.</span></div>
        <div class="srch" style="position: relative; width: 340px; max-width: 100%"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8A968F" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="position: absolute; left: 14px; top: 13px"><circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.3-4.3"></path></svg><input type="search" value="{{{{ q }}}}" onChange="{{{{ onQ }}}}" placeholder="Search company, product or city" aria-label="Search settlements" style="{INP}; width: 100%; padding-left: 38px; border-radius: 99px"></div></div>
      <div style="display: flex; gap: 4px; padding: 4px; border-radius: 14px; background: #E6ECE8; max-width: 460px"><sc-for list="{{{{ scopes }}}}" as="o" hint-placeholder-count="2"><button onClick="{{{{ o.tap }}}}" style="{{{{ o.st }}}}">{{{{ o.t }}}}<span style="font-size: 12px; font-weight: 800; color: #8A968F">{{{{ o.n }}}}</span></button></sc-for></div>
      <sc-if value="{{{{ isNear }}}}" hint-placeholder-val="{{{{ false }}}}"><div style="display: flex; align-items: center; gap: 10px; padding: 10px 14px; border-radius: 14px; background: #E9F6EF; color: #17603F; font-size: 13px; font-weight: 700"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path><circle cx="12" cy="10" r="3"></circle></svg>State and city settlements for California, based on your mailing address.</div></sc-if>
      <div class="scroll" style="display: flex; gap: 8px; overflow-x: auto; padding-bottom: 2px"><sc-for list="{{{{ cats }}}}" as="c" hint-placeholder-count="8"><button onClick="{{{{ c.tap }}}}" style="{{{{ c.st }}}}">{{{{ c.t }}}}</button></sc-for></div>
      <section style="background: #FFFFFF; border-radius: 18px; box-shadow: 0 0 0 1px #E3EAE6; overflow: hidden">
        <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 16px; border-bottom: 1px solid #EEF2F0"><span style="font-size: 13px; font-weight: 800; color: #5B6862">{{{{ sCount }}}} results</span><div style="display: flex; gap: 14px"><sc-for list="{{{{ sorts }}}}" as="o" hint-placeholder-count="2"><button onClick="{{{{ o.tap }}}}" style="{{{{ o.st }}}}">{{{{ o.t }}}}</button></sc-for></div></div>
        <sc-if value="{{{{ sNone }}}}" hint-placeholder-val="{{{{ false }}}}"><div style="padding: 28px 16px; text-align: center; font-size: 14px; color: #5B6862">No settlements match. Try another word or category.</div></sc-if>
        <sc-for list="{{{{ sRows }}}}" as="r" hint-placeholder-count="6"><div style="border-bottom: 1px solid #EEF2F0">
          <div class="srow">
            <img src="{{{{ r.logo }}}}" alt="" style="width: 34px; height: 34px; flex: none; border-radius: 10px; background: #FFFFFF; padding: 5px; box-sizing: border-box; object-fit: contain; box-shadow: inset 0 0 0 1px #E3EAE6">
            <button onClick="{{{{ r.toggle }}}}" aria-expanded="{{{{ r.isOpen }}}}" style="min-width: 0; display: flex; flex-direction: column; gap: 3px; background: transparent; text-align: left; color: inherit; padding: 0"><span style="font-size: 14px; font-weight: 800; display: flex; align-items: center; gap: 6px; min-width: 0"><span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{{{ r.co }}}}</span><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8A968F" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="{{{{ r.chev }}}}; flex: none"><path d="m6 9 6 6 6-6"></path></svg></span><span style="font-size: 12px; color: #5B6862; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{{{ r.title }}}}</span></button>
            <div class="hideS" style="min-width: 0; display: flex; flex-direction: column; gap: 4px"><span style="font-size: 13px; font-weight: 800; color: #12805C; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{{{ r.pay }}}}</span><span style="display: flex; gap: 6px; align-items: center"><span style="{{{{ r.proofSt }}}}">{{{{ r.proof }}}}</span><sc-if value="{{{{ r.isLocal }}}}" hint-placeholder-val="{{{{ false }}}}"><span style="font-size: 11px; font-weight: 800; color: #5B6862; white-space: nowrap">{{{{ r.area }}}}</span></sc-if></span></div>
            <span class="hideS" style="{{{{ r.dlSt }}}}">{{{{ r.dl }}}}</span>
            <sc-if value="{{{{ r.notMine }}}}" hint-placeholder-val="{{{{ true }}}}"><button onClick="{{{{ r.check }}}}" style="min-width: 84px; min-height: 34px; padding: 0 14px; border-radius: 99px; background: #0A0F0D; color: #FFFFFF; font-size: 13px; font-weight: 800">Check</button></sc-if>
            <sc-if value="{{{{ r.mine }}}}" hint-placeholder-val="{{{{ false }}}}"><button onClick="{{{{ r.goMine }}}}" style="min-width: 84px; min-height: 34px; padding: 0 12px; border-radius: 99px; background: #E9F6EF; color: #17603F; font-size: 12px; font-weight: 800; white-space: nowrap">{{{{ r.myLabel }}}}</button></sc-if>
          </div>
          <sc-if value="{{{{ r.isOpen }}}}" hint-placeholder-val="{{{{ false }}}}"><div class="cardin sdet" style="margin: 0 16px 14px 62px; padding: 14px; border-radius: 14px; background: #F3F6F4; display: flex; flex-direction: column; gap: 12px">
            <div style="display: flex; flex-direction: column; gap: 3px"><span style="font-size: 11px; font-weight: 800; letter-spacing: .5px; color: #8A968F">WHO QUALIFIES</span><span style="font-size: 14px; font-weight: 700; line-height: 1.45">{{{{ r.who }}}}</span></div>
            <div class="sgrid3" style="display: grid; grid-template-columns: repeat(3, minmax(0,1fr)); gap: 10px; font-size: 12px"><div style="display: flex; flex-direction: column; gap: 2px"><span style="color: #8A968F; font-weight: 700">Payout</span><span style="font-weight: 800">{{{{ r.pay }}}}</span></div><div style="display: flex; flex-direction: column; gap: 2px"><span style="color: #8A968F; font-weight: 700">Deadline</span><span style="font-weight: 800">{{{{ r.dlFmt }}}} · {{{{ r.dl }}}}</span></div><div style="display: flex; flex-direction: column; gap: 2px"><span style="color: #8A968F; font-weight: 700">Settlement fund</span><span style="font-weight: 800">{{{{ r.fund }}}}</span></div></div>
            <span style="font-size: 12px; color: #43504A">{{{{ r.how }}}} <span style="{{{{ r.proofSt }}}}">{{{{ r.proof }}}}</span></span>
            <sc-if value="{{{{ r.notMine }}}}" hint-placeholder-val="{{{{ true }}}}"><div style="display: flex; flex-wrap: wrap; align-items: center; gap: 8px"><span style="font-size: 13px; font-weight: 800; margin-right: auto">Does this describe you?</span><button onClick="{{{{ r.notMe }}}}" style="min-height: 36px; padding: 0 16px; border-radius: 99px; background: #FFFFFF; color: #0A0F0D; font-size: 13px; font-weight: 800; box-shadow: inset 0 0 0 1.5px #DDE5E0">Not me</button><button onClick="{{{{ r.add }}}}" style="min-height: 36px; padding: 0 16px; border-radius: 99px; background: #3DDC97; color: #0A0F0D; font-size: 13px; font-weight: 800">Yes, add to my claims</button></div></sc-if>
          </div></sc-if>
        </div></sc-for>
        <sc-if value="{{{{ sMore }}}}" hint-placeholder-val="{{{{ true }}}}"><div style="padding: 12px; display: flex; justify-content: center"><button onClick="{{{{ showMore }}}}" style="min-height: 38px; padding: 0 20px; border-radius: 99px; background: #EEF2F0; color: #0A0F0D; font-size: 13px; font-weight: 800">Show more · {{{{ sShown }}}} of {{{{ sCount }}}}</button></div></sc-if>
      </section>
    </sc-if>
'''
def frow(v):
    return f'''<div style="border-bottom: 1px solid #EEF2F0">
            <div style="display: flex; align-items: center; gap: 12px; padding: 12px 0">
              <div style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 4px"><span style="display: flex; align-items: center; gap: 6px; flex-wrap: wrap"><span style="font-size: 12px; font-weight: 800; color: #5B6862">{{{{ {v}.label }}}}</span><span style="{{{{ {v}.tagSt }}}}">{{{{ {v}.tag }}}}</span><button onClick="{{{{ {v}.toggle }}}}" aria-label="Why we need this" style="{IB}">{INFO}</button></span>
                <sc-if value="{{{{ {v}.viewing }}}}" hint-placeholder-val="{{{{ true }}}}"><sc-if value="{{{{ {v}.filled }}}}" hint-placeholder-val="{{{{ true }}}}"><span style="font-size: 15px; font-weight: 800; overflow-wrap: anywhere">{{{{ {v}.val }}}}</span></sc-if><sc-if value="{{{{ {v}.empty }}}}" hint-placeholder-val="{{{{ false }}}}"><span style="font-size: 14px; font-weight: 700; color: #B8333A">Missing</span></sc-if></sc-if>
                <sc-if value="{{{{ {v}.editing }}}}" hint-placeholder-val="{{{{ false }}}}"><div style="display: flex; flex-wrap: wrap; gap: 8px; align-items: center; padding-top: 2px"><input type="text" value="{{{{ {v}.draft }}}}" onChange="{{{{ {v}.onDraft }}}}" placeholder="{{{{ {v}.ph }}}}" aria-label="{{{{ {v}.label }}}}" style="{INP}; flex: 1 1 220px"><button onClick="{{{{ {v}.save }}}}" style="min-height: 38px; padding: 0 16px; border-radius: 99px; background: #3DDC97; color: #0A0F0D; font-size: 13px; font-weight: 800">Save</button><button onClick="{{{{ {v}.cancel }}}}" style="min-height: 38px; padding: 0 12px; border-radius: 99px; background: transparent; color: #5B6862; font-size: 13px; font-weight: 800">Cancel</button></div><sc-if value="{{{{ {v}.hasErr }}}}" hint-placeholder-val="{{{{ false }}}}"><span role="alert" style="font-size: 12px; font-weight: 700; color: #B8333A">{{{{ {v}.err }}}}</span></sc-if></sc-if>
              </div>
              <sc-if value="{{{{ {v}.viewing }}}}" hint-placeholder-val="{{{{ true }}}}"><button onClick="{{{{ {v}.start }}}}" style="{{{{ {v}.btnSt }}}}">{{{{ {v}.btn }}}}</button></sc-if>
            </div>
            <sc-if value="{{{{ {v}.open }}}}" hint-placeholder-val="{{{{ false }}}}"><div style="{TIPBOX}">{{{{ {v}.why }}}}</div></sc-if>
          </div>'''
def head(t,sub,extra=''):
    return f'<div style="display: flex; align-items: center; gap: 6px; padding: 12px 0 4px"><div style="flex-grow: 1; display: flex; flex-direction: column; gap: 2px"><h2 style="margin: 0; font-size: 16px">{t}</h2><span style="font-size: 12px; color: #5B6862">{sub}</span></div>{extra}</div>'
INFOV=f'''
    <sc-if value="{{{{ isInfo }}}}" hint-placeholder-val="{{{{ false }}}}">
      <div style="display: flex; flex-direction: column; gap: 4px"><h1 style="margin: 0; font-size: 22px; letter-spacing: -0.5px">Your info</h1><span style="font-size: 13px; color: #5B6862">Saved once, used on every claim you file. We only send a claim's administrator what its form asks for.</span></div>
      <div class="igrid" style="display: grid; grid-template-columns: minmax(0,1fr) minmax(0,1fr); gap: 14px; align-items: start">
        <div style="display: flex; flex-direction: column; gap: 14px">
          <section style="{{{{ cardPersonal }}}}">{head('About you','Matches you to class lists and confirms who you are')}
            <sc-for list="{{{{ personal }}}}" as="f" hint-placeholder-count="4">{frow('f')}</sc-for>
          </section>
          <section style="{{{{ cardPlain }}}}">{head('Filing authorization','Lets us submit claim forms in your name')}
            <div style="display: flex; align-items: center; gap: 12px; padding: 12px 0"><span style="width: 24px; height: 24px; flex: none; border-radius: 50%; background: #12805C; display: flex; align-items: center; justify-content: center"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg></span><div style="flex-grow: 1; display: flex; flex-direction: column; gap: 2px"><span style="font-size: 14px; font-weight: 800">Signed Nov 12, 2026</span><span style="font-size: 12px; color: #5B6862">You can cancel it any time in Settings.</span></div><a href="https://claimclub.io/legal/authorization.html" target="_blank" rel="noopener" style="flex: none; font-size: 13px; font-weight: 800; color: #12805C">View</a></div>
          </section>
        </div>
        <div style="display: flex; flex-direction: column; gap: 14px">
          <section style="{{{{ cardAddr }}}}">{head('Addresses','Old addresses help administrators find you')}
            {frow('address')}
            <div style="display: flex; flex-direction: column; gap: 10px; padding: 12px 0"><span style="display: flex; align-items: center; gap: 6px"><span style="font-size: 12px; font-weight: 800; color: #5B6862">Past addresses, last 10 years</span><span style="font-size: 11px; font-weight: 700; color: #8A968F">Optional</span><button onClick="{{{{ tPast.toggle }}}}" aria-label="Why we need this" style="{IB}">{INFO}</button></span>
              <sc-if value="{{{{ tPast.open }}}}" hint-placeholder-val="{{{{ false }}}}"><div style="{TIPBOX}">Lots of settlements cover purchases or accounts from years ago. If you moved, your old address is how the administrator finds you on their list.</div></sc-if>
              <sc-for list="{{{{ pastList }}}}" as="p" hint-placeholder-count="0"><div style="display: flex; align-items: center; gap: 10px; padding: 8px 12px; border-radius: 12px; background: #F3F6F4"><span style="flex-grow: 1; font-size: 13px; font-weight: 700">{{{{ p.p }}}}</span><button onClick="{{{{ p.rm }}}}" aria-label="Remove address" style="width: 28px; height: 28px; border-radius: 50%; background: transparent; color: #8A968F; display: flex; align-items: center; justify-content: center"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18 M6 6l12 12"></path></svg></button></div></sc-for>
              <div style="display: flex; gap: 8px"><input type="text" value="{{{{ pastDraft }}}}" onChange="{{{{ onPast }}}}" placeholder="Street, city, state, ZIP" aria-label="Add a past address" style="{INP}; flex: 1; min-width: 0"><button onClick="{{{{ addPast }}}}" style="flex: none; min-height: 42px; padding: 0 16px; border-radius: 99px; background: #0A0F0D; color: #FFFFFF; font-size: 13px; font-weight: 800">Add</button></div>
              <sc-if value="{{{{ hasPast }}}}" hint-placeholder-val="{{{{ false }}}}"><span></span></sc-if>
              <button onClick="{{{{ noPast }}}}" style="align-self: flex-start; background: transparent; padding: 0; font-size: 12px; font-weight: 800; color: #12805C">I have lived here 10+ years</button>
              <sc-if value="{{{{ pastDone }}}}" hint-placeholder-val="{{{{ false }}}}"><span style="font-size: 12px; font-weight: 700; color: #17603F">Got it. No past addresses needed.</span></sc-if>
            </div>
          </section>
          <section style="{{{{ cardPay }}}}">{head('How you get paid','Administrators pay you directly. Claimclub never holds your money.', f'<button onClick="{{{{ tBank.toggle }}}}" aria-label="Why we need this" style="{IB}">{INFO}</button>')}
            <sc-if value="{{{{ tBank.open }}}}" hint-placeholder-val="{{{{ false }}}}"><div style="{TIPBOX}">Most administrators pay by direct deposit, PayPal or check. We pick your default on every claim you file, and you can change it per claim.</div></sc-if>
            <div style="display: flex; align-items: center; gap: 12px; padding: 12px 0; border-bottom: 1px solid #EEF2F0"><span style="width: 36px; height: 36px; flex: none; border-radius: 10px; background: #EEF2F0; display: flex; align-items: center; justify-content: center; color: #0F3B2E"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 21h18 M3 10h18 M5 6l7-3 7 3 M4 10v11 M20 10v11 M8 14v3 M12 14v3 M16 14v3"></path></svg></span>
              <div style="flex-grow: 1; display: flex; flex-direction: column; gap: 2px"><sc-if value="{{{{ bankOn }}}}" hint-placeholder-val="{{{{ false }}}}"><span style="font-size: 14px; font-weight: 800">Bank connected</span><span style="font-size: 12px; color: #5B6862">Checking · verified through your bank</span></sc-if><sc-if value="{{{{ bankOff }}}}" hint-placeholder-val="{{{{ true }}}}"><span style="font-size: 14px; font-weight: 800">No bank connected</span><span style="font-size: 12px; color: #5B6862">Needed for direct deposit</span></sc-if></div>
              <sc-if value="{{{{ bankOff }}}}" hint-placeholder-val="{{{{ true }}}}"><button onClick="{{{{ connect }}}}" style="flex: none; min-height: 32px; padding: 0 14px; border-radius: 99px; background: #0A0F0D; color: #FFFFFF; font-size: 13px; font-weight: 800">Connect</button></sc-if><sc-if value="{{{{ bankOn }}}}" hint-placeholder-val="{{{{ false }}}}"><button onClick="{{{{ disconnect }}}}" style="flex: none; min-height: 32px; padding: 0 14px; border-radius: 99px; background: #EEF2F0; color: #0A0F0D; font-size: 13px; font-weight: 800">Disconnect</button></sc-if></div>
            <div style="display: flex; flex-direction: column; gap: 8px; padding: 12px 0"><span style="font-size: 12px; font-weight: 800; color: #5B6862">Default payout method</span><div style="display: flex; flex-wrap: wrap; gap: 8px"><sc-for list="{{{{ pays }}}}" as="p" hint-placeholder-count="3"><button onClick="{{{{ p.tap }}}}" style="{{{{ p.st }}}}">{{{{ p.o }}}}</button></sc-for></div>
              <sc-if value="{{{{ payNeedsBank }}}}" hint-placeholder-val="{{{{ false }}}}"><span style="font-size: 12px; font-weight: 700; color: #8A5A00">Connect a bank to use direct deposit.</span></sc-if></div>
          </section>
        </div>
      </div>
    </sc-if>
'''
k=s.index("    <sc-if value=\"{{ isSet }}\"")
s=s[:k]+ALL+INFOV+s[k:]
# ---------- CSS: srow + zoom + dark refinements ----------
rep("A_CSS='@keyframes shFade","A_CSS='.srow{display:grid;grid-template-columns:34px minmax(0,1.3fr) minmax(0,1fr) auto auto;gap:14px;align-items:center;padding:10px 16px}\\n.z-s>aside,.z-s>header,.z-s>nav,.z-s .zwrap,.z-s .shCard,.z-s .note{zoom:.86}.z-l>aside,.z-l>header,.z-l>nav,.z-l .zwrap,.z-l .shCard,.z-l .note{zoom:1.14}\\n@media (max-width:1100px){.srow{grid-template-columns:34px minmax(0,1fr) auto}.srow>.hideS{display:none !important}.igrid{grid-template-columns:minmax(0,1fr) !important}}\\n@keyframes shFade")
i=s.index("DARK_CSS='"); j=s.index("'\n",i)
extra=('\\n.dk img[style*="background: #FFFFFF"],.dk img[style*="background:#FFFFFF"]{background:#232D29 !important;box-shadow:none !important}'
 '\\n.dk img[src*="7fd6ec4499df609a"],.dk img[src*="7f4390cee228878d"],.dk img[src*="17d130cb2fd653ad"],.dk img[src*="121d9429923e05b9"]{filter:brightness(0) invert(1)}'
 '\\n.dk img[src*="9e823dce7e60dc8d"]{filter:invert(1) hue-rotate(180deg)}'
 '\\n.dk [style*="#FDECEC"]{background:#3A1A1D !important;color:#FF9AA0 !important}'
 '\\n.dk button[style*="background: #0A0F0D"],.dk button[style*="background:#0A0F0D"]{background:#3DDC97 !important;color:#0A0F0D !important}'
 '\\n.dk span[style*="background: #0A0F0D"],.dk span[style*="background:#0A0F0D"]{background:#2E3B36 !important;color:#E9F1ED !important}'
 '\\n.dk [style*="background: #0F3B2E"]:not(button){background:#0F2A21 !important;box-shadow:inset 0 0 0 1px #1E4536}'
 '\\n.dk [style*="background: #E6ECE8"]{background:#1A2320 !important}.dk [style*="background:#FFFFFF;color:#0A0F0D;box-shadow:0 1px 3px"]{background:#2A3632 !important}'
 '\\n.dk input{color:#E9F1ED !important}.dk input::placeholder{color:#6F7C76}'
 '\\n.dk .sdet,.dk [style*="background: #F3F6F4"]{background:#1B2420 !important}')
s=s[:j]+extra+s[j:]
# mobile css
rep(".findBtns{width:100%;flex-direction:column}",".srow{grid-template-columns:34px minmax(0,1fr) auto !important;gap:10px !important;padding:10px 14px !important}.srow>.hideS{display:none !important}.sdet{margin:0 14px 12px !important}.sgrid3{grid-template-columns:1fr 1fr !important}.srch{width:100% !important}.igrid{grid-template-columns:minmax(0,1fr) !important}\\n.findBtns{width:100%;flex-direction:column}")
open('make.py','w').write(s); print('markup ok')
