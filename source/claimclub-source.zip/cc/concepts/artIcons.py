# Custom illustrated icons (Nov 22 2026) for the How it works and About drafts. Same style as Flow C's TRUST_ART:
# soft tile, green gradient object, mint accent badge. art(name, size, tone) returns an <img> with a data URI
# (a data URI keeps each icon's gradient ids separate). tone: light (mint tile), dark (on the dark green band, round), amber.
import base64
T = {'light': ('#EAF8F1', '#D3EFE2', '#2FB57F', '#0F5A42', 20),
     'dark': ('#1F6B4D', '#14503A', '#5BE3A8', '#1E9468', 40),
     'amber': ('#FFF3D6', '#FBE3A8', '#E9A93A', '#8A5A00', 20)}
F = '-apple-system,Inter,Arial,sans-serif'
DEEP = '#0F3B2E'
def _svg(body, tone):
    a, b, g1, g2, rx = T[tone]
    d = (f'<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{g1}"/><stop offset="1" stop-color="{g2}"/></linearGradient>'
         f'<linearGradient id="t" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{a}"/><stop offset="1" stop-color="{b}"/></linearGradient>'
         '<filter id="s" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="0" dy="3" stdDeviation="2.5" flood-color="#0B2E23" flood-opacity=".3"/></filter></defs>'
         f'<rect width="80" height="80" rx="{rx}" fill="url(#t)"/>')
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80">' + d + body + '</svg>'
def badge(x, y, inner, fill='#3DDC97', r=10):
    return f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="#FFF" stroke-width="2.5"/>' + inner
def tick(x, y): return f'<path d="m{x-4.5} {y} 3 3 6-6" fill="none" stroke="{DEEP}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>'
def doc(x=20, y=14, w=34, h=44):
    return (f'<g filter="url(#s)"><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="5" fill="#FFF"/></g>'
            f'<rect x="{x+7}" y="{y+8}" width="{w-16}" height="4" rx="2" fill="{DEEP}"/>'
            + ''.join(f'<rect x="{x+7}" y="{y+17+i*8}" width="{w-14-(i%2)*6}" height="3.5" rx="1.75" fill="#D5E3DC"/>' for i in range(3)))
def lucide(x, y, s, path, c=DEEP, w=2.6):
    return f'<g transform="translate({x} {y}) scale({s})" fill="none" stroke="{c}" stroke-width="{w/s:.2f}" stroke-linecap="round" stroke-linejoin="round"><path d="{path}"/></g>'

B = {
 # check what you qualify for: checklist clipboard and a magnifier
 'check': ('<g filter="url(#s)"><rect x="16" y="16" width="36" height="46" rx="5" fill="#FFF"/></g><rect x="26" y="11" width="16" height="9" rx="3" fill="url(#g)"/>'
           + ''.join(f'<circle cx="25" cy="{30+i*10}" r="3.2" fill="{"#3DDC97" if i < 2 else "#D5E3DC"}"/><rect x="31" y="{28.3+i*10}" width="{15-i*3}" height="3.5" rx="1.75" fill="#D5E3DC"/>' for i in range(3))
           + '<g filter="url(#s)"><circle cx="53" cy="51" r="11" fill="#EAF8F1" stroke="url(#g)" stroke-width="5"/></g><path d="m61.5 59.5 7 7" stroke="url(#g)" stroke-width="6" stroke-linecap="round"/>'),
 # we file: claim form and a paper plane badge
 'file': doc() + badge(57, 57, lucide(50, 50, .58, 'm22 2-7 20-4-9-9-4Z M22 2 11 13'), r=12),
 # claim deadline: calendar with a circled day and a clock badge
 'deadline': ('<g filter="url(#s)"><rect x="14" y="19" width="46" height="42" rx="7" fill="#FFF"/></g><path d="M14 26a7 7 0 0 1 7-7h32a7 7 0 0 1 7 7v5H14z" fill="url(#g)"/>'
              '<rect x="24" y="14" width="4.5" height="10" rx="2.25" fill="#0F5A42"/><rect x="45.5" y="14" width="4.5" height="10" rx="2.25" fill="#0F5A42"/>'
              + ''.join(f'<rect x="{20+c*9}" y="{37+r*9}" width="5.5" height="5.5" rx="1.5" fill="#D5E3DC"/>' for r in range(2) for c in range(4) if (r, c) != (1, 2))
              + '<circle cx="40.8" cy="48.8" r="5.4" fill="none" stroke="#E5484D" stroke-width="2.2"/>'
              + badge(59, 58, f'<circle cx="59" cy="58" r="6" fill="none" stroke="{DEEP}" stroke-width="2.2"/><path d="M59 54.5V58l2.4 1.6" fill="none" stroke="{DEEP}" stroke-width="2.2" stroke-linecap="round"/>', r=11)),
 # court approval: gavel on a sound block with a check badge
 'approve': ('<g filter="url(#s)"><g transform="rotate(-38 38 34)"><rect x="25" y="16" width="28" height="15" rx="4" fill="url(#g)"/><rect x="22" y="18" width="4" height="11" rx="1.5" fill="#0F5A42"/><rect x="52" y="18" width="4" height="11" rx="1.5" fill="#0F5A42"/><rect x="36.5" y="30" width="5.5" height="22" rx="2.75" fill="#0F5A42"/></g>'
             '<rect x="12" y="55" width="34" height="9" rx="3" fill="url(#g)"/></g>' + badge(59, 57, tick(59, 57))),
 # payout: banknote and a coin stack
 'paid': ('<g filter="url(#s)"><rect x="12" y="24" width="40" height="26" rx="5" fill="url(#g)" transform="rotate(-10 32 37)"/></g>'
          '<circle cx="31" cy="37" r="6" fill="#FFF" fill-opacity=".92" transform="rotate(-10 32 37)"/><text x="31" y="40.6" text-anchor="middle" transform="rotate(-10 32 37)" font-family="' + F + '" font-weight="800" font-size="9.5" fill="#0F5A42">$</text>'
          '<g filter="url(#s)">' + ''.join(f'<rect x="42" y="{y}" width="26" height="7" fill="#1E9468"/><ellipse cx="55" cy="{y+7}" rx="13" ry="4.5" fill="#1E9468"/><ellipse cx="55" cy="{y}" rx="13" ry="4.5" fill="#3DDC97" stroke="#FFF" stroke-width="1.5"/>' for y in (58, 50, 42)) + '</g>'
          f'<text x="55" y="45.3" text-anchor="middle" font-family="{F}" font-weight="800" font-size="8" fill="{DEEP}">$</text>'),
 # 100% of every payout: two banknotes and a 100% pill
 'hundred': ('<g filter="url(#s)"><rect x="17" y="21" width="44" height="27" rx="5" fill="#14704F" transform="rotate(-8 39 34)"/><rect x="15" y="29" width="46" height="29" rx="5" fill="url(#g)"/></g>'
             '<rect x="19" y="33" width="38" height="21" rx="3" fill="none" stroke="#FFF" stroke-opacity=".35" stroke-width="1.5"/><circle cx="38" cy="43.5" r="7" fill="#FFF" fill-opacity=".92"/>'
             f'<text x="38" y="47.3" text-anchor="middle" font-family="{F}" font-weight="800" font-size="10" fill="#0F5A42">$</text>'
             f'<rect x="37" y="52" width="36" height="17" rx="8.5" fill="#3DDC97" stroke="#FFF" stroke-width="2.5"/><text x="55" y="64" text-anchor="middle" font-family="{F}" font-weight="800" font-size="10" fill="{DEEP}">100%</text>'),
 # free to file yourself: official form with a FREE tag and an open-link badge
 'free': (doc(16, 14, 36, 46) + '<g filter="url(#s)"><rect x="34" y="16" width="30" height="14" rx="7" fill="url(#g)"/></g>'
          f'<text x="49" y="26.4" text-anchor="middle" font-family="{F}" font-weight="800" font-size="8.5" fill="#FFF">FREE</text>'
          + badge(58, 58, lucide(52, 52, .5, 'M15 3h6v6 M10 14 21 3 M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6'), r=11)),
 # private: shield with a keyhole lock
 'private': ('<g filter="url(#s)"><path d="M40 14c7 5 13 6 20 6v18c0 13-9 20-20 25-11-5-20-12-20-25V20c7 0 13-1 20-6z" fill="url(#g)"/><path d="M40 20c5 3.5 9.5 4.5 14 4.8V38c0 9.5-6 15-14 19z" fill="#FFF" opacity=".12"/></g>'
             '<rect x="32" y="36" width="16" height="13" rx="3" fill="#3DDC97"/><path d="M35 36v-3.5a5 5 0 0 1 10 0V36" fill="none" stroke="#3DDC97" stroke-width="3"/>'
             f'<circle cx="40" cy="42" r="2" fill="{DEEP}"/><rect x="39" y="42" width="2" height="4" rx="1" fill="{DEEP}"/>'),
 # cancel anytime: a switch turned off with a check badge
 'cancel': ('<g filter="url(#s)"><rect x="14" y="27" width="52" height="27" rx="13.5" fill="url(#g)"/><circle cx="27.5" cy="40.5" r="10" fill="#FFF"/></g>'
            f'<text x="50" y="45" text-anchor="middle" font-family="{F}" font-weight="800" font-size="11" fill="#CFE9DD">OFF</text>' + badge(61, 22, tick(61, 22), r=9)),
 # what we are not: a balance scale (amber tile)
 'scale': ('<g filter="url(#s)"><rect x="38" y="19" width="4" height="38" rx="2" fill="url(#g)"/><rect x="18" y="22" width="44" height="4.5" rx="2.25" fill="url(#g)"/>'
           '<path d="M28 60h24a4 4 0 0 1 4 4H24a4 4 0 0 1 4-4z" fill="url(#g)"/><circle cx="40" cy="18" r="4" fill="url(#g)"/></g>'
           '<path d="M21 27 14 43M21 27l7 16M59 27l-7 16M59 27l7 16" stroke="#8A5A00" stroke-width="1.6" fill="none"/>'
           '<g filter="url(#s)"><path d="M12 43h18a9 6 0 0 1-18 0z" fill="#FFF"/><path d="M50 43h18a9 6 0 0 1-18 0z" fill="#FFF"/></g>'),
 # where settlements come from: court notices stacked, with a refresh badge
 'sources': ('<g filter="url(#s)" transform="rotate(-9 34 38)"><rect x="17" y="17" width="32" height="42" rx="4" fill="#FFF"/></g>' + doc(24, 14, 34, 46)
             + badge(58, 58, lucide(51.5, 51.5, .54, 'M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8 M3 3v5h5'), r=11)),
 # court filings: a courthouse
 'court': ('<g filter="url(#s)"><path d="M40 14 64 26H16z" fill="url(#g)"/><rect x="18" y="27" width="44" height="5" rx="1.5" fill="#0F5A42"/>'
           + ''.join(f'<rect x="{22+i*10}" y="34" width="6" height="21" rx="2" fill="url(#g)"/>' for i in range(4)) + '<rect x="15" y="56" width="50" height="7" rx="2" fill="#0F5A42"/></g>'),
 # official websites: a browser window with a check badge
 'web': ('<g filter="url(#s)"><rect x="12" y="18" width="52" height="40" rx="7" fill="#FFF"/></g><path d="M12 25a7 7 0 0 1 7-7h38a7 7 0 0 1 7 7v4H12z" fill="url(#g)"/>'
         + ''.join(f'<circle cx="{19+i*6}" cy="23.5" r="1.8" fill="#FFF" fill-opacity=".8"/>' for i in range(3))
         + '<rect x="19" y="35" width="26" height="4" rx="2" fill="#0F3B2E"/><rect x="19" y="43" width="34" height="3.5" rx="1.75" fill="#D5E3DC"/><rect x="19" y="50" width="22" height="3.5" rx="1.75" fill="#D5E3DC"/>'
         + badge(60, 58, tick(60, 58))),
 # daily scan: radar sweep
 'scan': ('<g filter="url(#s)"><circle cx="38" cy="40" r="24" fill="url(#g)"/></g><circle cx="38" cy="40" r="16" fill="none" stroke="#FFF" stroke-opacity=".35" stroke-width="1.5"/><circle cx="38" cy="40" r="8" fill="none" stroke="#FFF" stroke-opacity=".35" stroke-width="1.5"/>'
          '<path d="M38 40 56 26a24 24 0 0 1 6 14z" fill="#FFF" fill-opacity=".25"/><path d="M38 40 56 26" stroke="#FFF" stroke-width="2.5" stroke-linecap="round"/><circle cx="47" cy="31" r="3.4" fill="#3DDC97" stroke="#FFF" stroke-width="1.5"/><circle cx="38" cy="40" r="2.6" fill="#FFF"/>'),
 # support: envelope with a chat badge
 'mail': ('<g filter="url(#s)"><rect x="12" y="22" width="50" height="36" rx="6" fill="#FFF"/></g><path d="M14 25 37 43l23-18" fill="none" stroke="url(#g)" stroke-width="4.5" stroke-linejoin="round" stroke-linecap="round"/>'
          + badge(60, 57, ''.join(f'<circle cx="{55+i*5}" cy="57" r="1.7" fill="{DEEP}"/>' for i in range(3)), r=11)),
 # the company: office building
 'company': ('<g filter="url(#s)"><rect x="22" y="14" width="30" height="50" rx="4" fill="url(#g)"/><rect x="50" y="32" width="16" height="32" rx="3" fill="#0F5A42"/></g>'
             + ''.join(f'<rect x="{27+c*11}" y="{20+r*9}" width="7" height="5" rx="1.2" fill="#FFF" fill-opacity="{.9 if (r+c)%3 else .45}"/>' for r in range(4) for c in range(2))
             + '<rect x="32" y="54" width="10" height="10" rx="1.5" fill="#3DDC97"/>' + ''.join(f'<rect x="54" y="{37+i*8}" width="8" height="4" rx="1" fill="#FFF" fill-opacity=".55"/>' for i in range(3))),
}
B.update({
 # proof: a receipt with a check badge
 'proof': ('<g filter="url(#s)"><path d="M21 13h32a3 3 0 0 1 3 3v47l-6-4-6 4-6-4-6 4-6-4-6 4V16a3 3 0 0 1 3-3z" fill="#FFF"/></g>'
           f'<rect x="26" y="22" width="18" height="4" rx="2" fill="{DEEP}"/><rect x="26" y="31" width="22" height="3.5" rx="1.75" fill="#D5E3DC"/><rect x="26" y="39" width="16" height="3.5" rx="1.75" fill="#D5E3DC"/>'
           + badge(58, 56, tick(58, 56), r=11)),
 # settlement fund: a money bag
 'fund': ('<g filter="url(#s)"><path d="M32 22h16l-4 7c10 4 16 13 16 22 0 8-7 13-20 13S20 59 20 51c0-9 6-18 16-22z" fill="url(#g)"/><path d="M30 15c3 2 6 2 10 0 4 2 7 2 10 0l-2 7H32z" fill="#0F5A42"/></g>'
          '<rect x="33" y="27" width="14" height="4" rx="2" fill="#3DDC97"/><circle cx="40" cy="48" r="9" fill="#FFF" fill-opacity=".92"/>'
          f'<text x="40" y="52.3" text-anchor="middle" font-family="{F}" font-weight="800" font-size="12" fill="#0F5A42">$</text>'),
})
def uri(name, tone='light'):
    return 'data:image/svg+xml;base64,' + base64.b64encode(_svg(B[name], tone).encode()).decode()
def art(name, size, tone='light', extra=''):
    return f'<img src="{uri(name, tone)}" width="{size}" height="{size}" alt="" style="display: block; flex: none; width: {size}px; height: {size}px; {extra}">'
