# Find claims, row dropdown drafts (Nov 21 2026, canvas only). Replaces the Your claims dropdown drafts (wrong page).
# The live Find claims list (one list, most popular first, only claims not in Your claims) opens a row in place.
#   FindDD1  Facts then check: plain sentence, 4 fact tiles, big Check if I qualify; the question replaces the buttons.
#   FindDD2  Question first: opening a row asks the first question right away, facts are one quiet line.
#   FindDD3  Case card: payout and countdown on the left, who qualifies and what you need on the right.
# Each board: desktop with a row open, phone with the question showing, then the other states.
import os, json
from tierE import HEAD, JS, OUT
from perksD import ic, LU
from findD import T, logo
from upgradeD import desk, phone, INK, MUTE, LINE, MINT, GREEN, DARK, BG

LU.update({'ok': 'M20 6 9 17l-5-5', 'up': 'm18 15-6-6-6 6', 'plus': 'M5 12h14 M12 5v14', 'x': 'M18 6 6 18 M6 6l12 12',
           'clock': 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20z M12 6v6l4 2', 'file': 'M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z M14 2v4a2 2 0 0 0 2 2h4',
           'globe': 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20z M2 12h20 M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z',
           'pin': 'M20 10c0 5-5.5 10.2-7.4 11.8a1 1 0 0 1-1.2 0C9.5 20.2 4 15 4 10a8 8 0 0 1 16 0 M12 7a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
           'user': 'M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2 M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z', 'receipt': 'M4 2v20l3-2 3 2 3-2 3 2 3-2 2 2V2l-2 2-3-2-3 2-3-2-3 2z M8 8h8 M8 12h8',
           'zap': 'M13 2 3 14h9l-1 8 10-12h-9z', 'search': 'M11 3a8 8 0 1 0 0 16 8 8 0 0 0 0-16z m10 18-4.3-4.3'})
RED = '#B8333A'
# id, company, payout, who (plain), days left, proof, filed by, question
R = [('starbucks', 'Starbucks', '$30 to $74', 'You got a COBRA health insurance notice from Starbucks between July 2016 and Jan 2023', 12, 'None', 'Us, for you', 'Did you get a letter about COBRA health insurance after leaving a job at Starbucks?'),
     ('toyota', 'Toyota', '$250 or more', 'You own or lease a Toyota with a recalled Takata airbag', 752, 'VIN', 'Us, for you', 'Do you own or lease one of the listed Toyota models?'),
     ('kia', 'Kia', 'Up to $400', 'You paid to fix the power window on a 2016 or 2017 Kia Optima or Sportage', 3, 'Repair receipt', 'Us, for you', 'Did you pay to repair a power window on a 2016 or 2017 Kia Optima or Sportage?'),
     ('equifax', 'Equifax', 'Up to $400', 'You disputed a mistake on your Equifax credit report', 8, 'Notice code', 'Us, for you', 'Did you dispute a credit check on your Equifax report that you thought was a mistake?'),
     ('goodrx', 'GoodRx', 'Up to $40', 'You used GoodRx between 2017 and 2020', 31, 'None', 'Us, for you', 'Did you use GoodRx to save on a prescription between 2017 and 2020?'),
     ('navy', 'Navy Federal', 'Up to $100', 'You paid an overdraft fee at Navy Federal from 2017 to 2022', 44, 'None', 'Nobody needs to', ''),
     ('knotts', "Knott's Berry Farm", '$5 to $25', "You bought a Knott's ticket online and paid a service fee", 31, 'None', 'Us, for you', "Did you buy a Knott's Berry Farm ticket online and pay a service fee?"),
     ('squatch', 'Dr. Squatch', 'Up to $30', 'You had a Dr. Squatch subscription that renewed without warning', 70, 'None', 'Us, for you', 'Did a Dr. Squatch subscription renew without you agreeing to it?')]
BY = {r[0]: r for r in R}

def kick(t, c='#8A968F'): return f'<span style="font-size: 11.5px; font-weight: 800; letter-spacing: .9px; color: {c}">{t}</span>'
def txt(t, c=MUTE, sz=13.5, w=600): return f'<span style="font-size: {sz}px; font-weight: {w}; color: {c}; line-height: 1.5">{t}</span>'
def btn(t, kind='mint', icon='', grow=False):
    st = {'mint': f'background: {MINT}; color: {DARK}', 'dark': f'background: {DARK}; color: #FFFFFF', 'ghost': f'background: #FFFFFF; color: #26332C; box-shadow: inset 0 0 0 1.5px {LINE}', 'link': f'background: none; color: {MUTE}'}[kind]
    return f'<span style="display: inline-flex; align-items: center; justify-content: center; gap: 7px; min-height: 44px; padding: 0 20px; border-radius: 99px; font-size: 14px; font-weight: 800; {st}; {"flex: 1" if grow else ""}">{icon}{t}</span>'
def due(d): return 'Open for years' if d > 365 else f'{d} days left'
def head(i, right='plus', open_=False, m=False):
    _, co, pay, who, d, *_ = BY[i]
    r = {'plus': f'<span style="width: 34px; height: 34px; flex: none; border-radius: 99px; box-shadow: inset 0 0 0 1.5px {LINE}; background: #FFFFFF; display: flex; align-items: center; justify-content: center">{ic("plus", 16, INK, 2.4)}</span>',
         'up': f'<span style="display: flex">{ic("up", 16, MUTE, 2.4)}</span>',
         'lock': f'<span style="display: inline-flex; align-items: center; gap: 6px; flex: none; min-height: 34px; padding: 0 14px; border-radius: 99px; background: {DARK}; color: #FFFFFF; font-size: 13px; font-weight: 800">{ic("lock", 13, "#FFFFFF", 2.4)}Upgrade</span>'}[right]
    return (f'<div style="display: flex; align-items: center; gap: 12px; padding: 12px 14px">{logo(i, 38)}<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px">'
            f'<b style="font-size: 15px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{co} <span style="color: {GREEN}">· {pay}</span></b>'
            f'<span style="font-size: 13px; font-weight: 600; color: {MUTE}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{who}</span></span>{r}</div>')
def card(inner, open_=False):
    return f'<div style="background: #FFFFFF; border-radius: 14px; {"box-shadow: inset 0 0 0 1.5px " + GREEN + ", 0 12px 28px rgba(10,15,13,.07)" if open_ else "box-shadow: inset 0 0 0 1px " + LINE}">{inner}</div>'
def ynq(q, pos='ONE QUICK QUESTION', bg=BG):
    return (f'<div style="display: flex; flex-direction: column; gap: 10px; padding: 14px; border-radius: 14px; background: {bg}">{kick(pos, GREEN)}<b style="font-size: 15.5px; line-height: 1.4">{q}</b>'
            f'<div style="display: flex; gap: 8px">{btn("No", "ghost", "", True)}{btn("Yes", "mint", "", True)}</div></div>')
def result(kind, co):
    if kind == 'yes':
        return (f'<div style="display: flex; flex-direction: column; gap: 12px; padding: 14px; border-radius: 14px; background: #E3F6EC"><span style="display: flex; gap: 10px; align-items: flex-start; font-size: 14.5px; font-weight: 800; color: {DARK}; line-height: 1.4">'
                f'<span style="width: 26px; height: 26px; flex: none; border-radius: 99px; background: {GREEN}; display: flex; align-items: center; justify-content: center">{ic("ok", 14, "#FFFFFF", 3.2)}</span>You qualify. We added {co} to Your claims.</span>'
                f'<div style="display: flex; gap: 8px; flex-wrap: wrap">{btn("File it now", "dark")}{btn("Keep browsing", "ghost")}</div></div>')
    return (f'<div style="display: flex; flex-direction: column; gap: 12px; padding: 14px; border-radius: 14px; background: {BG}"><b style="font-size: 14.5px; line-height: 1.4">This one is probably not for you. No problem, there are plenty more.</b>'
            f'<div style="display: flex; gap: 8px; flex-wrap: wrap">{btn("Keep browsing", "dark")}{btn("I tapped the wrong answer", "ghost")}</div></div>')
def locked_note(m=False):
    return (f'<div style="display: flex; flex-direction: column; gap: 12px; padding: 14px; border-radius: 14px; background: #0F3B2E; color: #FFFFFF">{kick("FAST AND PRIORITY", MINT)}'
            f'<span style="font-size: 14px; font-weight: 700; line-height: 1.45; color: #E3F6EC">Standard covers the claims our bot files. This one needs a person, so it is part of Fast.</span>'
            f'<div style="display: flex; gap: 8px; flex-wrap: wrap">{btn("Upgrade to Fast · $15/mo", "mint", ic("zap", 15, DARK, 2.4))}<span style="display: inline-flex; align-items: center; min-height: 44px; padding: 0 12px; font-size: 14px; font-weight: 800; color: #B9D3C7">Not now</span></div></div>')

# ---------- 1 facts then check ----------
def b1(i, state='new', m=False):
    _, co, pay, who, d, proof, by, q = BY[i]
    tiles = [('PAYOUT', pay), ('CLOSES', due(d)), ('PROOF', proof), ('FILED BY', by)]
    f = (f'<div style="display: grid; grid-template-columns: repeat({2 if m else 4}, minmax(0, 1fr)); gap: 8px">' + ''.join(
        f'<div style="background: {BG}; border-radius: 12px; padding: 10px 12px; display: flex; flex-direction: column; gap: 2px">{kick(k)}<span style="font-size: 13.5px; font-weight: 800; color: {RED if k == "CLOSES" and d <= 7 else INK}">{v}</span></div>' for k, v in tiles) + '</div>')
    act = {'new': f'<div style="display: flex; gap: 8px; flex-wrap: wrap">{btn("Check if I qualify", "mint", "", m)}{btn("Not for me", "ghost")}</div>',
           'q': ynq(q), 'yes': result('yes', co), 'no': result('no', co), 'lock': locked_note(m),
           'auto': f'<div style="display: flex; gap: 10px; padding: 12px 14px; border-radius: 14px; background: #E8EEFB">{ic("clock", 17, "#2C4FA8", 2.2)}{txt("Nothing to file. People on the class list get paid automatically. Add it and we track the payout for you.", INK, 13.5, 700)}</div><div style="display: flex; gap: 8px">{btn("Track it for me", "mint")}</div>'}[state]
    return f'<div style="border-top: 1px solid {LINE}; padding: 14px; display: flex; flex-direction: column; gap: 12px">{txt(who + ".", INK, 14, 700)}{f}{act}</div>'

# ---------- 2 question first ----------
def b2(i, state='q', m=False):
    _, co, pay, who, d, proof, by, q = BY[i]
    line = (f'<div style="display: flex; flex-wrap: wrap; gap: 6px 14px; font-size: 12.5px; font-weight: 700; color: {MUTE}">'
            f'<span style="display: inline-flex; align-items: center; gap: 5px">{ic("receipt", 14, GREEN, 2.2)}{pay}</span>'
            f'<span style="display: inline-flex; align-items: center; gap: 5px; color: {RED if d <= 7 else MUTE}">{ic("clock", 14, RED if d <= 7 else GREEN, 2.2)}{due(d)}</span>'
            f'<span style="display: inline-flex; align-items: center; gap: 5px">{ic("file", 14, GREEN, 2.2)}{"No proof needed" if proof == "None" else "Needs " + (proof if proof.isupper() else proof.lower())}</span>'
            f'<span style="display: inline-flex; align-items: center; gap: 5px">{ic("user", 14, GREEN, 2.2)}{"We file it" if by.startswith("Us") else "Pays automatically"}</span></div>')
    main = {'q': (f'<div style="display: flex; flex-direction: column; gap: 12px"><b style="font-size: {17 if m else 18}px; line-height: 1.35; letter-spacing: -.2px">{q}</b>'
                  f'<div style="display: flex; gap: 8px">{btn("No", "ghost", "", True)}{btn("Yes", "mint", "", True)}</div>'
                  f'<span style="font-size: 12.5px; font-weight: 700; color: #8A968F">1 of 2 · Yes adds it to Your claims</span></div>'),
            'yes': result('yes', co), 'no': result('no', co), 'lock': locked_note(m),
            'auto': f'<div style="display: flex; flex-direction: column; gap: 10px"><b style="font-size: 17px; line-height: 1.35">Nothing to file. If you were a Navy Federal member who paid an overdraft fee, the money comes to you automatically.</b><div style="display: flex; gap: 8px">{btn("Track it for me", "mint")}{btn("Not for me", "ghost")}</div></div>'}[state]
    return f'<div style="border-top: 1px solid {LINE}; padding: 16px 14px; display: flex; flex-direction: column; gap: 14px">{main}{line}</div>'

# ---------- 3 case card ----------
def b3(i, state='new', m=False):
    _, co, pay, who, d, proof, by, q = BY[i]
    left = (f'<div style="{"" if m else "width: 210px; flex: none;"} border-radius: 14px; background: {DARK}; color: #FFFFFF; padding: 16px; display: flex; flex-direction: column; gap: 10px">'
            f'{kick("YOU COULD GET", "#9FD9BE")}<b style="font-size: 24px; letter-spacing: -.5px; line-height: 1.1">{pay}</b>'
            f'<span style="display: inline-flex; align-self: flex-start; align-items: center; gap: 6px; font-size: 12.5px; font-weight: 800; padding: 5px 10px; border-radius: 99px; background: {"#5A1E22" if d <= 7 else "rgba(255,255,255,.12)"}; color: {"#FFC9CC" if d <= 7 else "#E3F6EC"}">{ic("clock", 13, "#FFC9CC" if d <= 7 else MINT, 2.4)}{due(d)}</span>'
            f'<span style="font-size: 12.5px; font-weight: 600; color: #B9D3C7; line-height: 1.45">{"Paid automatically, nothing to file." if by.startswith("Nobody") else "We file it for you. Payouts usually come 6 to 12 months after the deadline."}</span></div>')
    need = ('Nothing, just your answers' if proof == 'None' else proof)
    li = lambda k, t: f'<div style="display: flex; gap: 10px; align-items: flex-start">{ic(k, 16, GREEN, 2.2)}{txt(t, INK, 13.5, 700)}</div>'
    right_top = (f'<div style="display: flex; flex-direction: column; gap: 10px">{kick("WHO QUALIFIES")}{li("ok", who)}'
                 f'{kick("WHAT YOU NEED")}{li("file", need)}</div>')
    act = {'new': f'<div style="display: flex; gap: 8px; flex-wrap: wrap">{btn("Check if I qualify", "mint", "", m)}{btn("Not for me", "link")}</div>',
           'q': ynq(q), 'yes': result('yes', co), 'no': result('no', co), 'lock': locked_note(m),
           'auto': f'<div style="display: flex; gap: 8px">{btn("Track it for me", "mint")}{btn("Not for me", "link")}</div>'}[state]
    right = f'<div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 14px">{right_top}{act}</div>'
    return f'<div style="border-top: 1px solid {LINE}; padding: 14px; display: flex; {"flex-direction: column" if m else "align-items: stretch"}; gap: 14px">{left}{right}</div>'

# ---------- page ----------
def tabs(m=False):
    t = lambda on, k, l, n: (f'<div style="flex: 1; display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 14px; {"background: #FFFFFF; box-shadow: inset 0 0 0 2px " + GREEN if on else "box-shadow: inset 0 0 0 1px " + LINE}">'
                             f'<span style="width: 30px; height: 30px; border-radius: 9px; background: {"#E9F6EF" if on else "#EEF2F0"}; display: flex; align-items: center; justify-content: center">{ic(k, 16, GREEN if on else MUTE, 2.2)}</span>'
                             f'<b style="font-size: 15px; color: {INK if on else "#43504A"}">{l} <span style="color: #8A968F; font-weight: 700">{n}</span></b></div>')
    return f'<div style="display: flex; gap: 10px">{t(True, "globe", "Nationwide", "144")}{t(False, "pin", "Near you", "4")}</div>'
def page(body, open_id, state, m=False):
    top = (f'<div style="display: flex; flex-direction: column; gap: 4px"><b style="font-size: {28 if m else 32}px; letter-spacing: -.8px">Find claims</b>{txt("Most popular first. Tap one to check if you qualify.", MUTE, 14.5)}</div>'
           f'<div style="height: 46px; border-radius: 99px; background: #FFFFFF; box-shadow: inset 0 0 0 1px {LINE}; display: flex; align-items: center; gap: 10px; padding: 0 16px; color: #8A968F; font-size: 14.5px; font-weight: 600">{ic("search", 17, "#8A968F", 2.2)}Search a company or product</div>{tabs(m)}')
    rows = ''.join(card(head(r[0], 'up' if r[0] == open_id else 'plus', r[0] == open_id) + (body(r[0], state, m) if r[0] == open_id else ''), r[0] == open_id) for r in R[: 6 if m else 7])
    return top + f'<div style="display: flex; flex-direction: column; gap: 8px">{rows}</div>'
def board(name, label, note, body, dstate, mstate, others, H):
    dk = desk(page(body, 'kia', dstate), 'Find claims', 1120, True)
    ph = phone(page(body, 'starbucks', mstate, True), 'Find', 1120, True)
    st = ''.join(f'<div style="display: flex; flex-direction: column; gap: 8px">{kick(t.upper(), GREEN)}{card(head(i, "lock" if s == "lock" else "up", True) + body(i, s), True)}</div>' for t, i, s in others)
    html = (f'<div data-board style="width: 2300px; height: {H}px; box-sizing: border-box; padding: 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: {INK}; display: flex; flex-direction: column; gap: 26px">'
            f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: {GREEN}">{label}</span>'
            f'<span style="font-size: 16px; color: #43504A; font-weight: 600; max-width: 1400px; line-height: 1.45">{note}</span></div>'
            f'<div style="display: flex; gap: 50px; align-items: flex-start">{dk}{ph}<div style="width: 600px; flex: none; display: flex; flex-direction: column; gap: 20px">{kick("OTHER STATES", "#43504A")}{st}</div></div></div>\n</x-dc>\n')
    open(os.path.join(OUT, f'{name}.dc.html'), 'w').write(HEAD % label.title() + html + JS.replace('"width":1926,"height":980', f'"width":2300,"height":{H}'))

if __name__ == '__main__':
    B = [('FindDD1', 'FIND CLAIMS DROPDOWN · 1 · FACTS THEN CHECK', 'Opening a claim shows who it is for in one plain sentence, four fact tiles (payout, closes, proof, who files) and one big Check if I qualify button. Tapping it swaps the buttons for the question, right in place.', b1, 'new', 'q',
          [('Checking (question)', 'equifax', 'q'), ('You qualify', 'goodrx', 'yes'), ('Not a match', 'knotts', 'no'), ('Pays automatically', 'navy', 'auto'), ('Not in your plan', 'toyota', 'lock')], 1960),
         ('FindDD2', 'FIND CLAIMS DROPDOWN · 2 · QUESTION FIRST', 'Opening a claim asks the first question straight away, with big No and Yes buttons. The facts shrink to one quiet line of icons underneath. One tap to open, one tap to answer.', b2, 'q', 'q',
          [('You qualify', 'goodrx', 'yes'), ('Not a match', 'knotts', 'no'), ('Pays automatically', 'navy', 'auto'), ('Not in your plan', 'toyota', 'lock')], 1360),
         ('FindDD3', 'FIND CLAIMS DROPDOWN · 3 · CASE CARD', 'Opening a claim shows a dark money card (what you could get, days left, how it gets paid) next to who qualifies and what you need. Check if I qualify sits under that and turns into the question.', b3, 'new', 'q',
          [('Checking (question)', 'equifax', 'q'), ('You qualify', 'goodrx', 'yes'), ('Pays automatically', 'navy', 'auto'), ('Not in your plan', 'toyota', 'lock')], 1900)]
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    for k in ['YourY1.dc.html', 'YourY2.dc.html', 'YourY3.dc.html']:
        c['boards'].pop(k, None)
        if k in c['order']: c['order'].remove(k)
    c['notes'].pop('tYour', None)
    if 'tYour' in c['noteOrder']: c['noteOrder'].remove('tYour')
    c['pages'] = [p for p in c['pages'] if p['id'] != 'yourc']
    if not any(p['id'] == 'finddd' for p in c['pages']): c['pages'].append({'id': 'finddd', 'name': 'Find claims dropdown'})
    y = 0
    for nm, lb, note, fn, ds, ms, oth, H in B:
        board(nm, lb, note, fn, ds, ms, oth, H)
        c['boards'][nm + '.dc.html'] = {'x': 0, 'y': y, 'w': 2300, 'h': H, 'title': lb.split(' · ', 1)[1].title(), 'page': 'finddd', 'is_interactive': False}
        if nm + '.dc.html' not in c['order']: c['order'].append(nm + '.dc.html')
        y += H + 120
    c['notes']['tFindDD'] = {'x': 0, 'y': -300, 'page': 'finddd', 'text': 'Find claims · 3 dropdown drafts', 'kind': 'title1', 'maxW': 2300, 'w': 240}
    if 'tFindDD' not in c['noteOrder']: c['noteOrder'].append('tFindDD')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w')); print('ok')
