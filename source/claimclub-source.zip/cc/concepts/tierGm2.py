# Phone iterations round 2 (Nov 21 2026, design only): three takes on B (open cards) and three on C (rows), all 3 plans on screen.
# Boards OfferG2mB (B1..B3) and OfferG2mC (C1..C3).
import os
from perksD import LU
LU.setdefault('clock', 'M12 2a10 10 0 1 0 0 20a10 10 0 1 0 0-20 M12 6v6l4 2')
from tierE import HEAD, JS, OUT, h, mob, mint_btn, ic, chip, INK, MUTE, LINE, MINT, GREEN, DARK

P = {
 'std': dict(name='Standard', price='Free', per='', speed='30 days', tag='', feats=['Filed within 30 days', 'Auto-filed claims only', '3 of your 6 claims'], btn='Start free'),
 'fast': dict(name='Fast', price='$15', per='/mo', speed='3 days', tag='Most popular', feats=['Filed within 3 days', 'All 173 nationwide claims', 'All 6 of your claims', 'Reminders on new claims'], btn='Start Fast · $15'),
 'pri': dict(name='Priority', price='$30', per='/mo', speed='24 hours', tag='Fastest', feats=['Filed within 24 hours', 'All 270 claims, incl. local', 'New claims filed for you', 'First look at new claims', 'Refunds + Subscription Manager'], btn='Start Priority · $30'),
}
PLUS = {'fast': ['All 173 nationwide claims', 'All 6 of your claims', 'Reminders on new claims'], 'pri': ['All 270 claims, incl. local', 'New claims filed for you', 'First look at new claims', 'Refunds + Subscription Manager']}
FOOT = lambda t='Start Fast · $15 today', s='$15 today, renews monthly. Cancel anytime. Payouts take 6 to 12 months on every plan.': (
    mint_btn(f'{ic("lock", 16, DARK, 2.4)}{t}', 52) + f'<span style="font-size: 11px; font-weight: 600; color: {MUTE}; text-align: center; line-height: 1.4">{s}</span>')

def li(t, c=GREEN, fg=INK, sz=13):
    return f'<div style="display: flex; align-items: center; gap: 8px; font-size: {sz}px; font-weight: 650; color: {fg}">{ic("check", 14, c, 3)}<span>{t}</span></div>'
def price(p, fg=INK, sub=MUTE, big=22):
    return f'<span style="display: flex; align-items: baseline; gap: 1px; white-space: nowrap"><b style="font-size: {big}px; letter-spacing: -.8px; color: {fg}">{p["price"]}</b><span style="font-size: 12px; font-weight: 700; color: {sub}">{p["per"]}</span></span>'
def pill(t, bg, fg):
    return f'<span style="font-size: 10.5px; font-weight: 800; letter-spacing: .4px; padding: 3px 8px; border-radius: 99px; background: {bg}; color: {fg}; white-space: nowrap">{t.upper()}</span>'
def radio(on, dark=False):
    return (f'<span style="width: 20px; height: 20px; flex: none; border-radius: 99px; background: {GREEN}; display: flex; align-items: center; justify-content: center">{ic("check", 12, "#FFFFFF", 3.4)}</span>' if on
            else f'<span style="width: 20px; height: 20px; flex: none; border-radius: 99px; box-shadow: inset 0 0 0 2px {"#4A5A53" if dark else "#C9D3CD"}"></span>')

# ---------- B1: clean cards, slim, own buttons ----------
def b1():
    def card(k):
        p = P[k]; dark = k == 'pri'; sel = k == 'fast'
        bg = 'linear-gradient(160deg, #1E2A25, #0E1512)' if dark else '#FFFFFF'
        ring = f'inset 0 0 0 2px {MINT}, 0 10px 24px rgba(18,128,92,.14)' if sel else ('none' if dark else f'inset 0 0 0 1px {LINE}')
        fg = '#FFFFFF' if dark else INK
        tag = pill(p['tag'], MINT, DARK) if sel else (pill(p['tag'], '#2F3D37', '#CFE0D7') if dark else '')
        btn = (mint_btn(p['btn'], 40, 14) if sel else
               f'<div style="height: 40px; border-radius: 99px; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 800; {"background: #FFFFFF; color: " + INK if dark else "box-shadow: inset 0 0 0 1.5px #C9D3CD; color: " + INK}">{p["btn"]}</div>')
        feats = ''.join(li(f, MINT if dark else GREEN, '#E6EEEA' if dark else INK, 12.5) for f in p['feats'][:4])
        return (f'<div style="border-radius: 18px; padding: 14px; background: {bg}; box-shadow: {ring}; display: flex; flex-direction: column; gap: 10px; color: {fg}">'
                f'<div style="display: flex; align-items: center; gap: 8px"><b style="font-size: 17px">{p["name"]}</b>{tag}<span style="flex: 1"></span>{price(p, fg, "#9FC3B4" if dark else MUTE)}</div>'
                f'<div style="display: flex; flex-direction: column; gap: 6px">{feats}</div>{btn}</div>')
    return mob(h('Pick your plan', 24, False) + card('fast') + card('pri') + card('std'))

# ---------- B2: ladder, each card only lists what it adds ----------
def b2():
    def card(k, head):
        p = P[k]; sel = k == 'fast'
        ring = f'inset 0 0 0 2px {MINT}' if sel else f'inset 0 0 0 1px {LINE}'
        items = p['feats'] if k == 'std' else [p['feats'][0]] + PLUS[k]
        tag = pill(p['tag'], MINT, DARK) if sel else (pill(p['tag'], '#FFF1CC', '#7A5300') if k == 'pri' else '')
        return (f'<div style="border-radius: 16px; padding: 12px 14px; background: #FFFFFF; box-shadow: {ring}; display: flex; flex-direction: column; gap: 8px">'
                f'<div style="display: flex; align-items: center; gap: 10px">{radio(sel)}<b style="font-size: 16px">{p["name"]}</b>{tag}<span style="flex: 1"></span>{price(p, big=20)}</div>'
                + (f'<span style="font-size: 11px; font-weight: 800; letter-spacing: .6px; color: {MUTE}; padding-left: 30px">{head}</span>' if head else '')
                + f'<div style="display: flex; flex-direction: column; gap: 5px; padding-left: 30px">{"".join(li(f, GREEN, INK, 12.5) for f in items)}</div></div>')
    return mob(h('Pick your plan', 24, False) + card('std', '') + card('fast', 'EVERYTHING IN STANDARD, PLUS') + card('pri', 'EVERYTHING IN FAST, PLUS'), FOOT())

# ---------- B3: speed is the headline ----------
def b3():
    def card(k):
        p = P[k]; dark = k == 'pri'; sel = k == 'fast'
        bg = DARK if dark else '#FFFFFF'
        ring = f'inset 0 0 0 2px {MINT}' if sel else ('none' if dark else f'inset 0 0 0 1px {LINE}')
        fg = '#FFFFFF' if dark else INK; mu = '#9FC3B4' if dark else MUTE
        num, unit = p['speed'].split(' ')
        feats = ''.join(li(f, MINT if dark else GREEN, '#E6EEEA' if dark else INK, 12.5) for f in p['feats'][1:4])
        return (f'<div style="border-radius: 18px; padding: 14px; background: {bg}; box-shadow: {ring}; color: {fg}; display: flex; gap: 14px; align-items: stretch">'
                f'<div style="width: 78px; flex: none; border-radius: 12px; background: {"rgba(61,220,151,.14)" if dark else ("#E9F6EF" if sel else "#F1F4F2")}; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 0">'
                f'{ic("zap" if dark else "clock", 15, MINT if dark else GREEN, 2.4)}<b style="font-size: 26px; letter-spacing: -1px; line-height: 1.1">{num}</b><span style="font-size: 11px; font-weight: 800; color: {mu}">{unit.upper()}</span></div>'
                f'<div style="flex: 1; display: flex; flex-direction: column; gap: 6px"><div style="display: flex; align-items: center; gap: 8px"><b style="font-size: 16px">{p["name"]}</b><span style="flex: 1"></span>{price(p, fg, mu, 19)}</div>'
                f'{feats}</div></div>')
    sub = f'<span style="font-size: 13px; font-weight: 600; color: {MUTE}; margin-top: -6px">How fast we file your claims after you join.</span>'
    return mob(h('How fast should we file?', 23, False) + sub + card('std') + card('fast') + card('pri'), FOOT())

# ---------- C1: radio rows + the picked plan's full list below ----------
def c1():
    def row(k):
        p = P[k]; sel = k == 'fast'
        ring = f'inset 0 0 0 2px {MINT}' if sel else f'inset 0 0 0 1px {LINE}'
        return (f'<div style="border-radius: 14px; padding: 12px 14px; background: #FFFFFF; box-shadow: {ring}; display: flex; align-items: center; gap: 12px">{radio(sel)}'
                f'<span style="flex: 1; display: flex; flex-direction: column; gap: 1px"><span style="display: flex; align-items: center; gap: 6px"><b style="font-size: 15.5px">{p["name"]}</b>{pill(p["tag"], MINT, DARK) if sel else ""}</span>'
                f'<span style="font-size: 12px; font-weight: 600; color: {MUTE}">Filed within {p["speed"]}</span></span>{price(p, big=19)}</div>')
    det = (f'<div style="border-radius: 14px; padding: 12px 14px; background: #E9F6EF; display: flex; flex-direction: column; gap: 6px">'
           f'<span style="font-size: 11px; font-weight: 800; letter-spacing: .6px; color: #17603F">FAST INCLUDES</span>' + ''.join(li(f, GREEN, INK, 12.5) for f in P['fast']['feats']) + '</div>')
    return mob(h('Pick your plan', 24, False) + row('std') + row('fast') + row('pri') + det, FOOT())

# ---------- C2: speed ladder (vertical track) ----------
def c2():
    def step(k, last=False):
        p = P[k]; sel = k == 'fast'
        dotc = GREEN if sel else ('#0E1512' if k == 'pri' else '#C9D3CD')
        return (f'<div style="display: flex; gap: 12px">'
                f'<div style="width: 20px; flex: none; display: flex; flex-direction: column; align-items: center"><span style="width: 16px; height: 16px; border-radius: 99px; background: {dotc}; margin-top: 16px; box-shadow: 0 0 0 4px {"rgba(61,220,151,.3)" if sel else "transparent"}"></span>'
                + ('' if last else f'<span style="flex: 1; width: 2px; background: {LINE}; margin-top: 4px"></span>') + '</div>'
                f'<div style="flex: 1; margin-bottom: 10px; border-radius: 14px; padding: 11px 13px; background: #FFFFFF; box-shadow: {"inset 0 0 0 2px " + MINT if sel else "inset 0 0 0 1px " + LINE}; display: flex; flex-direction: column; gap: 4px">'
                f'<div style="display: flex; align-items: center; gap: 6px"><b style="font-size: 15px">{p["name"]}</b>{pill(p["tag"], MINT, DARK) if sel else (pill(p["tag"], "#FFF1CC", "#7A5300") if k == "pri" else "")}<span style="flex: 1"></span>{price(p, big=18)}</div>'
                f'<span style="font-size: 13px; font-weight: 800; color: {GREEN if sel else INK}">Filed within {p["speed"]}</span>'
                f'<span style="font-size: 12px; font-weight: 600; color: {MUTE}; line-height: 1.4">{" · ".join(p["feats"][1:3] if k != "pri" else [p["feats"][1], "Refunds + subscriptions"])}</span></div></div>')
    return mob(h('How fast should we file?', 23, False) + f'<div style="display: flex; flex-direction: column">{step("std")}{step("fast")}{step("pri", True)}</div>', FOOT())

# ---------- C3: dense rows, price left, mini checks ----------
def c3():
    keys = [('Your 6 claims', ['3 of 6', 'All 6', 'All 6']), ('New claims', ['No', 'Reminders', 'Filed for you']), ('Refunds + subs', ['No', 'No', 'Yes'])]
    def row(i, k):
        p = P[k]; sel = k == 'fast'; dark = k == 'pri'
        bg = DARK if dark else '#FFFFFF'; fg = '#FFFFFF' if dark else INK; mu = '#9FC3B4' if dark else MUTE
        ring = f'inset 0 0 0 2px {MINT}' if sel else ('none' if dark else f'inset 0 0 0 1px {LINE}')
        mini = ''.join(f'<span style="display: flex; flex-direction: column; gap: 1px"><span style="font-size: 10px; font-weight: 700; color: {mu}">{n}</span><b style="font-size: 12px; color: {(mu if v == "No" else fg)}">{v}</b></span>' for n, vs in keys for v in [vs[i]])
        return (f'<div style="border-radius: 16px; padding: 12px 14px; background: {bg}; color: {fg}; box-shadow: {ring}; display: flex; flex-direction: column; gap: 10px">'
                f'<div style="display: flex; align-items: center; gap: 10px">{radio(sel, dark)}<b style="font-size: 16px">{p["name"]}</b><span style="flex: 1"></span>'
                f'<span style="font-size: 12px; font-weight: 800; padding: 4px 9px; border-radius: 99px; background: {"rgba(61,220,151,.16)" if dark else "#EEF3F0"}; color: {MINT if dark else INK}">{p["speed"]}</span>{price(p, fg, mu, 19)}</div>'
                f'<div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; padding-left: 30px">{mini}</div></div>')
    return mob(h('Pick your plan', 24, False) + row(0, 'std') + row(1, 'fast') + row(2, 'pri'), FOOT())

def board(name, title, items):
    cols = ''.join(f'<div style="display: flex; flex-direction: column; gap: 12px"><span style="font-size: 15px; font-weight: 800; color: #12805C; letter-spacing: 1px">{t}</span>'
                   f'<span style="font-size: 14px; font-weight: 600; color: #43504A; max-width: 400px; line-height: 1.45; min-height: 42px">{d}</span>{p}</div>' for t, d, p in items)
    page = ('<div data-board style="width: 1840px; height: 1080px; box-sizing: border-box; padding: 36px 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 22px">'
            f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #12805C">{title}</span>'
            '<span style="font-size: 16px; color: #43504A; font-weight: 600">All three plans on one phone screen, no tabs. Draft, not live. Standard free, Fast $15 a month, Priority $30 a month.</span></div>'
            f'<div style="display: flex; gap: 120px; justify-content: center">{cols}</div></div>\n</x-dc>\n')
    open(os.path.join(OUT, f'{name}.dc.html'), 'w').write(HEAD % title.title() + page + JS.replace('"width":1926,"height":980', '"width":1840,"height":1080'))

if __name__ == '__main__':
    board('OfferG2mB', 'OPEN CARDS · 3 ITERATIONS', [
        ('B1 · CLEAN CARDS', 'Fast first and ringed, Priority dark, Standard last. Four short features and a button on each card.', b1()),
        ('B2 · EVERYTHING IN, PLUS', 'Cheapest to fastest. Each card only lists what it adds, so the cards stay short. One sticky button.', b2()),
        ('B3 · SPEED FIRST', 'Each card leads with how fast we file (30 days, 3 days, 24 hours), then price and three features.', b3())])
    board('OfferG2mC', 'ROWS · 3 ITERATIONS', [
        ('C1 · ROWS + WHAT YOU GET', 'Three radio rows (name, filing time, price). The picked plan\'s full list shows under them.', c1()),
        ('C2 · SPEED LADDER', 'A vertical track from slowest to fastest; each stop shows filing time, price and two features.', c2()),
        ('C3 · ROWS WITH FACTS', 'Each row shows speed and price, then three side by side facts: your claims, new claims, refunds.', c3())])
    print('ok')
