# Settlement card logo concept (Nov 15). One format for every brand: a brand-colored top with a clean SVG mark
# from Simple Icons (CC0, brand hex included), sized by its real bounds so every mark looks the same size.
# Rows: today's logo files, option A (full brand color, white mark), option B (light tint, mark in brand color).
# Board: LogoCards. Marks and bounds come from brand_icons.json (simple-icons 16.38.0, bounds measured in Chrome).
import json, os, base64, math, datetime, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from how4 import HEAD, JS, OUT
HERE = os.path.dirname(os.path.abspath(__file__)); CC = os.path.dirname(HERE)
ICONS = json.load(open(os.path.join(HERE, 'brand_icons.json')))
SETS = {x['id']: x for x in json.load(open(os.path.join(HERE, 'sets.json')))}
ORDER = ['apple', 'google', 'youtube', 'netflix', 'googleplay', 'ubereats', 'starbucks', 'ups', 'visa', 'toyota']
# Where Simple Icons only has a near-black or grey hex, use the brand's own main color (and mark color) instead.
OVR = {'apple': ('#1D1D1F', None), 'googleplay': ('#01875F', None), 'ups': ('#351C15', '#FFB500')}
TODAY = datetime.date(2026, 11, 15)

def rgb(h): h = h.lstrip('#'); return [int(h[i:i + 2], 16) for i in (0, 2, 4)]
def hexs(c): return '#' + ''.join(f'{max(0, min(255, round(v))):02X}' for v in c)
def mix(a, b, t): A, B = rgb(a), rgb(b); return hexs([A[i] + (B[i] - A[i]) * t for i in range(3)])
def lum(h):
    c = [v / 255 for v in rgb(h)]; c = [v / 12.92 if v <= .03928 else ((v + .055) / 1.055) ** 2.4 for v in c]
    return .2126 * c[0] + .7152 * c[1] + .0722 * c[2]

def mark(k, fill, area=3400, maxw=150, maxh=66, extra=''):
    x, y, w, h = ICONS[k]['bbox']; a = w / h
    H = math.sqrt(area / a); W = a * H
    sc = min(1, maxw / W, maxh / H); W, H = W * sc, H * sc
    return (f'<svg role="img" aria-label="{ICONS[k]["title"]} logo" width="{W:.0f}" height="{H:.0f}" viewBox="{x} {y} {w} {h}" style="display: block; flex: none{extra}">'
            f'<path fill="{fill}" d="{ICONS[k]["path"]}"></path></svg>')
def ghost(k, fill, op):
    return (f'<svg aria-hidden="true" width="210" height="210" viewBox="0 0 24 24" style="position: absolute; right: -46px; bottom: -64px; transform: rotate(-14deg); opacity: {op}">'
            f'<path fill="{fill}" d="{ICONS[k]["path"]}"></path></svg>')

def top_a(k):
    base, fgo = OVR.get(k, ('#' + ICONS[k]['hex'], None))
    fg = fgo or ('#FFFFFF' if lum(base) < .45 else '#0A0F0D')
    bg = f'radial-gradient(130% 100% at 15% 0%, {mix(base, "#FFFFFF", .18)} 0%, {base} 52%, {mix(base, "#000000", .28)} 100%)'
    return bg, ghost(k, fg, .1) + f'<span style="position: relative; filter: drop-shadow(0 6px 14px rgba(0,0,0,.18))">{mark(k, fg)}</span>'
def top_b(k):
    base, fgo = OVR.get(k, ('#' + ICONS[k]['hex'], None))
    fg = base if k != 'ups' else '#351C15'
    tint = mix(base, '#FFFFFF', .9)
    bg = f'radial-gradient(130% 100% at 15% 0%, #FFFFFF 0%, {tint} 60%, {mix(base, "#FFFFFF", .82)} 100%)'
    return bg, ghost(k, base, .07) + f'<span style="position: relative">{mark(k, fg)}</span>'
def find_file(k):
    for d in ('logos', 'logos2', 'logos3'):
        for ext in ('svg', 'png', 'webp', 'jpg'):
            p = os.path.join(CC, d, f'{k}.{ext}')
            if os.path.exists(p): return p
def top_now(k):
    p = find_file(k)
    if not p: return '#F3F6F4', '<span style="font-size: 13px; font-weight: 800; color: #8A968F">No logo</span>'
    mime = {'svg': 'image/svg+xml', 'png': 'image/png', 'webp': 'image/webp', 'jpg': 'image/jpeg'}[p.rsplit('.', 1)[1]]
    src = f'data:{mime};base64,' + base64.b64encode(open(p, 'rb').read()).decode()
    return '#FFFFFF', f'<img src="{src}" alt="{SETS[k]["co"]} logo" style="max-height: 76px; max-width: 62%; object-fit: contain; display: block">'

def card(k, top):
    bg, inner = top(k); s = SETS[k]
    head = f'${s["amt"]:,}' if s.get('amt') else f'Up to ${s["max"]:,}'
    if s.get('dl'):
        dd = (datetime.date.fromisoformat(s['dl']) - TODAY).days; days, urgent = (f'{dd} days left', dd <= 30)
    else: days, urgent = 'Open now', False
    proof = s.get('proof') == 'No proof'
    return (f'<div style="width: 268px; flex: none; background: #FFFFFF; border-radius: 24px; overflow: hidden; display: flex; flex-direction: column; box-shadow: 0 1px 0 #E3EAE6, 0 10px 30px rgba(10,15,13,.07); border: 1px solid #E3EAE6">'
            f'<div style="background: {bg}; position: relative; height: 152px; display: flex; align-items: center; justify-content: center; overflow: hidden">{inner}</div>'
            '<div style="padding: 16px 18px 18px; display: flex; flex-direction: column; gap: 10px; border-top: 1px solid #EEF2F0">'
            f'<div style="display: flex; flex-direction: column; gap: 2px"><div style="font-size: 15px; font-weight: 700; color: #43504A; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{s["co"]}</div><div style="font-size: 24px; font-weight: 800; letter-spacing: -0.6px; color: #0A0F0D">{head}</div></div>'
            f'<div style="display: flex; justify-content: space-between; align-items: center; gap: 8px; min-height: 23px"><span style="font-size: 12px; font-weight: {800 if urgent else 700}; color: {"#B8333A" if urgent else "#5B6862"}; white-space: nowrap">{days}</span>'
            + ('<span style="font-size: 11px; font-weight: 800; background: #E9F6EF; color: #17603F; padding: 4px 8px; border-radius: 8px; white-space: nowrap">No proof needed</span>' if proof else '') + '</div>'
            '<span style="display: flex; align-items: center; justify-content: center; height: 46px; border-radius: 14px; background: #12805C; color: #FFFFFF; font-size: 15px; font-weight: 800">Claim now</span></div></div>')
def row(title, note, top):
    return (f'<div style="display: flex; flex-direction: column; gap: 14px"><div style="display: flex; align-items: baseline; gap: 12px"><b style="font-size: 22px; letter-spacing: -0.4px">{title}</b><span style="font-size: 14px; color: #5B6862; font-weight: 600">{note}</span></div>'
            '<div style="display: flex; gap: 14px">' + ''.join(card(k, top) for k in ORDER) + '</div></div>')
if __name__ == '__main__':
    body = (row('Today', 'The logo files we use now: mixed sizes, some blurry PNGs, white tops.', top_now)
            + row('Option A · Brand color', 'Same gradient recipe for every brand from its own color, white or dark mark, faint oversized mark as texture.', top_a)
            + row('Option B · Light tint', 'Same recipe on a pale tint of the brand color, mark in the brand color.', top_b))
    page = ('<div data-board style="width: 2900px; box-sizing: border-box; padding: 32px; background: #F3F6F4; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 34px">'
            '<div style="display: flex; flex-direction: column; gap: 6px"><div style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #43504A">SETTLEMENT CARD LOGOS · 10 BRANDS</div>'
            '<span style="font-size: 15px; color: #43504A; max-width: 1200px; line-height: 1.5">Marks are vector SVGs from Simple Icons (free to use, CC0), each with the brand color it lists. Every mark is sized by its real shape, so wide wordmarks and square icons look equally big. Nothing is loaded from other sites.</span></div>'
            + body + '</div>\n</x-dc>\n')
    open(os.path.join(OUT, 'LogoCards.dc.html'), 'w').write(HEAD % 'Settlement card logos' + page + JS)
    print('ok')
