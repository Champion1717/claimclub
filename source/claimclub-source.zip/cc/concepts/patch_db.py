s=open('make.py').read()
def rep(o,n):
    global s
    assert o in s,o[:100]; s=s.replace(o,n,1)
rep("    this.loadLive();\n","    this.state.authState = 'off'; this.state.loginEmail = ''; this.state.code = ''; this.state.codeSent = false; this.state.authErr = ''; this.state.authBusy = false; this.state.renewsAt = '';\n    this.loadLive();\n")
rep("  componentDidUpdate() {","""  componentDidMount() {
    if (typeof window === 'undefined' || !window.supabase || typeof fetch === 'undefined') return;
    this.setState({ authState: 'checking' });
    fetch('/api/config').then(r => r.json()).then(cfg => {
      if (!cfg.supabaseUrl || !cfg.supabaseAnonKey) { this.setState({ authState: 'off' }); return; }
      this._cfg = cfg;
      this._sb = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, { auth: { persistSession: true, autoRefreshToken: true } });
      return this._sb.auth.getSession().then(({ data }) => {
        if (data && data.session) return this.afterLogin(data.session);
        let em = ''; try { em = ((JSON.parse(localStorage.getItem('claimclub_session') || 'null') || {}).p || {}).email || ''; } catch (e) {}
        this.setState({ authState: 'signin', loginEmail: em });
      });
    }).catch(() => this.setState({ authState: 'off' }));
  }
  sendCode() {
    const email = (this.state.loginEmail || '').trim().toLowerCase();
    if (!/^[^@ ]+@[^@ ]+[.][^@ ]+$/.test(email)) { this.setState({ authErr: 'Enter the email you used to sign up' }); return; }
    this.setState({ authBusy: true, authErr: '' });
    this._sb.auth.signInWithOtp({ email, options: { shouldCreateUser: true } }).then(({ error }) => {
      this.setState({ authBusy: false, codeSent: !error, code: '', authErr: error ? (/rate/i.test(error.message) ? 'Too many codes sent. Wait a minute and try again.' : error.message) : '' });
    });
  }
  verifyCode() {
    const token = (this.state.code || '').replace(/[^0-9]/g, '');
    if (token.length !== 6) { this.setState({ authErr: 'Enter the 6-digit code' }); return; }
    this.setState({ authBusy: true, authErr: '' });
    this._sb.auth.verifyOtp({ email: this.state.loginEmail.trim().toLowerCase(), token, type: 'email' }).then(({ data, error }) => {
      if (error || !data.session) { this.setState({ authBusy: false, authErr: 'That code did not work. Check it or send a new one.' }); return; }
      this.afterLogin(data.session);
    });
  }
  api(action, extra) {
    return fetch('/api/membership', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + this._token }, body: JSON.stringify(Object.assign({ action }, extra || {})) }).then(r => r.json()).catch(() => ({}));
  }
  async afterLogin(session) {
    this._token = session.access_token;
    this._sb.auth.onAuthStateChange((ev, ses) => { if (ses) this._token = ses.access_token; });
    const sb = this._sb, uid = session.user.id, email = session.user.email;
    let local = null; try { local = JSON.parse(localStorage.getItem('claimclub_session') || 'null'); } catch (e) {}
    let [{ data: prof }, { data: rows }] = await Promise.all([sb.from('profiles').select('*').eq('id', uid).maybeSingle(), sb.from('claims').select('*').eq('user_id', uid)]);
    rows = rows || [];
    const link = await this.api('link');
    // First sign-in on this device after the claim flow: copy what they entered into their account.
    if (local && local.ids && local.ids.length && (!local.p || !local.p.email || local.p.email.toLowerCase() === email.toLowerCase())) {
      const have = new Set(rows.map(r => r.settlement_id)), signed = local.signed || [];
      const add = local.ids.filter(id => !have.has(id)).map(id => ({ user_id: uid, settlement_id: id, status: signed.indexOf(id) >= 0 ? 'filed' : 'ready', source: 'flow', filed_at: signed.indexOf(id) >= 0 ? new Date().toISOString() : null }));
      if (add.length) { const { data: ins } = await sb.from('claims').insert(add).select(); rows = rows.concat(ins || []); }
      const P = local.p || {}, addr = [P.street, P.city, [P.st, P.zip].filter(Boolean).join(' ')].filter(Boolean).join(', ');
      const patch = {}; const put = (k, v) => { if (v && !(prof && prof[k])) patch[k] = v; };
      put('name', P.name); put('phone', P.phone); put('dob', P.dob); put('address', addr); put('state', P.st);
      if (local.bank && !(prof && prof.bank_connected)) patch.bank_connected = true;
      if (signed.length && !(prof && prof.authorization_signed_at)) patch.authorization_signed_at = new Date().toISOString();
      if (Object.keys(patch).length) { const { data: p2 } = await sb.from('profiles').update(patch).eq('id', uid).select().maybeSingle(); if (p2) prof = p2; }
      if ((!link.membership) && this._cfg.testMode && local.paid) await this.api('test', { kind: local.paid, plan: local.plan });
    }
    const { data: mem } = await sb.from('memberships').select('*').eq('user_id', uid).maybeSingle();
    this.applyAccount(prof || { email }, rows, mem);
  }
  applyAccount(P, rows, mem) {
    const D = this.sets(), st = {}, mine = [];
    rows.forEach(r => { const d = D.find(x => x.id === r.settlement_id); if (!d) return; st[r.settlement_id] = r.status === 'removed' ? 'gone' : r.status; mine.push(this.toClaim(d)); });
    this._live = true; this._db = true; this._mine = mine; this._rows = {}; rows.forEach(r => { this._rows[r.settlement_id] = r.status; });
    const fmt = (iso) => iso ? new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '';
    const next = { authState: 'ready', st, added: [], ans: {},
      prof: { name: P.name || '', email: P.email || '', phone: P.phone || '', dob: P.dob || '', addr: P.address || '', past: P.past_addresses || [] },
      acct: { email: 1, auth: P.authorization_signed_at ? 1 : 0, name: P.name && P.address ? 1 : 0, dob: P.dob && P.phone ? 1 : 0, bank: P.bank_connected ? 1 : 0, past: (P.past_addresses && P.past_addresses.length) || P.lived_here_10y ? 1 : 0 },
      payDef: P.pay_default || 'Check', myState: P.state || '', theme: P.theme || this.state.theme, scale: P.scale || this.state.scale,
      plan: mem && mem.kind === 'member' ? mem.plan : '', cancelled: !!(mem && mem.status === 'cancelling'), mmPending: (mem && mem.pending_plan) || '',
      joinedOn: fmt(mem && mem.started_at) || fmt(P.created_at), renewsAt: fmt(mem && mem.renews_at), hasMem: !!mem };
    this._synced = this.snapshot(Object.assign({}, this.state, next));
    this.setState(next);
  }
  snapshot(s) {
    return JSON.stringify({ p: s.prof, a: s.acct, d: s.payDef, t: s.theme, z: s.scale, st: s.st });
  }
  syncNow() {
    const s = this.state, sb = this._sb; if (!sb || !this._db) return;
    const snap = this.snapshot(s); if (snap === this._synced) return; this._synced = snap;
    sb.auth.getUser().then(({ data }) => {
      const uid = data && data.user && data.user.id; if (!uid) return;
      const P = s.prof;
      sb.from('profiles').update({ name: P.name, email: P.email, phone: P.phone, dob: P.dob, address: P.addr, past_addresses: P.past || [], lived_here_10y: !!s.acct.past && !(P.past || []).length, bank_connected: !!s.acct.bank, pay_default: s.payDef, theme: s.theme, scale: s.scale }).eq('id', uid).then(() => {});
      const ups = [];
      this.claims().forEach(c => { const v = s.st[c.id]; if (!v) return; const status = v === 'gone' ? 'removed' : v; if (this._rows[c.id] === status) return;
        ups.push({ user_id: uid, settlement_id: c.id, status, source: this._mine.some(m => m.id === c.id) ? 'flow' : 'added', filed_at: status === 'filed' ? new Date().toISOString() : null }); this._rows[c.id] = status; });
      if (ups.length) sb.from('claims').upsert(ups, { onConflict: 'user_id,settlement_id' }).then(() => {});
    });
  }
  signOut() { if (this._sb) this._sb.auth.signOut().then(() => { try { localStorage.removeItem('claimclub_app'); } catch (e) {} location.reload(); }); }
  componentDidUpdate() {
    if (this._db) { clearTimeout(this._syncT); this._syncT = setTimeout(() => this.syncNow(), 700); }""")
# don't let the device-only save overwrite a signed-in account
rep("    if (!this._live) return;\n    try { const ss = JSON.parse(localStorage.getItem('claimclub_session') || 'null'); if (!ss) return;","    if (!this._live || this._db) return;\n    try { const ss = JSON.parse(localStorage.getItem('claimclub_session') || 'null'); if (!ss) return;")
# membership actions go through the server when signed in
rep("mmSwitch: () => this.setState({ mmPending: pick,","mmSwitch: () => { if (this._db) this.api('switch', { plan: pick }); this.setState({ mmPending: pick,")
rep("logo: this.logo('cc', 'C') } }),\n      mmBill:","logo: this.logo('cc', 'C') } }); },\n      mmBill:")
rep("mmConfirm: () => this.setState({ cancelled: true, mmPending: '', mm: 'done' }), mmResume: () => this.setState({","mmConfirm: () => { if (this._db) this.api('cancel'); this.setState({ cancelled: true, mmPending: '', mm: 'done' }); }, mmResume: () => { if (this._db) this.api('resume'); this.setState({")
rep("sub: 'It renews ' + renew + '.', logo: this.logo('cc', 'C') } }),","sub: 'It renews ' + renew + '.', logo: this.logo('cc', 'C') } }); },")
rep("const d = new Date(); d.setMonth(d.getMonth() + ({ '1m': 1, '3m': 3, '6m': 6 }[s.plan] || 1)); const renew = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });",
    "const d = new Date(); d.setMonth(d.getMonth() + ({ '1m': 1, '3m': 3, '6m': 6 }[s.plan] || 1)); const renew = s.renewsAt || d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });")
# auth values
rep("      firstName: ((s.prof.name","""      needAuth: s.authState === 'signin' || s.authState === 'checking', authChecking: s.authState === 'checking', authForm: s.authState === 'signin',
      emailStep: !s.codeSent, codeStep: !!s.codeSent, loginEmail: s.loginEmail, onLoginEmail: (e) => this.setState({ loginEmail: e.target.value, authErr: '' }),
      code: s.code, onCode: (e) => { const v = e.target.value.replace(/[^0-9]/g, '').slice(0, 6); this.setState({ code: v, authErr: '' }); if (v.length === 6) setTimeout(() => this.verifyCode(), 60); },
      sendCode: () => this.sendCode(), verify: () => this.verifyCode(), otherEmail: () => this.setState({ codeSent: false, code: '', authErr: '' }),
      authErr: s.authErr, hasAuthErr: !!s.authErr, authBusy: s.authBusy, authIdle: !s.authBusy, signedIn: !!this._db, signOut: () => this.signOut(), acctEmail: s.prof.email,
      firstName: ((s.prof.name""")
# sign-in overlay markup
SIGN='''  <sc-if value="{{ needAuth }}" hint-placeholder-val="{{ false }}"><div class="authWrap" style="position: absolute; inset: 0; z-index: 70; background: #F3F6F4; display: flex; align-items: center; justify-content: center; padding: 20px; box-sizing: border-box">
    <sc-if value="{{ authChecking }}" hint-placeholder-val="{{ false }}"><div style="width: 40px; height: 40px; border-radius: 50%; border: 3px solid #DDE5E0; border-top-color: #12805C; animation: spin .8s linear infinite"></div></sc-if>
    <sc-if value="{{ authForm }}" hint-placeholder-val="{{ true }}"><div class="cardin" style="width: 400px; max-width: 100%; background: #FFFFFF; border-radius: 24px; box-shadow: 0 0 0 1px #E3EAE6, 0 20px 60px rgba(10,15,13,.08); padding: 28px; display: flex; flex-direction: column; gap: 16px">
      <div style="display: flex; align-items: center; gap: 8px"><svg width="28" height="28" viewBox="0 0 100 100" aria-hidden="true">LOGO</svg><span style="font-size: 19px; font-weight: 800; letter-spacing: -0.4px">claim<span style="font-weight: 500">club</span><span style="font-size: .72em; font-weight: 600; color: #12805C; margin-left: -0.06em">.io</span></span></div>
      <sc-if value="{{ emailStep }}" hint-placeholder-val="{{ true }}">
        <div style="display: flex; flex-direction: column; gap: 4px"><h1 style="margin: 0; font-size: 22px; letter-spacing: -0.5px">Sign in to your dashboard</h1><span style="font-size: 14px; color: #5B6862">We'll email you a 6-digit code. No password needed.</span></div>
        <input type="email" autocomplete="email" value="{{ loginEmail }}" onChange="{{ onLoginEmail }}" placeholder="you@example.com" aria-label="Email" style="height: 48px; border-radius: 14px; border: 1.5px solid #DDE5E0; padding: 0 16px; font-size: 16px; font-family: inherit; font-weight: 600; color: #0A0F0D; background: #FFFFFF">
        <button onClick="{{ sendCode }}" style="min-height: 48px; border-radius: 99px; background: #0A0F0D; color: #FFFFFF; font-size: 15px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px"><sc-if value="{{ authBusy }}" hint-placeholder-val="{{ false }}"><span class="spin"></span></sc-if>Email me a code</button>
      </sc-if>
      <sc-if value="{{ codeStep }}" hint-placeholder-val="{{ false }}">
        <div style="display: flex; flex-direction: column; gap: 4px"><h1 style="margin: 0; font-size: 22px; letter-spacing: -0.5px">Check your email</h1><span style="font-size: 14px; color: #5B6862">Enter the 6-digit code we sent to <b style="color: #0A0F0D">{{ loginEmail }}</b>.</span></div>
        <input type="text" inputmode="numeric" autocomplete="one-time-code" maxlength="6" value="{{ code }}" onChange="{{ onCode }}" placeholder="123456" aria-label="6-digit code" style="height: 56px; border-radius: 14px; border: 1.5px solid #DDE5E0; padding: 0 16px; font-size: 26px; letter-spacing: 10px; text-align: center; font-family: inherit; font-weight: 800; color: #0A0F0D; background: #FFFFFF">
        <button onClick="{{ verify }}" style="min-height: 48px; border-radius: 99px; background: #3DDC97; color: #0A0F0D; font-size: 15px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px"><sc-if value="{{ authBusy }}" hint-placeholder-val="{{ false }}"><span class="spin" style="border-color: rgba(10,15,13,.25); border-top-color: #0A0F0D"></span></sc-if>Sign in</button>
        <div style="display: flex; justify-content: space-between; font-size: 13px; font-weight: 800"><button onClick="{{ otherEmail }}" style="background: transparent; padding: 0; color: #5B6862">Use a different email</button><button onClick="{{ sendCode }}" style="background: transparent; padding: 0; color: #12805C">Send a new code</button></div>
      </sc-if>
      <sc-if value="{{ hasAuthErr }}" hint-placeholder-val="{{ false }}"><span role="alert" style="font-size: 13px; font-weight: 700; color: #B8333A">{{ authErr }}</span></sc-if>
      <span style="font-size: 12px; color: #8A968F">By signing in you agree to our <a href="https://claimclub.io/legal/terms.html" target="_blank" rel="noopener" style="color: #5B6862">Terms</a> and <a href="https://claimclub.io/legal/privacy.html" target="_blank" rel="noopener" style="color: #5B6862">Privacy Policy</a>.</span>
    </div></sc-if>
  </div></sc-if>
'''
LOGO=open('/home/claude/cc/src/logo.txt').read().strip().replace('__C__','#0A0F0D').replace('#FFB224','#12805C')
rep("MMSHEET=","AUTHSCREEN="+repr(SIGN.replace('LOGO',LOGO))+"\nMMSHEET=")
rep("+SHEET+MMSHEET+NOTE+'</div>\\n'+TAIL","+SHEET+MMSHEET+NOTE+AUTHSCREEN+'</div>\\n'+TAIL")
# sign-out row in settings (only when signed in)
rep('<sc-if value="{{ isMember }}" hint-placeholder-val="{{ true }}"><button onClick="{{ manage }}"','<sc-if value="{{ isMember }}" hint-placeholder-val="{{ true }}"><button onClick="{{ manage }}"')
i=s.index('<a href="https://claimclub.io/about.html"'); j=s.index('</a>',i)+4
s=s[:j]+'<sc-if value="{{ signedIn }}" hint-placeholder-val="{{ false }}"><div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 0; border-top: 1px solid #EEF2F0"><span style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 14px; font-weight: 800">Signed in</span><span style="font-size: 12px; color: #5B6862">{{ acctEmail }}</span></span><button onClick="{{ signOut }}" style="min-height: 34px; padding: 0 14px; border-radius: 99px; background: #EEF2F0; color: #0A0F0D; font-size: 13px; font-weight: 800">Sign out</button></div></sc-if>'+s[j:]
s=s.replace('.dk .scroll{scrollbar-color:#34413B transparent}','.dk .scroll{scrollbar-color:#34413B transparent}\\n.dk .authWrap{background:#0D1311 !important}',1)
open('make.py','w').write(s); print('ok')
