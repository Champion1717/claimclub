import re
s=open('make.py').read()
def rep(o,n):
    global s
    assert o in s,o[:90]; s=s.replace(o,n,1)
# ---- theme option values: clear icon tiles ----
i=s.index("      themes: [['light'"); j=s.index("      zoomSt:",i)
s=s[:i]+"""      themes: [['light', 'Light', 'background-color:#F6F8F7;color:#E39B12;box-shadow:inset 0 0 0 1px #DDE5E0'], ['dark', 'Dark', 'background-color:#0D1311;color:#E8F0EC;box-shadow:inset 0 0 0 1px #26302C'], ['system', 'System', 'background-image:linear-gradient(90deg,#F6F8F7 50%,#0D1311 50%);color:#12805C;box-shadow:inset 0 0 0 1px #9AA8A1']].map(([k, t, tile]) => ({ t, on: s.theme === k, tap: () => this.setState({ theme: k }), isLight: k === 'light', isDark: k === 'dark', isSys: k === 'system',
        st: 'flex:1;display:flex;flex-direction:column;align-items:center;gap:8px;padding:10px;border-radius:14px;font-weight:800;font-size:13px;' + (s.theme === k ? 'background:#EAF2EE;color:#0F3B2E;box-shadow:inset 0 0 0 2px #12805C' : 'background:#FFFFFF;color:#43504A;box-shadow:inset 0 0 0 1.5px #DDE5E0'),
        tile: 'width:100%;height:56px;border-radius:10px;display:flex;align-items:center;justify-content:center;' + tile })),
"""+s[j:]
SUN='<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2 M12 20v2 M4.93 4.93l1.41 1.41 M17.66 17.66l1.41 1.41 M2 12h2 M20 12h2 M6.34 17.66l-1.41 1.41 M19.07 4.93l-1.41 1.41"></path></svg>'
MOON='<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"></path></svg>'
MON='<span style="display: flex; align-items: center; justify-content: center; width: 34px; height: 34px; border-radius: 9px; background-color: #FFFFFF; color: #12805C; box-shadow: 0 1px 3px rgba(0,0,0,.25)"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="20" height="14" x="2" y="3" rx="2"></rect><path d="M8 21h8 M12 17v4"></path></svg></span>'
o='<button onClick="{{ t.tap }}" aria-pressed="{{ t.on }}" style="{{ t.st }}"><span style="{{ t.pv }}"><span style="{{ t.pv1 }}"></span><span style="{{ t.pv2 }}"></span></span>{{ t.t }}</button>'
rep(o,'<button onClick="{{ t.tap }}" aria-pressed="{{ t.on }}" style="{{ t.st }}"><span style="{{ t.tile }}"><sc-if value="{{ t.isLight }}" hint-placeholder-val="{{ true }}">'+SUN+'</sc-if><sc-if value="{{ t.isDark }}" hint-placeholder-val="{{ false }}">'+MOON+'</sc-if><sc-if value="{{ t.isSys }}" hint-placeholder-val="{{ false }}">'+MON+'</sc-if></span>{{ t.t }}</button>')
# ---- replace attribute-hack dark css with variable theme ----
i=s.index("DARK_CSS='"); j=s.index("'\n",i)
BG={'FFFFFF':'#151D1A','F3F6F4':'#0D1311','EEF2F0':'#212B27','EEF2F8':'#17202B','DCE4F3':'#26324A','E9F6EF':'#133122','EAF2EE':'#1C2C25','E3EAE6':'#26302C','E1E6F0':'#262F40','DDE5E0':'#2A3430','FFF4DB':'#3A2E12','E8EEFB':'#1B2640','FDECEC':'#3A1A1D','E6ECE8':'#1A2320','0F3B2E':'#0F2A21','0A0F0E':'#3DDC97','0A0F0C':'#1D2723','D9F5E7':'#1D4A36'}
FG={'0A0F0D':'#E8F0EC','5B6862':'#9AA8A1','43504A':'#B3C0B9','8A968F':'#7F8C86','22324A':'#D0DBEF','5B6A85':'#95A5C4','8A93A6':'#7A8499','12805C':'#4FD69C','0F3B2E':'#7FD9AA','6B4600':'#F2C46B','8A5A00':'#F0B850','2C4FA8':'#9DB5F2','17603F':'#7FD9AA','B8333A':'#FF9AA0','FFFFFE':'#0A0F0D'}
LN={'E3EAE6':'#26302C','EEF2F0':'#222B27','DDE5E0':'#2E3A35','C9D3CD':'#3C4944','DCE2EE':'#26302C','E7EBF3':'#232B38'}
vars_=';'.join([f'--bg-{k}:{v}' for k,v in BG.items()]+[f'--fg-{k}:{v}' for k,v in FG.items()]+[f'--ln-{k}:{v}' for k,v in LN.items()])
DK=('.dk{'+vars_+';color-scheme:dark}'
 '\\n.dk svg [fill="#0A0F0D"]{fill:#E8F0EC}'
 '\\n.dk img[src*="7fd6ec4499df609a"],.dk img[src*="7f4390cee228878d"],.dk img[src*="17d130cb2fd653ad"],.dk img[src*="121d9429923e05b9"]{filter:brightness(0) invert(1);background:transparent !important;box-shadow:none !important}'
 '\\n.dk img[src*="9e823dce7e60dc8d"]{filter:invert(1) hue-rotate(180deg);background:transparent !important;box-shadow:none !important}'
 '\\n.dk img{box-shadow:none !important}'
 '\\n.dk .note{box-shadow:0 0 0 1px #2E3A35,0 24px 60px rgba(0,0,0,.55) !important}'
 '\\n.dk .shWrap{background:rgba(0,0,0,.62) !important}'
 '\\n.dk .shCard{box-shadow:0 0 0 1px #26302C,0 30px 80px rgba(0,0,0,.6) !important}'
 '\\n.dk input::placeholder{color:#6F7C76}'
 '\\n.dk .scroll{scrollbar-color:#34413B transparent}'
 '\\n.dk section[aria-label="Ready to file"],.dk section[aria-label="Find more claims"]{box-shadow:inset 0 0 0 1px #1E4536}')
s=s[:i]+"DARK_CSS='"+DK+s[j:]
# ---- theming pass applied to the generated files ----
rep("for name,src in [('DashA',A),('DashAM',AM)]:","""def themed(src):
    src=src.replace('border-radius: 20px; background: #0A0F0D; color: #FFFFFF;','border-radius: 20px; background: #0A0F0C; color: #FFFFFF;')
    for a,b in [('background: #0A0F0D; color: #FFFFFF','background: #0A0F0E; color: #FFFFFE'),("background:#0A0F0D;color:#FFFFFF","background:#0A0F0E;color:#FFFFFE"),('background: #3DDC97; color: #0A0F0D','background: #3DDC97; color: #0A0F0B'),("background:#3DDC97;color:#0A0F0D","background:#3DDC97;color:#0A0F0B")]:
        src=src.replace(a,b)
    src=re.sub(r'(?<![-\\w])(background:\\s*)#([0-9A-Fa-f]{6})\\b',lambda m:m.group(1)+'var(--bg-'+m.group(2).upper()+',#'+m.group(2)+')',src)
    src=re.sub(r'(?<![-\\w])(color:\\s*)#([0-9A-Fa-f]{6})\\b',lambda m:m.group(1)+'var(--fg-'+m.group(2).upper()+',#'+m.group(2)+')',src)
    def ln(m):
        return m.group(1)+re.sub(r'#([0-9A-Fa-f]{6})\\b',lambda h:'var(--ln-'+h.group(1).upper()+',#'+h.group(1)+')',m.group(2))
    src=re.sub(r'((?:box-shadow|border(?:-top|-bottom|-left|-right)?)\\s*:)([^;"\\'}]*)',ln,src)
    return src
A=themed(A); AM=themed(AM)
for name,src in [('DashA',A),('DashAM',AM)]:""")
open('make.py','w').write(s); print('ok')
