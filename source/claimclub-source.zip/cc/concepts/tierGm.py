# Phone iterations of the chosen Standard / Fast / Priority page (OfferG2m, comparison table, monthly), Nov 21 2026, design only.
# Henry: on phones all 3 plans must be visible at once, no tabs to tap. Board OfferG2mPhones: three phones side by side.
#   A  mini table: 3 plan columns with every feature row, Fast column picked, one sticky button
#   B  three stacked cards, all open, each with its own button
#   C  three compact rows with the 3 key differences each, Fast picked, one sticky button
import os
import tierE as E
from tierE import HEAD, JS, OUT, h, mob, mint_btn, ic, chip, INK, MUTE, LINE, MINT, GREEN, DARK
from tierG import ROWS, tiers, NOTE

T = tiers('m')
COL = {'basic': '#FFFFFF', 'plus': '#F2FBF6', 'pri': '#16201C'}
SHORT = {'Filing time': 'Filed in', 'Settlements you can claim': 'Settlements', 'Your 6 matched claims': 'Your 6 claims', 'New claims': 'New claims',
         'First look at new claims': 'First look', 'Claim refunds + Subscription Manager': 'Refunds + subs', 'Expected payout': 'Payout'}
VSHORT = {'Within 30 days': '30 days', 'Within 3 days': '3 days', 'Within 24 hours': '24 hours', 'Auto-filed only': 'Auto-filed', 'All 173 nationwide': '173', 'All 270, incl. local': '270 + local',
          '3 of 6 filed': '3 of 6', 'All 6 filed': 'All 6', 'Reminders when they open': 'Reminders', 'Filed for you automatically': 'Auto-filed', 'The day we find them': 'Day 1', '6 to 12 months': '6-12 mo'}
FOOT = lambda: (mint_btn(f'{ic("lock", 16, DARK, 2.4)}Start Fast · $15 today', 52) + f'<span style="font-size: 11.5px; font-weight: 600; color: {MUTE}; text-align: center">$15 today, renews every month. Cancel anytime.</span>')

def a():
    def cell(v, k, first=False):
        dark = k == 'pri'
        if v is True: inner = ic('check', 15, MINT if dark else GREEN, 3)
        elif v is False: inner = ic('x', 12, '#5E6E67' if dark else '#B5BFBA', 2.6)
        else: inner = f'<span style="font-size: 11.5px; font-weight: 800; line-height: 1.2">{VSHORT.get(v, v)}</span>'
        sel = k == 'plus'
        return (f'<div style="padding: 7px 3px; display: flex; align-items: center; justify-content: center; text-align: center; background: {COL[k]}; color: {"#FFFFFF" if dark else INK};'
                + (f' box-shadow: inset 2px 0 0 {MINT}, inset -2px 0 0 {MINT}' if sel else '') + f'">{inner}</div>')
    hd = '<div></div>' + ''.join(
        f'<div style="padding: 10px 3px 8px; display: flex; flex-direction: column; align-items: center; gap: 2px; border-radius: 14px 14px 0 0; background: {COL[t["k"]]}; color: {"#FFFFFF" if t["k"] == "pri" else INK};'
        + (f' box-shadow: inset 2px 2px 0 {MINT}, inset -2px 0 0 {MINT}' if t['k'] == 'plus' else '') + '">'
        + (f'<span style="font-size: 8.5px; font-weight: 900; letter-spacing: .6px; padding: 2px 6px; border-radius: 99px; background: {MINT}; color: {DARK}">POPULAR</span>' if t['k'] == 'plus' else '<span style="height: 14px"></span>')
        + f'<b style="font-size: 13px">{t["name"]}</b><b style="font-size: 18px; letter-spacing: -.6px">{t["price"]}</b><span style="font-size: 10.5px; font-weight: 700; color: {"#9FC3B4" if t["k"] == "pri" else MUTE}">{"/month" if t["per"] else "forever"}</span></div>' for t in T)
    body = ''.join(f'<div style="padding: 7px 0; font-size: 11.5px; font-weight: 700; display: flex; align-items: center; border-top: 1px solid {LINE}; line-height: 1.2">{SHORT[r[0]]}</div>' + ''.join(cell(r[i + 1], t['k']) for i, t in enumerate(T)) for r in ROWS)
    pick = '<div></div>' + ''.join(
        f'<div style="padding: 8px 4px 10px; display: flex; justify-content: center; background: {COL[t["k"]]}; border-radius: 0 0 14px 14px;'
        + (f' box-shadow: inset 2px -2px 0 {MINT}, inset -2px 0 0 {MINT}' if t['k'] == 'plus' else '') + '">'
        + (f'<span style="width: 22px; height: 22px; border-radius: 99px; background: {GREEN}; display: flex; align-items: center; justify-content: center">{ic("check", 13, "#FFFFFF", 3.2)}</span>' if t['k'] == 'plus'
           else f'<span style="width: 22px; height: 22px; border-radius: 99px; box-shadow: inset 0 0 0 2px {"#5E6E67" if t["k"] == "pri" else "#C9D3CD"}"></span>') + '</div>' for t in T)
    tbl = f'<div style="display: grid; grid-template-columns: 1.05fr 1fr 1fr 1fr; background: #FFFFFF; border-radius: 18px; padding: 4px 8px; box-shadow: inset 0 0 0 1.5px {LINE}">{hd}{body}{pick}</div>'
    return mob(h('Compare plans', 24, False) + f'<span style="font-size: 12.5px; font-weight: 600; color: {MUTE}; margin-top: -6px">Tap a column to pick a plan.</span>' + tbl, FOOT())

def b():
    def c(t, i):
        st, dark = E.style(t)
        keys = [0, 1, 3, 5] if t['k'] != 'basic' else [0, 1, 2, 6]
        lst = ''.join(E.row(ROWS[j][0], ROWS[j][i + 1], dark, 12.5) for j in keys)
        tag = chip('MOST POPULAR', MINT, DARK) if t.get('pop') else (chip('FASTEST', '#3A4A43', '#E3ECE7') if t['k'] == 'pri' else '')
        btn = E.btn({'basic': 'Start free', 'plus': 'Start Fast · $15', 'pri': 'Start Priority · $30'}[t['k']], t['k'], 40, 13.5)
        return (f'<div style="border-radius: 18px; padding: 13px 14px; display: flex; flex-direction: column; gap: 9px; {st}">'
                f'<div style="display: flex; align-items: center; justify-content: space-between; gap: 8px"><span style="display: flex; align-items: center; gap: 7px"><b style="font-size: 16px">{t["name"]}</b>{tag}</span>'
                f'<b style="font-size: 20px; letter-spacing: -.6px">{t["price"]}<span style="font-size: 11.5px; color: {"#9FC3B4" if dark else MUTE}">{t["per"]}</span></b></div>'
                f'<div style="display: flex; flex-direction: column; gap: 6px">{lst}</div>{btn}</div>')
    return mob(h('Pick your plan', 24, False) + c(T[1], 1) + c(T[2], 2) + c(T[0], 0))

def c():
    def r(t, i, sel):
        st, dark = E.style(t) if sel or t['k'] == 'pri' else (f'background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}', False)
        if sel: st = f'background: #FFFFFF; color: {INK}; box-shadow: inset 0 0 0 2.5px {MINT}, 0 14px 30px rgba(18,128,92,.16)'; dark = False
        pills = [ROWS[0][i + 1], ROWS[1][i + 1], {'basic': 'No new claims', 'plus': 'New claim reminders', 'pri': 'Refunds + subs'}[t['k']]]
        pl = ''.join(f'<span style="padding: 4px 8px; border-radius: 99px; font-size: 11.5px; font-weight: 800; background: {"rgba(255,255,255,.1)" if dark else "#EEF3F0"}; color: {"#E3ECE7" if dark else INK}">{p}</span>' for p in pills)
        dot = (f'<span style="width: 22px; height: 22px; flex: none; border-radius: 99px; background: {GREEN}; display: flex; align-items: center; justify-content: center">{ic("check", 13, "#FFFFFF", 3.2)}</span>' if sel
               else f'<span style="width: 22px; height: 22px; flex: none; border-radius: 99px; box-shadow: inset 0 0 0 2px {"#5E6E67" if dark else "#C9D3CD"}"></span>')
        tag = chip('MOST POPULAR', MINT, DARK) if t.get('pop') else (chip('FASTEST', '#3A4A43', '#E3ECE7') if t['k'] == 'pri' else '')
        return (f'<div style="border-radius: 18px; padding: 13px 14px; display: flex; flex-direction: column; gap: 9px; {st}">'
                f'<div style="display: flex; align-items: center; gap: 10px">{dot}<span style="flex: 1; display: flex; align-items: center; gap: 7px"><b style="font-size: 16px">{t["name"]}</b>{tag}</span>'
                f'<b style="font-size: 20px; letter-spacing: -.6px">{t["price"]}<span style="font-size: 11.5px; color: {"#9FC3B4" if dark else MUTE}">{t["per"]}</span></b></div>'
                f'<div style="display: flex; flex-wrap: wrap; gap: 5px; padding-left: 32px">{pl}</div></div>')
    note = f'<span style="font-size: 11.5px; font-weight: 600; color: {MUTE}; line-height: 1.45">Every plan: payouts usually 6 to 12 months, depending on each settlement. You keep 100%.</span>'
    return mob(h('How fast should we file?', 24, False) + r(T[0], 0, False) + r(T[1], 1, True) + r(T[2], 2, False) + note, FOOT())

if __name__ == '__main__':
    V = [('A · MINI TABLE', 'All 3 plans as columns with every row. Tap a column to pick; one sticky button.', a()),
         ('B · THREE OPEN CARDS', 'Fast, Priority, Standard stacked and fully open, each with its own button. Scrolls a little.', b()),
         ('C · THREE ROWS', 'One row per plan with its 3 key differences as chips. Fast picked; one sticky button.', c())]
    cols = ''.join(f'<div style="display: flex; flex-direction: column; gap: 14px; align-items: flex-start"><span style="font-size: 15px; font-weight: 800; color: #12805C; letter-spacing: 1px">{t}</span>'
                   f'<span style="font-size: 14px; font-weight: 600; color: #43504A; max-width: 400px; line-height: 1.45">{d}</span>{p}</div>' for t, d, p in V)
    page = ('<div data-board style="width: 1840px; height: 1080px; box-sizing: border-box; padding: 36px 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 22px">'
            '<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #12805C">STANDARD · FAST · PRIORITY · TABLE, MONTHLY · PHONE ITERATIONS</span>'
            '<span style="font-size: 16px; color: #43504A; font-weight: 600">All three plans visible on a phone with no tabs to tap. Draft, not live. Standard free, Fast $15 a month, Priority $30 a month.</span></div>'
            f'<div style="display: flex; gap: 120px; justify-content: center">{cols}</div></div>\n</x-dc>\n')
    open(os.path.join(OUT, 'OfferG2mPhones.dc.html'), 'w').write(HEAD % 'Plans 2 monthly, phones' + page + JS.replace('"width":1926,"height":980', '"width":1840,"height":1080'))
    print('ok')
