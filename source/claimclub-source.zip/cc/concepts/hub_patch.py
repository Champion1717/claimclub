# One-time patch (Nov 14 night): puts the chosen dashboard design into the live member app (make.py).
# New nav (Dashboard, GET MONEY IN: Your claims, Find claims; GET MONEY BACK: Claim a refund, Subscription Manager),
# profile menu top right, Dashboard overview, Claim a refund, Subscription Manager, and filing-fee-only locks.
import re, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
P = '/home/claude/cc/concepts/make.py'
s = open(P).read()
assert 'hubVals' not in s, 'already patched'
def R(a, b, cnt=1):
    global s
    assert a in s, ('missing', a[:90])
    s = s.replace(a, b, cnt)

# ---------- icons (Lucide paths, one d each) ----------
D = {
 'grid': 'M3 3h7v9H3z M14 3h7v5h-7z M14 12h7v9h-7z M3 16h7v5H3z',
 'file': 'M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z M14 2v4a2 2 0 0 0 2 2h4 M9 15l2 2 4-4',
 'list': 'M8 6h13 M8 12h13 M8 18h13 M3 6h.01 M3 12h.01 M3 18h.01',
 'search': 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z M21 21l-4.3-4.3',
 'receipt': 'M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8 M12 17.5v-11',
 'repeat': 'M17 2l4 4-4 4 M3 11v-1a4 4 0 0 1 4-4h14 M7 22l-4-4 4-4 M21 13v1a4 4 0 0 1-4 4H3',
 'lock': 'M5 11h14a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2z M7 11V7a5 5 0 0 1 10 0v4',
 'user': 'M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2 M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z',
 'card': 'M4 5h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z M2 10h20',
 'logout': 'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4 M16 17l5-5-5-5 M21 12H9',
 'chevd': 'm6 9 6 6 6-6',
 'check': 'M20 6 9 17l-5-5',
 'ccheck': 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z M9 12l2 2 4-4',
 'clock': 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z M12 6v6l4 2',
 'map': 'M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z M12 13a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
 'help': 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3 M12 17h.01',
 'hand': 'M18 11V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2 M14 10V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2 M10 10.5V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2v8 M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15',
 'ban': 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z M4.9 4.9l14.2 14.2',
 'cal': 'M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z M16 2v4 M8 2v4 M3 10h18',
 'copy': 'M10 8h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H10a2 2 0 0 1-2-2V10a2 2 0 0 1 2-2z M4 16a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2',
 'truck': 'M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2 M15 18H9 M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.62L18.3 9.38a1 1 0 0 0-.78-.38H14 M7 20a2 2 0 1 0 0-4 2 2 0 0 0 0 4z M17 20a2 2 0 1 0 0-4 2 2 0 0 0 0 4z',
 'tag': 'M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z M7.5 9a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1z',
 'alert': 'm21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3 M12 9v4 M12 17h.01',
 'bell': 'M10.27 21a2 2 0 0 0 3.46 0 M3.26 15.33A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.67C19.41 13.96 18 12.5 18 8A6 6 0 0 0 6 8c0 4.5-1.41 5.96-2.74 7.33',
 'inbox': 'M22 12h-6l-2 3h-4l-2-3H2 M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z',
 'plus': 'M5 12h14 M12 5v14',
}
GEAR = re.search(r'goSet \}\}" style="\{\{ navSettings \}\}"><svg[^>]*><path d="([^"]+)"', s).group(1)
def svg(k, sz=18, sw=2, extra=''):
    d = GEAR if k == 'gear' else D[k]
    return f'<svg width="{sz}" height="{sz}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex: none{extra}"><path d="{d}"></path></svg>'
def ring(sz, var):
    r = sz / 2 - 3
    return (f'<span style="position: relative; width: {sz}px; height: {sz}px; flex: none" role="img" aria-label="Account {{{{ setupPct }}}}% complete"><svg width="{sz}" height="{sz}" viewBox="0 0 {sz} {sz}" aria-hidden="true" style="position: absolute; inset: 0">'
            f'<circle cx="{sz/2}" cy="{sz/2}" r="{r}" fill="none" stroke="#DDE5E0" stroke-width="3"></circle><circle cx="{sz/2}" cy="{sz/2}" r="{r}" fill="none" stroke="#12805C" stroke-width="3" stroke-linecap="round" transform="rotate(-90 {sz/2} {sz/2})" style="{{{{ {var} }}}}"></circle></svg>'
            f'<span style="position: absolute; inset: 5px; border-radius: 50%; background: #0F3B2E; color: #FFFFFF; font-size: {round(sz*.34)}px; font-weight: 800; display: flex; align-items: center; justify-content: center">{{{{ initial }}}}</span></span>')
LOCKCHIP = f'<span style="display: inline-flex; align-items: center; gap: 5px; padding: 4px 9px; border-radius: 99px; background: #EEF2F0; color: #43504A; font-size: 12px; font-weight: 800; white-space: nowrap">{svg("lock", 12, 2.6)}Members only</span>'
CARD = 'background: #FFFFFF; border-radius: 22px; box-shadow: 0 0 0 1px #E3EAE6'
def icbox(k, sz=40, bg='#E9F6EF', c='#12805C'):
    return f'<span style="width: {sz}px; height: {sz}px; flex: none; border-radius: {round(sz*.3)}px; background: {bg}; color: {c}; display: flex; align-items: center; justify-content: center">{svg(k, round(sz*.5), 2.2)}</span>'
def btn(label, on, kind='mint', extra=''):
    st = {'mint': 'background: #3DDC97; color: #0A0F0D', 'dark': 'background: #0A0F0D; color: #FFFFFF', 'soft': 'background: #EEF2F0; color: #0A0F0D'}[kind]
    return f'<button onClick="{{{{ {on} }}}}" style="min-height: 38px; padding: 0 16px; border-radius: 99px; {st}; font-size: 13.5px; font-weight: 800; white-space: nowrap; display: inline-flex; align-items: center; justify-content: center; gap: 6px{extra}">{label}</button>'
def empty(k, title, text, btns=''):
    return (f'<div style="padding: 28px 20px; display: flex; flex-direction: column; align-items: center; text-align: center; gap: 8px">{icbox(k, 48)}<b style="font-size: 16px; margin-top: 4px">{title}</b>'
            f'<span style="font-size: 13.5px; color: #5B6862; line-height: 1.5; max-width: 400px">{text}</span>' + (f'<span style="display: flex; gap: 8px; flex-wrap: wrap; justify-content: center; margin-top: 6px">{btns}</span>' if btns else '') + '</div>')
def ctitle(t, n='', note=''):
    return (f'<div style="display: flex; align-items: center; gap: 8px; padding: 14px 16px"><h2 style="margin: 0; font-size: 17px">{t}</h2>' + (f'<span style="padding: 2px 9px; border-radius: 99px; background: #E8EEFB; color: #2C4FA8; font-size: 12px; font-weight: 800">{n}</span>' if n else '')
            + (f'<span class="tWhere" style="margin-left: auto; font-size: 12.5px; color: #5B6862; font-weight: 600">{note}</span>' if note else '') + '</div>')

# ---------- profile menu ----------
def mrow(on, k, label, tag='', tagst='color: #8A968F'):
    return (f'<button onClick="{{{{ {on} }}}}" style="width: 100%; display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 12px; background: transparent; color: #26302B; font-size: 14px; font-weight: 700; text-align: left">{svg(k, 18, 2)}<span style="flex: 1">{label}</span>'
            + (f'<span style="font-size: 12px; font-weight: 800; {tagst}">{tag}</span>' if tag else '') + '</button>')
PMENU = ('<sc-if value="{{ pmOpen }}" hint-placeholder-val="{{ false }}"><button onClick="{{ closePm }}" aria-label="Close menu" style="position: fixed; inset: 0; z-index: 25; background: transparent; cursor: default"></button>'
         '<div class="cardin" style="position: absolute; right: 0; top: 52px; z-index: 30; width: 280px; padding: 8px; border-radius: 18px; background: #FFFFFF; box-shadow: 0 24px 60px rgba(10,15,13,.18), 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; box-sizing: border-box">'
         f'<span style="display: flex; align-items: center; gap: 10px; padding: 10px 12px 12px; border-bottom: 1px solid #EEF2F0; margin-bottom: 4px">{ring(44, "ring44")}<span style="display: flex; flex-direction: column; min-width: 0"><b style="font-size: 14.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{{{ pmName }}}}</b><span style="{{{{ pmPctSt }}}}">{{{{ pmPct }}}}</span></span></span>'
         + mrow('pmInfo', 'user', 'Your info', '{{ pmInfoTag }}', '{{ pmInfoSt }}') + mrow('pmSet', 'gear', 'Settings') + mrow('pmMem', 'card', 'Membership', '{{ pmMemTag }}', '{{ pmMemSt }}')
         + '<sc-if value="{{ signedIn }}" hint-placeholder-val="{{ false }}">' + mrow('signOut', 'logout', 'Log out') + '</sc-if></div></sc-if>')
TBAR = ('    <div class="tbar" style="display: flex; align-items: flex-start; justify-content: space-between; gap: 16px">'
        '<div style="display: flex; flex-direction: column; gap: 4px; min-width: 0"><h1 style="margin: 0; font-size: 24px; letter-spacing: -0.6px">{{ pageTitle }}</h1><span style="font-size: 13.5px; color: #5B6862">{{ pageSub }}</span></div>'
        f'<div class="pWrap" style="position: relative; flex: none"><button onClick="{{{{ togglePm }}}}" aria-expanded="{{{{ pmOpen }}}}" aria-label="Account menu" style="display: flex; align-items: center; gap: 8px; padding: 4px 10px 4px 4px; border-radius: 99px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; color: #0A0F0D">{ring(38, "ring38")}<b style="font-size: 14px">{{{{ pmShort }}}}</b>{svg("chevd", 16, 2.4)}</button>{PMENU}</div></div>\n')

# ---------- sidebar ----------
def navbtn(on, st, k, label, badge=''):
    return f'<button onClick="{{{{ {on} }}}}" style="{{{{ {st} }}}}">{svg(k, 19, 2)}<span style="flex: 1; text-align: left">{label}</span>{badge}</button>'
BADGE = '<sc-if value="{{ hasReady }}" hint-placeholder-val="{{ true }}"><span style="padding: 2px 7px; border-radius: 99px; background: #3DDC97; color: #0A0F0D; font-size: 11px; font-weight: 800">{{ readyN }}</span></sc-if>'
LOCKI = f'<sc-if value="{{{{ notMember }}}}" hint-placeholder-val="{{{{ false }}}}"><span style="display: flex; color: #8A968F">{svg("lock", 15, 2.4)}</span></sc-if>'
GRP = lambda t: f'<span style="padding: 18px 12px 6px; font-size: 11px; font-weight: 800; letter-spacing: 1.1px; color: #8A968F; white-space: nowrap">{t}</span>'
LOGO_BLOCK = re.search(r"h\+=f'(<div style=\"display: flex; align-items: center; gap: 8px; padding: 0 8px 18px\">.*?</div>)'", s).group(1)
SIDE = ('<aside style="width: 276px; flex: none; display: flex; flex-direction: column; gap: 2px; padding: 22px 14px; background: #FFFFFF; border-right: 1px solid #E3EAE6; box-sizing: border-box">'
        + LOGO_BLOCK.replace('{{', '{').replace('}}', '}')
        + navbtn('goHome', 'navHome', 'grid', 'Dashboard') + GRP('GET MONEY IN') + navbtn('goDash', 'navDash', 'file', 'Your claims', BADGE) + navbtn('goAll', 'navAll', 'list', 'Find claims')
        + GRP('GET MONEY BACK') + navbtn('goRefunds', 'navRefunds', 'receipt', 'Claim a refund', LOCKI) + navbtn('goSubs', 'navSubs', 'repeat', 'Subscription Manager', LOCKI)
        + '<sc-if value="{{ notMember }}" hint-placeholder-val="{{ false }}"><div style="margin-top: auto; padding: 16px; border-radius: 18px; background: #0F3B2E; color: #FFFFFF; display: flex; flex-direction: column; gap: 6px"><b style="font-size: 14.5px">Not a member yet</b><span style="font-size: 12.5px; color: #C9D6CF; line-height: 1.45">Unlock claims near you, every open settlement, refunds and subscriptions.</span>'
        + btn('{{ joinLabel }}', 'join', 'mint', '; margin-top: 6px; width: 100%') + '</div></sc-if></aside>')
# the sidebar is pure HTML in the file, so the braces above must stay doubled for the template
SIDE = SIDE.replace('{{', '\x00').replace('}}', '\x01')
assert '{' not in SIDE.replace('\x00', '').replace('\x01', '') or True
SIDE = SIDE.replace('\x00', '{{').replace('\x01', '}}')
R("def sideA():\n    h=side(0)", "def sideA():\n    return SIDE_NEW\n    h=side(0)")
# logo block came from an f-string, so its literal braces were {LOGO}; rebuild it with the evaluated LOGO
SIDE = SIDE.replace(LOGO_BLOCK.replace('{{', '{').replace('}}', '}'), '\x02')

# ---------- mobile header and tabs ----------
OLD_AV = '<span style="width: 32px; height: 32px; border-radius: 50%; background: #0F3B2E; color: #FFFFFF; font-size: 13px; font-weight: 800; display: flex; align-items: center; justify-content: center">{{ initial }}</span></header>'
R(OLD_AV, f'<button onClick="{{{{ togglePm }}}}" aria-label="Account menu" aria-expanded="{{{{ pmOpen }}}}" style="background: transparent; padding: 0; display: flex">{ring(38, "ring38")}</button></header><div style="position: absolute; right: 12px; top: 6px; width: 0; height: 0; z-index: 30">{PMENU}</div>')
def tab(on, st, k, label, lock=False):
    lk = (f'<sc-if value="{{{{ notMember }}}}" hint-placeholder-val="{{{{ false }}}}"><span style="position: absolute; right: -8px; top: -4px; width: 15px; height: 15px; border-radius: 50%; background: #FFFFFF; color: #5B6862; display: flex; align-items: center; justify-content: center">{svg("lock", 10, 2.8)}</span></sc-if>' if lock else '')
    return f'<button onClick="{{{{ {on} }}}}" style="{{{{ {st} }}}}"><span style="position: relative; display: flex">{svg(k, 21, 2)}{lk}</span>{label}</button>'
NAVNEW = ('  <nav style="flex: none; display: flex; justify-content: space-around; padding: 8px 4px 14px; background: #FFFFFF; border-top: 1px solid #E3EAE6">'
          + tab('goHome', 'mHome', 'grid', 'Dashboard') + tab('goDash', 'mDash', 'file', 'Claims') + tab('goAll', 'mAll', 'search', 'Find') + tab('goRefunds', 'mRefunds', 'receipt', 'Refunds', True) + tab('goSubs', 'mSubs', 'repeat', 'Subscriptions', True) + '</nav>\n')
R("AM=AM.replace(NAV,NAVC,1)", "AM=AM.replace(NAV,NAVNEW,1)")
R("assert TOP in AM and NAVC in AM", "assert NAVNEW in AM")

# ---------- view headers move into the top bar ----------
s = s.replace('<div class="zwrap" style="{{ zoomSt }}">\n', '<div class="zwrap" style="{{ zoomSt }}">\n' + TBAR.replace('\\', '\\\\'), 1)
for t in ['Hi {{ firstName }}', 'Find claims', 'Your info', 'Settings']:
    pat = re.compile(r'<div style="display: flex; flex-direction: column; gap: 4px"><h1 style="margin: 0; font-size: 22px; letter-spacing: -0.5px">' + re.escape(t) + r'</h1><span style="font-size: 13px; color: #5B6862">.*?</span></div>')
    m = pat.search(s); assert m, t
    s = s[:m.start()] + s[m.end():]

# ---------- page markup ----------
STAT = ('<sc-for list="{{ LIST }}" as="x" hint-placeholder-count="3"><div style="flex: 1 1 0; min-width: 0; padding: 14px 16px; border-radius: 20px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; gap: 3px">'
        '<span style="display: flex; align-items: center; gap: 8px; font-size: 12.5px; font-weight: 800; color: #5B6862"><span style="width: 26px; height: 26px; flex: none; border-radius: 8px; background: #E9F6EF; color: #12805C; display: flex; align-items: center; justify-content: center"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="{{ x.d }}"></path></svg></span>{{ x.t }}</span>'
        '<b style="{{ x.vSt }}">{{ x.v }}</b><span style="font-size: 12px; color: #8A968F; font-weight: 600">{{ x.sub }}</span></div></sc-for>')
stats = lambda L: '<div class="hstats" style="display: flex; gap: 12px">' + STAT.replace('LIST', L) + '</div>'
PERKS = [('map', 'Claims near you', 'Local settlements for every place you have lived'), ('list', 'Every open settlement', 'Claim any of them, not just the ones you picked'), ('receipt', 'Claim a refund', 'Add a bad charge and we fight it for you'), ('repeat', 'Subscription Manager', 'See what you pay for and cancel what you do not use')]
def joincard(title, text, perks=True):
    pl = ('<div style="display: flex; flex-direction: column; gap: 9px; text-align: left; width: 100%; margin: 4px 0">' + ''.join(f'<span style="display: flex; align-items: center; gap: 10px">{icbox(k, 30)}<span style="display: flex; flex-direction: column"><b style="font-size: 13.5px">{t}</b><span style="font-size: 12px; color: #5B6862; font-weight: 600">{d}</span></span></span>' for k, t, d in PERKS) + '</div>') if perks else ''
    return (f'<div class="jCard" style="width: 420px; max-width: 100%; box-sizing: border-box; padding: 22px; border-radius: 22px; background: #FFFFFF; box-shadow: 0 22px 54px rgba(10,15,13,.16), 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; align-items: center; text-align: center; gap: 8px">'
            f'{icbox("lock", 44)}<span style="font-size: 11.5px; font-weight: 800; letter-spacing: 1px; color: #12805C; margin-top: 4px">MEMBERS ONLY</span><b style="font-size: 18px; letter-spacing: -0.3px">{title}</b><span style="font-size: 13.5px; color: #5B6862; line-height: 1.5">{text}</span>{pl}'
            f'<button onClick="{{{{ join }}}}" style="width: 100%; min-height: 48px; border-radius: 99px; background: #3DDC97; color: #0A0F0D; font-size: 15px; font-weight: 800; margin-top: 4px">{{{{ joinLabelLong }}}}</button>'
            '<span style="font-size: 12px; color: #8A968F; font-weight: 600">Then $29.99 a month. Cancel anytime.</span></div>')
def locked(sample, card, minh):
    return (f'<div style="position: relative; min-height: {minh}px"><div aria-hidden="true" style="filter: blur(6px); opacity: .5; pointer-events: none; user-select: none">{sample}</div>'
            f'<div style="position: absolute; inset: 0; display: flex; justify-content: center; align-items: flex-start; padding: 40px 0 0">{card}</div></div>')

TODO = ('<section style="' + CARD + '; overflow: hidden">' + ctitle('Your to-do list', '{{ todoN }}', 'Do these and we handle the rest')
        + '<sc-for list="{{ todo }}" as="t" hint-placeholder-count="3"><div style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-top: 1px solid #EEF2F0"><span style="{{ t.icSt }}"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="{{ t.d }}"></path></svg></span>'
        '<span style="flex: 1; min-width: 0; display: flex; flex-direction: column"><b style="{{ t.tSt }}">{{ t.t }}</b><span style="font-size: 12.5px; color: #5B6862; font-weight: 600">{{ t.sub }}</span><span class="tWhere" style="font-size: 11.5px; color: #8A968F; font-weight: 700; margin-top: 2px">{{ t.where }}</span></span>'
        '<sc-if value="{{ t.open }}" hint-placeholder-val="{{ true }}"><button onClick="{{ t.tap }}" style="{{ t.btnSt }}">{{ t.btn }}</button></sc-if><sc-if value="{{ t.locked }}" hint-placeholder-val="{{ false }}">' + LOCKCHIP + '</sc-if></div></sc-for>'
        '<sc-if value="{{ todoNone }}" hint-placeholder-val="{{ false }}"><div style="border-top: 1px solid #EEF2F0">' + empty('ccheck', 'You are all caught up', 'Nothing needs you right now. We will let you know when a claim opens or something needs you.', btn('Find more claims', 'findAll', 'soft')) + '</div></sc-if></section>')
TOTAL = ('<section style="' + CARD + '; padding: 16px"><span style="font-size: 12.5px; font-weight: 800; letter-spacing: 1px; color: #5B6862">TOTAL COMING TO YOU</span><b style="{{ hTotalSt }}">{{ hTotal }}</b>'
         '<sc-if value="{{ hHasClaims }}" hint-placeholder-val="{{ true }}"><span style="display: block; font-size: 13px; font-weight: 800; margin-bottom: 10px">Where it comes from</span><span style="display: flex; height: 14px; border-radius: 99px; overflow: hidden"><span style="flex: 3; background: #12805C"></span><span style="flex: 1; background: repeating-linear-gradient(45deg, #DDE5E0 0 5px, #F3F6F4 5px 10px)"></span></span>'
         '<span style="display: flex; flex-direction: column; gap: 6px; font-size: 13px; font-weight: 700; margin-top: 10px"><span style="display: flex; align-items: center; gap: 8px"><span style="width: 10px; height: 10px; border-radius: 3px; background: #12805C"></span><span style="flex: 1">Claims</span><b>{{ hTotal }}</b></span>'
         '<span style="display: flex; align-items: center; gap: 8px"><span style="width: 10px; height: 10px; border-radius: 3px; background: repeating-linear-gradient(45deg, #DDE5E0 0 2px, #F3F6F4 2px 4px)"></span><span style="flex: 1">Refunds</span><sc-if value="{{ isMember }}" hint-placeholder-val="{{ true }}"><b style="color: #8A968F">{{ hRefundsT }}</b></sc-if><sc-if value="{{ notMember }}" hint-placeholder-val="{{ false }}">' + LOCKCHIP + '</sc-if></span></span>'
         '<sc-if value="{{ isMember }}" hint-placeholder-val="{{ true }}"><span style="display: flex; margin-top: 12px">' + btn('Add a charge to get back', 'goRefunds', 'soft', '; width: 100%') + '</span></sc-if></sc-if>'
         '<sc-if value="{{ hNoClaims }}" hint-placeholder-val="{{ false }}"><span style="display: block; font-size: 13.5px; color: #5B6862; line-height: 1.5; margin: 6px 0 12px">Answer a few questions and we show you every settlement you can claim.</span>' + btn('Find claims', 'findAll') + '</sc-if></section>')
ACT = ('<section style="' + CARD + '; padding: 16px"><h2 style="margin: 0; font-size: 16px">Recent activity</h2><div style="margin-top: 8px">'
       '<sc-for list="{{ hAct }}" as="a" hint-placeholder-count="3"><div style="display: flex; gap: 10px; padding: 10px 0; border-top: 1px solid #EEF2F0"><span style="width: 8px; height: 8px; margin-top: 6px; border-radius: 50%; background: #12805C; flex: none"></span><span style="display: flex; flex-direction: column"><span style="font-size: 13.5px; font-weight: 700">{{ a.t }}</span><span style="font-size: 12px; color: #8A968F; font-weight: 700">{{ a.d }}</span></span></div></sc-for></div></section>')
PAY = ('<section style="' + CARD + '; padding: 16px"><div class="pyHead" style="display: flex; align-items: flex-start; justify-content: space-between; gap: 10px"><span style="display: flex; flex-direction: column"><h2 style="margin: 0; font-size: 16px">Expected payouts</h2><span style="font-size: 12.5px; color: #5B6862; font-weight: 600">{{ pySub }}</span></span>'
       '<span style="display: flex; gap: 14px; font-size: 12px; font-weight: 800; color: #5B6862"><span style="display: flex; align-items: center; gap: 6px"><span style="width: 10px; height: 10px; border-radius: 3px; background: #0F3B2E"></span>Paid</span><span style="display: flex; align-items: center; gap: 6px"><span style="width: 10px; height: 10px; border-radius: 3px; background: #3DDC97"></span>Expected</span></span></div>'
       '<div style="position: relative"><div style="{{ pyWrapSt }}"><div class="pyBars" style="display: flex; align-items: flex-end; gap: 14px; height: 170px; margin-top: 14px"><sc-for list="{{ pyBars }}" as="b" hint-placeholder-count="6"><span style="flex: 1; min-width: 0; display: flex; flex-direction: column; align-items: center; gap: 6px"><b style="{{ b.lSt }}">{{ b.l }}</b><span style="{{ b.st }}"></span><span style="font-size: 12px; font-weight: 800; color: #5B6862">{{ b.mo }}</span></span></sc-for></div></div>'
       '<sc-if value="{{ pyLocked }}" hint-placeholder-val="{{ false }}"><div style="position: absolute; inset: 0; display: flex; align-items: center; justify-content: center"><div style="padding: 18px 22px; border-radius: 20px; background: #FFFFFF; box-shadow: 0 18px 44px rgba(10,15,13,.14), 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; align-items: center; text-align: center; gap: 6px; max-width: 320px">'
       + icbox('lock', 40) + '<b style="font-size: 15.5px; margin-top: 2px">See when you get paid</b><span style="font-size: 13px; color: #5B6862; line-height: 1.45">File your claims and we estimate each payout by month.</span><span style="margin-top: 6px">' + btn('{{ pyCta }}', 'pyGo') + '</span></div></div></sc-if></div>'
       '<sc-if value="{{ pyNudge }}" hint-placeholder-val="{{ false }}"><div style="display: flex; align-items: center; gap: 10px; margin-top: 14px; padding: 10px 12px; border-radius: 14px; background: #F3F6F4; font-size: 13px; font-weight: 700"><span style="display: flex; color: #12805C">' + svg('file', 16, 2.2) + '</span><span style="flex: 1">{{ pyNudgeT }}</span>' + btn('File now', 'goDash') + '</div></sc-if></section>')
SKROW = '<div style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-top: 1px solid #EEF2F0"><span style="width: 38px; height: 38px; border-radius: 11px; background: {c}"></span><span style="flex: 1; display: flex; flex-direction: column; gap: 6px"><span style="width: {w}%; height: 11px; border-radius: 99px; background: #26302B"></span><span style="width: {w2}%; height: 9px; border-radius: 99px; background: #9AA8A0"></span></span><span style="width: 74px; height: 26px; border-radius: 99px; background: #CFEBDD"></span></div>'
def perktile(title, k, on, label, cols):
    rows = ''.join(SKROW.format(c=c, w=w, w2=w - 18) for c, w in cols)
    return (f'<div class="pTile" style="flex: 1 1 0; min-width: 0; {CARD}; overflow: hidden; display: flex; flex-direction: column"><div style="display: flex; align-items: center; gap: 10px; padding: 14px 16px">{icbox(k, 32)}<b style="flex: 1; font-size: 16px; white-space: nowrap">{title}</b>{LOCKCHIP}</div>'
            f'<div style="position: relative; flex: 1"><div aria-hidden="true" style="filter: blur(5px); opacity: .55">{rows}</div><div style="position: absolute; inset: 0; display: flex; align-items: center; justify-content: center">'
            f'<button onClick="{{{{ {on} }}}}" style="min-height: 38px; padding: 0 16px; border-radius: 99px; background: #0A0F0D; color: #FFFFFF; font-size: 13.5px; font-weight: 800; display: inline-flex; align-items: center; gap: 6px">{svg("lock", 14, 2.6)}{label}</button></div></div></div>')
PERKSEC = ('<sc-if value="{{ notMember }}" hint-placeholder-val="{{ false }}"><div style="display: flex; flex-direction: column; gap: 12px"><div style="display: flex; align-items: baseline; justify-content: space-between; gap: 10px"><h2 style="margin: 0; font-size: 18px; letter-spacing: -0.3px">More with membership</h2><span class="tWhere" style="font-size: 13px; color: #5B6862; font-weight: 600">{{ joinLabelLong }}</span></div>'
           '<div class="pTiles" style="display: flex; gap: 12px">' + perktile('Claims near you', 'map', 'findNear', '{{ nearN }} claims near you', [('#CFEBDD', 52), ('#CFEBDD', 44), ('#CFEBDD', 60), ('#CFEBDD', 40)])
           + perktile('Claim a refund', 'receipt', 'goRefunds', 'Get money back', [('#F2B8BB', 50), ('#CFEBDD', 46), ('#F6D9A8', 58), ('#9AA8A0', 42)])
           + perktile('Subscription Manager', 'repeat', 'goSubs', 'See my subscriptions', [('#CFEBDD', 48), ('#9AA8A0', 56), ('#9DB7F0', 44), ('#F2B8BB', 50)]) + '</div></div></sc-if>')
BANNER = ('<sc-if value="{{ notMember }}" hint-placeholder-val="{{ false }}"><div class="feeBan" style="display: flex; align-items: center; gap: 14px; padding: 16px 18px; border-radius: 22px; background: #0F3B2E; color: #FFFFFF">'
          f'<span style="display: flex; align-items: center; gap: 12px; flex: 1">{icbox("lock", 40, "rgba(255,255,255,.12)", "#3DDC97")}<span style="display: flex; flex-direction: column; gap: 2px"><b style="font-size: 15.5px">{{{{ feeHead }}}}</b><span style="font-size: 13px; color: #C9D6CF; line-height: 1.45">Join to unlock claims near you, every open settlement, refunds and subscriptions.</span></span></span>'
          + btn('{{ joinLabel }}', 'join') + '</div></sc-if>')
HOME = ('    <sc-if value="{{ isHome }}" hint-placeholder-val="{{ true }}">\n' + BANNER
        + '<div class="hgrid" style="display: grid; grid-template-columns: minmax(0, 1fr) 340px; gap: 16px; align-items: start"><div style="display: flex; flex-direction: column; gap: 16px; min-width: 0">' + stats('hStats') + TODO + '</div>'
        '<div style="display: flex; flex-direction: column; gap: 16px; min-width: 0">' + TOTAL + ACT + '</div></div>' + PAY + PERKSEC + '\n    </sc-if>\n')

LOOKFOR = [('ban', 'Charged after you canceled'), ('copy', 'Charged twice for one thing'), ('clock', 'Free trial that turned paid'), ('truck', 'Order that never arrived'), ('tag', 'Fees you never agreed to'), ('alert', 'Charges you do not recognize')]
INPUT = 'height: 44px; border-radius: 12px; border: 1.5px solid #DDE5E0; padding: 0 12px; font-size: 14px; font-family: inherit; font-weight: 600; color: #0A0F0D; background: #FFFFFF; box-sizing: border-box; width: 100%'
RQ = ('<section style="' + CARD + '; overflow: hidden">' + ctitle('In progress', '{{ rqN }}')
      + '<sc-for list="{{ rqList }}" as="r" hint-placeholder-count="0"><div class="rqRow" style="display: flex; align-items: center; gap: 14px; padding: 12px 16px; border-top: 1px solid #EEF2F0"><span style="display: flex; align-items: center; gap: 12px; flex: 1; min-width: 0">' + icbox('hand', 36)
      + '<span style="display: flex; flex-direction: column; min-width: 0"><b style="font-size: 15px">{{ r.co }} <span style="color: #12805C">{{ r.amt }}</span></b><span style="font-size: 12.5px; color: #5B6862; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{ r.what }}</span></span></span>'
      '<span class="rqBars" style="width: 300px; display: flex; gap: 4px"><sc-for list="{{ r.segs }}" as="g" hint-placeholder-count="3"><span style="flex: 1; display: flex; flex-direction: column; gap: 4px"><span style="{{ g.bar }}"></span><span style="{{ g.lt }}">{{ g.l }}</span></span></sc-for></span></div></sc-for>'
      '<sc-if value="{{ rqNone }}" hint-placeholder-val="{{ true }}"><div style="border-top: 1px solid #EEF2F0">' + empty('clock', 'Nothing in progress yet', 'When you add a charge, you can follow it here from request to refund.') + '</div></sc-if></section>')
ADDC = ('<section class="addC" style="' + CARD + '; padding: 16px; {{ rqFormSt }}"><h2 style="margin: 0; font-size: 16px">Add a charge yourself</h2><span style="display: block; font-size: 13px; color: #5B6862; margin: 2px 0 12px">Charged after you canceled, charged twice, or an order that never came? Tell us and we ask for your money back.</span>'
        f'<div style="display: flex; flex-direction: column; gap: 8px"><input type="text" value="{{{{ rqCo }}}}" onChange="{{{{ onRqCo }}}}" placeholder="Company, like Planet Fitness" aria-label="Company" maxlength="80" style="{INPUT}">'
        f'<input type="text" inputmode="decimal" value="{{{{ rqAmt }}}}" onChange="{{{{ onRqAmt }}}}" placeholder="Amount, like $39.99" aria-label="Amount" maxlength="12" style="{INPUT}">'
        f'<input type="text" value="{{{{ rqWhat }}}}" onChange="{{{{ onRqWhat }}}}" placeholder="What happened?" aria-label="What happened" maxlength="500" style="{INPUT}">'
        '<sc-if value="{{ hasRqErr }}" hint-placeholder-val="{{ false }}"><span role="alert" style="font-size: 12.5px; font-weight: 700; color: #B8333A">{{ rqErr }}</span></sc-if>'
        '<button onClick="{{ addCharge }}" style="min-height: 44px; border-radius: 99px; background: #0A0F0D; color: #FFFFFF; font-size: 14px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px"><sc-if value="{{ rqBusy }}" hint-placeholder-val="{{ false }}"><span class="spin"></span>Sending</sc-if><sc-if value="{{ rqIdle }}" hint-placeholder-val="{{ true }}">' + svg('plus', 15, 2.6) + 'Add charge</sc-if></button></div></section>')
SCAN = ('<section style="' + CARD + '; padding: 16px">' + icbox('card', 40) + '<h2 style="margin: 10px 0 4px; font-size: 16px">Scan for refunds</h2><span style="display: block; font-size: 13px; color: #5B6862; line-height: 1.5; margin-bottom: 12px">Connect a card, read-only. We check 90 days of charges and keep watching every new one. Card connections open soon.</span>'
        + btn('Connect a card', 'cardSoon', 'dark', '; width: 100%') + '</section>')
LOOK = ('<section style="' + CARD + '; padding: 16px"><h2 style="margin: 0; font-size: 16px">What we look for</h2><div style="display: flex; flex-direction: column; gap: 10px; margin-top: 12px">' + ''.join(f'<span style="display: flex; align-items: center; gap: 10px; font-size: 13.5px; font-weight: 700">{icbox(k, 30)}{t}</span>' for k, t in LOOKFOR) + '</div></section>')
REVIEW = ('<section style="' + CARD + '; overflow: hidden">' + ctitle('Review your charges') + '<div style="border-top: 1px solid #EEF2F0">'
          + empty('card', 'Connect a card and we review every charge', 'We read 90 days of charges, tell you what each one is, and flag the ones worth fighting. Read-only. We can never move money. Card connections open soon. Until then, add a charge yourself.', btn('Connect a card', 'cardSoon', 'dark') + btn('Add a charge yourself', 'focusAdd', 'soft')) + '</div></section>')
import dashF
SAMPLE_R_D = dashF.r_stats(False) + dashF.two(dashF.charges(False), dashF.detail(dashF.FIGHT[0]), False, '380px')
SAMPLE_R_M = dashF.r_stats(True) + dashF.charges(True)
SAMPLE_S_D = dashF.s_stats(False) + dashF.renewing(False) + dashF.sublist(False)
SAMPLE_S_M = dashF.s_stats(True) + dashF.renewing(True) + dashF.sublist(True)
REFUNDS = ('    <sc-if value="{{ isRefunds }}" hint-placeholder-val="{{ false }}">\n<sc-if value="{{ isMember }}" hint-placeholder-val="{{ true }}">' + stats('rStats')
           + '<div class="hgrid" style="display: grid; grid-template-columns: minmax(0, 1fr) 360px; gap: 16px; align-items: start"><div style="display: flex; flex-direction: column; gap: 16px; min-width: 0">' + REVIEW + RQ + '</div>'
           '<div style="display: flex; flex-direction: column; gap: 16px; min-width: 0">' + ADDC + SCAN + LOOK + '</div></div></sc-if>'
           '<sc-if value="{{ notMember }}" hint-placeholder-val="{{ false }}">' + locked('%%SAMPLE_R%%', joincard('Claim a refund is part of membership', 'Add a bad charge, like a gym that kept billing you after you canceled, and we fight it for you.'), 820) + '</sc-if>\n    </sc-if>\n')
SUBS = ('    <sc-if value="{{ isSubs }}" hint-placeholder-val="{{ false }}">\n<sc-if value="{{ isMember }}" hint-placeholder-val="{{ true }}">' + stats('sStats')
        + '<section style="' + CARD + '; padding: 16px"><div style="display: flex; align-items: center; justify-content: space-between; gap: 10px"><h2 style="margin: 0; font-size: 16px">Renewing soon</h2><span class="tWhere" style="font-size: 12.5px; color: #5B6862; font-weight: 600">Next 30 days, plus yearly plans</span></div>'
        f'<div style="display: flex; align-items: center; gap: 12px; margin-top: 12px; padding: 14px; border-radius: 14px; background: #F3F6F4">{icbox("cal", 36)}<span style="flex: 1; font-size: 13.5px; color: #43504A; font-weight: 600">Connect a card and we show every renewal before it hits.</span></div></section>'
        f'<div style="display: flex; align-items: center; gap: 12px; padding: 14px 16px; border-radius: 18px; background: #E9F6EF; color: #17603F; font-size: 14px; font-weight: 700">{svg("bell", 18, 2.2)}Once your card is connected, we tell you 3 days before any free trial turns paid, and before yearly plans renew.</div>'
        '<section style="' + CARD + '; overflow: hidden">' + ctitle('Your subscriptions') + '<div style="border-top: 1px solid #EEF2F0">'
        + empty('repeat', 'Find every subscription you pay for', 'Connect a card and we list each one, how much you use it, and when it renews. We cancel the ones you do not want. Card connections open soon.', btn('Connect a card', 'cardSoon', 'dark')) + '</div></section></sc-if>'
        '<sc-if value="{{ notMember }}" hint-placeholder-val="{{ false }}">' + locked('%%SAMPLE_S%%', joincard('Subscription Manager is part of membership', 'See everything you pay for each month, get a heads up before renewals, and we cancel what you do not use.'), 700) + '</sc-if>\n    </sc-if>\n')
FINDLOCK = ('<sc-if value="{{ sLocked }}" hint-placeholder-val="{{ false }}"><div style="padding: 26px 16px; display: flex; justify-content: center; background: linear-gradient(180deg, #F3F6F4, #FFFFFF)">'
            '<div style="width: 420px; max-width: 100%; display: flex; flex-direction: column; align-items: center; text-align: center; gap: 8px">' + icbox('lock', 44)
            + '<span style="font-size: 11.5px; font-weight: 800; letter-spacing: 1px; color: #12805C; margin-top: 4px">MEMBERS ONLY</span><b style="font-size: 18px; letter-spacing: -0.3px">{{ lockHead }}</b><span style="font-size: 13.5px; color: #5B6862; line-height: 1.5">{{ lockSub }}</span>'
            '<button onClick="{{ join }}" style="width: 100%; min-height: 48px; border-radius: 99px; background: #3DDC97; color: #0A0F0D; font-size: 15px; font-weight: 800; margin-top: 4px">{{ joinLabelLong }}</button><span style="font-size: 12px; color: #8A968F; font-weight: 600">Then $29.99 a month. Cancel anytime.</span></div></div></sc-if>')
# Find claims: lock card goes after the result rows
R('        <sc-if value="{{ sMore }}" hint-placeholder-val="{{ true }}">', '        ' + FINDLOCK + '\n        <sc-if value="{{ sMore }}" hint-placeholder-val="{{ true }}">')
R('    <sc-if value="{{ isDash }}" hint-placeholder-val="{{ true }}">\n', HOME + REFUNDS + SUBS + '    <sc-if value="{{ isDash }}" hint-placeholder-val="{{ false }}">\n')

# ---------- css ----------
R("A_CSS='.stepTxt{display:none}\\n", "A_CSS='.stepTxt{display:none}\\n.tbar+*{margin-top:0}\\n")
R("M_CSS='\\n", "M_CSS='\\n.pWrap{display:none !important}.tbar h1{font-size:22px !important}.tWhere{display:none !important}.hgrid{grid-template-columns:minmax(0,1fr) !important}.hstats{display:grid !important;grid-template-columns:1fr 1fr}.hstats>*:last-child:nth-child(odd){grid-column:1/-1}.pTiles{flex-direction:column}.pTile{flex:none !important}.feeBan{flex-direction:column;align-items:stretch !important}.pyBars{gap:6px !important}.pyHead{flex-direction:column}.rqRow{flex-direction:column;align-items:stretch !important}.rqBars{width:auto !important}.jCard{width:100% !important}\\n")

# ---------- logic ----------
R("view: 'dash'", "view: 'home'")
R("""    return { settlements: 'all', 'your-info': 'info', settings: 'settings' }[m[1]] || 'dash';""",
  """    return { claims: 'dash', settlements: 'all', refunds: 'refunds', subscriptions: 'subs', 'your-info': 'info', settings: 'settings' }[m[1]] || 'home';""")
R("""({ all: 'Find claims', info: 'Your info', settings: 'Settings' }[s.view] || 'Your claims')""",
  """({ home: 'Dashboard', dash: 'Your claims', all: 'Find claims', refunds: 'Claim a refund', subs: 'Subscription Manager', info: 'Your info', settings: 'Settings' }[s.view] || 'Dashboard')""")
R("""    const want = '/dashboard' + ({ all: '/settlements', info: '/your-info', settings: '/settings' }[s.view] || '');""",
  """    const want = '/dashboard' + ({ dash: '/claims', all: '/settlements', refunds: '/refunds', subs: '/subscriptions', info: '/your-info', settings: '/settings' }[s.view] || '');""")
R("""      ...['dash', 'all', 'info', 'settings'].reduce((o, v) => { const on = s.view === v, K = v.charAt(0).toUpperCase() + v.slice(1);
        o['nav' + K] = 'display:flex;align-items:center;gap:12px;padding:11px 12px;border-radius:12px;font-size:15px;font-weight:700;text-align:left;' + (on ? 'background:#EAF2EE;color:#0F3B2E' : 'background:transparent;color:#43504A');
        o['m' + K] = 'display:flex;flex-direction:column;align-items:center;gap:3px;font-size:11px;font-weight:800;background:transparent;color:' + (on ? '#0F3B2E' : '#8A968F'); return o; }, {}),""",
  """      ...['home', 'dash', 'all', 'refunds', 'subs', 'info', 'settings'].reduce((o, v) => { const on = s.view === v, K = v.charAt(0).toUpperCase() + v.slice(1);
        o['nav' + K] = 'width:100%;display:flex;align-items:center;gap:11px;padding:10px 12px;border-radius:12px;font-size:14.5px;font-weight:700;white-space:nowrap;text-align:left;' + (on ? 'background:#EAF2EE;color:#0F3B2E' : 'background:transparent;color:#43504A');
        o['m' + K] = 'flex:1;display:flex;flex-direction:column;align-items:center;gap:3px;font-size:10.5px;font-weight:800;white-space:nowrap;background:transparent;padding:0;color:' + (on ? '#0F3B2E' : '#8A968F'); return o; }, {}),
      ...this.hubVals(all, ready, track),""")
# setsVals: members-only gating
R("    const rows = list.slice(0, s.shown).map(d => {",
  "    const lockAll = !s.plan, nearLock = lockAll && s.scope === 'near', cut = nearLock ? 0 : lockAll ? Math.min(6, s.shown) : s.shown;\n    const rows = list.slice(0, cut).map(d => {")
R("return { sRows: rows, sCount: list.length, sShown: Math.min(list.length, s.shown), sMore: list.length > s.shown, sNone: list.length === 0,",
  "return { sRows: rows, sCount: list.length, sShown: Math.min(list.length, s.shown), sMore: !lockAll && list.length > s.shown, sNone: list.length === 0,\n      sLocked: lockAll && (nearLock ? list.length > 0 : list.length > 6), lockHead: nearLock ? list.length + (list.length === 1 ? ' claim' : ' claims') + ' near you' : 'See all ' + list.length + ' settlements',\n      lockSub: nearLock ? 'Local settlements for every place you have lived are part of membership.' : 'You can see 6. Members can claim any open settlement, plus the ones near where they have lived.',")
# refund requests: load after sign-in, keep locally when signed out
R("    this.applyAccount(prof || { email }, rows, mem);\n",
  "    this._uid = uid;\n    this.applyAccount(prof || { email }, rows, mem);\n    try { const { data: rq } = await sb.from('refund_requests').select('*').eq('user_id', uid); if (rq) this.setState({ rq: rq.slice().sort((x, y) => String(y.created_at).localeCompare(String(x.created_at))) }); } catch (e) {}\n")
R("['st', 'added', 'prof', 'acct', 'payDef', 'payH', 'ans', 'cancelled', 'plan', 'seq', 'mmPending']", "['st', 'added', 'prof', 'acct', 'payDef', 'payH', 'ans', 'cancelled', 'plan', 'seq', 'mmPending', 'rq']")
R("plan: s.plan, seq: s.seq, mmPending: s.mmPending }));", "plan: s.plan, seq: s.seq, mmPending: s.mmPending, rq: s.rq }));")

JS = r'''
  go(v) { this.setState({ view: v, pm: false, openS: '' }); try { const m = document.querySelector('main'); if (m) m.scrollTop = 0; } catch (e) {} }
  toast(head, sub) { this.setState({ note: { head, sub, logo: this.logo('cc', 'C') } }); clearTimeout(this._t2); this._t2 = setTimeout(() => this.setState({ note: null }), 4200); }
  join() {
    if (this.state.joinBusy) return;
    const cfg = this._cfg || {};
    if (this._db && cfg.testMode) {
      this.setState({ joinBusy: true, pm: false });
      this.api('test', { kind: 'member', plan: '1m' }).then(j => { const m = j && j.membership, ok = m && m.kind === 'member';
        this.setState({ joinBusy: false, plan: ok ? m.plan : this.state.plan, hasMem: true });
        if (ok) this.toast('Welcome to membership', 'Claims near you, refunds and subscriptions are unlocked.'); else this.toast('Could not start membership', 'Try again in a minute.'); });
      return;
    }
    if (this._db) {
      this.setState({ joinBusy: true, pm: false });
      fetch('/api/checkout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ kind: 'member', plan: '1m', email: this.state.prof.email, back: 'dashboard' }) })
        .then(r => r.json()).then(j => { if (j && j.url) location.href = j.url; else { this.setState({ joinBusy: false }); this.toast('Checkout did not open', 'Try again in a minute.'); } })
        .catch(() => { this.setState({ joinBusy: false }); this.toast('Checkout did not open', 'Check your connection and try again.'); });
      return;
    }
    location.href = '/claim';
  }
  addCharge() {
    const s = this.state; if (s.rqBusy) return;
    const co = (s.rqCo || '').trim().replace(/\s+/g, ' '), what = (s.rqWhat || '').trim(), a = (s.rqAmt || '').replace(/[$,\s]/g, '');
    if (co.length < 2) { this.setState({ rqErr: 'Enter the company that charged you' }); return; }
    if (a && !(+a > 0 && +a < 100000)) { this.setState({ rqErr: 'Enter the amount, like 39.99' }); return; }
    if (what.length < 3) { this.setState({ rqErr: 'Tell us what happened' }); return; }
    const amount = a ? Math.round(+a * 100) / 100 : null;
    const done = (r) => { this.setState({ rq: [r].concat(this.state.rq || []), rqCo: '', rqAmt: '', rqWhat: '', rqErr: '', rqBusy: false }); this.toast('Refund request sent', 'We will ask ' + co + ' for your money back and keep you posted.'); };
    if (this._db && this._sb && this._uid) {
      this.setState({ rqBusy: true, rqErr: '' });
      this._sb.from('refund_requests').insert({ user_id: this._uid, company: co, amount, what }).select().then(({ data, error }) => {
        if (error) { this.setState({ rqBusy: false, rqErr: /row-level|policy/i.test(error.message) ? 'Refunds are part of membership.' : 'Could not send that. Try again.' }); return; }
        done((data && data[0]) || { company: co, amount, what, status: 'requested', created_at: new Date().toISOString() });
      });
      return;
    }
    done({ company: co, amount, what, status: 'requested', created_at: new Date().toISOString() });
  }
  hubVals(all, ready, track) {
    const s = this.state, member = !!s.plan, D = HUBD;
    const m2 = (n) => '$' + Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const m0 = (n) => '$' + Math.round(n || 0).toLocaleString('en-US');
    const sum = (a) => a.reduce((t, r) => t + (r.n || 0), 0);
    const live = all.filter(r => r.st !== 'gone' && r.st !== 'denied'), paid = live.filter(r => r.st === 'paid'), prog = live.filter(r => r.st && r.st !== 'ready' && r.st !== 'paid');
    const steps = this.setup(), left = steps.filter(x => !s.acct[x.id]).length, pct = this.setupPctNow();
    const ringSt = (sz) => { const r = sz / 2 - 3, C = 2 * Math.PI * r; return 'stroke-dasharray:' + C.toFixed(1) + ';stroke-dashoffset:' + (C * (1 - pct / 100)).toFixed(1); };
    const vSt = (c) => 'font-size:28px;letter-spacing:-0.8px;color:' + c;
    const grey = '#8A968F', first = ((s.prof.name || '').split(' ')[0]) || '';
    const rq = (s.rq || []).filter(r => r.status !== 'removed'), rqOpen = rq.filter(r => r.status === 'requested' || r.status === 'replied'), rqDone = rq.filter(r => r.status === 'refunded');
    const rsum = (a) => a.reduce((t, r) => t + (+r.amount || 0), 0);
    const urgent = ready.filter(r => r.days > 0 && r.days <= 7).length;
    const btnSt = (k) => 'min-height:38px;padding:0 16px;border-radius:99px;font-size:13.5px;font-weight:800;white-space:nowrap;' + ({ mint: 'background:#3DDC97;color:#0A0F0D', dark: 'background:#0A0F0D;color:#FFFFFF', soft: 'background:#EEF2F0;color:#0A0F0D' })[k];
    const T = [];
    if (ready.length) T.push({ d: D.file, t: 'File ' + ready.length + (ready.length === 1 ? ' claim' : ' claims'), sub: (sum(ready) ? 'Worth up to ' + m0(sum(ready)) + '. ' : '') + (urgent ? urgent + (urgent === 1 ? ' closes' : ' close') + ' this week.' : 'We file them for you.'), where: 'Your claims', btn: 'File now', k: 'mint', tap: () => this.go('dash') });
    if (left) T.push({ d: D.user, t: 'Finish your account', sub: left + (left === 1 ? ' step' : ' steps') + ' left so we can file for you faster.', where: 'Your info', btn: 'Finish', k: 'soft', tap: () => this.goInfo() });
    if (member && !rq.length) T.push({ d: D.receipt, t: 'Get money back from a bad charge', sub: 'Charged after you canceled, or twice? Add it and we fight it.', where: 'Claim a refund', btn: 'Add charge', k: 'dark', tap: () => this.go('refunds') });
    if (!member) { T.push({ locked: 1, d: D.map, t: 'Claims near you', sub: 'Local settlements for every place you have lived.', where: 'Find claims' }); T.push({ locked: 1, d: D.receipt, t: 'Get money back from bad charges', sub: 'Members add a charge and we fight it for them.', where: 'Claim a refund' }); }
    const todo = T.map(t => Object.assign({}, t, { open: !t.locked, locked: !!t.locked, btnSt: t.k ? btnSt(t.k) : '', tap: t.tap || (() => {}),
      icSt: 'width:40px;height:40px;flex:none;border-radius:12px;display:flex;align-items:center;justify-content:center;' + (t.locked ? 'background:#EEF2F0;color:#8A968F' : 'background:#E9F6EF;color:#12805C'),
      tSt: 'font-size:15px;color:' + (t.locked ? '#43504A' : '#0A0F0D') }));
    const openN = todo.filter(t => t.open).length;
    // recent activity
    const AL = { requested: 'filing request sent', needs_info: 'needs a few more details', filed: 'filed with the administrator', review: 'in review', approved: 'approved', paid: 'paid' }, M = this._meta || {};
    const fd = (iso) => iso ? new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '';
    const act = live.filter(r => AL[r.st]).map(r => ({ t: r.co + ' claim ' + AL[r.st], d: fd((M[r.id] || {}).filedAt || (M[r.id] || {}).requestedAt) || 'Updated' }))
      .concat(rq.map(r => ({ t: 'Refund request sent to ' + r.company, d: fd(r.created_at) }))).slice(0, 4);
    act.push({ t: member ? 'You joined Claimclub' : 'Filing fee paid', d: s.joinedOn || '' });
    // expected payouts by month
    const MO = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], now = new Date();
    const filed = live.filter(r => r.st && r.st !== 'ready'), locked = !filed.length;
    let span = 6; const idxOf = (r) => { const d = new Date(Date.now() + (Math.max(0, r.days) + 120) * 864e5); return (d.getFullYear() - now.getFullYear()) * 12 + d.getMonth() - now.getMonth(); };
    filed.forEach(r => { if (r.st !== 'paid' && r.kind !== 'arb') span = Math.max(span, Math.min(9, idxOf(r) + 1)); });
    const bars = Array.from({ length: span }, (_, i) => ({ mo: MO[(now.getMonth() + i) % 12], v: 0, paid: 0 }));
    if (locked) [40, 140, 100, 95, 40, 180].forEach((v, i) => { bars[i].v = v; });
    else filed.forEach(r => { if (r.st === 'paid') { bars[0].paid += r.n || 0; return; } if (r.kind === 'arb') return; bars[Math.max(0, Math.min(span - 1, idxOf(r)))].v += r.n || 0; });
    const mx = Math.max.apply(null, bars.map(b => b.v + b.paid).concat([1]));
    const pyBars = bars.map(b => { const v = b.v + b.paid;
      return { mo: b.mo, l: m0(v), lSt: 'font-size:11.5px;white-space:nowrap;color:' + (v ? '#0A0F0D' : '#B9C6BF'), st: 'width:100%;border-radius:8px 8px 4px 4px;height:' + Math.max(6, Math.round(v / mx * 120)) + 'px;background:' + (b.paid && !b.v ? '#0F3B2E' : v ? '#3DDC97' : '#EEF2F0') }; });
    const tot = sum(live.filter(r => r.st !== 'paid'));
    const pages = { home: ['Hi' + (first ? ' ' + first : ''), openN ? openN + (openN === 1 ? ' thing' : ' things') + ' to do. Everything else we handle.' : (member ? 'Nothing needs you right now. We are on it.' : 'Your claims are filed. We will tell you when each one pays.')],
      dash: ['Your claims', ready.length ? 'You have ' + ready.length + (ready.length === 1 ? ' claim' : ' claims') + ' ready to file' + (sum(ready) ? ', worth up to ' + m0(sum(ready)) + '.' : '.') : 'Everything is filed. We are tracking ' + track.length + ' claims for you.'],
      all: ['Find claims', this.sets().filter(d => this.daysTo(d.dl) > 0 && !d.st).length + ' open settlements, checked every day.' + (member ? '' : ' Members see every one.')],
      refunds: ['Claim a refund', member ? 'Tell us about a bad charge and we fight it for you. You approve each one.' : 'Get money back from charges you should not have paid.'],
      subs: ['Subscription Manager', 'Everything you pay for every month, from your connected cards.'],
      info: ['Your info', "Saved once, used on every claim you file. We only send a claim's administrator what its form asks for."],
      settings: ['Settings', 'Make Claimclub look and work the way you like.'] };
    const pg = pages[s.view] || pages.home;
    const SEG = ['Requested', 'Company replied', 'Refunded'], SI = { requested: 0, replied: 1, refunded: 2 };
    return {
      isHome: s.view === 'home', isRefunds: s.view === 'refunds', isSubs: s.view === 'subs', pageTitle: pg[0], pageSub: pg[1],
      goHome: () => this.go('home'), goRefunds: () => this.go('refunds'), goSubs: () => this.go('subs'),
      pmOpen: !!s.pm, togglePm: () => this.setState({ pm: !s.pm }), closePm: () => this.setState({ pm: false }),
      pmInfo: () => { this.setState({ pm: false }); this.goInfo(); }, pmSet: () => this.setState({ view: 'settings', pm: false }), pmMem: () => { if (member) this.setState({ pm: false, mm: 'home', mmPick: '' }); else this.join(); },
      pmName: s.prof.name || s.prof.email || 'Your account', pmShort: first || 'Account', pmPct: pct >= 100 ? 'Account complete' : 'Account ' + pct + '% complete', pmPctSt: 'font-size:12px;font-weight:700;color:' + (pct >= 100 ? '#12805C' : '#5B6862'),
      pmInfoTag: left ? left + ' left' : 'Complete', pmInfoSt: 'color:' + (left ? '#B07A12' : '#12805C'), pmMemTag: member ? (s.cancelled ? 'Ending' : 'Active') : 'Join', pmMemSt: 'color:' + (member ? '#12805C' : '#B07A12'),
      ring38: ringSt(38), ring44: ringSt(44),
      join: () => this.join(), joinLabel: s.joinBusy ? 'Opening...' : 'Join for $7.99', joinLabelLong: s.joinBusy ? 'Opening checkout...' : 'Join for $7.99 your first month',
      feeHead: 'You paid the filing fee for ' + live.length + (live.length === 1 ? ' claim' : ' claims'),
      hStats: [
        { t: 'Paid to you', d: D.check, v: m2(sum(paid)), vSt: vSt(paid.length ? '#12805C' : grey), sub: paid.length ? paid.length + (paid.length === 1 ? ' claim paid' : ' claims paid') : 'Your first payout shows here' },
        { t: 'In progress', d: D.clock, v: m2(sum(prog)), vSt: vSt(prog.length ? '#2C4FA8' : grey), sub: prog.length ? prog.length + (prog.length === 1 ? ' claim filed' : ' claims filed') : ready.length ? ready.length + ' ready to file' : 'Nothing filed yet' },
        member ? { t: 'Subscriptions', d: D.repeat, v: 'Not set up', vSt: vSt(grey), sub: 'Card connections open soon' } : { t: 'Subscriptions', d: D.lock, v: 'Members only', vSt: vSt(grey), sub: 'Join to see what you pay for' }],
      todo, todoN: openN ? String(openN) : '', todoNone: member && !openN,
      hTotal: m2(tot), hTotalSt: 'display:block;font-size:40px;letter-spacing:-1.5px;margin:4px 0 14px;color:' + (tot ? '#0A0F0D' : '#8A968F'), hHasClaims: live.length > 0, hNoClaims: !live.length,
      hRefundsT: rqOpen.length ? m2(rsum(rqOpen)) + ' requested' : 'Add a charge', hAct: act,
      pyBars, pyLocked: locked, pyWrapSt: locked ? 'filter:blur(7px);opacity:.55;pointer-events:none' : '',
      pySub: locked ? 'Shows up once you file a claim' : 'Estimates for ' + filed.length + (filed.length === 1 ? ' filed claim' : ' filed claims') + ', from each settlement timeline',
      pyCta: ready.length ? 'File ' + ready.length + (ready.length === 1 ? ' claim' : ' claims') : 'Find claims', pyGo: () => this.go(ready.length ? 'dash' : 'all'),
      pyNudge: !locked && ready.length > 0, pyNudgeT: ready.length + (ready.length === 1 ? ' claim is' : ' claims are') + ' ready to file' + (sum(ready) ? ', worth up to ' + m0(sum(ready)) + '.' : '.'),
      rStats: [
        { t: 'Worth fighting', d: D.hand, v: '$0.00', vSt: vSt(grey), sub: 'Card connections open soon' },
        { t: 'Not sure', d: D.help, v: '0 charges', vSt: vSt(grey), sub: 'Nothing to check' },
        { t: 'In progress', d: D.clock, v: m2(rsum(rqOpen)), vSt: vSt(rqOpen.length ? '#2C4FA8' : grey), sub: rqOpen.length ? rqOpen.length + (rqOpen.length === 1 ? ' request' : ' requests') : 'No requests yet' },
        { t: 'Refunded', d: D.check, v: m2(rsum(rqDone)), vSt: vSt(rqDone.length ? '#12805C' : grey), sub: rqDone.length ? rqDone.length + ' so far' : 'Nothing yet' }],
      sStats: [
        { t: 'Per month', d: D.repeat, v: 'Not set up', vSt: vSt(grey), sub: 'Connect a card to see' },
        { t: 'Not used', d: D.ban, v: '$0.00', vSt: vSt(grey), sub: 'Nothing to cut yet' },
        { t: 'Next renewal', d: D.cal, v: 'None yet', vSt: vSt(grey), sub: 'We remind you before each one' }],
      rqList: rq.map(r => { const at = SI[r.status] ?? 0, den = r.status === 'denied';
        return { co: r.company, amt: r.amount ? m2(+r.amount) : '', what: r.what,
          segs: SEG.map((l, i) => ({ l: den && i === 2 ? 'Not refunded' : l, bar: 'display:block;height:5px;border-radius:99px;background:' + (den && i === 2 ? '#E5484D' : i <= at ? '#12805C' : '#E3EAE6'), lt: 'font-size:11px;font-weight:700;white-space:nowrap;color:' + (i <= at ? '#0A0F0D' : '#8A968F') })) }; }),
      rqN: rqOpen.length ? String(rqOpen.length) : '', rqNone: !rq.length,
      rqCo: s.rqCo || '', rqAmt: s.rqAmt || '', rqWhat: s.rqWhat || '', rqErr: s.rqErr || '', hasRqErr: !!s.rqErr, rqBusy: !!s.rqBusy, rqIdle: !s.rqBusy,
      rqFormSt: s.rqFocus ? 'box-shadow:0 0 0 2px #12805C,0 0 0 6px rgba(61,220,151,.25)' : '',
      onRqCo: (e) => this.setState({ rqCo: e.target.value, rqErr: '' }), onRqAmt: (e) => this.setState({ rqAmt: e.target.value, rqErr: '' }), onRqWhat: (e) => this.setState({ rqWhat: e.target.value, rqErr: '' }),
      addCharge: () => this.addCharge(),
      focusAdd: () => { this.setState({ rqFocus: true }); try { const f = document.querySelector('.addC'); if (f) { f.scrollIntoView({ behavior: 'smooth', block: 'center' }); const i = f.querySelector('input'); if (i) i.focus({ preventScroll: true }); } } catch (e) {} clearTimeout(this._rf); this._rf = setTimeout(() => this.setState({ rqFocus: false }), 1800); },
      cardSoon: () => this.toast('Card connections open soon', 'We will email you the day you can connect a card. Until then, add a charge yourself.')
    };
  }
  renderVals() {'''
JS = JS.replace('HUBD', '{' + ', '.join(f"{k}: '{v}'" for k, v in D.items() if k in ('file', 'user', 'receipt', 'map', 'check', 'clock', 'repeat', 'lock', 'hand', 'help', 'ban', 'cal')) + '}')
assert "'''" not in JS
R("\n  renderVals() {", JS.replace("\\", "\\\\"), 1)
# goInfo already exists as a method. Also make goDash/goAll close the menu and use go().
R("goDash: () => this.setState({ view: 'dash' }),", "goDash: () => this.go('dash'),")
R("goSet: () => this.setState({ view: 'settings' }),", "goSet: () => this.go('settings'),")

# samples (blurred previews for non-members) and sidebar markup are inserted as Python constants
s = s.replace("A=HEAD%(", "SIDE_NEW=" + repr(SIDE).replace("'\\x02'", "'+LOGO_SIDE+'").replace('\\x02', "'+LOGO_SIDE+'") + "\nNAVNEW=" + repr(NAVNEW) + "\nA=HEAD%(", 1)
logo_src = re.search(r"    h\+=f'(<div style=\"display: flex; align-items: center; gap: 8px; padding: 0 8px 18px\">.*?</div>)'\n", s).group(1)
s = s.replace("SIDE_NEW=", "LOGO_SIDE=f'" + logo_src + "'\nSIDE_NEW=", 1)
noimg = lambda h: re.sub(r'<img src="data:[^"]*" alt="" style="([^"]*)">', lambda m: '<span style="' + m.group(1) + '; background: #DDE5E0"></span>', h)
SAMPLE_R_D, SAMPLE_R_M, SAMPLE_S_D, SAMPLE_S_M = map(noimg, (SAMPLE_R_D, SAMPLE_R_M, SAMPLE_S_D, SAMPLE_S_M))
open('/home/claude/cc/concepts/hub_samples.py', 'w').write('SAMPLE_R_D = ' + repr(SAMPLE_R_D) + '\nSAMPLE_R_M = ' + repr(SAMPLE_R_M) + '\nSAMPLE_S_D = ' + repr(SAMPLE_S_D) + '\nSAMPLE_S_M = ' + repr(SAMPLE_S_M) + '\n')
s = s.replace("A=themed(A); AM=themed(AM)", "from hub_samples import SAMPLE_R_D, SAMPLE_R_M, SAMPLE_S_D, SAMPLE_S_M\nA=A.replace('%%SAMPLE_R%%',SAMPLE_R_D).replace('%%SAMPLE_S%%',SAMPLE_S_D); AM=AM.replace('%%SAMPLE_R%%',SAMPLE_R_M).replace('%%SAMPLE_S%%',SAMPLE_S_M)\nA=themed(A); AM=themed(AM)", 1)
open(P, 'w').write(s)
print('patched', len(s))
