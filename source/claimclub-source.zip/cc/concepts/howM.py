# Three mobile layouts for "How Claimclub works" that don't need a sideways swipe: HowM1..HowM3.dc.html (390 wide boards).
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import how4
from how4 import iphone, ic, STEPS, HEAD, OUT, eyebrow

SCR = how4.screens(True)
HEADER = ('<div style="display: flex; flex-direction: column; align-items: center; gap: 10px; text-align: center; padding: 0 22px">' + eyebrow(c='#3DDC97') +
          '<h2 style="margin: 0; font-size: 30px; line-height: 1.08; letter-spacing: -1px">Three steps, then the settlement pays you.</h2>'
          '<p style="margin: 0; font-size: 15px; line-height: 1.5; color: #C9D6CF">We do the paperwork. You get paid when each settlement pays out.</p></div>')
num = lambda i: f'<span style="width: 28px; height: 28px; flex: none; border-radius: 50%; background: #3DDC97; color: #0F3B2E; font-weight: 800; font-size: 14px; display: flex; align-items: center; justify-content: center">{i+1}</span>'

def cropped(i, zoom, show, fade=True):
    """Phone i (rendered at 250px) scaled by zoom, showing only the top `show` px (scaled), fading at the bottom."""
    inner = show / zoom
    mask = '-webkit-mask-image: linear-gradient(180deg, #000 70%, transparent); mask-image: linear-gradient(180deg, #000 70%, transparent);' if fade else ''
    return f'<div style="zoom: {zoom}; width: 250px; height: {inner:.0f}px; overflow: hidden; flex: none; {mask}">{iphone(SCR[i], 250)}</div>'

def m1():  # three short rows: small cropped phone + text
    rows = ''.join(
        f'<div style="display: flex; gap: 16px; align-items: center; padding: 18px; border-radius: 22px; background: rgba(255,255,255,.06); box-shadow: inset 0 0 0 1px rgba(255,255,255,.08)">'
        f'{cropped(i, .54, 200)}'
        f'<div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 8px">{num(i)}<h3 style="margin: 0; font-size: 18px; line-height: 1.2; letter-spacing: -.3px">{t}</h3><p style="margin: 0; font-size: 13.5px; line-height: 1.5; color: #C9D6CF">{d}</p></div></div>'
        for i, (k, t, d, tag) in enumerate(STEPS))
    return f'<section class="meshDark" style="color: #FFFFFF; padding: 44px 16px 40px; display: flex; flex-direction: column; gap: 26px">{HEADER}<div style="display: flex; flex-direction: column; gap: 12px">{rows}</div></section>'

def m2():  # one sticky phone; the screen changes as each step scrolls past
    stack = ''.join(f'<div class="hmS hmS{i}" style="position: absolute; inset: 0; transition: opacity .35s ease, transform .35s ease">{iphone(SCR[i], 250)}</div>' for i in range(3))
    phone = (f'<div style="position: sticky; top: 0; z-index: 2; padding: 14px 0 0; display: flex; justify-content: center; background: linear-gradient(180deg, #11402F 82%, rgba(17,64,47,0))">'
             f'<div style="zoom: .86; position: relative; width: 250px; height: 380px; overflow: hidden; -webkit-mask-image: linear-gradient(180deg, #000 78%, transparent); mask-image: linear-gradient(180deg, #000 78%, transparent)">{stack}</div></div>')
    dots = '<div style="display: flex; justify-content: center; gap: 6px; margin-top: -6px; position: sticky; top: 336px; z-index: 3">' + ''.join(f'<span class="hmD hmD{i}" style="width: 8px; height: 8px; border-radius: 99px; background: rgba(255,255,255,.3); transition: all .3s"></span>' for i in range(3)) + '</div>'
    steps = ''.join(f'<div class="hmStep" data-i="{i}" style="min-height: 300px; padding: 26px 22px 0; display: flex; flex-direction: column; gap: 10px">{num(i)}<h3 style="margin: 0; font-size: 22px; letter-spacing: -.4px">{t}</h3><p style="margin: 0; font-size: 15px; line-height: 1.55; color: #C9D6CF">{d}</p></div>' for i, (k, t, d, tag) in enumerate(STEPS))
    css = '<style>.hmWrap .hmS{opacity:0;transform:translateY(14px)}' + ''.join(f'.hmWrap[data-s="{i}"] .hmS{i}{{opacity:1;transform:none}}.hmWrap[data-s="{i}"] .hmD{i}{{background:#3DDC97;width:22px}}' for i in range(3)) + '</style>'
    return f'{css}<section class="meshDark hmWrap" data-s="0" style="color: #FFFFFF; padding: 44px 0 30px">{HEADER}<div style="height: 18px"></div>{phone}{dots}{steps}</section>'

def m3():  # three phones stacked, each cropped to the top half, text above
    blocks = ''.join(
        f'<div style="display: flex; flex-direction: column; align-items: center; gap: 16px; text-align: center">'
        f'<div style="display: flex; flex-direction: column; align-items: center; gap: 8px; padding: 0 22px">{num(i)}<h3 style="margin: 0; font-size: 21px; letter-spacing: -.4px">{t}</h3><p style="margin: 0; font-size: 14.5px; line-height: 1.5; color: #C9D6CF">{d}</p></div>'
        f'{cropped(i, .9, 300)}</div>'
        for i, (k, t, d, tag) in enumerate(STEPS))
    return f'<section class="meshDark" style="color: #FFFFFF; padding: 44px 0 28px; display: flex; flex-direction: column; gap: 30px">{HEADER}<div style="display: flex; flex-direction: column; gap: 34px">{blocks}</div></section>'

VARIANTS = [('HowM1', 'How it works on phones · 1 · Three short rows', m1), ('HowM2', 'How it works on phones · 2 · One phone, screen changes as you scroll', m2), ('HowM3', 'How it works on phones · 3 · Three phones stacked', m3)]

JS = '''<script type="text/x-dc" data-dc-script data-props='{"$preview":{"width":390,"height":844}}'>
class Component extends DCLogic {
  renderVals() { return {}; }
  componentDidMount() {
    const w = document.querySelector('.hmWrap'); if (!w || !('IntersectionObserver' in window)) return;
    const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) w.setAttribute('data-s', e.target.dataset.i); }), { rootMargin: '-55% 0px -40% 0px' });
    w.querySelectorAll('.hmStep').forEach((s) => io.observe(s));
  }
}
</script>
</body>
</html>
'''

def page(fn, title):
    body = (f'<div style="width: 390px; height: 844px; overflow-y: auto; background: #FFFFFF; font-family: \'Manrope\', sans-serif" class="scroll">'
            '<div style="padding: 22px 16px 26px; font-size: 13px; color: #5B6862; font-weight: 600; text-align: center">(page above: settlements)</div>'
            f'{fn()}<div style="padding: 26px 16px 300px; font-size: 13px; color: #5B6862; font-weight: 600; text-align: center">(page below: reviews, pricing)</div></div>\n</x-dc>\n')
    return HEAD % title + body + JS

def build():
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    y0 = max(b['y'] + b['h'] for k, b in c['boards'].items() if not k.startswith('HowM')) + 260
    c['notes']['tHM'] = {'x': 0, 'y': y0, 'text': 'How it works on phones · 3 options with no sideways swipe (scroll inside each)', 'kind': 'title1', 'maxW': 1400, 'w': 240}
    if 'tHM' not in c['noteOrder']: c['noteOrder'].append('tHM')
    for k, (name, title, fn) in enumerate(VARIANTS):
        open(os.path.join(OUT, name + '.dc.html'), 'w').write(page(fn, title))
        c['boards'][name + '.dc.html'] = {'x': k * 470, 'y': y0 + 220, 'w': 390, 'h': 844, 'is_interactive': True, 'title': title}
        if name + '.dc.html' not in c['order']: c['order'].append(name + '.dc.html')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w'))
    print('built', [v[0] for v in VARIANTS], 'y0', y0)

if __name__ == '__main__':
    build()
