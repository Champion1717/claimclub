import re
s=open('make.py').read()
def rep(o,n,src=None):
    global s
    assert o in s,o[:90]; s=s.replace(o,n,1)
i=s.index('# ---------------- A: Inbox'); j=s.index('# ---------------- B: Pipeline'); A=s[i:j]
def ra(o,n):
    global A
    assert o in A,o[:90]; A=A.replace(o,n,1)
# pill one line
ra('padding: 4px 10px; border-radius: 99px; background: #FDECEC; color: #B8333A">{{ urgentN }} closing this week','padding: 4px 10px; border-radius: 99px; background: #FDECEC; color: #B8333A; white-space: nowrap; flex: none">{{ urgentN }} closing this week')
# ready row: subtle marker for multi-step claims
ra('<div class="hideS" style="min-width: 0; font-size: 12px; color: #43504A">{{ r.kindNote }}</div>','<div class="hideS" style="min-width: 0; font-size: 12px; color: #43504A; display: flex; align-items: center; gap: 6px"><sc-if value="{{ r.needs }}" hint-placeholder-val="{{ false }}"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8A5A00" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9 M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"></path></svg></sc-if>{{ r.kindNote }}</div>')
# main wrapper + views
m0=A.index('  <main class="scroll amain"'); m1=A.index('>',m0)+1
mainTag=A[m0:m1].replace('display: flex; flex-direction: column; gap: 14px','display: block')
end=A.index('  </main>')
body=A[m1:end]
SETTINGS='''
    <sc-if value="{{ isSet }}" hint-placeholder-val="{{ false }}">
      <div style="display: flex; flex-direction: column; gap: 4px"><h1 style="margin: 0; font-size: 22px; letter-spacing: -0.5px">Settings</h1><span style="font-size: 13px; color: #5B6862">Make Claimclub look and work the way you like.</span></div>
      <section style="background: #FFFFFF; border-radius: 18px; box-shadow: 0 0 0 1px #E3EAE6; padding: 16px; display: flex; flex-direction: column; gap: 12px">
        <div style="display: flex; flex-direction: column; gap: 2px"><h2 style="margin: 0; font-size: 16px">Display size</h2><span style="font-size: 12px; color: #5B6862">Changes the size of text and cards on your dashboard. It saves on this device.</span></div>
        <div style="display: flex; gap: 10px"><sc-for list="{{ scales }}" as="z" hint-placeholder-count="3"><button onClick="{{ z.tap }}" aria-pressed="{{ z.on }}" style="{{ z.st }}"><span style="{{ z.aa }}">Aa</span>{{ z.t }}</button></sc-for></div>
      </section>
      <section style="background: #FFFFFF; border-radius: 18px; box-shadow: 0 0 0 1px #E3EAE6; padding: 6px 16px">
        <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 0; border-bottom: 1px solid #EEF2F0"><div style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 14px; font-weight: 800">Text alerts</span><span style="font-size: 12px; color: #5B6862">Approvals, payouts and new matches</span></div><span style="width: 42px; height: 24px; border-radius: 99px; background: #12805C; position: relative; flex: none"><span style="position: absolute; right: 3px; top: 3px; width: 18px; height: 18px; border-radius: 50%; background: #FFFFFF"></span></span></div>
        <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 0; border-bottom: 1px solid #EEF2F0"><div style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 14px; font-weight: 800">Email receipts</span><span style="font-size: 12px; color: #5B6862">A copy of every claim we file</span></div><span style="width: 42px; height: 24px; border-radius: 99px; background: #12805C; position: relative; flex: none"><span style="position: absolute; right: 3px; top: 3px; width: 18px; height: 18px; border-radius: 50%; background: #FFFFFF"></span></span></div>
        <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 0"><div style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 14px; font-weight: 800">Membership</span><span style="font-size: 12px; color: #5B6862">Monthly · $9.99/month</span></div><button style="min-height: 34px; padding: 0 14px; border-radius: 99px; background: #EEF2F0; color: #0A0F0D; font-size: 13px; font-weight: 800">Manage membership</button></div>
      </section>
    </sc-if>
'''
A=A[:m0]+mainTag+'\n    <div style="{{ zoomSt }}">\n    <sc-if value="{{ isDash }}" hint-placeholder-val="{{ true }}">'+body+'    </sc-if>'+SETTINGS+'    </div>\n'+A[end:]
# sheet markup + css
A=A.replace("A_CSS='.arow","A_CSS='@keyframes shFade{from{opacity:0}}@keyframes shPop{from{opacity:0;transform:translateY(18px) scale(.98)}}\\n.arow",1)
A=A.replace("side(0)+","sideA()+",1)
assert "+NOTE+'</div>\\n'+TAIL" in A
A=A.replace("+NOTE+'</div>\\n'+TAIL","+SHEET+NOTE+'</div>\\n'+TAIL",1)
s=s[:i]+A+s[j:]
CHECK='<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>'
SHEET='''  <sc-if value="{{ sheetOpen }}" hint-placeholder-val="{{ false }}"><div class="shWrap" style="position: absolute; inset: 0; z-index: 40; background: rgba(10,15,13,.45); display: flex; align-items: center; justify-content: center; animation: shFade .2s ease both">
    <div class="shCard" role="dialog" aria-modal="true" aria-label="File your {{ sh.co }} claim" style="width: 560px; max-width: calc(100% - 32px); max-height: calc(100% - 48px); display: flex; flex-direction: column; background: #FFFFFF; border-radius: 24px; box-shadow: 0 30px 80px rgba(0,0,0,.3); overflow: hidden; animation: shPop .3s cubic-bezier(.2,.9,.3,1.1) both">
      <div style="padding: 18px 20px 14px; display: flex; flex-direction: column; gap: 14px; border-bottom: 1px solid #EEF2F0">
        <div style="display: flex; align-items: center; gap: 12px"><img src="{{ sh.logo }}" alt="" style="width: 40px; height: 40px; flex: none; border-radius: 12px; padding: 6px; box-sizing: border-box; object-fit: contain; box-shadow: inset 0 0 0 1px #E3EAE6"><div style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-size: 16px; font-weight: 800">{{ sh.co }} <span style="color: #12805C">{{ sh.amt }}</span></span><span style="font-size: 12px; color: #5B6862">{{ sh.title }}</span></div><button onClick="{{ sh.close }}" aria-label="Close" style="width: 32px; height: 32px; flex: none; border-radius: 50%; background: #EEF2F0; color: #0A0F0D; display: flex; align-items: center; justify-content: center"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18 M6 6l12 12"></path></svg></button></div>
        <div style="display: flex; flex-direction: column; gap: 8px"><div style="display: flex; gap: 4px"><sc-for list="{{ sh.dots }}" as="d" hint-placeholder-count="3"><span style="{{ d.st }}"></span></sc-for></div><span style="font-size: 12px; font-weight: 800; color: #5B6862">STEP {{ sh.step }} OF 3 · <span style="color: #0A0F0D">{{ sh.stepTitle }}</span></span></div>
      </div>
      <div class="scroll" style="flex-grow: 1; min-height: 0; overflow-y: auto; padding: 18px 20px; display: flex; flex-direction: column; gap: 16px">
        <sc-if value="{{ sh.s1 }}" hint-placeholder-val="{{ true }}">
          <sc-for list="{{ sh.qs }}" as="q" hint-placeholder-count="2"><div style="display: flex; flex-direction: column; gap: 10px"><span style="font-size: 15px; font-weight: 700; line-height: 1.4">{{ q.t }}</span><div style="display: flex; gap: 8px"><button onClick="{{ q.yes }}" style="{{ q.yesSt }}">Yes</button><button onClick="{{ q.no }}" style="{{ q.noSt }}">No</button></div></div></sc-for>
          <sc-if value="{{ sh.anyNo }}" hint-placeholder-val="{{ false }}"><div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 14px; border-radius: 14px; background: #FFF4DB; color: #6B4600; font-size: 13px; line-height: 1.45"><span>Based on this answer you probably don't qualify. Filing anyway could get your claim rejected.</span><button onClick="{{ sh.remove }}" style="flex: none; min-height: 32px; padding: 0 12px; border-radius: 99px; background: #FFFFFF; color: #6B4600; font-size: 12px; font-weight: 800">Remove claim</button></div></sc-if>
        </sc-if>
        <sc-if value="{{ sh.s2 }}" hint-placeholder-val="{{ false }}">
          <sc-for list="{{ sh.fields }}" as="f" hint-placeholder-count="2"><div style="display: flex; flex-direction: column; gap: 8px">
            <div style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 15px; font-weight: 800">{{ f.label }}<sc-if value="{{ f.optional }}" hint-placeholder-val="{{ false }}"> <span style="font-size: 12px; font-weight: 700; color: #8A968F">Optional</span></sc-if></span><span style="font-size: 12px; color: #5B6862">{{ f.hint }}</span></div>
            <sc-if value="{{ f.isChips }}" hint-placeholder-val="{{ true }}"><div style="display: flex; flex-wrap: wrap; gap: 8px"><sc-for list="{{ f.opts }}" as="o" hint-placeholder-count="4"><button onClick="{{ o.tap }}" style="{{ o.st }}">{{ o.o }}</button></sc-for></div></sc-if>
            <sc-if value="{{ f.isText }}" hint-placeholder-val="{{ false }}"><input type="text" value="{{ f.val }}" onChange="{{ f.onIn }}" placeholder="{{ f.ph }}" style="height: 44px; border-radius: 12px; border: 1.5px solid #DDE5E0; padding: 0 14px; font-size: 15px; font-family: inherit; font-weight: 600; color: #0A0F0D; background: #FFFFFF"></sc-if>
          </div></sc-for>
          <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px 14px; border-radius: 14px; background: #E9F6EF; font-size: 13px; font-weight: 800; color: #17603F"><span>Estimated payout</span><span style="font-size: 16px">{{ sh.est }}</span></div>
        </sc-if>
        <sc-if value="{{ sh.s3 }}" hint-placeholder-val="{{ false }}">
          <div style="display: flex; flex-direction: column; border-radius: 14px; box-shadow: inset 0 0 0 1px #E3EAE6; padding: 4px 14px">
            <div style="display: flex; justify-content: space-between; gap: 12px; padding: 10px 0; border-bottom: 1px solid #EEF2F0; font-size: 13px"><span style="color: #5B6862">Name</span><span style="font-weight: 800">Henry Sidwell</span></div>
            <div style="display: flex; justify-content: space-between; gap: 12px; padding: 10px 0; border-bottom: 1px solid #EEF2F0; font-size: 13px"><span style="color: #5B6862">Mailing address</span><span style="font-weight: 800">Saved in Your info</span></div>
            <div style="display: flex; justify-content: space-between; gap: 12px; padding: 10px 0; border-bottom: 1px solid #EEF2F0; font-size: 13px"><span style="color: #5B6862">Your answers</span><span style="font-weight: 800; text-align: right">{{ sh.summary }}</span></div>
            <div style="display: flex; justify-content: space-between; gap: 12px; padding: 10px 0; font-size: 13px"><span style="color: #5B6862">Estimated payout</span><span style="font-weight: 800; color: #12805C">{{ sh.est }}</span></div>
          </div>
          <div style="display: flex; flex-direction: column; gap: 8px"><span style="font-size: 15px; font-weight: 800">How should they pay you?</span><div style="display: flex; flex-wrap: wrap; gap: 8px"><sc-for list="{{ sh.pay }}" as="p" hint-placeholder-count="3"><button onClick="{{ p.tap }}" style="{{ p.st }}">{{ p.o }}</button></sc-for></div>
            <sc-if value="{{ sh.needBank }}" hint-placeholder-val="{{ false }}"><div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 10px 12px; border-radius: 12px; background: #FFF4DB; color: #6B4600; font-size: 13px"><span>Connect a bank to get direct deposit.</span><button onClick="{{ sh.connectBank }}" style="flex: none; min-height: 30px; padding: 0 12px; border-radius: 99px; background: #0A0F0D; color: #FFFFFF; font-size: 12px; font-weight: 800">Connect bank</button></div></sc-if></div>
          <button onClick="{{ sh.signTap }}" style="display: flex; align-items: flex-start; gap: 12px; padding: 12px 14px; border-radius: 14px; background: #F3F6F4; text-align: left; color: #0A0F0D"><span style="{{ sh.signBox }}"><sc-if value="{{ sh.sign }}" hint-placeholder-val="{{ false }}">'''+CHECK+'''</sc-if></span><span style="font-size: 13px; line-height: 1.45">I declare under penalty of perjury that this information is true, and I authorize Claimclub to submit this claim for me.</span></button>
        </sc-if>
      </div>
      <div style="display: flex; gap: 10px; padding: 14px 20px 18px; border-top: 1px solid #EEF2F0"><sc-if value="{{ sh.hasBack }}" hint-placeholder-val="{{ false }}"><button onClick="{{ sh.back }}" style="min-height: 46px; padding: 0 20px; border-radius: 99px; background: #EEF2F0; color: #0A0F0D; font-size: 15px; font-weight: 800">Back</button></sc-if><button onClick="{{ sh.next }}" style="{{ sh.nextSt }}">{{ sh.nextLabel }}</button></div>
    </div>
  </div></sc-if>
'''
ICONS={'Dashboard':'M3 3h7v9H3z M14 3h7v5h-7z M14 12h7v9h-7z M3 16h7v5H3z','All settlements':'M8 6h13 M8 12h13 M8 18h13 M3 6h.01 M3 12h.01 M3 18h.01','Your info':'M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2 M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z','Settings':'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-2.82 1.17V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-2.82-1.17l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 3 13.17H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.17-2.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9.91 3V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 2.82 1.17l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 21 9.91V10a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z'}
DEF="def sideA():\n    h=side(0)\n"
DEF+="    h=h.replace('<div style=\"display: flex; align-items: center; gap: 12px; padding: 11px 12px; border-radius: 12px; font-size: 15px; font-weight: 700; background: #EAF2EE; color: #0F3B2E\">','<button onClick=\"{{ goDash }}\" style=\"{{ navDash }}\">',1)\n"
DEF+="    i=h.index('<button onClick=\"{{ goDash }}\"'); k=h.index('</div>',i); h=h[:k]+'</button>'+h[k+6:]\n"
DEF+="    i=h.index('Settings</div>'); a=h.rindex('<div style=',0,i); h=h[:a]+'<button onClick=\"{{ goSet }}\" style=\"{{ navSet }}\">'+h[h.index('>',a)+1:i]+'Settings</button>'+h[i+len('Settings</div>'):]\n"
DEF+="    return h\n"
s=s.replace("NOTE='''",DEF+"SHEET="+repr(SHEET)+"\nNOTE='''",1)
# mobile nav clickable + css
s=s.replace(".amain{padding:14px 14px 20px !important;gap:12px !important}",".amain{padding:14px 14px 20px !important}.amain>div{gap:12px !important}\\n.shWrap{align-items:flex-end !important}.shCard{width:100% !important;max-width:none !important;max-height:92% !important;border-radius:22px 22px 0 0 !important}")
s=s.replace("assert TOP in AM and NAV in AM","""NAVC=NAV.replace('<span style="display: flex; flex-direction: column; align-items: center; gap: 3px; font-size: 11px; font-weight: 800; color: #0F3B2E">','<button onClick="{{ goDash }}" style="{{ mDash }}">',1)
NAVC=re.sub(r'(<button onClick="\\{\\{ goDash \\}\\}".*?)</span>',r'\\1</button>',NAVC,count=1,flags=re.S)
k=NAVC.index('Settings</span>'); a=NAVC.rindex('<span style=',0,k); NAVC=NAVC[:a]+'<button onClick="{{ goSet }}" style="{{ mSet }}">'+NAVC[NAVC.index('>',a)+1:k]+'Settings</button>'+NAVC[k+len('Settings</span>'):]
AM=AM.replace(NAV,NAVC,1)
assert TOP in AM and NAVC in AM""",1)
s=s.replace("for name,src in [('DashA',A),('DashAM',AM),('DashB',B),('DashC',C)]:","for name,src in [('DashA',A),('DashAM',AM)]:")
if 'import re' not in s.split('\n')[0]: s='import re\n'+s
open('make.py','w').write(s)
print('ok')
