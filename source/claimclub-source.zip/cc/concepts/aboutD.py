# How it works and About pages (Nov 21 2026, canvas only, not live). Same frame, nav and footer as the
# settlement pages drafts (setD.py), on the canvas page "Settlement pages". HowP = /how-it-works, AboutP = /about.
import os, json
from setD import (HEAD, JS, OUT, ic, LU, INK, MUTE, LINE, MINT, GREEN, DARK, BG, NAT, BY, tile, chip, btn, foot, desk, phone, pay)

LU.update({
    'heart': 'M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z',
    'eye': 'M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
    'lockk': 'M5 11h14a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2z M7 11V7a5 5 0 0 1 10 0v4',
    'bell2': 'M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9 M10.3 21a1.94 1.94 0 0 0 3.4 0',
    'pen': 'M12 20h9 M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z',
    'send': 'm22 2-7 20-4-9-9-4Z M22 2 11 13',
    'gavel': 'm14 13-7.5 7.5a2.12 2.12 0 0 1-3-3L11 10 m5 6 6-6 m-8-8 6 6 m-4.5-4.5L8 7 m9 9 3.5-3.5',
    'mail': 'M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z m18 2-10 7L2 6',
    'globe': 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20z M2 12h20 M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z',
    'refresh': 'M21 12a9 9 0 1 1-3-6.7L21 8 M21 3v5h-5',
    'building': 'M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2 M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2 M10 6h4 M10 10h4 M10 14h4 M10 18h4',
})
from setD import nav
from artIcons import art

def h2(t, m=False, c=INK, center=False):
    return f'<h2 style="margin: 0; font-size: {28 if m else 40}px; letter-spacing: -{.8 if m else 1.2}px; line-height: 1.1; color: {c}; {"text-align: center" if center else ""}">{t}</h2>'
def kick(t, c=GREEN, center=False):
    return f'<span style="font-size: 12.5px; font-weight: 800; letter-spacing: 1.2px; color: {c}; {"text-align: center" if center else ""}">{t}</span>'
def p(t, m=False, c='#43504A', center=False, mw=None):
    return f'<span style="font-size: {15.5 if m else 18}px; line-height: 1.55; color: {c}; font-weight: 600; {"text-align: center; align-self: center" if center else ""}; {"max-width: %dpx" % mw if mw else ""}">{t}</span>'

# ---------- step visuals (small product mockups) ----------
def v_question(m=False):
    return (f'<div style="width: {300 if m else 340}px; background: #FFFFFF; border-radius: 22px; padding: 20px; display: flex; flex-direction: column; gap: 12px; box-shadow: 0 20px 44px rgba(10,15,13,.14)">'
            f'<span style="display: flex; align-items: center; gap: 10px">{tile("visa", 40)}<span style="display: flex; flex-direction: column"><b style="font-size: 14px">Visa & Mastercard</b><span style="font-size: 12.5px; color: {GREEN}; font-weight: 800">Up to $1,000</span></span></span>'
            f'<b style="font-size: 17px; line-height: 1.3">Have you paid an ATM fee at an out-of-network ATM?</b>'
            f'<div style="display: flex; gap: 8px"><span style="flex: 1; height: 46px; border-radius: 14px; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; align-items: center; justify-content: center; gap: 6px; font-weight: 800">{ic("x", 16, "#B8333A", 2.6)}No</span>'
            f'<span style="flex: 1; height: 46px; border-radius: 14px; background: {MINT}; color: {DARK}; display: flex; align-items: center; justify-content: center; gap: 6px; font-weight: 800">{ic("ok", 16, DARK, 2.8)}Yes</span></div>'
            f'<span style="display: flex; gap: 4px">' + ''.join(f'<i style="flex: 1; height: 4px; border-radius: 4px; background: {GREEN if i < 3 else LINE}"></i>' for i in range(7)) + '</span></div>')
def v_matches(m=False):
    rows = [('apple', 'Apple', '$95'), ('visa', 'Visa & Mastercard', '$1,000'), ('googleplay', 'Google Play', '$100'), ('realpage', 'RealPage', '$100')]
    return (f'<div style="width: {300 if m else 340}px; background: #FFFFFF; border-radius: 22px; padding: 20px; display: flex; flex-direction: column; gap: 4px; box-shadow: 0 20px 44px rgba(10,15,13,.14)">'
            f'<span style="font-size: 11.5px; font-weight: 800; letter-spacing: 1.1px; color: {MUTE}">YOU COULD GET</span><b style="font-size: 36px; letter-spacing: -1.2px; color: {GREEN}; line-height: 1.1">Up to $1,295</b>'
            f'<span style="font-size: 13px; color: {MUTE}; font-weight: 700; margin-bottom: 8px">From 4 settlements you qualify for</span>'
            + ''.join(f'<span style="display: flex; align-items: center; gap: 10px; padding: 7px 0; border-top: 1px solid {LINE}">{tile(i, 30)}<b style="font-size: 14px; flex: 1">{n}</b><b style="font-size: 14px; color: {GREEN}">{v}</b></span>' for i, n, v in rows) + '</div>')
def v_filed(m=False):
    rows = [('apple', 'Apple', ('Filed', 'g')), ('visa', 'Visa & Mastercard', ('Filed', 'g')), ('googleplay', 'Google Play', ('Filing', 'n')), ('realpage', 'RealPage', ('Filing', 'n'))]
    return (f'<div style="width: {300 if m else 340}px; background: #FFFFFF; border-radius: 22px; padding: 20px; display: flex; flex-direction: column; gap: 4px; box-shadow: 0 20px 44px rgba(10,15,13,.14)">'
            f'<span style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px">{ic("pen", 16, GREEN, 2.3)}<b style="font-size: 14px">Signed by Ana Reyes</b><span style="margin-left: auto; font-size: 12px; color: {MUTE}; font-weight: 700">Nov 21</span></span>'
            + ''.join(f'<span style="display: flex; align-items: center; gap: 10px; padding: 8px 0; border-top: 1px solid {LINE}">{tile(i, 30)}<b style="font-size: 14px; flex: 1">{n}</b>{chip(s[0], s[1], "ok" if s[0] == "Filed" else "clock")}</span>' for i, n, s in rows) + '</div>')
def v_paid(m=False):
    note = lambda co, amt, t, op=1: (f'<div style="background: rgba(255,255,255,.94); border-radius: 18px; padding: 12px 14px; display: flex; gap: 10px; align-items: center; opacity: {op}; box-shadow: 0 10px 24px rgba(0,0,0,.18)">'
                                    f'<span style="width: 34px; height: 34px; border-radius: 9px; background: {DARK}; display: flex; align-items: center; justify-content: center; flex: none">{ic("ok", 18, MINT, 3)}</span>'
                                    f'<span style="display: flex; flex-direction: column; flex: 1; gap: 1px"><span style="display: flex"><b style="font-size: 12.5px; flex: 1; color: {MUTE}">CLAIMCLUB</b><span style="font-size: 12px; color: {MUTE}; font-weight: 600">{t}</span></span>'
                                    f'<b style="font-size: 14px">You got paid {amt}</b><span style="font-size: 13px; color: #43504A; font-weight: 600">{co} settlement sent it to your PayPal.</span></span></div>')
    return (f'<div style="width: {300 if m else 340}px; border-radius: 26px; padding: 26px 14px; display: flex; flex-direction: column; gap: 10px; background: radial-gradient(120% 120% at 20% 0%, #2B8A63, {DARK} 70%)">'
            f'<b style="font-size: 54px; color: #FFFFFF; text-align: center; letter-spacing: -1.5px; line-height: 1">9:41</b><span style="font-size: 13px; color: #CFE9DD; text-align: center; font-weight: 700; margin-bottom: 10px">Tuesday, June 8</span>'
            + note('Visa & Mastercard', '$212.40', 'now') + note('Apple', '$95.00', '2d ago', .85) + '</div>')

STEPS = [('01', 'Answer a few yes or no questions', 'One minute, no account needed. Each question is one settlement: did you buy this, use that, live here.', v_question),
         ('02', 'See what you could get', 'We match you to the open settlements you likely qualify for and show what each one pays. Checking is free.', v_matches),
         ('03', 'Sign once and we file', 'Your details go on every claim form. You agree once, and we file each claim and send you the claim numbers.', v_filed),
         ('04', 'The settlement pays you', 'Payouts come straight from each settlement, usually 6 to 12 months after its deadline. We tell you when money is on the way.', v_paid)]

def step_rows(m=False):
    out = ''
    for i, (n, t, b, v) in enumerate(STEPS):
        txt = (f'<div style="flex: 1; display: flex; flex-direction: column; gap: 12px; {"" if m else "max-width: 440px"}">'
               f'<span style="width: 44px; height: 44px; border-radius: 14px; background: {DARK}; color: {MINT}; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 16px">{n}</span>'
               f'<b style="font-size: {24 if m else 32}px; letter-spacing: -.8px; line-height: 1.12">{t}</b>{p(b, m)}</div>')
        stage = f'<div style="{"" if m else "flex: 1;"} border-radius: 28px; background: {"#E9F6EF" if i % 2 == 0 else BG}; padding: {28 if m else 44}px; display: flex; align-items: center; justify-content: center">{v(m)}</div>'
        if m: out += f'<div style="display: flex; flex-direction: column; gap: 18px">{txt}{stage}</div>'
        else: out += f'<div style="display: flex; gap: 64px; align-items: center; {"flex-direction: row-reverse" if i % 2 else ""}">{txt}{stage}</div>'
    return out

def plans(m=False):
    P = [('cal', 'Standard', 'Free', 'Filed within 30 days', 'Claims we can file automatically'),
         ('zap', 'Fast', '$15/mo', 'Filed within 3 days', 'Every nationwide claim'),
         ('sparkle' if 'sparkle' in LU else 'zap', 'Priority', '$30/mo', 'Filed within 24 hours', 'Every claim, plus local ones')]
    cards = ''.join(f'<div style="flex: 1; border-radius: 20px; padding: 22px; display: flex; flex-direction: column; gap: 8px; {"background: " + DARK + "; color: #FFFFFF" if k == "Priority" else "background: #FFFFFF; box-shadow: inset 0 0 0 1px " + LINE}">'
                    f'<span style="display: flex; align-items: center; gap: 8px"><b style="font-size: 18px; flex: 1">{k}</b><b style="font-size: 18px">{pr}</b></span>'
                    f'<span style="display: flex; align-items: center; gap: 7px; font-size: 14.5px; font-weight: 800; color: {MINT if k == "Priority" else GREEN}">{ic("clock", 15, MINT if k == "Priority" else GREEN, 2.4)}{sp}</span>'
                    f'<span style="font-size: 14px; font-weight: 600; color: {"#CFE9DD" if k == "Priority" else "#43504A"}">{wh}</span></div>' for ic_, k, pr, sp, wh in P)
    return (f'<div style="display: flex; flex-direction: column; gap: 18px">{kick("WHAT IT COSTS")}{h2("Checking is free. Pick how fast we file.", m)}'
            f'{p("Every plan files your claims and tracks them. Paid plans file sooner and cover more claims. Payouts take 6 to 12 months on every plan, because the settlement decides when it pays.", m, mw=760)}'
            f'<div style="display: flex; gap: 14px; {"flex-direction: column" if m else ""}">{cards}</div></div>')

def pay_timeline(m=False):
    T = [('check', 'Today', 'You check and pick a plan'), ('file', 'Within 24 hours to 30 days', 'We file your claims'), ('deadline', 'Claim deadline', 'The settlement stops taking claims'),
         ('approve', 'Final approval and appeals', 'The court signs off'), ('paid', '6 to 12 months after the deadline', 'The settlement pays you directly')]
    if m:
        items = ''.join(f'<div style="display: flex; gap: 14px; position: relative; padding-bottom: {0 if i == 4 else 18}px">' + (f'<i style="position: absolute; left: 18px; top: 38px; bottom: 0; width: 2px; background: rgba(255,255,255,.18)"></i>' if i < 4 else '')
                        + art(k, 38, 'dark') +
                        f'<span style="display: flex; flex-direction: column; gap: 2px; padding-top: 6px"><b style="font-size: 15px">{t}</b><span style="font-size: 14px; color: #B9D3C7; font-weight: 600">{s}</span></span></div>' for i, (k, t, s) in enumerate(T))
    else:
        items = ('<div style="display: flex; position: relative">' + f'<i style="position: absolute; left: 10%; right: 10%; top: 31px; height: 2px; background: rgba(255,255,255,.18)"></i>'
                 + ''.join(f'<div style="flex: 1; display: flex; flex-direction: column; align-items: center; gap: 10px; text-align: center; position: relative; padding: 0 10px">'
                           + art(k, 64, 'dark', f'border-radius: 99px; box-shadow: 0 0 0 6px {DARK}') +
                           f'<b style="font-size: 16px; line-height: 1.3">{t}</b><span style="font-size: 14px; color: #B9D3C7; font-weight: 600; line-height: 1.4">{s}</span></div>' for i, (k, t, s) in enumerate(T)) + '</div>')
    return (f'<div style="background: {DARK}; color: #FFFFFF; border-radius: {24 if m else 32}px; padding: {26 if m else 48}px; display: flex; flex-direction: column; gap: {20 if m else 34}px">'
            f'<div style="display: flex; flex-direction: column; gap: 12px">{kick("WHEN DO I GET PAID?", MINT)}{h2("The settlement pays on its own schedule", m, "#FFFFFF")}'
            f'{p("Filing faster gets your claim in early, but no plan makes a settlement pay sooner. Here is the usual path.", m, "#CFE9DD", mw=700)}</div>{items}</div>')

def promises(m=False, title='Your money stays yours'):
    P = [('hundred', '100% of every payout', 'We charge a flat price, never a cut of what you get.'),
         ('free', 'Free to file yourself', 'Every settlement page links to its official site, where filing is free.'),
         ('private', 'Your details stay private', 'We only send your info to the administrator of a claim you agree to file.'),
         ('cancel', 'Cancel anytime', 'One tap in your account. Claims we already filed stay filed.')]
    return (f'<div style="display: flex; flex-direction: column; gap: 22px">{h2(title, m)}'
            f'<div style="display: grid; grid-template-columns: {"1fr" if m else "repeat(4, 1fr)"}; gap: 14px">'
            + ''.join(f'<div style="background: {BG}; border-radius: 20px; padding: 22px; display: flex; flex-direction: column; gap: 10px">{art(k, 56)}'
                      f'<b style="font-size: 17px">{t}</b><span style="font-size: 14.5px; color: #43504A; font-weight: 600; line-height: 1.5">{b}</span></div>' for k, t, b in P) + '</div></div>')

def faqs(qs, m=False):
    return (f'<div style="display: flex; flex-direction: column; gap: 14px">{h2("Questions people ask", m)}<div style="display: flex; flex-direction: column">'
            + ''.join(f'<div style="border-top: 1px solid {LINE}; padding: {16 if m else 20}px 0; display: flex; flex-direction: column; gap: 8px"><span style="display: flex; align-items: center; gap: 12px"><b style="font-size: {16 if m else 18}px; flex: 1">{q}</b>{ic("down" if i else "x", 20, MUTE, 2.2)}</span>'
                      + (f'<span style="font-size: 15.5px; color: #43504A; font-weight: 600; line-height: 1.55; max-width: 760px">{a}</span>' if i == 0 else '') + '</div>' for i, (q, a) in enumerate(qs)) + '</div></div>')
HOWQ = [('Is this a scam? Why would a settlement pay me?', 'Class action settlements are real court cases. When a company settles, the court approves a fund for everyone affected, and anyone who qualifies can claim a share. Most people never hear about them, so the money goes unclaimed.'),
        ('Do I need proof?', 'Many settlements need no proof. When one does, we tell you exactly what to send before we file.'),
        ('Why not just file myself?', 'You can, for free. Claimclub saves you from finding every case, reading every notice and filling in every form.'),
        ('What do you do with my information?', 'We put it on the claim forms you agree to and send it to each settlement administrator. We never sell it.')]

def cta_band(m=False):
    return (f'<div style="background: radial-gradient(120% 140% at 0% 0%, #1E7A55 0%, {DARK} 60%); border-radius: {24 if m else 32}px; padding: {28 if m else 52}px; display: flex; {"flex-direction: column; gap: 18px" if m else "align-items: center; gap: 30px"}">'
            f'<div style="flex: 1; display: flex; flex-direction: column; gap: 10px">{h2("See what you could be owed", m, "#FFFFFF")}{p(f"{len(NAT)} open settlements, one minute of yes or no questions. Free to check.", m, "#CFE9DD")}</div>'
            f'{btn("Check what I qualify for", "mint", 58, m, "right")}</div>')

def how_d():
    hero = (f'<div style="padding: 64px 48px 40px; display: flex; flex-direction: column; align-items: center; gap: 18px; text-align: center; background: linear-gradient(180deg, #E9F6EF, #FFFFFF)">'
            f'{kick("HOW IT WORKS", center=True)}<h1 style="margin: 0; font-size: 60px; letter-spacing: -2px; line-height: 1.02; max-width: 900px">From money you\'re owed to money in your account</h1>'
            f'{p("We find the class action settlements you qualify for, file the claims for you and follow each one until it pays.", center=True, mw=680)}'
            f'<span style="display: flex; gap: 12px; margin-top: 8px">{btn("Check what I qualify for", "mint", 58, icon="right")}{btn("See open settlements", "line", 58)}</span></div>')
    body = (f'<div style="padding: 30px 48px 64px; display: flex; flex-direction: column; gap: 72px">{step_rows()}{pay_timeline()}{plans()}{promises()}{faqs(HOWQ)}{cta_band()}</div>')
    return desk(nav(on='How it works') + hero + body + foot(), 4420, '/how-it-works')
def how_m():
    hero = (f'<div style="padding: 28px 16px 20px; display: flex; flex-direction: column; gap: 14px; background: linear-gradient(180deg, #E9F6EF, #FFFFFF)">'
            f'{kick("HOW IT WORKS")}<h1 style="margin: 0; font-size: 34px; letter-spacing: -1.1px; line-height: 1.05">From money you\'re owed to money in your account</h1>'
            f'{p("We find the settlements you qualify for, file the claims and follow each one until it pays.", True)}{btn("Check what I qualify for", "mint", 54, True, "right")}</div>')
    body = f'<div style="padding: 16px 16px 40px; display: flex; flex-direction: column; gap: 48px">{step_rows(True)}{pay_timeline(True)}{plans(True)}</div>'
    return phone(nav(True) + hero + body, 4420)

# ---------- About ----------
def about_d():
    hero = (f'<div style="background: radial-gradient(120% 140% at 0% 0%, #1E7A55 0%, {DARK} 55%, #072619 100%); color: #FFFFFF">' + nav(dark=True, on='About') +
            f'<div style="padding: 56px 48px 64px; display: flex; gap: 60px; align-items: center"><div style="flex: 1; display: flex; flex-direction: column; gap: 18px">'
            f'{kick("ABOUT CLAIMCLUB", MINT)}<h1 style="margin: 0; font-size: 58px; letter-spacing: -1.9px; line-height: 1.03">Money you\'re owed shouldn\'t go unclaimed</h1>'
            f'{p("Every year, settlement money goes unclaimed because people never hear about the case or never get to the forms. We built Claimclub to find those settlements for you and do the paperwork.", c="#CFE9DD", mw=620)}</div>'
            f'<div style="width: 420px; flex: none; display: grid; grid-template-columns: 1fr 1fr; gap: 12px">'
            + ''.join(f'<div style="background: rgba(255,255,255,.08); border-radius: 20px; padding: 20px; display: flex; flex-direction: column; gap: 6px; {"grid-column: span 2" if i == 2 else ""}"><b style="font-size: 34px; letter-spacing: -1px; color: {MINT}">{v}</b><span style="font-size: 14px; color: #CFE9DD; font-weight: 700; line-height: 1.4">{t}</span></div>'
                      for i, (v, t) in enumerate([(str(len(NAT)), 'open nationwide settlements we track'), ('Daily', 'checks for new cases and changed deadlines'), ('100%', 'of every payout goes to you, never a cut')])) + '</div></div></div>')
    believe = promises(False, 'What we believe')
    nots = (f'<div style="display: flex; gap: 40px; align-items: stretch">'
            f'<div style="flex: 1; border-radius: 24px; background: #FFF8E8; box-shadow: inset 0 0 0 1px #F3E2B5; padding: 30px; display: flex; flex-direction: column; gap: 12px">'
            f'<span style="display: flex; align-items: center; gap: 10px">{art("scale", 48, "amber")}<b style="font-size: 22px">What we are not</b></span>'
            f'<span style="font-size: 16px; line-height: 1.6; color: #43504A; font-weight: 600">Claimclub is a claims preparation service. We are not a law firm, a settlement administrator or class counsel, and we are not tied to the companies or courts in the cases we list. Some arbitration claims are handled by independent partner law firms, and we always tell you before a referral.</span></div>'
            f'<div style="flex: 1; border-radius: 24px; background: {BG}; padding: 30px; display: flex; flex-direction: column; gap: 14px">'
            f'<span style="display: flex; align-items: center; gap: 10px">{art("sources", 48)}<b style="font-size: 22px">Where our settlements come from</b></span>'
            + ''.join(f'<span style="display: flex; gap: 12px; align-items: center; font-size: 15.5px; color: #2A3530; font-weight: 600; line-height: 1.5">{art(k, 36)}{t}</span>' for k, t in [('court', 'Public court filings and approved settlement notices'), ('web', 'Official settlement websites and their administrators'), ('scan', 'A daily scan of settlement news for new cases and deadline changes')])
            + '</div></div>')
    flow = (f'<div style="display: flex; flex-direction: column; gap: 22px">{h2("How Claimclub works")}<div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px">'
            + ''.join(f'<div style="border-radius: 20px; box-shadow: inset 0 0 0 1px {LINE}; padding: 22px; display: flex; flex-direction: column; gap: 10px"><b style="font-size: 14px; color: {GREEN}">{n}</b><b style="font-size: 18px; line-height: 1.25">{t}</b></div>' for n, t, b, v in STEPS)
            + f'</div><b style="font-size: 15px; color: {GREEN}; display: flex; align-items: center; gap: 6px">See how it works in detail {ic("right", 16, GREEN, 2.4)}</b></div>')
    company = (f'<div style="display: flex; gap: 14px">'
               + ''.join(f'<div style="flex: 1; border-radius: 20px; background: {BG}; padding: 24px; display: flex; flex-direction: column; gap: 8px"><span style="display: flex; align-items: center; gap: 12px">{art(k, 44)}<b style="font-size: 16px">{t}</b></span><span style="font-size: 15px; color: #43504A; font-weight: 600; line-height: 1.5">{b}</span></div>'
                         for k, t, b in [('mail', 'Support', 'support@mail.claimclub.io<br>Questions about a claim or your account.'), ('private', 'Privacy and security', 'privacy@mail.claimclub.io<br>Read our Security Policy.'), ('company', 'The company', 'DBC Workshop LLC<br>408 Andrew Ave, Encinitas, CA 92024')]) + '</div>')
    body = f'<div style="padding: 56px 48px 64px; display: flex; flex-direction: column; gap: 64px">{believe}{nots}{flow}<div style="display: flex; flex-direction: column; gap: 18px">{h2("Get in touch")}{company}</div>{cta_band()}</div>'
    return desk(hero + body + foot(), 2240, '/about')
def about_m():
    hero = (f'<div style="background: radial-gradient(140% 120% at 0% 0%, #1E7A55 0%, {DARK} 55%, #072619 100%); color: #FFFFFF">' + nav(True, True) +
            f'<div style="padding: 20px 16px 28px; display: flex; flex-direction: column; gap: 14px">{kick("ABOUT CLAIMCLUB", MINT)}'
            f'<h1 style="margin: 0; font-size: 34px; letter-spacing: -1.1px; line-height: 1.05">Money you\'re owed shouldn\'t go unclaimed</h1>'
            f'{p("Settlement money goes unclaimed because people never hear about the case or never get to the forms. Claimclub finds those settlements for you and does the paperwork.", True, "#CFE9DD")}'
            f'<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px">'
            + ''.join(f'<div style="background: rgba(255,255,255,.08); border-radius: 16px; padding: 14px; display: flex; flex-direction: column; gap: 4px"><b style="font-size: 26px; color: {MINT}">{v}</b><span style="font-size: 12.5px; color: #CFE9DD; font-weight: 700">{t}</span></div>'
                      for v, t in [(str(len(NAT)), 'open settlements tracked'), ('100%', 'of every payout is yours')]) + '</div></div></div>')
    body = f'<div style="padding: 28px 16px 40px; display: flex; flex-direction: column; gap: 40px">{promises(True, "What we believe")}<div style="border-radius: 20px; background: #FFF8E8; box-shadow: inset 0 0 0 1px #F3E2B5; padding: 20px; display: flex; flex-direction: column; gap: 8px"><span style="display: flex; align-items: center; gap: 10px">{art("scale", 40, "amber")}<b style="font-size: 18px">What we are not</b></span><span style="font-size: 15px; line-height: 1.55; color: #43504A; font-weight: 600">A claims preparation service, not a law firm, settlement administrator or class counsel. We are not tied to the companies or courts in the cases we list.</span></div>{cta_band(True)}</div>'
    return phone(hero + body, 2240)

if __name__ == '__main__':
    from setD import board
    B = [('HowP', 'HOW IT WORKS PAGE · /how-it-works', 'Four steps, each with a small product picture (question, matches, signed and filed, payout on the lock screen). Then when you get paid (filing faster never makes a settlement pay sooner), the three plans, our promises, questions and one call to action. Plan names follow whatever you pick.', how_d(), how_m(), 4420),
         ('AboutP', 'ABOUT PAGE · /about', 'Replaces today\'s plain About page. Dark green hero with three honest numbers, what we believe, what we are not and where our settlements come from, the 4 steps (links to How it works), contact and the company.', about_d(), about_m(), 2240)]
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    x = 4 * 1940
    for nm, label, note, d, m, H in B:
        h = board(nm, label, note, d, m, H)
        c['boards'][nm + '.dc.html'] = {'x': x, 'y': 0, 'w': 1840, 'h': h, 'title': label.title(), 'page': 'setp', 'is_interactive': False}
        if nm + '.dc.html' not in c['order']: c['order'].append(nm + '.dc.html')
        x += 1940
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w'))
    print('ok')
