# Member dashboard, chosen designs (Nov 14 night). Henry picked:
#   Dashboard = DashD2 (to-do first) + expected payouts chart from DashD3 + profile menu from DashD1
#   Claim a refund = RefundR1 layout, reworked into a charge review (what is this charge, is it worth fighting)
#   Subscription Manager = SubsS1 + the Renewing soon strip from SubsS2
# Each page gets three boards: the page with data, the page for a new member, and a States board with every tile in each state.
# Boards: DashHome, DashHomeNew, DashHomeStates, RefundReview, RefundReviewNew, RefundReviewStates, SubsManager, SubsManagerNew, SubsManagerStates.
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from how4 import ic, IC, HEAD, JS, OUT
from refundC import mark, brand, SUBS, PROG, STAGES, CLAIMS, MINT, DARK, GREEN
from dashI import card, stat, pill, tag, row, listcard, col, bars, fmt, MNAV
IC.update({
    'alert': '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"></path><path d="M12 9v4"></path><path d="M12 17h.01"></path>',
    'help': '<circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><path d="M12 17h.01"></path>',
    'refresh': '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"></path><path d="M21 3v5h-5"></path><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"></path><path d="M8 16H3v5"></path>',
    'chevr': '<path d="m9 18 6-6-6-6"></path>',
    'ccheck': '<circle cx="12" cy="12" r="10"></circle><path d="m9 12 2 2 4-4"></path>',
    'inbox': '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"></polyline><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"></path>',
    'chart': '<line x1="12" x2="12" y1="20" y2="10"></line><line x1="18" x2="18" y1="20" y2="4"></line><line x1="6" x2="6" y1="20" y2="16"></line>',
    'coffee': '<path d="M10 2v2"></path><path d="M14 2v2"></path><path d="M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1"></path><path d="M6 2v2"></path>',
    'gamepad': '<line x1="6" x2="10" y1="12" y2="12"></line><line x1="8" x2="8" y1="10" y2="14"></line><line x1="15" x2="15.01" y1="13" y2="13"></line><line x1="18" x2="18.01" y1="11" y2="11"></line><rect width="20" height="12" x="2" y="6" rx="2"></rect>',
    'utensils': '<path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2"></path><path d="M7 2v20"></path><path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 3 2h3Zm0 0v7"></path>',
    'lock': '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path>', 'chevd': '<path d="m6 9 6 6 6-6"></path>',
    'logout': '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" x2="9" y1="12" y2="12"></line>',
    'card': '<rect width="20" height="14" x="2" y="5" rx="2"></rect><line x1="2" x2="22" y1="10" y2="10"></line>', 'cal': '<rect width="18" height="18" x="3" y="4" rx="2"></rect><path d="M16 2v4 M8 2v4 M3 10h18"></path>',
    'trend': '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline><polyline points="16 7 22 7 22 13"></polyline>'})
MONO = 'ui-monospace, SFMono-Regular, Menlo, monospace'
AMBER_BG, AMBER = '#FFF3D6', '#8A5A00'
RED = '#B8333A'
UNUSED = [x for x in SUBS if x[5] == 'unused']; TOTAL_S = sum(x[3] for x in SUBS); WASTE = sum(x[3] for x in UNUSED)

# ---------- charges from a connected card ----------
# (src, icon, name, descriptor, date, amount, what, verdict, reasons/question, back, chance, card)
CH = [
    ('logos2/netflix.svg', 'receipt', 'Netflix', 'NETFLIX.COM 866-579-7172 CA', 'Oct 14', 15.99, 'Streaming plan, Standard', 'fight',
     ['You canceled on Jul 12. We found the cancel email.', 'Charged 3 more times since then: Aug 14, Sep 14 and Oct 14.', 'Netflix usually refunds charges made after a cancel.'], 47.97, 'High', 'Visa 4417'),
    (None, 'hand', 'City Fitness', 'CITYFIT*MEMBERSHIP 800-555-0199', 'Nov 3', 39.99, 'Gym membership, monthly', 'fight',
     ['No check-ins since July.', 'You asked to cancel on Aug 2 and they kept billing.'], 39.99, 'Good', 'Visa 4417'),
    ('logos/amazon.svg', 'receipt', 'Amazon', 'AMZN Mktp US*2K41J8', 'Nov 8', 32.18, 'One order, charged twice', 'fight',
     ['Two charges of $32.18, one minute apart.', 'Only one order matches in your history.'], 32.18, 'High', 'Visa 4417'),
    ('logos2/disney.png', 'receipt', 'Disney+', 'DISNEY PLUS 888-905-7888', 'Nov 1', 13.99, 'Free trial that turned paid', 'fight',
     ['Your free trial ended Oct 31.', 'Not opened since the trial started.'], 13.99, 'Good', 'Amex 1009'),
    ('logos2/ubereats.png', 'receipt', 'Uber Eats', 'UBER *EATS PENDING', 'Nov 9', 24.60, 'Food delivery order', 'look', 'Did this order arrive?', 24.60, '', 'Visa 4417'),
    (None, 'gamepad', 'Steam', 'PAYPAL *STEAMGAMES 4029357733', 'Nov 5', 59.99, 'A game bought on Steam, paid through PayPal', 'look', 'Do you recognize this charge?', 59.99, '', 'Amex 1009'),
    (None, 'coffee', 'Blue Bottle Coffee', 'SQ *BLUE BOTTLE COF', 'Nov 10', 6.75, 'Coffee shop in Oakland, CA. You go about once a week.', 'ok', '', 0, '', 'Visa 4417'),
    ('logos2/youtube.png', 'receipt', 'YouTube Premium', 'GOOGLE *YouTubePremium', 'Nov 4', 22.99, 'Family plan. Used this week.', 'ok', '', 0, '', 'Visa 4417'),
    ('logos/apple.svg', 'receipt', 'iCloud+', 'APL*ITUNES.COM/BILL 866-712-7753', 'Nov 2', 2.99, 'Apple storage plan, 50 GB', 'ok', '', 0, '', 'Visa 4417'),
    (None, 'utensils', 'Shake Shack', 'TST* SHAKE SHACK 1123', 'Oct 30', 18.42, 'Restaurant in San Francisco, CA', 'ok', '', 0, '', 'Amex 1009')]
FIGHT = [c for c in CH if c[7] == 'fight']; LOOK = [c for c in CH if c[7] == 'look']; OK = [c for c in CH if c[7] == 'ok']
FIGHT_T = sum(c[9] for c in FIGHT); LOOK_T = sum(c[9] for c in LOOK)
REVIEWED, NORMAL_N = 142, 142 - len(FIGHT) - len(LOOK)
CLAIMS_T = 515.00; TOTAL = CLAIMS_T + FIGHT_T
CARDS = [('logos2/visa.svg', 'Chase Visa', '4417', 'Watching. Checked today.', 'ok'), ('', 'American Express', '1009', 'Watching. Checked today.', 'ok'), ('', 'Capital One Mastercard', '8820', 'Bank asks you to sign in again', 'bad')]

# ---------- shell (full height, so the boards show the whole page) ----------
def avatar(s=40, ring=71):
    C = 2 * 3.1416 * (s / 2 - 3)
    return (f'<span style="position: relative; width: {s}px; height: {s}px; flex: none" role="img" aria-label="Account {ring}% complete"><svg width="{s}" height="{s}" viewBox="0 0 {s} {s}" aria-hidden="true" style="position: absolute; inset: 0">'
            f'<circle cx="{s/2}" cy="{s/2}" r="{s/2-3}" fill="none" stroke="#DDE5E0" stroke-width="3"></circle><circle cx="{s/2}" cy="{s/2}" r="{s/2-3}" fill="none" stroke="{GREEN}" stroke-width="3" stroke-linecap="round" transform="rotate(-90 {s/2} {s/2})" stroke-dasharray="{C:.1f}" stroke-dashoffset="{C*(1-ring/100):.1f}"></circle></svg>'
            f'<span style="position: absolute; inset: 5px; border-radius: 50%; background: {DARK}; color: #FFFFFF; font-size: {round(s*.34)}px; font-weight: 800; display: flex; align-items: center; justify-content: center">H</span></span>')
def menu(ring=71, floating=True, member=True):
    r = lambda k, t, sub='', c='#8A968F': f'<span style="display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 12px; font-size: 14px; font-weight: 700; color: #26302B">{ic(k, 18, 2)}<span style="flex: 1">{t}</span><span style="font-size: 12px; color: {c}; font-weight: 800">{sub}</span></span>'
    done = ring >= 100
    pos = 'position: absolute; right: 0; top: 52px; z-index: 5; ' if floating else ''
    return (f'<div style="{pos}width: 280px; padding: 8px; border-radius: 18px; background: #FFFFFF; box-shadow: 0 24px 60px rgba(10,15,13,.18), 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; box-sizing: border-box">'
            f'<span style="display: flex; align-items: center; gap: 10px; padding: 10px 12px 12px; border-bottom: 1px solid #EEF2F0; margin-bottom: 4px">{avatar(44, ring)}<span style="display: flex; flex-direction: column"><b style="font-size: 14.5px">Henry Sidwell</b><span style="font-size: 12px; color: {GREEN if done else "#5B6862"}; font-weight: 700">{"Account complete" if done else f"Account {ring}% complete"}</span></span></span>'
            + r('user', 'Your info', 'Complete' if done else '2 left', GREEN if done else '#B07A12') + r('shield', 'Settings') + r('card', 'Membership', 'Active' if member else 'Join', GREEN if member else '#B07A12') + r('logout', 'Log out') + '</div>')
def shell(m, page, body, title, sub='', show_menu=False, ring=71, badges=None, member=True):
    LK = set() if member else {'refunds', 'subs'}
    b = {'claims': '5', 'refunds': str(len(FIGHT) + len(LOOK)), 'subs': str(len(UNUSED))} if badges is None else badges
    NAV = [('home', 'grid', 'Dashboard'), ('claims', 'file', 'Your claims'), ('find', 'list', 'Find claims'), ('refunds', 'receipt', 'Claim a refund'), ('subs', 'repeat', 'Subscription Manager')]
    if m:
        nav = ('<nav style="flex: none; display: flex; justify-content: space-around; padding: 8px 4px 14px; background: #FFFFFF; border-top: 1px solid #E3EAE6">' + ''.join(
            f'<span style="flex: 1; display: flex; flex-direction: column; align-items: center; gap: 3px; font-size: 10.5px; font-weight: 800; white-space: nowrap; color: {DARK if k == page else "#8A968F"}"><span style="position: relative; display: flex">{ic(i, 21, 2.2 if k == page else 2)}' + (f'<span style="position: absolute; right: -7px; top: -4px; width: 15px; height: 15px; border-radius: 50%; background: #FFFFFF; display: flex; align-items: center; justify-content: center; color: #5B6862">{ic("lock", 10, 2.8)}</span>' if k in LK else '') + f'</span>{t}</span>' for k, i, t in MNAV) + '</nav>')
        top = f'<header style="flex: none; display: flex; align-items: center; justify-content: space-between; padding: 10px 16px; background: #FFFFFF; border-bottom: 1px solid #E3EAE6">{brand(22, "#0A0F0D")}{avatar(38, ring)}</header>'
        head = f'<div style="display: flex; flex-direction: column; gap: 3px"><h1 style="margin: 0; font-size: 22px; letter-spacing: -.5px">{title}</h1>' + (f'<span style="font-size: 13px; color: #5B6862">{sub}</span>' if sub else '') + '</div>'
        return f'<div style="min-height: 844px; display: flex; flex-direction: column; background: #F3F6F4; font-family: Manrope, sans-serif; color: #0A0F0D">{top}<main style="flex: 1 0 auto; padding: 16px; display: grid; grid-template-columns: minmax(0, 1fr); grid-auto-rows: max-content; align-content: start; gap: 14px">{head}{body}</main>{nav}</div>'
    grp = lambda t: f'<span style="padding: 18px 12px 6px; font-size: 11px; font-weight: 800; letter-spacing: 1.1px; color: #8A968F; white-space: nowrap">{t}</span>'
    item = lambda k, i, t: (f'<span style="display: flex; align-items: center; gap: 11px; padding: 10px 12px; border-radius: 12px; font-size: 14.5px; font-weight: 700; white-space: nowrap; {"background: #EAF2EE; color: #0F3B2E" if k == page else "color: #43504A"}">{ic(i, 19, 2)}<span style="flex: 1">{t}</span>'
                            + (f'<span style="display: flex; color: #8A968F">{ic("lock", 15, 2.4)}</span>' if k in LK else (f'<span style="padding: 2px 7px; border-radius: 99px; background: {MINT}; color: {DARK}; font-size: 11px; font-weight: 800">{b[k]}</span>' if b.get(k) else '')) + '</span>')
    side = (f'<aside style="width: 276px; flex: none; display: flex; flex-direction: column; gap: 2px; padding: 22px 14px; background: #FFFFFF; border-right: 1px solid #E3EAE6; box-sizing: border-box"><span style="padding: 0 10px 18px">{brand(26, "#0A0F0D")}</span>'
            + item(*NAV[0]) + grp('GET MONEY IN') + item(*NAV[1]) + item(*NAV[2]) + grp('GET MONEY BACK') + item(*NAV[3]) + item(*NAV[4])
            + ('' if member else f'<div style="margin-top: auto; padding: 16px; border-radius: 18px; background: {DARK}; color: #FFFFFF; display: flex; flex-direction: column; gap: 6px"><b style="font-size: 14.5px">Not a member yet</b><span style="font-size: 12.5px; color: #C9D6CF; line-height: 1.45">Unlock claims near you, refunds and subscriptions.</span><span style="margin-top: 6px">{pill("Join for $7.99", "mint")}</span></div>') + '</aside>')
    topbar = (f'<div style="display: flex; align-items: flex-start; justify-content: space-between; gap: 16px"><div style="display: flex; flex-direction: column; gap: 4px"><h1 style="margin: 0; font-size: 24px; letter-spacing: -.6px">{title}</h1>'
              + (f'<span style="font-size: 13.5px; color: #5B6862">{sub}</span>' if sub else '') + '</div>'
              f'<span style="position: relative; display: flex; align-items: center; gap: 8px; padding: 4px 10px 4px 4px; border-radius: 99px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6">{avatar(38, ring)}<b style="font-size: 14px">Henry</b>{ic("chevd", 16, 2.4, "#8A968F")}{menu(ring, member=member) if show_menu else ""}</span></div>')
    return f'<div style="min-height: 900px; display: flex; background: #F3F6F4; font-family: Manrope, sans-serif; color: #0A0F0D">{side}<main style="flex: 1; min-width: 0; padding: 24px 32px 40px; display: grid; grid-template-columns: minmax(0, 1fr); grid-auto-rows: max-content; align-content: start; gap: 16px">{topbar}{body}</main></div>'

# ---------- shared pieces ----------
def two(a, b, m, w='340px'):
    return f'<div style="display: grid; grid-template-columns: {"minmax(0, 1fr)" if m else "minmax(0, 1fr) " + w}; gap: 16px; align-items: start">{a}{b}</div>'
def stats(items, m, cols=None):
    if m: return '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px">' + ''.join((f'<div style="grid-column: 1 / -1; display: flex">{stat(*x, m=True)}</div>' if len(items) % 2 and i == len(items) - 1 else stat(*x, m=True)) for i, x in enumerate(items)) + '</div>'
    return '<div style="display: flex; gap: 12px">' + ''.join(stat(*x) for x in items) + '</div>'
def iconbox(k, s=40, bg='#E9F6EF', c=GREEN):
    return f'<span style="width: {s}px; height: {s}px; flex: none; border-radius: {round(s*.3)}px; background: {bg}; color: {c}; display: flex; align-items: center; justify-content: center">{ic(k, round(s*.5), 2.2)}</span>'
def empty(k, title, text, btns='', pad=26, bg='#E9F6EF', c=GREEN):
    return (f'<div style="padding: {pad}px 20px; display: flex; flex-direction: column; align-items: center; text-align: center; gap: 8px">{iconbox(k, 48, bg, c)}'
            f'<b style="font-size: 16px; margin-top: 4px">{title}</b><span style="font-size: 13.5px; color: #5B6862; line-height: 1.5; max-width: 380px">{text}</span>'
            + (f'<span style="display: flex; gap: 8px; flex-wrap: wrap; justify-content: center; margin-top: 6px">{btns}</span>' if btns else '') + '</div>')
skel = lambda w, h=12: f'<span style="display: block; width: {w}; height: {h}px; border-radius: 99px; background: linear-gradient(90deg, #EEF2F0, #F7F9F8, #EEF2F0)"></span>'
def verdict(v, small=False):
    t, bg, c, k = {'fight': ('Worth fighting', '#E9F6EF', '#17603F', 'hand'), 'look': ('Not sure, check it', AMBER_BG, AMBER, 'help'), 'ok': ('Looks normal', '#EEF2F0', '#5B6862', 'ccheck'),
                   'prog': ('In progress', '#E8EEFB', '#2C4FA8', 'clock'), 'done': ('Refunded', '#E9F6EF', '#17603F', 'check'), 'fine': ('You said it is fine', '#EEF2F0', '#5B6862', 'check')}[v]
    return f'<span style="display: inline-flex; align-items: center; gap: 5px; padding: 4px 9px; border-radius: 99px; background: {bg}; color: {c}; font-size: {11.5 if small else 12}px; font-weight: 800; white-space: nowrap">{ic(k, 13, 2.6)}{t}</span>'
section = lambda t, right='': f'<div style="display: flex; align-items: center; justify-content: space-between; padding: 14px 16px 6px; font-size: 11.5px; font-weight: 800; letter-spacing: 1px; color: #5B6862; border-top: 1px solid #EEF2F0"><span>{t}</span><span>{right}</span></div>'
def ctitle(t, n='', note=''):
    return (f'<div style="display: flex; align-items: center; gap: 8px; padding: 14px 16px"><b style="font-size: 17px">{t}</b>' + (f'<span style="padding: 2px 9px; border-radius: 99px; background: #E8EEFB; color: #2C4FA8; font-size: 12px; font-weight: 800">{n}</span>' if n else '')
            + (f'<span style="margin-left: auto; font-size: 12.5px; color: #5B6862; font-weight: 600">{note}</span>' if note else '') + '</div>')
box = lambda inner: f'<div style="border-radius: 22px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; overflow: hidden">{inner}</div>'

# ======================= DASHBOARD =======================
def d_stats(m, s='full'):
    if s == 'full':
        items = [('Paid to you', '$31.45', '$25 claims, $6.45 refunds', GREEN, 'check'), ('In progress', '$227.64', '5 claims, 3 refunds', '#2C4FA8', 'clock'), ('Subscriptions', fmt(TOTAL_S) + '/mo', fmt(WASTE) + ' a month not used', '#0A0F0D', 'repeat')]
    else:
        items = [('Paid to you', '$0.00', 'Your first payout shows here', '#8A968F', 'check'), ('In progress', '$0.00', '5 claims ready to file', '#8A968F', 'clock'), ('Subscriptions', 'Not set up', 'Connect a card to see them', '#8A968F', 'repeat')]
    return stats(items, m)
TODO = [('file', 'File 5 claims', 'Worth up to $300. 1 closes this week.', 'File now', 'mint', 'Your claims'),
        ('receipt', f'Fight {len(FIGHT)} refunds', f'We found {fmt(FIGHT_T)} you can get back.', 'Review', 'mint', 'Claim a refund'),
        ('help', f'Check {len(LOOK)} charges', 'We are not sure about these. Tell us if they are right.', 'Check', 'soft', 'Claim a refund'),
        ('repeat', f'Cancel {len(UNUSED)} subscriptions', 'Not used in 60+ days. Save ' + fmt(WASTE) + ' a month.', 'Review', 'dark', 'Subscription Manager'),
        ('user', 'Finish your account', 'Add your date of birth and phone so we can file faster.', 'Add', 'soft', 'Your info')]
TODO_NEW = [('file', 'File 5 claims', 'Worth up to $515. 1 closes this week.', 'File now', 'mint', 'Your claims'),
            ('card', 'Connect a card', 'We check 90 days of charges for refunds and subscriptions.', 'Connect', 'dark', 'Claim a refund'),
            ('user', 'Finish your account', 'Add your date of birth and phone so we can file faster.', 'Add', 'soft', 'Your info')]
def todo(m, s='full'):
    if s == 'done':
        return box(ctitle('Your to-do list') + '<div style="border-top: 1px solid #EEF2F0">' + empty('ccheck', 'You are all caught up', 'Nothing needs you right now. We will let you know when a claim opens or we find a charge to fight.', pill('Find more claims', 'soft')) + '</div>')
    items = TODO if s == 'full' else TODO_NEW
    rows = ''.join(f'<div style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-top: 1px solid #EEF2F0">{iconbox(k)}'
                   f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column"><b style="font-size: 15px">{t}</b><span style="font-size: 12.5px; color: #5B6862; font-weight: 600">{d}</span>' + ('' if m else f'<span style="font-size: 11.5px; color: #8A968F; font-weight: 700; margin-top: 2px">{where}</span>') + f'</span>{pill(b, kind)}</div>' for k, t, d, b, kind, where in items)
    return box(ctitle('Your to-do list', str(len(items)), '' if m else 'Do these and we handle the rest') + rows)
def total(m, s='full'):
    leg = lambda c, t, v, dashed=False: f'<span style="display: flex; align-items: center; gap: 8px"><span style="width: 10px; height: 10px; border-radius: 3px; {"background: repeating-linear-gradient(45deg, #DDE5E0 0 2px, #F3F6F4 2px 4px)" if dashed else "background: " + c}"></span><span style="flex: 1">{t}</span><b style="{"color: #8A968F" if dashed else ""}">{v}</b></span>'
    head = '<span style="font-size: 12.5px; font-weight: 800; letter-spacing: 1px; color: #5B6862">TOTAL COMING TO YOU</span>'
    if s == 'zero':
        return card(head + f'<b style="display: block; font-size: 40px; letter-spacing: -1.5px; margin: 4px 0 6px; color: #8A968F">$0.00</b><span style="display: block; font-size: 13.5px; color: #5B6862; line-height: 1.5; margin-bottom: 12px">Answer a few questions and we show you every settlement you can claim.</span>' + pill('Check what I am owed'))
    if s == 'claims':
        return card(head + f'<b style="display: block; font-size: 40px; letter-spacing: -1.5px; margin: 4px 0 14px">{fmt(CLAIMS_T)}</b>'
                    f'<span style="display: block; font-size: 13px; font-weight: 800; margin-bottom: 10px">Where it comes from</span><span style="display: flex; height: 14px; border-radius: 99px; overflow: hidden"><span style="flex: 515; background: {GREEN}"></span><span style="flex: 160; background: repeating-linear-gradient(45deg, #DDE5E0 0 5px, #F3F6F4 5px 10px)"></span></span>'
                    '<span style="display: flex; flex-direction: column; gap: 6px; font-size: 13px; font-weight: 700; margin: 10px 0 12px">' + leg(GREEN, 'Claims', fmt(CLAIMS_T)) + leg('', 'Refunds', 'Connect a card', True) + '</span>' + pill('Connect a card to find refunds', 'soft'))
    return card(head + f'<b style="display: block; font-size: 40px; letter-spacing: -1.5px; margin: 4px 0 14px">{fmt(TOTAL)}</b>'
                f'<span style="display: block; font-size: 13px; font-weight: 800; margin-bottom: 10px">Where it comes from</span><span style="display: flex; height: 14px; border-radius: 99px; overflow: hidden"><span style="flex: {CLAIMS_T}; background: {GREEN}"></span><span style="flex: {FIGHT_T}; background: {MINT}"></span></span>'
                '<span style="display: flex; flex-direction: column; gap: 6px; font-size: 13px; font-weight: 700; margin-top: 10px">' + leg(GREEN, 'Claims', fmt(CLAIMS_T)) + leg(MINT, 'Refunds', fmt(FIGHT_T)) + '</span>')
ACT = [('Today', 'Starbucks refunded $6.45 to your Visa 4417', 'check'), ('Yesterday', 'SeatGeek replied to your refund request', 'inbox'), ('Nov 12', 'Netflix claim filed with the administrator', 'file'), ('Nov 12', 'Dr. Squatch paid $25 to your PayPal', 'wallet')]
def activity(m, s='full'):
    if s == 'empty':
        return card('<b style="font-size: 16px">Recent activity</b>' + empty('inbox', 'Nothing yet', 'When you file a claim or we find a refund, updates show up here.', '', 18))
    if s == 'new':
        feed = [('Today', 'You joined Claimclub. We found 5 claims for you.', 'check')]
    else:
        feed = ACT
    return card('<b style="font-size: 16px">Recent activity</b><div style="margin-top: 8px">' + ''.join(
        f'<div style="display: flex; gap: 10px; padding: 10px 0; border-top: 1px solid #EEF2F0"><span style="width: 8px; height: 8px; margin-top: 6px; border-radius: 50%; background: {GREEN}; flex: none"></span><span style="display: flex; flex-direction: column"><span style="font-size: 13.5px; font-weight: 700">{t}</span><span style="font-size: 12px; color: #8A968F; font-weight: 700">{d}</span></span></div>' for d, t, k in feed) + '</div>')
MONTHS = [('Dec', 6.45, 'paid'), ('Jan', 140, ''), ('Feb', 100, ''), ('Mar', 95, ''), ('Apr', 40, ''), ('May', 180, '')]
def chart(m, data, h=150):
    mx = max(v for _, v, _ in data) or 1
    return (f'<div style="display: flex; align-items: flex-end; gap: {8 if m else 14}px; height: {h}px; margin-top: 14px">' + ''.join(
        f'<span style="flex: 1; display: flex; flex-direction: column; align-items: center; gap: 6px"><b style="font-size: 11.5px; color: {"#0A0F0D" if v else "#B9C6BF"}">{("$" + format(v, ",.0f")) if v else "$0"}</b>'
        f'<span style="width: 100%; height: {max(6, v / mx * (h - 50)):.0f}px; border-radius: 8px 8px 4px 4px; background: {DARK if st == "paid" else (MINT if v else "#EEF2F0")}"></span><span style="font-size: 12px; font-weight: 800; color: #5B6862">{mo}</span></span>' for mo, v, st in data) + '</div>')
CLAIM_MONTHS = [('Dec', 0, ''), ('Jan', 140, ''), ('Feb', 100, ''), ('Mar', 95, ''), ('Apr', 0, ''), ('May', 180, '')]
def payouts(m, s='full'):
    legend = (f'<span style="display: flex; gap: 14px; font-size: 12px; font-weight: 800; color: #5B6862"><span style="display: flex; align-items: center; gap: 6px"><span style="width: 10px; height: 10px; border-radius: 3px; background: {DARK}"></span>Paid</span>'
              f'<span style="display: flex; align-items: center; gap: 6px"><span style="width: 10px; height: 10px; border-radius: 3px; background: {MINT}"></span>Expected</span></span>')
    head = (f'<div style="display: flex; {"flex-direction: column; gap: 8px" if m else "align-items: flex-start; justify-content: space-between"}"><span style="display: flex; flex-direction: column"><b style="font-size: 16px">Expected payouts</b>'
            '<span style="font-size: 12.5px; color: #5B6862; font-weight: 600">{sub}</span></span>' + legend + '</div>')
    if s == 'locked':
        over = (f'<div style="position: absolute; inset: 0; display: flex; align-items: center; justify-content: center"><div style="padding: 18px 22px; border-radius: 20px; background: #FFFFFF; box-shadow: 0 18px 44px rgba(10,15,13,.14), 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; align-items: center; text-align: center; gap: 6px; max-width: 320px">'
                f'{iconbox("lock", 40)}<b style="font-size: 15.5px; margin-top: 2px">See when you get paid</b><span style="font-size: 13px; color: #5B6862; line-height: 1.45">File your claims and we estimate each payout by month.</span><span style="margin-top: 6px">{pill("File 5 claims")}</span></div></div>')
        return card(head.format(sub='Shows up once you file a claim') + f'<div style="position: relative"><div style="filter: blur(7px); opacity: .55" aria-hidden="true">{chart(m, MONTHS, 170)}</div>{over}</div>')
    if s == 'one':
        data = [('Dec', 0, ''), ('Jan', 0, ''), ('Feb', 0, ''), ('Mar', 95, ''), ('Apr', 0, ''), ('May', 0, '')]
        return card(head.format(sub='1 claim filed. File the other 4 to see more here.') + chart(m, data) + f'<div style="display: flex; align-items: center; gap: 10px; margin-top: 14px; padding: 10px 12px; border-radius: 14px; background: #F3F6F4; font-size: 13px; font-weight: 700">{ic("file", 16, 2.2, GREEN)}<span style="flex: 1">4 claims are ready to file, worth up to $420.</span>{pill("File now")}</div>')
    if s == 'claims':
        return card(head.format(sub='Estimates for your 5 filed claims, from each settlement timeline') + chart(m, CLAIM_MONTHS))
    return card(head.format(sub='Estimates from settlement and refund timelines') + chart(m, MONTHS))
def dash_page(m, s='full'):
    if s == 'new':
        body = two(col(d_stats(m, 'new'), todo(m, 'new')), col(total(m, 'claims'), activity(m, 'new')), m) + payouts(m, 'locked')
        return shell(m, 'home', body, 'Hi Henry', '3 things to start. Everything else we handle.', ring=40, badges={'claims': '5'})
    body = two(col(d_stats(m), todo(m)), col(total(m), activity(m)), m) + payouts(m)
    return shell(m, 'home', body, 'Hi Henry', f'{len(TODO)} things to do. Everything else we handle.', show_menu=not m)

# ======================= CLAIM A REFUND =======================
def chips(items, sel=0, m=False):
    return (f'<div style="display: flex; gap: 8px; {"overflow-x: auto" if m else "flex-wrap: wrap"}; padding: 0 16px 12px">' + ''.join(
        f'<span style="flex: none; min-height: 34px; padding: 0 13px; border-radius: 99px; font-size: 13px; font-weight: 800; display: flex; align-items: center; gap: 6px; white-space: nowrap; {"background: #0F3B2E; color: #FFFFFF" if i == sel else "background: #FFFFFF; color: #43504A; box-shadow: inset 0 0 0 1.5px #DDE5E0"}">{t}<span style="opacity: .7">{n}</span></span>' for i, (t, n) in enumerate(items)) + '</div>')
def chrow(c, m, sel=False, v=None):
    src, icon, nm, desc, date, amt, what, vd, why, back, chance, cardn = c
    v = v or vd
    left = f'border-left: 3px solid {GREEN}; background: #F5FBF8;' if sel else 'border-left: 3px solid transparent;'
    if m:
        return (f'<div style="display: flex; gap: 12px; padding: 12px 14px 12px 11px; border-top: 1px solid #EEF2F0; {left}">{mark(src, nm, icon, 40)}<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 3px">'
                f'<span style="display: flex; justify-content: space-between; gap: 8px"><b style="font-size: 14.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{nm}</b><b style="font-size: 14.5px">{fmt(amt)}</b></span>'
                f'<span style="font-family: {MONO}; font-size: 11px; color: #8A968F; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{desc}</span>'
                f'<span style="display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-top: 3px"><span style="font-size: 12px; color: #5B6862; font-weight: 700">{date}</span>{verdict(v, True)}</span></span></div>')
    return (f'<div style="display: grid; grid-template-columns: 58px minmax(0, 1.25fr) minmax(0, 1fr) 90px 168px 18px; align-items: center; gap: 14px; padding: 11px 16px 11px 13px; border-top: 1px solid #EEF2F0; {left}">'
            f'<span style="font-size: 12.5px; font-weight: 800; color: #5B6862">{date}</span>'
            f'<span style="display: flex; align-items: center; gap: 11px; min-width: 0">{mark(src, nm, icon, 38)}<span style="min-width: 0; display: flex; flex-direction: column; gap: 2px"><b style="font-size: 14.5px">{nm}</b><span style="font-family: {MONO}; font-size: 11px; color: #8A968F; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{desc}</span></span></span>'
            f'<span style="font-size: 13px; color: #43504A; font-weight: 600; line-height: 1.35">{what}</span><b style="font-size: 15px; text-align: right">{fmt(amt)}</b><span>{verdict(v)}</span>{ic("chevr", 16, 2.4, "#B9C6BF")}</div>')
def colhead():
    return ('<div style="display: grid; grid-template-columns: 58px minmax(0, 1.25fr) minmax(0, 1fr) 90px 168px 18px; gap: 14px; padding: 8px 16px; font-size: 11px; font-weight: 800; letter-spacing: .8px; color: #8A968F; background: #F7F9F8; border-top: 1px solid #EEF2F0">'
            '<span>DATE</span><span>ON YOUR STATEMENT</span><span>WHAT IT IS</span><span style="text-align: right">AMOUNT</span><span>WORTH FIGHTING?</span><span></span></div>')
def search_bar():
    return f'<div style="display: flex; gap: 8px; padding: 0 16px 12px"><span style="flex: 1; display: flex; align-items: center; gap: 8px; height: 40px; padding: 0 12px; border-radius: 12px; box-shadow: inset 0 0 0 1.5px #DDE5E0; color: #8A968F; font-size: 13.5px; font-weight: 600">{ic("search", 16, 2.2)}Search a charge, like NFLX or AMZN</span><span style="display: flex; align-items: center; gap: 6px; height: 40px; padding: 0 12px; border-radius: 12px; box-shadow: inset 0 0 0 1.5px #DDE5E0; font-size: 13px; font-weight: 800; color: #43504A">{ic("card", 16, 2.2)}All cards{ic("chevd", 14, 2.4, "#8A968F")}</span></div>'
def charges(m, s='full'):
    title = ctitle('Review your charges', '', '' if m or s == 'nocard' else f'{REVIEWED} charges from the last 90 days')
    if s == 'nocard':
        return box(title + '<div style="border-top: 1px solid #EEF2F0">' + empty('card', 'Connect a card and we review every charge', 'We read 90 days of charges, tell you what each one is, and flag the ones worth fighting. Read-only. We can never move money.', pill('Connect a card', 'dark') + pill('Add a charge yourself', 'soft'), 34) + '</div>')
    if s == 'scanning':
        sk = ''.join(f'<div style="display: flex; align-items: center; gap: 12px; padding: 14px 16px; border-top: 1px solid #EEF2F0"><span style="width: 38px; height: 38px; border-radius: 11px; background: #EEF2F0"></span><span style="flex: 1; display: flex; flex-direction: column; gap: 7px">{skel(f"{w}%")}{skel(f"{w-20}%", 9)}</span>{skel("70px")}</div>' for w in (52, 44, 60, 38))
        return box(title + f'<div style="display: flex; align-items: center; gap: 12px; margin: 0 16px 14px; padding: 12px 14px; border-radius: 14px; background: #E9F6EF">{ic("refresh", 18, 2.4, GREEN)}<span style="flex: 1; display: flex; flex-direction: column; gap: 6px"><b style="font-size: 13.5px">Reviewing 142 charges from Chase Visa 4417</b><span style="height: 6px; border-radius: 99px; background: #CFEBDD; overflow: hidden"><span style="display: block; width: 64%; height: 100%; background: {GREEN}"></span></span></span><b style="font-size: 13px; color: {GREEN}">64%</b></div>' + sk)
    if s == 'clear':
        return box(title + chips([('To review', '0'), ('Worth fighting', '0'), ('Not sure', '0'), ('Looks normal', str(REVIEWED)), ('All', str(REVIEWED))], 0, m) + '<div style="border-top: 1px solid #EEF2F0">'
                   + empty('ccheck', 'Nothing to fight right now', f'All {REVIEWED} charges look normal. We check new charges every day and tell you when something looks off.', pill(f'See all {REVIEWED} charges', 'soft'), 30) + '</div>')
    rows = (section(f'WORTH FIGHTING · {len(FIGHT)}', f'ABOUT {fmt(FIGHT_T)} BACK') + ''.join(chrow(c, m, i == 0) for i, c in enumerate(FIGHT))
            + section(f'NOT SURE, TELL US · {len(LOOK)}', '') + ''.join(chrow(c, m) for c in LOOK)
            + section(f'LOOKS NORMAL · {NORMAL_N}', '') + ''.join(chrow(c, m) for c in OK[:3 if m else 4])
            + f'<div style="padding: 12px 16px; border-top: 1px solid #EEF2F0; font-size: 13px; font-weight: 800; color: {GREEN}">Show all {NORMAL_N} normal charges</div>')
    return box(title + ('' if m else search_bar()) + chips([('To review', str(len(FIGHT) + len(LOOK))), ('Worth fighting', str(len(FIGHT))), ('Not sure', str(len(LOOK))), ('Looks normal', str(NORMAL_N)), ('All', str(REVIEWED))], 0, m)
               + ('' if m else colhead()) + rows)
def facts(c, extra=()):
    src, icon, nm, desc, date, amt, what, vd, why, back, chance, cardn = c
    f = [('Date', date), ('Card', cardn), ('Amount', fmt(amt))] + list(extra)
    return ('<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px 14px">' + ''.join(f'<span style="display: flex; flex-direction: column"><span style="font-size: 11.5px; font-weight: 800; color: #8A968F">{k}</span><b style="font-size: 13.5px">{v}</b></span>' for k, v in f) + '</div>')
def detail(c, v=None, m=False, compact=False):
    src, icon, nm, desc, date, amt, what, vd, why, back, chance, cardn = c
    v = v or vd
    top = (f'<div style="display: flex; align-items: center; gap: 12px">{mark(src, nm, icon, 48)}<span style="flex: 1; display: flex; flex-direction: column; align-items: flex-start; gap: 4px"><b style="font-size: 17px">{nm}</b>{verdict(v)}</span><b style="font-size: 20px; letter-spacing: -.5px">{fmt(amt)}</b></div>'
           f'<div style="display: flex; flex-direction: column; gap: 4px"><span style="font-size: 11.5px; font-weight: 800; letter-spacing: .8px; color: #8A968F">ON YOUR STATEMENT</span><span style="padding: 9px 11px; border-radius: 10px; background: #F3F6F4; font-family: {MONO}; font-size: 12.5px; color: #26302B">{desc}</span></div>'
           f'<div style="display: flex; flex-direction: column; gap: 4px"><span style="font-size: 11.5px; font-weight: 800; letter-spacing: .8px; color: #8A968F">WHAT IT IS</span><span style="font-size: 14px; font-weight: 700; line-height: 1.45">{what}</span></div>')
    btn = lambda t, k, bg, c, sh='': f'<span style="flex: 1; min-height: 48px; border-radius: 16px; background: {bg}; color: {c}; {sh} font-size: 15px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 6px; white-space: nowrap">{ic(k, 16, 2.8) if k else ""}{t}</span>'
    if v == 'fight':
        hist = '' if nm != 'Netflix' else ('<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 11.5px; font-weight: 800; letter-spacing: .8px; color: #8A968F">CHARGE HISTORY</span><div style="display: flex; gap: 4px">'
                + ''.join(f'<span style="flex: 1; padding: 7px 6px; border-radius: 10px; text-align: center; background: {"#EEF2F0" if i == 0 else "#FCECEC"}; display: flex; flex-direction: column"><b style="font-size: 12px">{d}</b><span style="font-size: 11px; font-weight: 800; color: {"#5B6862" if i == 0 else RED}">{t}</span></span>' for i, (d, t) in enumerate((('Jul 12', 'Canceled'), ('Aug 14', '$15.99'), ('Sep 14', '$15.99'), ('Oct 14', '$15.99'))))
                + '</div></div>')
        mid = (f'<div style="padding: 14px; border-radius: 16px; background: #E9F6EF; display: flex; flex-direction: column; gap: 8px"><span style="display: flex; justify-content: space-between; align-items: baseline"><b style="font-size: 15px; color: #0F3B2E">Yes, worth fighting</b><span style="font-size: 12px; font-weight: 800; color: #17603F">{chance} chance</span></span>'
               f'<b style="font-size: 26px; letter-spacing: -.8px; color: {DARK}">About {fmt(back)} back</b>'
               + ''.join(f'<span style="display: flex; gap: 8px; font-size: 13px; font-weight: 600; color: #26302B; line-height: 1.4"><span style="color: {GREEN}; display: flex; margin-top: 1px">{ic("check", 15, 3)}</span>{r}</span>' for r in why) + '</div>' + hist)
        acts = (f'<div style="display: flex; flex-direction: column; gap: 8px">{btn("Fight it", "hand", MINT, DARK, "box-shadow: 0 10px 24px rgba(61,220,151,.3);")}<div style="display: flex; gap: 8px">{btn("It is fine", "", "#FFFFFF", "#0A0F0D", "box-shadow: inset 0 0 0 1.5px #DDE5E0;")}{btn("I do not know it", "", "#FFFFFF", "#0A0F0D", "box-shadow: inset 0 0 0 1.5px #DDE5E0;")}</div>'
                '<span style="font-size: 12px; color: #8A968F; font-weight: 600; text-align: center">Tapping Fight it sends the request. We cancel the plan and ask for the money back.</span></div>')
    elif v == 'look':
        yes, no = ('Yes, it arrived', 'No, fight it') if nm == 'Uber Eats' else ('Yes, that was me', 'No, I do not know it')
        sub = 'If it never arrived, we ask Uber Eats for the full $24.60 back.' if nm == 'Uber Eats' else 'If you did not make it, we report it to your card as fraud and ask for the $59.99 back.'
        mid = f'<div style="padding: 14px; border-radius: 16px; background: {AMBER_BG}; display: flex; flex-direction: column; gap: 6px"><b style="font-size: 16px; color: {AMBER}">{why}</b><span style="font-size: 13px; color: #5C4310; font-weight: 600; line-height: 1.45">{sub}</span></div>'
        acts = f'<div style="display: flex; gap: 8px">{btn(yes, "check", "#FFFFFF", "#0A0F0D", "box-shadow: inset 0 0 0 1.5px #DDE5E0;")}{btn(no, "hand", MINT, DARK)}</div>'
    elif v == 'ok':
        mid = f'<div style="padding: 14px; border-radius: 16px; background: #F3F6F4; display: flex; flex-direction: column; gap: 6px"><b style="font-size: 15px">Looks normal</b><span style="font-size: 13px; color: #5B6862; font-weight: 600; line-height: 1.45">A regular purchase at a place you go often. Nothing to get back here.</span></div>'
        acts = f'<div style="display: flex; gap: 8px">{btn("Fight it anyway", "hand", "#FFFFFF", "#0A0F0D", "box-shadow: inset 0 0 0 1.5px #DDE5E0;")}</div>'
    elif v == 'prog':
        mid = f'<div style="padding: 14px; border-radius: 16px; background: #E8EEFB; display: flex; flex-direction: column; gap: 10px"><b style="font-size: 15px; color: #2C4FA8">We sent your request on Nov 6</b>{bars(2)}<span style="font-size: 13px; color: #33415E; font-weight: 600; line-height: 1.45">SeatGeek replied yesterday. Most refunds land 5 to 10 days after a reply.</span></div>'
        acts = ''
    else:  # done
        mid = f'<div style="padding: 14px; border-radius: 16px; background: #E9F6EF; display: flex; flex-direction: column; gap: 6px"><b style="font-size: 26px; letter-spacing: -.8px; color: {DARK}">{fmt(amt)} back</b><span style="font-size: 13px; color: #17603F; font-weight: 700">Refunded to your {cardn} on Nov 14.</span></div>'
        acts = ''
    if compact:
        return f'<div style="display: flex; flex-direction: column; gap: 12px; padding-top: 12px"><span style="padding: 8px 10px; border-radius: 10px; background: #FFFFFF; font-size: 13px; font-weight: 700">{what}</span>{mid}{acts}</div>'
    return f'<div style="border-radius: 22px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; padding: 18px; display: flex; flex-direction: column; gap: 14px">{top}{facts(c)}{mid}{acts}</div>'
def cards_tile(s='multi'):
    head = lambda sub='': f'<div style="display: flex; align-items: center; justify-content: space-between"><b style="font-size: 16px">Your cards</b><span style="font-size: 12.5px; font-weight: 800; color: {GREEN}">{sub}</span></div>'
    def crd(src, nm, last, st, ok):
        logo = mark(src, nm, 'card', 36) if src else iconbox('card', 36, '#EEF2F0', '#43504A')
        right = '' if ok == 'ok' else pill('Reconnect', 'dark')
        return (f'<div style="display: flex; align-items: center; gap: 10px; padding: 10px 0; border-top: 1px solid #EEF2F0">{logo}<span style="flex: 1; min-width: 0; display: flex; flex-direction: column"><b style="font-size: 14px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{nm} {last}</b>'
                f'<span style="display: flex; align-items: center; gap: 5px; font-size: 12px; font-weight: 700; color: {GREEN if ok == "ok" else RED}">{ic("ccheck" if ok == "ok" else "alert", 13, 2.4)}{st}</span></span>{right}</div>')
    if s == 'none':
        return card(f'{iconbox("card", 40)}<b style="display: block; font-size: 16px; margin: 10px 0 4px">Scan for refunds</b><span style="display: block; font-size: 13px; color: #5B6862; line-height: 1.5; margin-bottom: 12px">Connect a card, read-only. We check 90 days of charges and keep watching every new one.</span>' + pill('Connect a card', 'dark'))
    if s == 'scanning':
        return card(head() + f'<div style="display: flex; align-items: center; gap: 10px; padding: 10px 0; border-top: 1px solid #EEF2F0; margin-top: 10px">{mark("logos2/visa.svg", "Visa", "card", 36)}<span style="flex: 1; display: flex; flex-direction: column; gap: 6px"><b style="font-size: 14px">Chase Visa 4417</b><span style="height: 6px; border-radius: 99px; background: #E3EAE6; overflow: hidden"><span style="display: block; width: 64%; height: 100%; background: {GREEN}"></span></span><span style="font-size: 12px; font-weight: 700; color: #5B6862">Checking 90 days of charges. About a minute left.</span></span></div>')
    lst = {'one': CARDS[:1], 'multi': CARDS[:2], 'bad': CARDS}[s]
    return card(head('+ Add a card') + '<div style="margin-top: 10px">' + ''.join(crd(*x) for x in lst) + '</div>'
                + (f'<span style="display: block; margin-top: 8px; padding: 10px 12px; border-radius: 12px; background: #F3F6F4; font-size: 12.5px; color: #43504A; font-weight: 600">Add every card you pay with. Most people find more on their second card.</span>' if s == 'one' else ''))
def add_charge():
    return card(f'<b style="font-size: 16px">Add a charge yourself</b><span style="display: block; font-size: 13px; color: #5B6862; margin: 2px 0 10px">Anything we did not spot, or a card you do not want to connect.</span>'
                + ''.join(f'<span style="display: flex; height: 42px; margin-bottom: 8px; border-radius: 12px; box-shadow: inset 0 0 0 1.5px #DDE5E0; padding: 0 12px; align-items: center; font-size: 13.5px; font-weight: 600; color: #8A968F">{p}</span>' for p in ('Company, like Planet Fitness', 'Amount, like $39.99', 'What happened?')) + pill(ic('plus', 15, 2.6) + ' Add charge', 'soft'))
def progress(m, s='full'):
    if s == 'empty':
        return box(ctitle('In progress') + '<div style="border-top: 1px solid #EEF2F0">' + empty('clock', 'Nothing in progress yet', 'When you fight a charge, you can follow it here from request to refund.', '', 22) + '</div>')
    return listcard('In progress', '3', [f'<div style="display: flex; {"flex-direction: column; align-items: stretch" if m else "align-items: center"}; gap: 12px; padding: 12px 16px; border-top: 1px solid #EEF2F0"><span style="display: flex; align-items: center; gap: 12px; flex: 1; min-width: 0">{mark(src, nm, "hand", 36)}<span style="display: flex; flex-direction: column"><b style="font-size: 15px">{nm} <span style="color: {GREEN}">{amt}</span></b><span style="font-size: 12.5px; color: #5B6862; font-weight: 600">{why}</span></span></span><span style="{"" if m else "width: 320px"}">{bars(at)}</span></div>' for src, nm, why, amt, at in PROG])
def r_stats(m, s='full'):
    if s == 'full':
        items = [('Worth fighting', fmt(FIGHT_T), f'{len(FIGHT)} charges', GREEN, 'hand'), ('Not sure', str(len(LOOK)) + ' charges', 'Tell us if they are right', AMBER, 'help'), ('In progress', '$127.64', '3 requests', '#2C4FA8', 'clock'), ('Refunded', '$6.45', '1 so far', '#0A0F0D', 'check')]
    else:
        items = [('Worth fighting', '$0.00', 'Connect a card to start', '#8A968F', 'hand'), ('Not sure', '0 charges', 'Nothing to check', '#8A968F', 'help'), ('In progress', '$0.00', 'No requests yet', '#8A968F', 'clock'), ('Refunded', '$0.00', 'Nothing yet', '#8A968F', 'check')]
    return stats(items, m)
LOOKFOR = [('ban', 'Charged after you canceled'), ('copy', 'Charged twice for one thing'), ('clock', 'Free trial that turned paid'), ('truck', 'Order that never arrived'), ('tag', 'Fees you never agreed to'), ('alert', 'Charges you do not recognize')]
def lookfor():
    return card('<b style="font-size: 16px">What we look for</b><div style="display: flex; flex-direction: column; gap: 10px; margin-top: 12px">' + ''.join(f'<span style="display: flex; align-items: center; gap: 10px; font-size: 13.5px; font-weight: 700">{iconbox(k, 30)}{t}</span>' for k, t in LOOKFOR) + '</div>')
def mob_expand(c):
    return f'<div style="padding: 0 14px 14px; border-top: 1px solid #EEF2F0; background: #F5FBF8">{detail(c, m=True, compact=True)}</div>'
def refund_page(m, s='full'):
    sub = 'We check every charge on your cards and tell you which ones are worth fighting.'
    if s == 'new':
        body = r_stats(m, 'new') + two(col(charges(m, 'nocard'), progress(m, 'empty')), col(cards_tile('none'), lookfor(), add_charge()), m, '360px')
        return shell(m, 'refunds', body, 'Claim a refund', sub, ring=40, badges={'claims': '5'})
    if m:
        lst = charges(m).replace(chrow(FIGHT[0], m, True), chrow(FIGHT[0], m, True) + mob_expand(FIGHT[0]), 1)
        return shell(m, 'refunds', r_stats(m) + lst + progress(m) + cards_tile('multi') + add_charge(), 'Claim a refund', sub)
    body = r_stats(m) + two(col(charges(m), progress(m)), col(detail(FIGHT[0]), cards_tile("multi"), add_charge()), m, '380px')
    return shell(m, 'refunds', body, 'Claim a refund', sub)

# ======================= SUBSCRIPTION MANAGER =======================
REN = [('Dec 2', 'YouTube Premium', '$22.99', ''), ('Dec 6', 'Disney+', '$13.99', 'Trial ended, now paid'), ('Dec 9', 'Netflix', '$15.49', ''), ('Dec 14', 'City Fitness', '$39.99', 'Not used'), ('Mar 2', 'Amazon Prime', '$179.88 yearly', 'Yearly')]
def renewing(m, s='full'):
    h = '<div style="display: flex; align-items: center; justify-content: space-between"><b style="font-size: 16px">Renewing soon</b><span style="font-size: 12.5px; color: #5B6862; font-weight: 600">Next 30 days, plus yearly plans</span></div>'
    if s == 'nocard':
        return card(h + f'<div style="display: flex; align-items: center; gap: 12px; margin-top: 12px; padding: 14px; border-radius: 14px; background: #F3F6F4">{iconbox("cal", 36)}<span style="flex: 1; font-size: 13.5px; color: #43504A; font-weight: 600">Connect a card and we show every renewal before it hits.</span></div>')
    if s == 'none':
        return card(h + f'<div style="display: flex; align-items: center; gap: 12px; margin-top: 12px; padding: 14px; border-radius: 14px; background: #F3F6F4">{iconbox("ccheck", 36)}<span style="flex: 1; font-size: 13.5px; color: #43504A; font-weight: 600">Nothing renews in the next 30 days. Next up: Amazon Prime on Mar 2.</span></div>')
    chip = lambda d, n, a, note: (f'<span style="flex: none; min-width: 132px; padding: 10px 12px; border-radius: 14px; background: {"#FCECEC" if note in ("Not used", "Trial ended, now paid") else "#F3F6F4"}; display: flex; flex-direction: column"><span style="font-size: 12px; font-weight: 800; color: {RED if note in ("Not used", "Trial ended, now paid") else GREEN}">{d}</span>'
                                  f'<b style="font-size: 13.5px; white-space: nowrap">{n}</b><span style="font-size: 12px; color: #5B6862">{a}</span>' + (f'<span style="font-size: 11px; font-weight: 800; color: {RED if note != "Yearly" else "#5B6862"}; margin-top: 2px">{note}</span>' if note else '') + '</span>')
    return card(h + '<div style="display: flex; gap: 10px; overflow-x: auto; margin-top: 10px">' + ''.join(chip(*x) for x in REN) + '</div>')
def s_stats(m, s='full'):
    if s == 'full':
        items = [('Per month', fmt(TOTAL_S), f'{len(SUBS)} subscriptions', '#0A0F0D', 'repeat'), ('Not used', fmt(WASTE), 'a month you could save', RED, 'ban'), ('Next renewal', 'Dec 2', 'YouTube Premium, $22.99', '#0A0F0D', 'cal')]
    else:
        items = [('Per month', 'Not set up', 'Connect a card to see', '#8A968F', 'repeat'), ('Not used', '$0.00', 'Nothing to cut yet', '#8A968F', 'ban'), ('Next renewal', 'None yet', 'We remind you before each one', '#8A968F', 'cal')]
    return stats(items, m)
def subrow(src, nm, plan, amt, use, st, m, state=None):
    state = state or ('cancel' if st == 'unused' else 'keep')
    usec = RED if st == 'unused' else '#17603F'
    right = {'cancel': pill('Cancel for me', 'dark'), 'keep': pill('Keep', 'soft'),
             'canceling': f'<span style="display: flex; align-items: center; gap: 6px; font-size: 12.5px; font-weight: 800; color: #2C4FA8; white-space: nowrap">{ic("clock", 14, 2.4)}Canceling</span>',
             'canceled': f'<span style="display: flex; align-items: center; gap: 6px; font-size: 12.5px; font-weight: 800; color: {GREEN}; white-space: nowrap">{ic("ccheck", 14, 2.4)}Canceled</span>',
             'stuck': pill('Sign in to finish', 'dark')}[state]
    note = {'cancel': use, 'keep': use, 'canceling': 'We confirm by email in 1 to 3 days', 'canceled': f'Canceled Nov 14. You save {fmt(amt)} a month.', 'stuck': f'{nm} needs you to sign in once'}[state]
    notec = {'cancel': usec, 'keep': usec, 'canceling': '#2C4FA8', 'canceled': GREEN, 'stuck': AMBER}[state]
    return row(src, nm, plan + ' · ' + fmt(amt) + '/mo', '', (f'<span style="font-size: 12px; font-weight: 800; color: {notec}; white-space: nowrap; {"display: none" if m else ""}">{note}</span>') + right, 40, 'repeat').replace(
        '<span style="font-size: 12.5px; color: #5B6862; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">' + plan,
        f'<span style="font-size: 12.5px; color: #5B6862; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">' + (f'<span style="color: {notec}; font-weight: 800">{note}</span><br>' if m else '') + plan)
def sublist(m, s='full'):
    if s == 'nocard':
        return box(ctitle('Your subscriptions') + '<div style="border-top: 1px solid #EEF2F0">' + empty('repeat', 'Find every subscription you pay for', 'Connect a card and we list each one, how much you use it, and when it renews. We cancel the ones you do not want.', pill('Connect a card', 'dark'), 34) + '</div>')
    if s == 'scanning':
        sk = ''.join(f'<div style="display: flex; align-items: center; gap: 12px; padding: 14px 16px; border-top: 1px solid #EEF2F0"><span style="width: 40px; height: 40px; border-radius: 11px; background: #EEF2F0"></span><span style="flex: 1; display: flex; flex-direction: column; gap: 7px">{skel(f"{w}%")}{skel(f"{w-18}%", 9)}</span>{skel("90px", 30)}</div>' for w in (46, 58, 40))
        return box(ctitle('Your subscriptions') + f'<div style="display: flex; align-items: center; gap: 10px; margin: 0 16px 14px; padding: 12px 14px; border-radius: 14px; background: #E9F6EF; font-size: 13.5px; font-weight: 800">{ic("refresh", 18, 2.4, GREEN)}Finding subscriptions on Chase Visa 4417</div>' + sk)
    if s == 'none':
        return box(ctitle('Your subscriptions', '0') + '<div style="border-top: 1px solid #EEF2F0">' + empty('ccheck', 'No subscriptions found', 'Nothing repeats on your connected cards. Pay with another card? Add it and we check that one too.', pill('Add a card', 'soft'), 30) + '</div>')
    if s == 'allused':
        used = [x for x in SUBS if x[5] == 'used']
        return box(ctitle('Your subscriptions', str(len(used))) + f'<div style="display: flex; align-items: center; gap: 10px; margin: 0 16px 12px; padding: 12px 14px; border-radius: 14px; background: #E9F6EF; color: #17603F; font-size: 13.5px; font-weight: 800">{ic("ccheck", 18, 2.4)}You use everything you pay for. Nice.</div>' + ''.join(subrow(*x, m) for x in used))
    if s == 'mixed':
        L = sorted(SUBS, key=lambda x: x[5] != 'unused')
        states = {'City Fitness': 'canceled', 'Disney+': 'canceling', 'MyFitnessPal': 'stuck'}
        return box(ctitle('Your subscriptions', str(len(SUBS)), 'After you tap Cancel for me') + ''.join(subrow(*x, m, states.get(x[1])) for x in L))
    return box(ctitle('Your subscriptions', str(len(SUBS)), 'Unused ones first') + ''.join(subrow(*x, m) for x in sorted(SUBS, key=lambda x: x[5] != 'unused')))
def alerts(s='on'):
    if s == 'off':
        return f'<div style="display: flex; align-items: center; gap: 12px; padding: 14px 16px; border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; font-size: 14px; font-weight: 700; color: #43504A">{ic("bell", 18, 2.2, "#8A968F")}<span style="flex: 1">Renewal reminders are off. Turn them on to hear 3 days before a charge.</span>{pill("Turn on", "soft")}</div>'
    return f'<div style="display: flex; align-items: center; gap: 12px; padding: 14px 16px; border-radius: 18px; background: #E9F6EF; color: #17603F; font-size: 14px; font-weight: 700">{ic("bell", 18, 2.2)}We tell you 3 days before any free trial turns paid, and before yearly plans renew.</div>'
def subs_page(m, s='full'):
    if s == 'new':
        return shell(m, 'subs', s_stats(m, 'new') + renewing(m, 'nocard') + sublist(m, 'nocard'), 'Subscription Manager', 'Everything you pay for every month, from your connected cards.', ring=40, badges={'claims': '5'})
    return shell(m, 'subs', s_stats(m) + renewing(m) + alerts() + sublist(m), 'Subscription Manager', 'Everything you pay for every month, from your connected cards.')

# ======================= STATES BOARDS =======================
def cell(label, note, inner, w):
    return (f'<div style="width: {w}px; flex: none; display: flex; flex-direction: column; gap: 10px"><span style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap"><span style="padding: 4px 10px; border-radius: 99px; background: {DARK}; color: #FFFFFF; font-size: 12px; font-weight: 800; white-space: nowrap">{label}</span>'
            f'<span style="font-size: 12.5px; color: #5B6862; font-weight: 600">{note}</span></span><div style="font-family: Manrope, sans-serif">{inner}</div></div>')
def group(title, cells):
    return (f'<div style="display: flex; flex-direction: column; gap: 14px; padding: 22px; border-radius: 22px; background: #F3F6F4"><b style="font-size: 18px; letter-spacing: -.3px">{title}</b>'
            f'<div style="display: flex; flex-wrap: wrap; gap: 22px 24px; align-items: flex-start">' + ''.join(cells) + '</div></div>')
def dash_states():
    return [group('Stat tiles', [cell('Has activity', 'Money paid, in progress and subscriptions', d_stats(False), 900), cell('New member', 'Nothing filed or connected yet', d_stats(False, 'new'), 900)]),
            group('To-do list', [cell('Things to do', '', todo(False), 860), cell('New member', 'Only the first steps', todo(False, 'new'), 860), cell('All done', 'Nothing needs the member', todo(False, 'done'), 860)]),
            group('Total coming to you', [cell('Claims and refunds', '', total(False), 340), cell('Claims only', 'No card connected yet', total(False, 'claims'), 340), cell('Nothing yet', 'No claims found', total(False, 'zero'), 340)]
                  + [cell('Recent activity', 'Has updates', activity(False), 340), cell('Recent activity', 'Just joined', activity(False, 'new'), 340), cell('Recent activity', 'Empty', activity(False, 'empty'), 340)]),
            group('Expected payouts', [cell('No claims filed', 'Blurred until a claim is filed', payouts(False, 'locked'), 860), cell('1 claim filed', 'Shows what is filed, nudges the rest', payouts(False, 'one'), 860), cell('Claims filed', 'Paid and expected by month', payouts(False), 860)]),
            group('Profile menu (top right)', [cell('Account not finished', 'Ring shows 71%', menu(71, False), 280), cell('Account complete', 'Full ring', menu(100, False), 280)])]
def refund_states():
    nf = [c for c in CH if c[2] == 'Netflix'][0]; ue = LOOK[0]; st = LOOK[1]; bb = OK[0]
    sg = ('logos2/seatgeek.png', 'receipt', 'SeatGeek', 'SEATGEEK TICKETS NY', 'Oct 28', 41.20, 'Service fees on an event that was canceled', 'prog', [], 41.20, '', 'Visa 4417')
    sb = ('logos/starbucks.svg', 'coffee', 'Starbucks', 'STARBUCKS STORE 05213', 'Oct 21', 6.45, 'One coffee order, charged twice', 'done', [], 6.45, '', 'Visa 4417')
    return [group('Stat tiles', [cell('Has charges', '', r_stats(False), 1100), cell('No card yet', '', r_stats(False, 'new'), 1100)]),
            group('Your cards (scan for refunds)', [cell('No card', 'Ask to connect one', cards_tile('none'), 340), cell('Scanning', 'First check after connecting', cards_tile('scanning'), 340), cell('1 card', 'Nudge to add more', cards_tile('one'), 340),
                                                    cell('2 or more cards', 'Each card listed', cards_tile('multi'), 340), cell('Card needs sign-in', 'Bank link expired', cards_tile('bad'), 340)]),
            group('Review your charges', [cell('No card', '', charges(False, 'nocard'), 860), cell('Scanning', 'While we read the charges', charges(False, 'scanning'), 860), cell('Nothing to fight', 'Everything looks normal', charges(False, 'clear'), 860)]),
            group('Charge details (opens when you tap a charge)', [cell('Worth fighting', '', detail(nf), 380), cell('Not sure: did it arrive?', '', detail(ue), 380), cell('Not sure: do you know it?', '', detail(st), 380), cell('Looks normal', '', detail(bb), 380),
                                                                  cell('In progress', 'After Fight it', detail(sg), 380), cell('Refunded', '', detail(sb), 380)]),
            group('In progress', [cell('Has requests', '', progress(False), 860), cell('Empty', '', progress(False, 'empty'), 860)])]
def subs_states():
    return [group('Stat tiles', [cell('Has subscriptions', '', s_stats(False), 900), cell('No card yet', '', s_stats(False, 'new'), 900)]),
            group('Renewing soon', [cell('Upcoming renewals', 'Red when unused or a trial turned paid', renewing(False), 860), cell('Nothing soon', '', renewing(False, 'none'), 860), cell('No card yet', '', renewing(False, 'nocard'), 860)]),
            group('Reminders', [cell('On', '', alerts('on'), 860), cell('Off', '', alerts('off'), 860)]),
            group('Your subscriptions', [cell('Has subscriptions', '', sublist(False), 1100), cell('Cancel states', 'Canceled, canceling, and one that needs a sign-in', sublist(False, 'mixed'), 1100),
                                         cell('All used', '', sublist(False, 'allused'), 1100), cell('Scanning', '', sublist(False, 'scanning'), 1100), cell('None found', '', sublist(False, 'none'), 1100), cell('No card yet', '', sublist(False, 'nocard'), 1100)])]

# ======================= FILING FEE ONLY (no membership) =======================
# Paid the $49.99 filing fee for the claims they picked. Members only: claims near you, the full Find claims list,
# Claim a refund and Subscription Manager. Those stay visible but blurred behind a join card.
PERKS = [('map', 'Claims near you', 'Local settlements for every place you have lived'), ('list', 'Every open settlement', 'All 294, not just the ones you picked'),
         ('receipt', 'Claim a refund', 'We check your card and fight bad charges'), ('repeat', 'Subscription Manager', 'We cancel what you do not use')]
IC.update({'map': '<path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"></path><circle cx="12" cy="10" r="3"></circle>'})
def join_card(title, text, w=380, perks=True, m=False):
    pl = ('<div style="display: flex; flex-direction: column; gap: 8px; text-align: left; width: 100%; margin: 4px 0">' + ''.join(f'<span style="display: flex; align-items: center; gap: 10px">{iconbox(k, 30)}<span style="display: flex; flex-direction: column"><b style="font-size: 13.5px">{t}</b><span style="font-size: 12px; color: #5B6862; font-weight: 600">{d}</span></span></span>' for k, t, d in PERKS) + '</div>') if perks else ''
    return (f'<div style="width: {"100%" if m else str(w) + "px"}; max-width: 100%; box-sizing: border-box; padding: 20px; border-radius: 22px; background: #FFFFFF; box-shadow: 0 22px 54px rgba(10,15,13,.16), 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; align-items: center; text-align: center; gap: 8px">'
            f'{iconbox("lock", 44)}<span style="font-size: 11.5px; font-weight: 800; letter-spacing: 1px; color: {GREEN}; margin-top: 4px">MEMBERS ONLY</span><b style="font-size: 18px; letter-spacing: -.3px">{title}</b><span style="font-size: 13.5px; color: #5B6862; line-height: 1.5">{text}</span>{pl}'
            f'<span style="width: 100%; min-height: 48px; border-radius: 99px; background: {MINT}; color: {DARK}; font-size: 15px; font-weight: 800; display: flex; align-items: center; justify-content: center; margin-top: 4px">Join for $7.99 your first month</span>'
            '<span style="font-size: 12px; color: #8A968F; font-weight: 600">Then $29.99 a month. Cancel anytime.</span></div>')
def locked(inner, overlay, minh=0, top=False):
    return (f'<div style="position: relative; min-height: {minh}px"><div aria-hidden="true" style="filter: blur(6px); opacity: .5; pointer-events: none; user-select: none">{inner}</div>'
            f'<div style="position: absolute; inset: 0; display: flex; justify-content: center; align-items: {"flex-start; padding-top: 40px" if top else "center"}">{overlay}</div></div>')
def lockline(t):
    return f'<span style="display: inline-flex; align-items: center; gap: 5px; padding: 4px 9px; border-radius: 99px; background: #EEF2F0; color: #43504A; font-size: 12px; font-weight: 800; white-space: nowrap">{ic("lock", 12, 2.6)}{t}</span>'
def fee_banner(m):
    return (f'<div style="display: flex; {"flex-direction: column; align-items: stretch" if m else "align-items: center"}; gap: 14px; padding: 16px 18px; border-radius: 22px; background: {DARK}; color: #FFFFFF">'
            f'<span style="display: flex; align-items: center; gap: 12px; flex: 1">{iconbox("lock", 40, "rgba(255,255,255,.12)", MINT)}<span style="display: flex; flex-direction: column; gap: 2px"><b style="font-size: 15.5px">You paid the filing fee for 5 claims</b>'
            f'<span style="font-size: 13px; color: #C9D6CF; line-height: 1.45">Join to unlock claims near you, every open settlement, refunds and subscriptions.</span></span></span>{pill("Join for $7.99")}</div>')
FEE_TODO = [('user', 'Finish your account', 'Add your date of birth and phone so we can file faster.', pill('Add', 'soft')),
            ('map', 'Claims near you', '12 local settlements match places you have lived.', lockline('Members only')),
            ('receipt', 'Find refunds on your card', 'Members get charges checked and fought for them.', lockline('Members only'))]
def fee_todo(m):
    rows = ''.join(f'<div style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-top: 1px solid #EEF2F0">{iconbox(k, 40, "#E9F6EF" if i == 0 else "#EEF2F0", GREEN if i == 0 else "#8A968F")}'
                   f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column"><b style="font-size: 15px; color: {"#0A0F0D" if i == 0 else "#43504A"}">{t}</b><span style="font-size: 12.5px; color: #5B6862; font-weight: 600">{d}</span></span>{b}</div>' for i, (k, t, d, b) in enumerate(FEE_TODO))
    return box(ctitle('Your to-do list', '1', '' if m else 'Locked items unlock with membership') + rows)
def fee_total(m):
    head = '<span style="font-size: 12.5px; font-weight: 800; letter-spacing: 1px; color: #5B6862">TOTAL COMING TO YOU</span>'
    return card(head + f'<b style="display: block; font-size: 40px; letter-spacing: -1.5px; margin: 4px 0 14px">{fmt(CLAIMS_T)}</b>'
                f'<span style="display: block; font-size: 13px; font-weight: 800; margin-bottom: 10px">Where it comes from</span><span style="display: flex; height: 14px; border-radius: 99px; overflow: hidden"><span style="flex: 515; background: {GREEN}"></span><span style="flex: 160; background: repeating-linear-gradient(45deg, #DDE5E0 0 5px, #F3F6F4 5px 10px)"></span></span>'
                '<span style="display: flex; flex-direction: column; gap: 6px; font-size: 13px; font-weight: 700; margin-top: 10px">'
                f'<span style="display: flex; align-items: center; gap: 8px"><span style="width: 10px; height: 10px; border-radius: 3px; background: {GREEN}"></span><span style="flex: 1">Claims</span><b>{fmt(CLAIMS_T)}</b></span>'
                f'<span style="display: flex; align-items: center; gap: 8px"><span style="width: 10px; height: 10px; border-radius: 3px; background: repeating-linear-gradient(45deg, #DDE5E0 0 2px, #F3F6F4 2px 4px)"></span><span style="flex: 1">Refunds</span>{lockline("Members only")}</span></span>')
LOCAL = [('Kroger', 'Overcharged deli prices', 'Ohio', '$40'), ('Comcast', 'Late fee settlement', 'California', '$65'), ('PG&E', 'Billing error refund', 'California', '$120'), ('Safeway', 'Weighted produce pricing', 'California', '$25')]
def local_rows():
    return ''.join(row('', n, f'{w} · {st}', a, tag('Claim now'), 38, 'map') for n, w, st, a in LOCAL)
def fee_perks(m):
    tile = lambda title, icon, inner, cta: (f'<div style="flex: {"none" if m else "1 1 0"}; min-width: 0; border-radius: 22px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; overflow: hidden; display: flex; flex-direction: column">'
        f'<div style="display: flex; align-items: center; gap: 10px; padding: 14px 16px">{iconbox(icon, 32)}<b style="flex: 1; font-size: 16px; white-space: nowrap">{title}</b>{lockline("Members only")}</div>'
        f'<div style="position: relative; flex: 1"><div aria-hidden="true" style="filter: blur(5px); opacity: .55">{inner}</div><div style="position: absolute; inset: 0; display: flex; align-items: center; justify-content: center">{pill(ic("lock", 14, 2.6) + "&nbsp;" + cta, "dark")}</div></div></div>')
    a = tile('Claims near you', 'map', local_rows()[: len(local_rows())], '12 claims near you')
    b = tile('Claim a refund', 'receipt', ''.join(row(src, nm, why, fmt(back), tag('Worth fighting'), 38, icon) for src, icon, nm, d, dt, amt, why, v, r, back, ch, cd in FIGHT[:4]), 'Find my refunds')
    c = tile('Subscription Manager', 'repeat', ''.join(row(src, nm, use, fmt(amt) + '/mo', tag('Cancel for me'), 38, 'repeat') for src, nm, plan, amt, use, st in (UNUSED + SUBS)[:4]), 'See my subscriptions')
    return (f'<div style="display: flex; flex-direction: column; gap: 12px"><div style="display: flex; align-items: baseline; justify-content: space-between"><b style="font-size: 18px; letter-spacing: -.3px">More with membership</b><span style="font-size: 13px; color: #5B6862; font-weight: 600">{"" if m else "Join for $7.99 your first month"}</span></div>'
            f'<div style="display: flex; {"flex-direction: column" if m else ""}; gap: 12px">{a}{b}{c}</div></div>')
def fee_dash(m):
    st = stats([('Paid to you', '$0.00', 'Your first payout shows here', '#8A968F', 'check'), ('In progress', fmt(CLAIMS_T), '5 claims filed', '#2C4FA8', 'clock'), ('Subscriptions', 'Members only', 'Join to see what you pay for', '#8A968F', 'lock')], m)
    feed = card('<b style="font-size: 16px">Recent activity</b><div style="margin-top: 8px">' + ''.join(
        f'<div style="display: flex; gap: 10px; padding: 10px 0; border-top: 1px solid #EEF2F0"><span style="width: 8px; height: 8px; margin-top: 6px; border-radius: 50%; background: {GREEN}; flex: none"></span><span style="display: flex; flex-direction: column"><span style="font-size: 13.5px; font-weight: 700">{t}</span><span style="font-size: 12px; color: #8A968F; font-weight: 700">{d}</span></span></div>'
        for d, t in (('Today', 'Netflix claim filed with the administrator'), ('Today', 'Apple claim filed with the administrator'), ('Today', 'Filing fee paid for 5 claims'))) + '</div>')
    body = fee_banner(m) + two(col(st, fee_todo(m)), col(fee_total(m), feed), m) + payouts(m, 'claims') + fee_perks(m)
    return shell(m, 'home', body, 'Hi Henry', 'Your 5 claims are filed. We will tell you when each one pays.', show_menu=not m, member=False, badges={'claims': '5'})
SETS = [('logos/apple.svg', 'Apple', 'Siri privacy settlement', 'Up to $100', 'Closes Dec 2'), ('logos2/google.png', 'Google', 'Location tracking', 'Up to $85', 'Closes Jan 10'), ('logos2/youtube.png', 'YouTube', 'Kids data settlement', 'Up to $30', 'Closes Dec 19'),
        ('logos/starbucks.svg', 'Starbucks', 'Rewards card fees', 'Up to $45', 'Closes Feb 1'), ('logos2/netflix.svg', 'Netflix', 'Auto-renew settlement', 'Up to $60', 'Closes Jan 22'), ('logos/amazon.svg', 'Amazon', 'Prime cancel settlement', 'Up to $51', 'Closes Mar 4'),
        ('logos2/disney.png', 'Disney+', 'Price increase notice', 'Up to $20', 'Closes Feb 14'), ('logos2/ubereats.png', 'Uber Eats', 'Delivery fee settlement', 'Up to $35', 'Closes Jan 30'), ('logos2/seatgeek.png', 'SeatGeek', 'Ticket fee settlement', 'Up to $40', 'Closes Feb 20')]
def fee_find(m):
    tabs = (f'<div style="display: flex; gap: 8px; {"overflow-x: auto" if m else ""}">' + ''.join(f'<span style="flex: none; min-height: 38px; padding: 0 14px; border-radius: 99px; font-size: 13.5px; font-weight: 800; display: flex; align-items: center; gap: 6px; white-space: nowrap; {"background: #0F3B2E; color: #FFFFFF" if i == 0 else "background: #FFFFFF; color: #43504A; box-shadow: inset 0 0 0 1.5px #DDE5E0"}">{t}</span>'
            for i, t in enumerate(('Nationwide', ic('lock', 13, 2.6) + ' Near you', 'Popular', 'Closing soon', 'A to Z'))) + '</div>')
    rw = lambda x: row(x[0], x[1], x[2] + ' · ' + x[4], x[3], pill('Claim', 'soft'), 40, 'file')
    open6 = ''.join(rw(x) for x in SETS[:6])
    rest = ''.join(rw(x) for x in SETS[6:] + SETS[:3])
    lst = box(ctitle('All open settlements', '294', '' if m else 'You can see 6. Members see all 294.') + open6
              + locked(rest, join_card('See all 294 settlements', 'Members can claim any open settlement, plus the ones near where you have lived.', 400, False, m), 360))
    near = box(ctitle('Near you', '', '' if m else 'California and Ohio, from your addresses') + locked(local_rows(), pill(ic('lock', 14, 2.6) + '&nbsp;12 claims near you. Join to see them', 'dark')))
    return shell(m, 'find', tabs + (lst + near if m else two(lst, near, m, '420px')), 'Find claims', 'Open settlements you can claim.', member=False, badges={'claims': '5'})
def fee_refund(m):
    inner = r_stats(m) + two(charges(m), col(detail(FIGHT[0])), m, '380px') if not m else r_stats(m) + charges(m)
    body = locked(inner, join_card('Claim a refund is part of membership', 'We check every charge on your cards, tell you what each one is, and fight the ones worth fighting.', 420, True, m), 900 if not m else 700, True)
    return shell(m, 'refunds', body, 'Claim a refund', 'We check every charge on your cards and tell you which ones are worth fighting.', member=False, badges={'claims': '5'})
def fee_subs(m):
    inner = s_stats(m) + renewing(m) + sublist(m)
    body = locked(inner, join_card('Subscription Manager is part of membership', 'See everything you pay for each month, get a heads up before renewals, and we cancel what you do not use.', 420, True, m), 700, True)
    return shell(m, 'subs', body, 'Subscription Manager', 'Everything you pay for every month, from your connected cards.', member=False, badges={'claims': '5'})

BOARDS = [('DashHome', 'Dashboard · chosen design (profile menu shown open)', lambda m: dash_page(m), None),
          ('DashHomeNew', 'Dashboard · new member (claims found, nothing filed, no card)', lambda m: dash_page(m, 'new'), None),
          ('DashHomeStates', 'Dashboard · every tile in each state', None, dash_states),
          ('RefundReview', 'Claim a refund · review your charges (Netflix selected)', lambda m: refund_page(m), None),
          ('RefundReviewNew', 'Claim a refund · new member (no card yet)', lambda m: refund_page(m, 'new'), None),
          ('RefundReviewStates', 'Claim a refund · every tile in each state', None, refund_states),
          ('SubsManager', 'Subscription Manager · chosen design', lambda m: subs_page(m), None),
          ('SubsManagerNew', 'Subscription Manager · new member (no card yet)', lambda m: subs_page(m, 'new'), None),
          ('SubsManagerStates', 'Subscription Manager · every tile in each state', None, subs_states),
          ('FeeDash', 'Filing fee only · Dashboard (profile menu shown open)', fee_dash, None),
          ('FeeFind', 'Filing fee only · Find claims (6 shown, rest and Near you locked)', fee_find, None),
          ('FeeRefund', 'Filing fee only · Claim a refund (locked, still visible)', fee_refund, None),
          ('FeeSubs', 'Filing fee only · Subscription Manager (locked, still visible)', fee_subs, None)]
if __name__ == '__main__':
    for name, title, fn, sfn in BOARDS:
        if fn:
            inner = (f'<div style="display: flex; gap: 48px; align-items: flex-start"><div style="width: 1440px; flex: none; overflow: hidden; border-radius: 18px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{fn(False)}</div>'
                     f'<div style="width: 390px; flex: none; overflow: hidden; border-radius: 28px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{fn(True)}</div></div>')
        else:
            inner = '<div style="display: flex; flex-direction: column; gap: 20px">' + ''.join(sfn()) + '</div>'
        page = (f'<div data-board style="width: 1926px; box-sizing: border-box; padding: 24px; background: #E7ECE9; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 14px">'
                f'<div style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #43504A">{title.upper()}</div>{inner}</div>\n</x-dc>\n')
        open(os.path.join(OUT, name + '.dc.html'), 'w').write(HEAD % title + page + JS)
    print('built', [b[0] for b in BOARDS])
