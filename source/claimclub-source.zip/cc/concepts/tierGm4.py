# B3 with tags, 3 icon sets for the time-to-file block (Nov 21 2026, design only). Henry: Standard shows "Only X claims".
# Board OfferG2mT. Icons are Lucide (ISC), copied into cc/concepts/lucide/.
import os, re
from tierGm2 import P, FOOT, li, price, pill, radio, board
from tierE import mob, h, ic, INK, MUTE, LINE, MINT, GREEN, DARK

STD_N = 17  # placeholder: nationwide settlements that need no claim form (auto). Replace with the real auto-filed count.
D = os.path.dirname(os.path.abspath(__file__))
def lic(name, sz, c, sw=2.2):
    inner = re.sub(r'^.*?<svg[^>]*>|</svg>.*$', '', open(os.path.join(D, 'lucide', name + '.svg')).read(), flags=re.S).strip()
    return f'<svg width="{sz}" height="{sz}" viewBox="0 0 24 24" fill="none" stroke="{c}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex: none">{inner}</svg>'
SUB = f'<span style="font-size: 13px; font-weight: 600; color: {MUTE}; margin-top: -6px">How fast we file your claims after you join.</span>'
FEATS = {'std': [f'Only {STD_N} claims', '3 of your 6 claims'], 'fast': ['All 173 nationwide claims', 'All 6 of your claims', 'Reminders on new claims'],
         'pri': ['All 270 claims, incl. local', 'New claims filed for you', 'Refunds + subscriptions']}

def screen(icons, isz=18):
    def card(k):
        p = P[k]; dark = k == 'pri'; sel = k == 'fast'
        bg = DARK if dark else '#FFFFFF'
        ring = f'inset 0 0 0 2px {MINT}, 0 12px 26px rgba(18,128,92,.16)' if sel else ('0 12px 26px rgba(10,15,13,.18)' if dark else f'inset 0 0 0 1px {LINE}')
        fg = '#FFFFFF' if dark else INK; mu = '#9FC3B4' if dark else MUTE
        num, unit = p['speed'].split(' ')
        blk = ('background: ' + MINT + '; color: ' + DARK) if sel else ('background: rgba(61,220,151,.16); color: #FFFFFF' if dark else 'background: #F1F4F2; color: ' + INK)
        icc = DARK if sel else (MINT if dark else MUTE)
        tag = pill(p['tag'], MINT, DARK) if sel else (pill(p['tag'], 'rgba(61,220,151,.18)', MINT) if dark else '')
        feats = ''.join(li(f, MINT if dark else GREEN, '#E6EEEA' if dark else INK, 12.5) if not f.startswith('Only') else
                        f'<div style="display: flex; align-items: center; gap: 8px; font-size: 12.5px; font-weight: 800; color: #9A6B00">{ic("x", 13, "#C08A00", 2.8)}<span>{f}</span></div>' for f in FEATS[k])
        return (f'<div style="border-radius: 18px; padding: 12px; background: {bg}; box-shadow: {ring}; color: {fg}; display: flex; gap: 12px; align-items: stretch">'
                f'<div style="width: 76px; flex: none; border-radius: 12px; {blk}; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 1px">'
                f'{lic(icons[k], isz, icc)}<b style="font-size: 27px; letter-spacing: -1px; line-height: 1.1">{num}</b><span style="font-size: 10.5px; font-weight: 800; opacity: .8">{unit.upper()}</span></div>'
                f'<div style="flex: 1; display: flex; flex-direction: column; gap: 6px; padding: 2px 0"><div style="display: flex; align-items: center; gap: 7px">{radio(sel, dark)}<b style="font-size: 16px">{p["name"]}</b>{tag}<span style="flex: 1"></span>{price(p, fg, mu, 18)}</div>'
                + feats + '</div></div>')
    return mob(h('How fast should we file?', 23, False) + SUB + card('std') + card('fast') + card('pri'), FOOT())

if __name__ == '__main__':
    board('OfferG2mT', 'B3 WITH TAGS · 3 ICON SETS', [
        ('T1 · TURTLE, RABBIT, ROCKET', 'Playful speed animals: slow, quick, fastest. Standard says "Only 17 claims".', screen({'std': 'turtle', 'fast': 'rabbit', 'pri': 'rocket'}, 24)),
        ('T2 · HOURGLASS, TIMER, BOLT', 'Time-based: waiting, a few days, right away.', screen({'std': 'hourglass', 'fast': 'timer', 'pri': 'zap'}, 22)),
        ('T3 · CALENDAR, GAUGE, ROCKET', 'A month on the calendar, a speed gauge, then the rocket for 24 hours.', screen({'std': 'calendar-days', 'fast': 'gauge', 'pri': 'rocket'}, 22))])
    print('ok')
