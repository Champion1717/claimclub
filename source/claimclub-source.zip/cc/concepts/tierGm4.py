# B3 with tags, 3 icon sets for the time-to-file block (Nov 21 2026, design only). Henry: Standard shows "Only X claims".
# Board OfferG2mT. Icons are Lucide (ISC), copied into cc/concepts/lucide/.
import os, re
from tierGm2 import P, FOOT, li, price, pill, radio, board
from tierE import mob, h, ic, INK, MUTE, LINE, MINT, GREEN, DARK

STD_N = 17  # placeholder: nationwide settlements that need no claim form (auto). Replace with the real auto-filed count.
D = os.path.dirname(os.path.abspath(__file__))
def lic(name, sz, c, sw=2.2):
    inner = re.sub(r'^.*?<svg[^>]*>|</svg>.*$', '', open(os.path.join(D, 'lucide', name + '.svg')).read(), flags=re.S).strip()
    return f'<svg width="{sz}" height="{sz}" viewBox="0 0 24 24" fill="none" stroke="{c}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex: none">{inner}</svg>'
SUB = f'<span style="font-size: 13px; font-weight: 600; color: {MUTE}; margin-top: -6px">How fast we file your claims after you join.</span>'
FEATS = {'std': [f'Only {STD_N} claims', '3 of your 6 claims', 'Track claims in your dashboard'], 'fast': ['All 173 nationwide claims', 'All 6 of your claims', 'Reminders on new claims', 'Track claims in your dashboard'],
         'pri': ['All 270 claims, incl. local', 'New claims filed for you', 'First look at new claims', 'Claim refunds', 'Subscription Manager']}

def screen(icons, isz=18, pick='fast'):
    def card(k):
        p = P[k]; dark = k == 'pri'; sel = k == pick
        bg = DARK if dark else '#FFFFFF'
        ring = f'inset 0 0 0 2px {MINT}, 0 12px 26px rgba(18,128,92,.16)' if sel and not dark else f'inset 0 0 0 2px {MINT}, 0 12px 26px rgba(10,15,13,.22)' if sel else ('0 12px 26px rgba(10,15,13,.18)' if dark else f'inset 0 0 0 1px {LINE}')
        fg = '#FFFFFF' if dark else INK; mu = '#9FC3B4' if dark else MUTE
        num, unit = p['speed'].split(' ')
        blk = ('background: ' + MINT + '; color: ' + DARK) if sel else ('background: rgba(61,220,151,.16); color: #FFFFFF' if dark else 'background: #F1F4F2; color: ' + INK)
        icc = DARK if sel else (MINT if dark else MUTE)
        tag = pill(p['tag'], MINT, DARK) if k == 'fast' else (pill(p['tag'], 'rgba(61,220,151,.18)', MINT) if dark else '')
        feats = ''.join(li(f, MINT if dark else GREEN, '#E6EEEA' if dark else INK, 12.5) for f in FEATS[k])
        return (f'<div style="border-radius: 18px; padding: 12px; background: {bg}; box-shadow: {ring}; color: {fg}; display: flex; gap: 12px; align-items: stretch">'
                f'<div style="width: 76px; flex: none; border-radius: 12px; {blk}; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 1px">'
                f'{lic(icons[k], isz, icc)}<b style="font-size: 27px; letter-spacing: -1px; line-height: 1.1">{num}</b><span style="font-size: 10.5px; font-weight: 800; opacity: .8">{unit.upper()}</span></div>'
                f'<div style="flex: 1; display: flex; flex-direction: column; gap: 6px; padding: 2px 0"><div style="display: flex; align-items: center; gap: 7px">{radio(sel, dark)}<b style="font-size: 16px">{p["name"]}</b>{tag}<span style="flex: 1"></span>{price(p, fg, mu, 18)}</div>'
                + feats + '</div></div>')
    foot = FOOT() if pick == 'fast' else FOOT('Start Priority · $30 today', '$30 today, renews monthly. Cancel anytime. Payouts take 6 to 12 months on every plan.')
    return mob(h('How fast should we file?', 23, False) + SUB + card('std') + card('fast') + card('pri'), foot)

if __name__ == '__main__':
    board('OfferG2mT', 'B3 WITH TAGS · 3 ICON SETS', [
        ('T1 · TURTLE, RABBIT, ROCKET', 'Playful speed animals: slow, quick, fastest. Standard says "Only 17 claims".', screen({'std': 'turtle', 'fast': 'rabbit', 'pri': 'rocket'}, 24)),
        ('T2 · HOURGLASS, TIMER, BOLT', 'Time-based: waiting, a few days, right away.', screen({'std': 'hourglass', 'fast': 'timer', 'pri': 'zap'}, 22)),
        ('T3 · CALENDAR, GAUGE, ROCKET', 'A month on the calendar, a speed gauge, then the rocket for 24 hours.', screen({'std': 'calendar-days', 'fast': 'gauge', 'pri': 'rocket'}, 22))])
    T3 = {'std': 'calendar-days', 'fast': 'gauge', 'pri': 'rocket'}
    board('OfferG2mT3', 'T3 · CALENDAR, GAUGE, ROCKET · FINAL', [
        ('FAST PICKED', 'Default when the page opens. Standard lists "Only 17 claims" like any other line. Priority shows its 5 extras.', screen(T3, 22)),
        ('PRIORITY PICKED', 'After tapping Priority: mint ring and time block on Priority, button becomes "Start Priority · $30 today".', screen(T3, 22, 'pri'))])
    print('ok')
