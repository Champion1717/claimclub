import re
LOGO=open('/home/claude/cc/src/logo.txt').read().strip().replace('__C__','#0A0F0D').replace('#FFB224','#12805C')
LOGOW=open('/home/claude/cc/src/logo.txt').read().strip().replace('__C__','#FFFFFF').replace('#FFB224','#3DDC97')
HEAD='''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>%s</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@500;600;700;800&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet">
<style>
button{font-family:inherit;border:0;cursor:pointer}
.scroll{scrollbar-width:thin;scrollbar-color:#C9D3CD transparent}.scroll::-webkit-scrollbar{width:8px;height:8px}.scroll::-webkit-scrollbar-thumb{background:#C9D3CD;border-radius:99px}.scroll::-webkit-scrollbar-track{background:transparent}
button:focus-visible{outline:3px solid #3DDC97;outline-offset:2px}
@keyframes spin{to{transform:rotate(360deg)}}
.spin{width:16px;height:16px;border-radius:50%%;border:2.5px solid rgba(255,255,255,.35);border-top-color:#FFFFFF;animation:spin .7s linear infinite}
@keyframes noteIn{0%%{opacity:0;transform:translateY(18px) scale(.96)}60%%{opacity:1;transform:translateY(-2px) scale(1.01)}100%%{opacity:1;transform:none}}
.note{animation:noteIn .45s cubic-bezier(.2,.9,.3,1.2) both}
@keyframes chk{from{stroke-dashoffset:24}to{stroke-dashoffset:0}}
.note .ck path{stroke-dasharray:24;animation:chk .45s ease .25s both}
@keyframes ring{0%%{transform:scale(.6);opacity:.9}100%%{transform:scale(2.2);opacity:0}}
.note .rg{animation:ring .9s ease-out .15s both}
@keyframes pop{0%%{opacity:0;transform:translate(0,0) scale(.5)}20%%{opacity:1}100%%{opacity:0;transform:translate(var(--x),var(--y)) scale(1)}}
.note .cf{position:absolute;left:30px;top:30px;width:6px;height:6px;border-radius:2px;animation:pop .9s cubic-bezier(.2,.8,.3,1) .2s both}
@keyframes justIn{0%%{background:#D9F5E7;transform:translateY(-6px);opacity:0}30%%{opacity:1;transform:none}100%%{background:#FFFFFF}}
.just{animation:justIn 1.6s ease both}
@keyframes cardIn{0%%{opacity:0;transform:translateY(-10px) scale(.97)}100%%{opacity:1;transform:none}}
.cardin{animation:cardIn .45s cubic-bezier(.2,.9,.3,1.2) both}
@media (prefers-reduced-motion: reduce){*{animation-duration:.01s !important;animation-iteration-count:1 !important}}
%s
</style>
</helmet>
'''
TAIL='''</x-dc>
<script type="text/x-dc" data-dc-script data-props='{"$preview":{"width":1440,"height":900}}'>
class Component extends DCLogic {
  constructor(props) {
    super(props);
    this.state = { st: { apple: 'ready', cvs: 'ready', googleplay: 'ready', amazon: 'ready', tyson: 'ready', goodrx: 'review', realpage: 'filed', netflix: 'filed', kroger: 'approved', squatch: 'paid' }, busy: '', note: null, just: '', seq: 48210, focus: 0, view: 'all', acct: { email: 1, auth: 1, name: 1 }, info: '', ans: {}, sheet: null, form: {}, view: 'dash', scale: 'm', theme: 'light', bankAsk: false };
  }
  claims() {
    return [
      { id: 'apple', co: 'Apple', title: 'Siri Privacy Settlement', amt: '$95', n: 95, days: 39, kind: 'here', need: true, why: 'You owned an Apple device with Siri, 2014 to 2024' },
      { id: 'cvs', co: 'CVS', title: 'Generic Drug Pricing', amt: '$5', n: 5, days: 4, kind: 'here', why: 'You filled a generic prescription at CVS' },
      { id: 'googleplay', co: 'Google Play', title: 'App Store Settlement', amt: '$100', n: 100, days: 29, kind: 'here', need: true, why: 'You bought apps or in-app items on Google Play' },
      { id: 'amazon', co: 'Amazon', title: 'Prime Cancellation Settlement', amt: 'Varies', n: 0, days: 19, kind: 'auto', why: 'You had Amazon Prime, 2019 to 2025' },
      { id: 'tyson', co: 'Tyson & beef packers', title: 'Beef Price-Fixing', amt: '$100', n: 100, days: 18, kind: 'here', why: 'You bought beef for your household' },
      { id: 'goodrx', co: 'GoodRx', title: 'Data Sharing Settlement', amt: '$40', n: 40, days: 47, kind: 'here', why: '' },
      { id: 'realpage', co: 'RealPage', title: 'Rent Algorithm Settlement', amt: '$100', n: 100, days: 78, kind: 'here', why: '' },
      { id: 'netflix', co: 'Netflix', title: 'Arbitration Claim', amt: 'TBD', n: 0, days: 0, kind: 'arb', why: '' },
      { id: 'kroger', co: 'Kroger', title: 'Data Breach Settlement', amt: '$50', n: 50, days: 0, kind: 'here', why: '' },
      { id: 'squatch', co: 'Dr. Squatch', title: 'Soap Labeling Settlement', amt: '$25', n: 25, days: 0, kind: 'here', why: '' }
    ].concat(this.extras().filter(x => (this.state.ans || {})[x.id] === 'yes'));
  }
  extras() {
    return [
      { id: 'visa', co: 'Visa & Mastercard', title: 'ATM Access Fee Settlement', amt: 'Up to $1,000', n: 0, days: 88, kind: 'here', q: 'Have you paid a fee to use an out-of-network ATM?', why: 'You paid an out-of-network ATM fee' },
      { id: 'starbucks', co: 'Starbucks', title: 'COBRA Notice Settlement', amt: '$74', n: 74, days: 19, kind: 'here', q: 'Did you get a COBRA health insurance notice after leaving Starbucks?', why: 'You got a Starbucks COBRA notice' },
      { id: 'knotts', co: 'Six Flags', title: "Knott's & Great America Ticket Fees", amt: '$8', n: 8, days: 39, kind: 'here', q: "Did you buy Knott's Berry Farm or Great America tickets online?", why: 'You bought tickets online' },
      { id: 'bofa', co: 'Bank of America', title: 'Debit Card Dispute Settlement', amt: 'Varies', n: 0, days: 28, kind: 'here', q: 'Did Bank of America deny a fraud dispute you filed since 2023?', why: 'Bank of America denied your dispute' }
    ];
  }
  logos() {
    return { visa: '/_blob/17d130cb2fd653ada0d1561043e8aa56', starbucks: '/_blob/28379ee7c2bc6b1d08ee6e6ec8cde00a', knotts: '/_blob/41faa40085ee9bfc601f3cf6dc22de18', bofa: '/_blob/121d9429923e05b984526c8965383d6a', amazon: '/_blob/9e823dce7e60dc8d8b58da2243d7151d', apple: '/_blob/7fd6ec4499df609a19ab46e16342f49d', cvs: '/_blob/1ceb7905467ce333f9268b10d05d201d', goodrx: '/_blob/20058f58cf0cc867f90794121d8fa7cd', kroger: '/_blob/1bde1fe61d713099dffdf1ede7857c39', squatch: '/_blob/2d81ba8fe0a13c9f47d35e8ecbd1db1d', googleplay: '/_blob/7f4390cee228878d694a9ab5d8bd863a', netflix: '/_blob/6450426b362962920828f44df101d658', realpage: '/_blob/db93ff119ed82ac214d13401f1e7f659', tyson: '/_blob/c655327b9222899295d427826bd844fe' };
  }
  setupVals() {
    const s = this.state, steps = this.setup(), tip = (k) => ({ open: s.info === k, toggle: () => this.setState({ info: s.info === k ? '' : k }) });
    const TAG = { 'For filing': 'background:#E9F6EF;color:#17603F', 'For payouts': 'background:#FFF4DB;color:#8A5A00', 'For notifications': 'background:#E8EEFB;color:#2C4FA8', 'Account': 'background:#EEF2F0;color:#43504A' };
    const done = steps.filter(x => s.acct[x.id]).length, pct = Math.round(done / steps.length * 100), C = 2 * Math.PI * 34;
    const next = steps.find(x => !s.acct[x.id]);
    const mark = (id) => this.setState({ acct: Object.assign({}, this.state.acct, { [id]: 1 }), info: '' });
    return {
      steps: steps.map(x => { const d = !!s.acct[x.id], t = tip('s-' + x.id); return Object.assign({}, x, {
        done: d, todo: !d, open: t.open, toggle: t.toggle, act: () => mark(x.id), isNext: next && next.id === x.id, optional: !!x.optional,
        tagStyle: 'font-size:11px;font-weight:800;padding:2px 8px;border-radius:99px;' + TAG[x.tag],
        dot: 'width:24px;height:24px;flex:none;border-radius:50%;display:flex;align-items:center;justify-content:center;' + (d ? 'background:#12805C' : 'box-shadow:inset 0 0 0 2px #C9D3CD'),
        lbl: 'font-size:15px;font-weight:800;' + (d ? 'color:#8A968F;text-decoration:line-through' : 'color:#0A0F0D'),
        ctaStyle: 'min-height:36px;padding:0 16px;border-radius:99px;font-size:13px;font-weight:800;white-space:nowrap;' + (next && next.id === x.id ? 'background:#0A0F0D;color:#FFFFFF' : 'background:#EEF2F0;color:#0A0F0D'),
        infoStyle: 'width:28px;height:28px;flex:none;border-radius:50%;display:flex;align-items:center;justify-content:center;' + (t.open ? 'background:#0A0F0D;color:#FFFFFF' : 'background:transparent;color:#8A968F')
      }); }),
      setupPct: pct, setupLeft: steps.length - done, setupDone: done === steps.length, setupOpen: done < steps.length,
      ringStyle: 'transition:stroke-dashoffset .6s cubic-bezier(.2,.8,.2,1);stroke-dasharray:' + C.toFixed(1) + ';stroke-dashoffset:' + (C * (1 - pct / 100)).toFixed(1),
      nextLabel: next ? next.label : '', nextAct: () => next && mark(next.id),
      curN: next ? steps.indexOf(next) + 1 : steps.length, stepsN: steps.length, curTag: next ? next.tag : '', curWhy: next ? next.why : '', curCta: next ? next.cta : '', curOptional: !!(next && next.optional),
      curTagStyle: 'font-size:11px;font-weight:800;padding:2px 8px;border-radius:99px;' + (next ? TAG[next.tag] : ''), skipStep: () => next && mark(next.id), tCur: tip('cur'),
      setupBar: 'width:' + pct + '%;height:100%;border-radius:99px;background:#12805C;transition:width .6s cubic-bezier(.2,.8,.2,1)',
      tReady: tip('ready'), tTrack: tip('track'), tSetup: tip('setup')
    };
  }
  answer(id, v) {
    const st = Object.assign({}, this.state.st), ans = Object.assign({}, this.state.ans, { [id]: v });
    if (v === 'yes') st[id] = 'ready';
    this.setState({ ans, st, just: v === 'yes' ? id : '' });
  }
  forms() {
    return {
      apple: { qs: [{ k: 'q1', t: 'Did you own an Apple device with Siri between Sept 17, 2014 and Dec 31, 2024?' }, { k: 'q2', t: 'Did Siri ever turn on by itself during a private conversation?' }],
        fields: [{ k: 'dev', type: 'multi', label: 'Which Siri devices did you own?', hint: '$20 per device, up to 5 devices.', opts: ['iPhone', 'iPad', 'Mac', 'Apple Watch', 'HomePod', 'Apple TV'] },
          { k: 'sn', type: 'text', label: 'Serial number or Apple ID email', hint: 'Optional. It can speed up approval.', ph: 'e.g. F2LXK1ABCD12', optional: true }],
        est: (f) => '$' + Math.min(5, (f.dev || []).length) * 20, sum: (f) => (f.dev || []).join(', ') },
      googleplay: { qs: [{ k: 'q1', t: 'Did you buy apps or in-app items on Google Play between Aug 16, 2016 and Sept 30, 2023?' }, { k: 'q2', t: 'Were you living in the U.S. when you made those purchases?' }],
        fields: [{ k: 'acct', type: 'text', label: 'Google account email you used', hint: 'The administrator uses it to look up your purchases.', ph: 'name@gmail.com' },
          { k: 'spend', type: 'single', label: 'About how much did you spend in total?', hint: 'A rough estimate is fine.', opts: ['Under $50', '$50 to $200', '$200 to $1,000', 'Over $1,000'] }],
        est: (f) => 'Up to $100', sum: (f) => [f.acct, f.spend].filter(Boolean).join(' · ') }
    };
  }
  file(id) {
    const c = this.claims().find(x => x.id === id);
    if (c && c.need) { this.setState({ sheet: { id, step: 1 }, form: {}, bankAsk: false }); return; }
    this.doFile(id);
  }
  setForm(k, v) { this.setState({ form: Object.assign({}, this.state.form, { [k]: v }) }); }
  sheetVals() {
    const s = this.state, sh = s.sheet;
    const chip = (on) => 'min-height:36px;padding:0 14px;border-radius:99px;font-size:13px;font-weight:800;' + (on ? 'background:#0F3B2E;color:#FFFFFF' : 'background:#FFFFFF;color:#0A0F0D;box-shadow:inset 0 0 0 1.5px #DDE5E0');
    if (!sh) return { sheetOpen: false, sh: { s1: false, s2: false, s3: false, qs: [], fields: [], pay: [] } };
    const c = this.claims().find(x => x.id === sh.id), F = this.forms()[sh.id], f = s.form;
    const qs = F.qs.map(q => ({ t: q.t, yes: () => this.setForm(q.k, 'yes'), no: () => this.setForm(q.k, 'no'), yesSt: chip(f[q.k] === 'yes'), noSt: chip(f[q.k] === 'no') }));
    const anyNo = F.qs.some(q => f[q.k] === 'no'), ok1 = F.qs.every(q => f[q.k] === 'yes');
    const fields = F.fields.map(x => ({ label: x.label, hint: x.hint, ph: x.ph || '', isText: x.type === 'text', isChips: x.type !== 'text', optional: !!x.optional, val: f[x.k] || '',
      onIn: (e) => this.setForm(x.k, e.target.value),
      opts: (x.opts || []).map(o => { const on = x.type === 'multi' ? (f[x.k] || []).indexOf(o) >= 0 : f[x.k] === o; return { o, st: chip(on), tap: () => { if (x.type === 'multi') { const a = (f[x.k] || []).slice(), i = a.indexOf(o); i >= 0 ? a.splice(i, 1) : a.push(o); this.setForm(x.k, a); } else this.setForm(x.k, o); } }; }) }));
    const ok2 = F.fields.every(x => x.optional || (x.type === 'multi' ? (f[x.k] || []).length > 0 : x.type === 'text' ? /@/.test(f[x.k] || '') : !!f[x.k]));
    const bank = !!s.acct.bank, pm = f.pay || (bank ? 'Direct deposit' : '');
    const needBank = pm === 'Direct deposit' && !bank;
    const ok3 = !!pm && !needBank && !!f.sign;
    const step = sh.step, can = step === 1 ? ok1 : step === 2 ? ok2 : ok3;
    const titles = ['Confirm you qualify', 'A few details', 'Review and sign'];
    return {
      sheetOpen: true,
      sh: {
        co: c.co, title: c.title, logo: this.logos()[c.id], amt: c.amt, step, s1: step === 1, s2: step === 2, s3: step === 3, stepTitle: titles[step - 1],
        dots: [1, 2, 3].map(i => ({ st: 'flex:1;height:5px;border-radius:99px;background:' + (i <= step ? '#12805C' : '#E3EAE6') })),
        qs, anyNo, fields, est: F.est(f), summary: F.sum(f) || '',
        pay: ['Direct deposit', 'PayPal', 'Check'].map(o => ({ o, st: chip(pm === o), tap: () => this.setForm('pay', o) })), needBank,
        connectBank: () => this.setState({ acct: Object.assign({}, s.acct, { bank: 1 }) }),
        sign: !!f.sign, signTap: () => this.setForm('sign', !f.sign), signBox: 'width:22px;height:22px;flex:none;border-radius:7px;display:flex;align-items:center;justify-content:center;' + (f.sign ? 'background:#12805C' : 'box-shadow:inset 0 0 0 2px #C9D3CD;background:#FFFFFF'),
        hasBack: step > 1, back: () => this.setState({ sheet: { id: sh.id, step: step - 1 } }),
        nextLabel: step === 3 ? 'Submit claim' : 'Continue',
        nextSt: 'flex:1;min-height:46px;border-radius:99px;font-size:15px;font-weight:800;transition:opacity .15s;' + (step === 3 ? 'background:#3DDC97;color:#0A0F0D' : 'background:#0A0F0D;color:#FFFFFF') + (can ? '' : ';opacity:.35;cursor:not-allowed'),
        next: () => { if (!can) return; if (step < 3) this.setState({ sheet: { id: sh.id, step: step + 1 } }); else { this.setState({ sheet: null }); this.doFile(sh.id); } },
        close: () => this.setState({ sheet: null }),
        remove: () => { this.setState({ sheet: null, st: Object.assign({}, s.st, { [sh.id]: 'gone' }) }); }
      }
    };
  }
  doFile(id) {
    if (this.state.busy) return;
    this.setState({ busy: id });
    clearTimeout(this._t1); clearTimeout(this._t2);
    this._t1 = setTimeout(() => {
      const c = this.claims().find(x => x.id === id), seq = this.state.seq + 1;
      this.setState({ busy: '', just: id, seq, st: Object.assign({}, this.state.st, { [id]: 'filed' }), note: { co: c.co, logo: this.logos()[id], claimId: 'CC-' + seq, amt: c.amt } });
      this._t2 = setTimeout(() => this.setState({ note: null, just: '' }), 4200);
    }, 900);
  }
  setup() {
    return [
      { id: 'email', label: 'Verify your email', tag: 'Account', cta: 'Verify', why: 'We send your filing receipts and claim updates here, and use it to recover your account.' },
      { id: 'auth', label: 'Sign the filing authorization', tag: 'For filing', cta: 'Sign', why: 'This gives Claimclub permission to submit claim forms in your name. Administrators need it before anyone can file for you.' },
      { id: 'name', label: 'Legal name and current address', tag: 'For filing', cta: 'Add', why: 'Administrators match claims to their class list by name and mailing address. A mismatch is the most common reason a claim gets rejected.' },
      { id: 'dob', label: 'Date of birth and phone number', tag: 'For filing', cta: 'Add', why: 'Many claim forms ask for these to confirm who you are and block duplicate claims. We only send them to the administrator of a claim you file.' },
      { id: 'past', label: 'Past addresses, last 10 years', tag: 'For filing', cta: 'Add', optional: true, why: 'Lots of settlements cover purchases or accounts from years ago. Old addresses help administrators find you on their class list, so more of your claims get approved.' },
      { id: 'bank', label: 'Connect a bank for payouts', tag: 'For payouts', cta: 'Connect', why: 'Most administrators pay by direct deposit, PayPal or check. A connected bank lets us pick direct deposit on each claim so money goes straight to you. Claimclub never holds your payout.' },
      { id: 'notify', label: 'Turn on text alerts', tag: 'For notifications', cta: 'Turn on', why: 'We text you when a claim is approved, when a payout is sent, and when a new settlement matches you before its deadline.' }
    ];
  }
  renderVals() {
    const s = this.state, L = this.logos();
    const ST = ['filed', 'review', 'approved', 'paid'], STL = { filed: 'Filed', review: 'In review', approved: 'Approved', paid: 'Paid' };
    const NEXT = { filed: 'Waiting on the administrator to confirm', review: 'Administrator is reviewing claims', approved: 'Payouts start after final court approval', paid: 'Paid to you' };
    const row = (c) => {
      const st = s.st[c.id], idx = ST.indexOf(st), urgent = c.days > 0 && c.days <= 7;
      return Object.assign({}, c, {
        logo: L[c.id] || '', st, stLabel: STL[st] || 'Ready to file', next: NEXT[st] || '', isReady: st === 'ready', isPaid: st === 'paid',
        isAuto: c.kind === 'auto', needs: !!c.need, oneTap: !c.need, isArb: c.kind === 'arb',
        kindNote: c.need ? 'Needs a few details · about 1 min' : c.kind === 'auto' ? 'Paid automatically. File to add it to your tracking.' : c.kind === 'arb' ? 'Handled by a partner law firm' : 'We file it. No proof needed.',
        dl: c.days > 0 ? c.days + 'd left' : '', urgent,
        dlStyle: 'font-size:12px;font-weight:800;padding:4px 9px;border-radius:99px;white-space:nowrap;' + (urgent ? 'background:#FDECEC;color:#B8333A' : 'background:#EEF2F0;color:#43504A'),
        busy: s.busy === c.id, idle: s.busy !== c.id, file: () => this.file(c.id),
        btnA: 'min-width:84px;min-height:34px;padding:0 16px;border-radius:99px;font-size:13px;font-weight:800;display:inline-flex;align-items:center;justify-content:center;gap:8px;background:#3DDC97;color:#0A0F0D',
        trSegs: ST.map((x, i) => ({ st: 'flex:1;height:6px;border-radius:99px;background:' + (i <= idx ? (st === 'paid' ? '#12805C' : '#4A72D9') : '#E1E6F0') })),
        btn: 'min-width:112px;min-height:44px;padding:0 20px;border-radius:99px;font-size:15px;font-weight:800;display:inline-flex;align-items:center;justify-content:center;gap:8px;transition:background .15s;' + (s.busy === c.id ? 'background:#12805C;color:#FFFFFF' : 'background:#0F3B2E;color:#FFFFFF'),
        rowCls: s.just === c.id ? 'just' : '', cardCls: s.just === c.id ? 'cardin' : '',
        segs: ST.map((x, i) => ({ st: 'flex:1;height:6px;border-radius:99px;background:' + (i <= idx ? (st === 'paid' ? '#12805C' : '#1E9E70') : '#E3EAE6') })),
        pill: 'font-size:12px;font-weight:800;padding:4px 10px;border-radius:99px;white-space:nowrap;' + ({ filed: 'background:#E8EEFB;color:#2C4FA8', review: 'background:#FFF4DB;color:#8A5A00', approved: 'background:#E9F6EF;color:#17603F', paid: 'background:#12805C;color:#FFFFFF' }[st] || 'background:#0F3B2E;color:#FFFFFF')
      });
    };
    const all = this.claims().filter(c => s.st[c.id] !== 'gone').map(row);
    const ready = all.filter(r => r.isReady).sort((a, b) => a.days - b.days), track = all.filter(r => !r.isReady);
    const sum = (a) => a.reduce((t, r) => t + r.n, 0), money = (n) => '$' + n.toLocaleString('en-US');
    const col = (k) => all.filter(r => r.st === k);
    const fc = Math.min(s.focus, Math.max(0, ready.length - 1)), cur = ready[fc];
    const conf = [];
    for (let i = 0; i < 12; i++) { const a = i / 12 * Math.PI * 2; conf.push({ st: '--x:' + Math.round(Math.cos(a) * 46) + 'px;--y:' + Math.round(Math.sin(a) * 46) + 'px;background:' + ['#3DDC97', '#FFB224', '#12805C', '#9FE8C4'][i % 4] }); }
    return {
      all, ready, track, readyN: ready.length, trackN: track.length, hasReady: ready.length > 0, noReady: ready.length === 0,
      readyTotal: money(sum(ready)), estTotal: money(sum(all)), paidTotal: money(sum(all.filter(r => r.isPaid))), pendingTotal: money(sum(track.filter(r => !r.isPaid))),
      urgentN: ready.filter(r => r.urgent).length, hasUrgent: ready.some(r => r.urgent),
      fileAll: () => { const r = ready[0]; if (r) this.file(r.id); },
      colReady: ready, colFiled: col('filed'), colReview: col('review'), colApproved: col('approved'), colPaid: col('paid'),
      nFiled: col('filed').length, nReview: col('review').length, nApproved: col('approved').length, nPaid: col('paid').length,
      cur: cur || null, hasCur: !!cur, noCur: !cur, curIdx: fc + 1, curOf: ready.length,
      skip: () => this.setState({ focus: ready.length ? (fc + 1) % ready.length : 0 }),
      queue: ready.map((r, i) => Object.assign({}, r, { qStyle: 'width:44px;height:44px;flex:none;border-radius:13px;background:#FFFFFF;padding:7px;box-sizing:border-box;box-shadow:' + (i === fc ? '0 0 0 2.5px #0F3B2E' : 'inset 0 0 0 1px #DDE5E0'), pick: () => this.setState({ focus: i }) })),
      filedPct: Math.round(track.length / all.length * 100), donePctStyle: 'width:' + Math.round(track.length / all.length * 100) + '%%;height:100%%;border-radius:99px;background:#3DDC97;transition:width .6s cubic-bezier(.2,.8,.2,1)',
      ...this.setupVals(), ...this.sheetVals(),
      isDash: s.view === 'dash', isSet: s.view === 'settings', goDash: () => this.setState({ view: 'dash' }), goSet: () => this.setState({ view: 'settings' }),
      navDash: 'display:flex;align-items:center;gap:12px;padding:11px 12px;border-radius:12px;font-size:15px;font-weight:700;' + (s.view === 'dash' ? 'background:#EAF2EE;color:#0F3B2E' : 'background:transparent;color:#43504A'),
      navSet: 'display:flex;align-items:center;gap:12px;padding:11px 12px;border-radius:12px;font-size:15px;font-weight:700;' + (s.view === 'settings' ? 'background:#EAF2EE;color:#0F3B2E' : 'background:transparent;color:#43504A'),
      mDash: 'display:flex;flex-direction:column;align-items:center;gap:3px;font-size:11px;font-weight:800;background:transparent;color:' + (s.view === 'dash' ? '#0F3B2E' : '#8A968F'),
      mSet: 'display:flex;flex-direction:column;align-items:center;gap:3px;font-size:11px;font-weight:800;background:transparent;color:' + (s.view === 'settings' ? '#0F3B2E' : '#8A968F'),
      rootCls: (s.theme === 'dark' || (s.theme === 'system' && typeof matchMedia !== 'undefined' && matchMedia('(prefers-color-scheme: dark)').matches)) ? 'dk' : '',
      themes: [['light', 'Light', '#F3F6F4', '#FFFFFF', '#0F3B2E'], ['dark', 'Dark', '#0E1412', '#161E1B', '#0F3B2E'], ['system', 'System', 'linear-gradient(90deg,#F3F6F4 50%,#0E1412 50%)', 'linear-gradient(90deg,#FFFFFF 50%,#161E1B 50%)', '#0F3B2E']].map(([k, t, a, b, c]) => ({ t, on: s.theme === k, tap: () => this.setState({ theme: k }),
        st: 'flex:1;display:flex;flex-direction:column;align-items:center;gap:8px;padding:10px;border-radius:14px;font-weight:800;font-size:13px;' + (s.theme === k ? 'background:#EAF2EE;color:#0F3B2E;box-shadow:inset 0 0 0 2px #12805C' : 'background:#FFFFFF;color:#43504A;box-shadow:inset 0 0 0 1.5px #DDE5E0'),
        pv: 'width:100%;height:46px;border-radius:9px;display:flex;flex-direction:column;gap:5px;padding:7px;box-sizing:border-box;' + (a[0] === '#' ? 'background-color:' : 'background:') + a, pv1: 'height:9px;width:60%;border-radius:4px;background-color:' + c, pv2: 'flex:1;border-radius:5px;' + (b[0] === '#' ? 'background-color:' : 'background:') + b })),
      zoomSt: 'display:flex;flex-direction:column;gap:14px;zoom:' + ({ s: 0.86, m: 1, l: 1.14 }[s.scale]),
      scales: [['s', 'Small', 13], ['m', 'Medium', 17], ['l', 'Large', 22]].map(([k, t, px]) => ({ t, aa: 'font-size:' + px + 'px;font-weight:800;line-height:1', on: s.scale === k, tap: () => this.setState({ scale: k }),
        st: 'flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;min-height:84px;border-radius:14px;font-weight:800;font-size:13px;' + (s.scale === k ? 'background:#EAF2EE;color:#0F3B2E;box-shadow:inset 0 0 0 2px #12805C' : 'background:#FFFFFF;color:#43504A;box-shadow:inset 0 0 0 1.5px #DDE5E0') })),
      more: this.extras().filter(x => !(s.ans || {})[x.id]).slice(0, 3).map(x => Object.assign({}, x, { logo: L[x.id], yes: () => this.answer(x.id, 'yes'), no: () => this.answer(x.id, 'no') })),
      findTitle: ready.length === 0 ? "All filed. Let's find more claims." : 'Find more claims',
      greetA: ready.length ? 'You have ' : 'Everything is filed. ', greetB: ready.length ? ready.length + (ready.length === 1 ? ' claim' : ' claims') + ' ready to file' : 'We are tracking ' + track.length + ' claims', greetC: ready.length ? (sum(ready) ? ' worth up to ' + money(sum(ready)) + '.' : '.') : ' for you.',
      showFind: ready.length === 0 || Object.keys(s.ans || {}).length > 0,
      hasMore: this.extras().some(x => !(s.ans || {})[x.id]), noMore: !this.extras().some(x => !(s.ans || {})[x.id]),
      hasNote: !!s.note, note: s.note || { co: '', logo: '', claimId: '', amt: '' }, conf, closeNote: () => this.setState({ note: null })
    };
  }
}
</script>
</body>
</html>
'''
def sideA():
    h=side(0)
    h=h.replace('<div style="display: flex; align-items: center; gap: 12px; padding: 11px 12px; border-radius: 12px; font-size: 15px; font-weight: 700; background: #EAF2EE; color: #0F3B2E">','<button onClick="{{ goDash }}" style="{{ navDash }}">',1)
    i=h.index('<button onClick="{{ goDash }}"'); k=h.index('</div>',i); h=h[:k]+'</button>'+h[k+6:]
    i=h.index('Settings</div>'); a=h.rindex('<div style=',0,i); h=h[:a]+'<button onClick="{{ goSet }}" style="{{ navSet }}">'+h[h.index('>',a)+1:i]+'Settings</button>'+h[i+len('Settings</div>'):]
    return h
SHEET='  <sc-if value="{{ sheetOpen }}" hint-placeholder-val="{{ false }}"><div class="shWrap" style="position: absolute; inset: 0; z-index: 40; background: rgba(10,15,13,.45); display: flex; align-items: center; justify-content: center; animation: shFade .2s ease both">\n    <div class="shCard" role="dialog" aria-modal="true" aria-label="File your {{ sh.co }} claim" style="width: 560px; max-width: calc(100% - 32px); max-height: calc(100% - 48px); display: flex; flex-direction: column; background: #FFFFFF; border-radius: 24px; box-shadow: 0 30px 80px rgba(0,0,0,.3); overflow: hidden; animation: shPop .3s cubic-bezier(.2,.9,.3,1.1) both">\n      <div style="padding: 18px 20px 14px; display: flex; flex-direction: column; gap: 14px; border-bottom: 1px solid #EEF2F0">\n        <div style="display: flex; align-items: center; gap: 12px"><img src="{{ sh.logo }}" alt="" style="width: 40px; height: 40px; flex: none; border-radius: 12px; padding: 6px; box-sizing: border-box; object-fit: contain; box-shadow: inset 0 0 0 1px #E3EAE6"><div style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-size: 16px; font-weight: 800">{{ sh.co }} <span style="color: #12805C">{{ sh.amt }}</span></span><span style="font-size: 12px; color: #5B6862">{{ sh.title }}</span></div><button onClick="{{ sh.close }}" aria-label="Close" style="width: 32px; height: 32px; flex: none; border-radius: 50%; background: #EEF2F0; color: #0A0F0D; display: flex; align-items: center; justify-content: center"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18 M6 6l12 12"></path></svg></button></div>\n        <div style="display: flex; flex-direction: column; gap: 8px"><div style="display: flex; gap: 4px"><sc-for list="{{ sh.dots }}" as="d" hint-placeholder-count="3"><span style="{{ d.st }}"></span></sc-for></div><span style="font-size: 12px; font-weight: 800; color: #5B6862">STEP {{ sh.step }} OF 3 · <span style="color: #0A0F0D">{{ sh.stepTitle }}</span></span></div>\n      </div>\n      <div class="scroll" style="flex-grow: 1; min-height: 0; overflow-y: auto; padding: 18px 20px; display: flex; flex-direction: column; gap: 16px">\n        <sc-if value="{{ sh.s1 }}" hint-placeholder-val="{{ true }}">\n          <sc-for list="{{ sh.qs }}" as="q" hint-placeholder-count="2"><div style="display: flex; flex-direction: column; gap: 10px"><span style="font-size: 15px; font-weight: 700; line-height: 1.4">{{ q.t }}</span><div style="display: flex; gap: 8px"><button onClick="{{ q.yes }}" style="{{ q.yesSt }}">Yes</button><button onClick="{{ q.no }}" style="{{ q.noSt }}">No</button></div></div></sc-for>\n          <sc-if value="{{ sh.anyNo }}" hint-placeholder-val="{{ false }}"><div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 14px; border-radius: 14px; background: #FFF4DB; color: #6B4600; font-size: 13px; line-height: 1.45"><span>Based on this answer you probably don\'t qualify. Filing anyway could get your claim rejected.</span><button onClick="{{ sh.remove }}" style="flex: none; min-height: 32px; padding: 0 12px; border-radius: 99px; background: #FFFFFF; color: #6B4600; font-size: 12px; font-weight: 800">Remove claim</button></div></sc-if>\n        </sc-if>\n        <sc-if value="{{ sh.s2 }}" hint-placeholder-val="{{ false }}">\n          <sc-for list="{{ sh.fields }}" as="f" hint-placeholder-count="2"><div style="display: flex; flex-direction: column; gap: 8px">\n            <div style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 15px; font-weight: 800">{{ f.label }}<sc-if value="{{ f.optional }}" hint-placeholder-val="{{ false }}"> <span style="font-size: 12px; font-weight: 700; color: #8A968F">Optional</span></sc-if></span><span style="font-size: 12px; color: #5B6862">{{ f.hint }}</span></div>\n            <sc-if value="{{ f.isChips }}" hint-placeholder-val="{{ true }}"><div style="display: flex; flex-wrap: wrap; gap: 8px"><sc-for list="{{ f.opts }}" as="o" hint-placeholder-count="4"><button onClick="{{ o.tap }}" style="{{ o.st }}">{{ o.o }}</button></sc-for></div></sc-if>\n            <sc-if value="{{ f.isText }}" hint-placeholder-val="{{ false }}"><input type="text" value="{{ f.val }}" onChange="{{ f.onIn }}" placeholder="{{ f.ph }}" style="height: 44px; border-radius: 12px; border: 1.5px solid #DDE5E0; padding: 0 14px; font-size: 15px; font-family: inherit; font-weight: 600; color: #0A0F0D; background: #FFFFFF"></sc-if>\n          </div></sc-for>\n          <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px 14px; border-radius: 14px; background: #E9F6EF; font-size: 13px; font-weight: 800; color: #17603F"><span>Estimated payout</span><span style="font-size: 16px">{{ sh.est }}</span></div>\n        </sc-if>\n        <sc-if value="{{ sh.s3 }}" hint-placeholder-val="{{ false }}">\n          <div style="display: flex; flex-direction: column; border-radius: 14px; box-shadow: inset 0 0 0 1px #E3EAE6; padding: 4px 14px">\n            <div style="display: flex; justify-content: space-between; gap: 12px; padding: 10px 0; border-bottom: 1px solid #EEF2F0; font-size: 13px"><span style="color: #5B6862">Name</span><span style="font-weight: 800">Henry Sidwell</span></div>\n            <div style="display: flex; justify-content: space-between; gap: 12px; padding: 10px 0; border-bottom: 1px solid #EEF2F0; font-size: 13px"><span style="color: #5B6862">Mailing address</span><span style="font-weight: 800">Saved in Your info</span></div>\n            <div style="display: flex; justify-content: space-between; gap: 12px; padding: 10px 0; border-bottom: 1px solid #EEF2F0; font-size: 13px"><span style="color: #5B6862">Your answers</span><span style="font-weight: 800; text-align: right">{{ sh.summary }}</span></div>\n            <div style="display: flex; justify-content: space-between; gap: 12px; padding: 10px 0; font-size: 13px"><span style="color: #5B6862">Estimated payout</span><span style="font-weight: 800; color: #12805C">{{ sh.est }}</span></div>\n          </div>\n          <div style="display: flex; flex-direction: column; gap: 8px"><span style="font-size: 15px; font-weight: 800">How should they pay you?</span><div style="display: flex; flex-wrap: wrap; gap: 8px"><sc-for list="{{ sh.pay }}" as="p" hint-placeholder-count="3"><button onClick="{{ p.tap }}" style="{{ p.st }}">{{ p.o }}</button></sc-for></div>\n            <sc-if value="{{ sh.needBank }}" hint-placeholder-val="{{ false }}"><div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 10px 12px; border-radius: 12px; background: #FFF4DB; color: #6B4600; font-size: 13px"><span>Connect a bank to get direct deposit.</span><button onClick="{{ sh.connectBank }}" style="flex: none; min-height: 30px; padding: 0 12px; border-radius: 99px; background: #0A0F0D; color: #FFFFFF; font-size: 12px; font-weight: 800">Connect bank</button></div></sc-if></div>\n          <button onClick="{{ sh.signTap }}" style="display: flex; align-items: flex-start; gap: 12px; padding: 12px 14px; border-radius: 14px; background: #F3F6F4; text-align: left; color: #0A0F0D"><span style="{{ sh.signBox }}"><sc-if value="{{ sh.sign }}" hint-placeholder-val="{{ false }}"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg></sc-if></span><span style="font-size: 13px; line-height: 1.45">I declare under penalty of perjury that this information is true, and I authorize Claimclub to submit this claim for me.</span></button>\n        </sc-if>\n      </div>\n      <div style="display: flex; gap: 10px; padding: 14px 20px 18px; border-top: 1px solid #EEF2F0"><sc-if value="{{ sh.hasBack }}" hint-placeholder-val="{{ false }}"><button onClick="{{ sh.back }}" style="min-height: 46px; padding: 0 20px; border-radius: 99px; background: #EEF2F0; color: #0A0F0D; font-size: 15px; font-weight: 800">Back</button></sc-if><button onClick="{{ sh.next }}" style="{{ sh.nextSt }}">{{ sh.nextLabel }}</button></div>\n    </div>\n  </div></sc-if>\n'
NOTE='''  <sc-if value="{{ hasNote }}" hint-placeholder-val="{{ false }}"><div class="note" role="status" aria-live="polite" style="position: absolute; bottom: 24px; right: 24px; z-index: 50; width: 380px; display: flex; align-items: center; gap: 14px; padding: 14px 16px; border-radius: 20px; background: #0A0F0D; color: #FFFFFF; box-shadow: 0 24px 60px rgba(0,0,0,.28)">
    <div style="position: relative; width: 60px; height: 60px; flex: none"><span class="rg" style="position: absolute; inset: 8px; border-radius: 50%; border: 2px solid #3DDC97"></span><sc-for list="{{ conf }}" as="c" hint-placeholder-count="0"><span class="cf" style="{{ c.st }}"></span></sc-for>
      <img src="{{ note.logo }}" alt="" style="position: absolute; inset: 6px; width: 48px; height: 48px; border-radius: 14px; background: #FFFFFF; padding: 8px; box-sizing: border-box; object-fit: contain">
      <span class="ck" style="position: absolute; right: -2px; bottom: -2px; width: 24px; height: 24px; border-radius: 50%; background: #3DDC97; display: flex; align-items: center; justify-content: center; box-shadow: 0 0 0 3px #0A0F0D"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#0A0F0D" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg></span></div>
    <div style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><span style="font-size: 16px; font-weight: 800">Filed with {{ note.co }}</span><span style="font-size: 13px; color: #B9CCC2">Claim {{ note.claimId }} · We'll track it until it pays</span></div>
    <button onClick="{{ closeNote }}" aria-label="Dismiss" style="width: 30px; height: 30px; flex: none; border-radius: 50%; background: rgba(255,255,255,.1); color: #FFFFFF; display: flex; align-items: center; justify-content: center"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18 M6 6l12 12"></path></svg></button>
  </div></sc-if>
'''
FILEBTN='<button onClick="{{ %s.file }}" style="{{ %s.btn }}" aria-label="File the {{ %s.co }} claim"><sc-if value="{{ %s.busy }}" hint-placeholder-val="{{ false }}"><span class="spin"></span>Filing</sc-if><sc-if value="{{ %s.idle }}" hint-placeholder-val="{{ true }}">File</sc-if></button>'
def fb(v): return FILEBTN % (v,v,v,v,v)
def logoimg(v,size=44,r=13): return f'<img src="{{{{ {v}.logo }}}}" alt="" style="width: {size}px; height: {size}px; flex: none; border-radius: {r}px; background: #FFFFFF; padding: {round(size*0.17)}px; box-sizing: border-box; object-fit: contain; box-shadow: inset 0 0 0 1px #E3EAE6">'
def side(active):
    items=[('Dashboard','M3 3h7v9H3z M14 3h7v5h-7z M14 12h7v9h-7z M3 16h7v5H3z'),('All settlements','M8 6h13 M8 12h13 M8 18h13 M3 6h.01 M3 12h.01 M3 18h.01'),('Your info','M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2 M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z'),('Settings','M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z')]
    h='<aside style="width: 232px; flex: none; display: flex; flex-direction: column; gap: 6px; padding: 22px 16px; background: #FFFFFF; border-right: 1px solid #E3EAE6; box-sizing: border-box">'
    h+=f'<div style="display: flex; align-items: center; gap: 8px; padding: 0 8px 18px"><svg width="28" height="28" viewBox="0 0 100 100" aria-hidden="true">{LOGO}</svg><span style="font-size: 19px; font-weight: 800; letter-spacing: -0.4px">claim<span style="font-weight: 500">club</span><span style="font-size: .72em; font-weight: 600; color: #12805C; margin-left: -0.06em">.io</span></span></div>'
    for i,(t,d) in enumerate(items):
        on=i==0
        h+=f'<div style="display: flex; align-items: center; gap: 12px; padding: 11px 12px; border-radius: 12px; font-size: 15px; font-weight: 700; {"background: #EAF2EE; color: #0F3B2E" if on else "color: #43504A"}"><svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="{d}"></path></svg>{t}</div>'
    h+='<div style="margin-top: auto; padding: 14px; border-radius: 16px; background: #F3F6F4; display: flex; flex-direction: column; gap: 4px"><span style="font-size: 13px; font-weight: 800">Membership <span style="color: #17603F">· Active</span></span><span style="font-size: 12px; color: #5B6862">Monthly · $9.99/month</span></div></aside>'
    return h
ROOT='<div style="position: relative; width: 100%; height: 100vh; min-height: 640px; box-sizing: border-box; background: #F3F6F4; color: #0A0F0D; font-family: Manrope, sans-serif; display: flex; overflow: hidden">\n'

# ---------------- A: Inbox ----------------
DARK_CSS='.dk{background:#0E1412 !important;color:#E9F1ED !important;color-scheme:dark}\n.dk :not(img)[style*="background: #FFFFFF"]{background:#161E1B !important}\n.dk :not(img)[style*="background:#FFFFFF"]{background:#161E1B !important}\n.dk :not(img)[style*="background: #F3F6F4"]{background:#0E1412 !important}\n.dk :not(img)[style*="background:#F3F6F4"]{background:#0E1412 !important}\n.dk :not(img)[style*="background: #EEF2F0"]{background:#232D29 !important}\n.dk :not(img)[style*="background:#EEF2F0"]{background:#232D29 !important}\n.dk :not(img)[style*="background: #EEF2F8"]{background:#18202C !important}\n.dk :not(img)[style*="background:#EEF2F8"]{background:#18202C !important}\n.dk :not(img)[style*="background: #DCE4F3"]{background:#26324A !important}\n.dk :not(img)[style*="background:#DCE4F3"]{background:#26324A !important}\n.dk :not(img)[style*="background: #E9F6EF"]{background:#12301F !important}\n.dk :not(img)[style*="background:#E9F6EF"]{background:#12301F !important}\n.dk :not(img)[style*="background: #EAF2EE"]{background:#1C2B25 !important}\n.dk :not(img)[style*="background:#EAF2EE"]{background:#1C2B25 !important}\n.dk :not(img)[style*="background: #E3EAE6"]{background:#2A3430 !important}\n.dk :not(img)[style*="background:#E3EAE6"]{background:#2A3430 !important}\n.dk :not(img)[style*="background: #E1E6F0"]{background:#283042 !important}\n.dk :not(img)[style*="background:#E1E6F0"]{background:#283042 !important}\n.dk :not(img)[style*="background: #DDE5E0"]{background:#2A3430 !important}\n.dk :not(img)[style*="background:#DDE5E0"]{background:#2A3430 !important}\n.dk :not(img)[style*="background: #FFF4DB"]{background:#3A2E12 !important}\n.dk :not(img)[style*="background:#FFF4DB"]{background:#3A2E12 !important}\n.dk :not(img)[style*="background: #E8EEFB"]{background:#1C2740 !important}\n.dk :not(img)[style*="background:#E8EEFB"]{background:#1C2740 !important}\n.dk [style*="; color: #0A0F0D"],.dk [style^="color: #0A0F0D"]{color:#E9F1ED !important}\n.dk [style*=";color:#0A0F0D"],.dk [style^="color:#0A0F0D"]{color:#E9F1ED !important}\n.dk [style*="; color: #5B6862"],.dk [style^="color: #5B6862"]{color:#9AA8A1 !important}\n.dk [style*=";color:#5B6862"],.dk [style^="color:#5B6862"]{color:#9AA8A1 !important}\n.dk [style*="; color: #43504A"],.dk [style^="color: #43504A"]{color:#B3C0B9 !important}\n.dk [style*=";color:#43504A"],.dk [style^="color:#43504A"]{color:#B3C0B9 !important}\n.dk [style*="; color: #8A968F"],.dk [style^="color: #8A968F"]{color:#7F8C86 !important}\n.dk [style*=";color:#8A968F"],.dk [style^="color:#8A968F"]{color:#7F8C86 !important}\n.dk [style*="; color: #22324A"],.dk [style^="color: #22324A"]{color:#D0DBEF !important}\n.dk [style*=";color:#22324A"],.dk [style^="color:#22324A"]{color:#D0DBEF !important}\n.dk [style*="; color: #5B6A85"],.dk [style^="color: #5B6A85"]{color:#95A5C4 !important}\n.dk [style*=";color:#5B6A85"],.dk [style^="color:#5B6A85"]{color:#95A5C4 !important}\n.dk [style*="; color: #8A93A6"],.dk [style^="color: #8A93A6"]{color:#7A8499 !important}\n.dk [style*=";color:#8A93A6"],.dk [style^="color:#8A93A6"]{color:#7A8499 !important}\n.dk [style*="; color: #12805C"],.dk [style^="color: #12805C"]{color:#4FD69C !important}\n.dk [style*=";color:#12805C"],.dk [style^="color:#12805C"]{color:#4FD69C !important}\n.dk [style*="; color: #0F3B2E"],.dk [style^="color: #0F3B2E"]{color:#7FD9AA !important}\n.dk [style*=";color:#0F3B2E"],.dk [style^="color:#0F3B2E"]{color:#7FD9AA !important}\n.dk [style*="; color: #6B4600"],.dk [style^="color: #6B4600"]{color:#F2C46B !important}\n.dk [style*=";color:#6B4600"],.dk [style^="color:#6B4600"]{color:#F2C46B !important}\n.dk [style*="; color: #8A5A00"],.dk [style^="color: #8A5A00"]{color:#F0B850 !important}\n.dk [style*=";color:#8A5A00"],.dk [style^="color:#8A5A00"]{color:#F0B850 !important}\n.dk [style*="; color: #2C4FA8"],.dk [style^="color: #2C4FA8"]{color:#9DB5F2 !important}\n.dk [style*=";color:#2C4FA8"],.dk [style^="color:#2C4FA8"]{color:#9DB5F2 !important}\n.dk [style*="; color: #17603F"],.dk [style^="color: #17603F"]{color:#7FD9AA !important}\n.dk [style*=";color:#17603F"],.dk [style^="color:#17603F"]{color:#7FD9AA !important}\n.dk :not(.note)[style*="background: #0A0F0D"]{background:#E9F1ED !important;color:#0A0F0D !important}\n.dk :not(.note)[style*="background:#0A0F0D"]{background:#E9F1ED !important;color:#0A0F0D !important}\n.dk [style*="background: #3DDC97"],.dk [style*="background: #3DDC97"] *{color:#0A0F0D !important}\n.dk [style*="background:#3DDC97"],.dk [style*="background:#3DDC97"] *{color:#0A0F0D !important}\n.dk [style*="0 0 0 1px #E3EAE6"],.dk [style*="0 0 0 1px #DCE2EE"]{box-shadow:0 0 0 1px #26302C !important}\n.dk [style*="inset 0 0 0 1px #E3EAE6"],.dk [style*="inset 0 0 0 1px #DDE5E0"]{box-shadow:inset 0 0 0 1px #2E3A35 !important}\n.dk [style*="inset 0 0 0 1.5px #DDE5E0"]{box-shadow:inset 0 0 0 1.5px #34413B !important}\n.dk [style*="inset 0 0 0 2px #C9D3CD"]{box-shadow:inset 0 0 0 2px #3C4944 !important}\n.dk [style*="solid #EEF2F0"],.dk [style*="solid #E3EAE6"],.dk [style*="solid #DDE5E0"]{border-color:#26302C !important}\n.dk .arow{background:#161E1B}.dk .trow{border-top-color:#232B38}\n.dk svg [fill="#0A0F0D"]{fill:#E9F1ED}\n.dk .note{box-shadow:0 0 0 1px #2A3530,0 24px 60px rgba(0,0,0,.5) !important}\n.dk .shWrap{background:rgba(0,0,0,.6) !important}\n.dk img[style*="background: #FFFFFF"]{box-shadow:none !important}\n.dk .scroll{scrollbar-color:#34413B transparent}\n@keyframes justInDk{0%{background:#1D4A36;transform:translateY(-6px);opacity:0}30%{opacity:1;transform:none}100%{background:transparent}}.dk .just{animation-name:justInDk}'
A_CSS='@keyframes shFade{from{opacity:0}}@keyframes shPop{from{opacity:0;transform:translateY(18px) scale(.98)}}\n.arow{display:grid;grid-template-columns:34px minmax(0,1.6fr) minmax(0,1fr) auto auto;gap:14px;align-items:center;padding:9px 12px;background:#FFFFFF;border-radius:16px}\n.trow{display:grid;grid-template-columns:34px minmax(0,1.4fr) minmax(0,1.4fr) 96px;gap:14px;align-items:center;padding:10px 16px;border-top:1px solid #E7EBF3}\n.sgrid{display:grid;grid-template-columns:1fr 1fr;column-gap:28px}\n@media (max-width:1100px){.arow{grid-template-columns:34px minmax(0,1fr) auto}.arow>.hideS{display:none !important}.trow{grid-template-columns:34px minmax(0,1fr) auto}.trow>.hideS{display:none}.sgrid{grid-template-columns:1fr}.setupTop{grid-template-columns:1fr !important}}\n.arow .spin{border-color:rgba(10,15,13,.25);border-top-color:#0A0F0D}'
A=HEAD%('Dashboard option A · To-do inbox',A_CSS+'\n'+DARK_CSS)+ROOT.replace('<div style=','<div class="{{ rootCls }}" style=',1)+sideA()+'''  <main class="scroll amain" style="flex-grow: 1; min-width: 0; min-height: 0; overflow-y: auto; padding: 24px 32px 32px; box-sizing: border-box; display: block">
    <div style="{{ zoomSt }}">
    <sc-if value="{{ isDash }}" hint-placeholder-val="{{ true }}">
    <div class="greet" style="flex-shrink: 0; display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 14px">
      <div style="display: flex; flex-direction: column; gap: 4px"><h1 style="margin: 0; font-size: 22px; letter-spacing: -0.5px">Hi Henry</h1><span style="font-size: 13px; color: #5B6862">{{ greetA }}<b style="color: #0A0F0D">{{ greetB }}</b>{{ greetC }}</span></div>
      <div style="display: flex; gap: 8px; flex-wrap: wrap">
        <span style="display: flex; flex-direction: column; padding: 7px 12px; border-radius: 12px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6"><span style="font-size: 11px; color: #5B6862; font-weight: 700">Estimated</span><span style="font-size: 16px; font-weight: 800">{{ estTotal }}</span></span>
        <span style="display: flex; flex-direction: column; padding: 7px 12px; border-radius: 12px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6"><span style="font-size: 11px; color: #5B6862; font-weight: 700">Tracking</span><span style="font-size: 16px; font-weight: 800">{{ trackN }}</span></span>
        <span style="display: flex; flex-direction: column; padding: 7px 12px; border-radius: 12px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6"><span style="font-size: 11px; color: #5B6862; font-weight: 700">Paid to you</span><span style="font-size: 16px; font-weight: 800; color: #12805C">{{ paidTotal }}</span></span>
      </div>
    </div>

    <sc-if value="{{ setupOpen }}" hint-placeholder-val="{{ true }}"><section aria-label="Finish your account" style="flex-shrink: 0; background: #FFFFFF; border-radius: 16px; box-shadow: 0 0 0 1px #E3EAE6; overflow: hidden">
      <div class="setupRow" style="display: flex; align-items: center; gap: 16px; padding: 12px 16px">
        <div class="setupProg" style="width: 170px; flex: none; display: flex; flex-direction: column; gap: 6px"><span style="font-size: 12px; font-weight: 800; color: #5B6862">Finish your account · {{ setupPct }}%</span><div style="height: 6px; border-radius: 99px; background: #E3EAE6; overflow: hidden"><div style="{{ setupBar }}"></div></div></div>
        <span class="setupDiv" style="width: 1px; align-self: stretch; background: #EEF2F0"></span>
        <span style="flex: none; font-size: 12px; font-weight: 800; padding: 3px 9px; border-radius: 99px; background: #0A0F0D; color: #FFFFFF">Step {{ curN }} of {{ stepsN }}</span>
        <div class="curBox" style="flex-grow: 1; min-width: 0; display: flex; align-items: center; gap: 8px"><span class="curLbl" style="font-size: 14px; font-weight: 800; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{ nextLabel }}</span><span style="{{ curTagStyle }}">{{ curTag }}</span><button onClick="{{ tCur.toggle }}" aria-label="Why we need this" style="width: 26px; height: 26px; flex: none; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: transparent; color: #7C8AA5"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="M12 16v-4 M12 8h.01"></path></svg></button></div>
        <sc-if value="{{ curOptional }}" hint-placeholder-val="{{ false }}"><button onClick="{{ skipStep }}" style="min-height: 34px; padding: 0 14px; border-radius: 99px; background: transparent; color: #5B6862; font-size: 13px; font-weight: 800">Skip</button></sc-if>
        <button onClick="{{ nextAct }}" style="flex: none; min-height: 34px; padding: 0 16px; border-radius: 99px; background: #0A0F0D; color: #FFFFFF; font-size: 13px; font-weight: 800">{{ curCta }}</button>
      </div>
      <sc-if value="{{ tCur.open }}" hint-placeholder-val="{{ false }}"><div style="margin: 0 16px 12px; padding: 10px 12px; border-radius: 12px; background: #F3F6F4; font-size: 13px; line-height: 1.5; color: #43504A">{{ curWhy }}</div></sc-if>
    </section></sc-if>
    <sc-if value="{{ setupDone }}" hint-placeholder-val="{{ false }}"><div class="cardin" style="flex-shrink: 0; display: flex; align-items: center; gap: 12px; padding: 10px 16px; border-radius: 14px; background: #E9F6EF; color: #17603F; font-size: 13px; font-weight: 800"><span style="width: 24px; height: 24px; border-radius: 50%; background: #12805C; display: flex; align-items: center; justify-content: center"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg></span>Your account is complete. Every claim you file uses your saved info.</div></sc-if>

    <sc-if value="{{ hasReady }}" hint-placeholder-val="{{ true }}"><section aria-label="Ready to file" style="flex-shrink: 0; background: #0F3B2E; border-radius: 18px; overflow: hidden; color: #FFFFFF">
      <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 14px 16px 10px"><div style="display: flex; align-items: center; gap: 10px"><h2 style="margin: 0; font-size: 16px">Ready to file</h2><span style="font-size: 12px; font-weight: 800; padding: 2px 9px; border-radius: 99px; background: #3DDC97; color: #0A0F0D">{{ readyN }}</span><sc-if value="{{ hasUrgent }}" hint-placeholder-val="{{ true }}"><span style="font-size: 12px; font-weight: 800; padding: 4px 10px; border-radius: 99px; background: #FDECEC; color: #B8333A; white-space: nowrap; flex: none">{{ urgentN }} closing this week</span></sc-if><button onClick="{{ tReady.toggle }}" aria-label="About filing" style="width: 28px; height: 28px; flex: none; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: transparent; color: #9FE8C4"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="M12 16v-4 M12 8h.01"></path></svg></button></div><span class="hideM" style="font-size: 12px; color: #B9CCC2">Tap File on each claim you want</span></div>
      <sc-if value="{{ tReady.open }}" hint-placeholder-val="{{ false }}"><div style="margin: 0 16px 12px; padding: 10px 12px; border-radius: 12px; font-size: 13px; line-height: 1.5; background: rgba(255,255,255,.1); color: #E4F2EB">Nothing is filed without your OK. When you tap File we submit that claim form in your name using your saved info, then send you the claim ID. Automatic settlements still need a tap so we can track the payout for you.</div></sc-if>
      <div style="display: flex; flex-direction: column; gap: 6px; padding: 0 10px 10px">
      <sc-for list="{{ ready }}" as="r" hint-placeholder-count="5"><div class="arow {{ r.cardCls }}" style="color: #0A0F0D">
        ''' + logoimg('r',34,10) + '''
        <div style="min-width: 0; display: flex; flex-direction: column; gap: 2px"><span style="font-size: 14px; font-weight: 800">{{ r.co }} <span style="color: #12805C">{{ r.amt }}</span></span><span style="font-size: 12px; color: #5B6862; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{ r.title }}</span></div>
        <div class="hideS" style="min-width: 0; font-size: 12px; color: #43504A; display: flex; align-items: center; gap: 6px"><sc-if value="{{ r.needs }}" hint-placeholder-val="{{ false }}"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8A5A00" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20h9 M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"></path></svg></sc-if>{{ r.kindNote }}</div>
        <span style="{{ r.dlStyle }}">{{ r.dl }}</span>
        <button onClick="{{ r.file }}" style="{{ r.btnA }}" aria-label="File the {{ r.co }} claim"><sc-if value="{{ r.busy }}" hint-placeholder-val="{{ false }}"><span class="spin"></span>Filing</sc-if><sc-if value="{{ r.idle }}" hint-placeholder-val="{{ true }}">File</sc-if></button>
      </div></sc-for>
      </div>
    </section></sc-if>
    <sc-if value="{{ showFind }}" hint-placeholder-val="{{ false }}"><section aria-label="Find more claims" class="cardin" style="flex-shrink: 0; background: #0F3B2E; border-radius: 18px; color: #FFFFFF; padding: 16px 16px 14px; display: flex; flex-direction: column; gap: 14px">
      <div style="display: flex; align-items: center; justify-content: space-between; gap: 14px; flex-wrap: wrap">
        <div style="display: flex; align-items: center; gap: 12px"><span style="width: 34px; height: 34px; flex: none; border-radius: 50%; background: #3DDC97; display: flex; align-items: center; justify-content: center"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#0A0F0D" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.3-4.3"></path></svg></span><div style="display: flex; flex-direction: column; gap: 2px"><h2 style="margin: 0; font-size: 16px">{{ findTitle }}</h2><span style="font-size: 12px; color: #B9CCC2">Answer a quick question and we'll add any match to Ready to file.</span></div></div>
        <div class="findBtns" style="display: flex; gap: 8px"><button style="min-height: 34px; padding: 0 14px; border-radius: 99px; background: #FFFFFF; color: #0A0F0D; font-size: 13px; font-weight: 800">Browse all 294 settlements</button><button style="min-height: 34px; padding: 0 14px; border-radius: 99px; background: rgba(255,255,255,.12); color: #FFFFFF; font-size: 13px; font-weight: 800; display: flex; align-items: center; gap: 6px"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path><circle cx="12" cy="10" r="3"></circle></svg>Scan near me</button></div>
      </div>
      <sc-if value="{{ hasMore }}" hint-placeholder-val="{{ true }}"><div class="moreGrid" style="display: grid; grid-template-columns: repeat(3, minmax(0,1fr)); gap: 10px">
        <sc-for list="{{ more }}" as="m" hint-placeholder-count="3"><div class="cardin" style="background: #FFFFFF; color: #0A0F0D; border-radius: 14px; padding: 12px; display: flex; flex-direction: column; gap: 10px">
          <div style="display: flex; align-items: center; gap: 10px"><img src="{{ m.logo }}" alt="" style="width: 32px; height: 32px; flex: none; border-radius: 9px; background: #FFFFFF; padding: 5px; box-sizing: border-box; object-fit: contain; box-shadow: inset 0 0 0 1px #E3EAE6"><div style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column"><span style="font-size: 13px; font-weight: 800; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{ m.co }}</span><span style="font-size: 11px; color: #5B6862; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{ m.title }}</span></div><span style="flex: none; font-size: 13px; font-weight: 800; color: #12805C">{{ m.amt }}</span></div>
          <span style="font-size: 13px; font-weight: 700; line-height: 1.4; flex-grow: 1">{{ m.q }}</span>
          <div style="display: flex; gap: 6px"><button onClick="{{ m.yes }}" style="flex: 1; min-height: 32px; border-radius: 99px; background: #3DDC97; color: #0A0F0D; font-size: 13px; font-weight: 800">Yes</button><button onClick="{{ m.no }}" style="flex: 1; min-height: 32px; border-radius: 99px; background: #EEF2F0; color: #0A0F0D; font-size: 13px; font-weight: 800">No</button></div>
        </div></sc-for>
      </div></sc-if>
      <sc-if value="{{ noMore }}" hint-placeholder-val="{{ false }}"><div style="padding: 12px 14px; border-radius: 12px; background: rgba(255,255,255,.08); font-size: 13px; color: #CFE5DA">That's every quick check for now. Browse the full list or scan near you to find more, and we'll text you when a new settlement matches.</div></sc-if>
    </section></sc-if>

    <section aria-label="Tracking" style="flex-shrink: 0; background: #FFFFFF; border-radius: 24px; box-shadow: 0 0 0 1px #DCE2EE; overflow: hidden">
      <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 16px; background: #EEF2F8"><div style="display: flex; align-items: center; gap: 10px"><h2 style="margin: 0; font-size: 16px; color: #22324A">Tracking</h2><span style="font-size: 12px; font-weight: 800; padding: 2px 9px; border-radius: 99px; background: #DCE4F3; color: #2C4FA8">{{ trackN }}</span><button onClick="{{ tTrack.toggle }}" aria-label="About tracking" style="width: 28px; height: 28px; flex: none; border-radius: 50%; display: flex; align-items: center; justify-content: center; background: transparent; color: #7C8AA5"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="M12 16v-4 M12 8h.01"></path></svg></button></div><span class="hideM" style="font-size: 12px; color: #5B6A85">Nothing to do here. We'll text you if anything changes.</span></div>
      <sc-if value="{{ tTrack.open }}" hint-placeholder-val="{{ false }}"><div style="margin: 0 16px 12px; padding: 10px 12px; border-radius: 12px; font-size: 13px; line-height: 1.5; background: #EEF2F8; color: #33415C">Administrators move claims through four stages. Payouts usually start after the court gives final approval, which can take a few months. We check every claim and text you when its status changes.</div></sc-if>
      <sc-for list="{{ track }}" as="r" hint-placeholder-count="5"><div class="trow {{ r.rowCls }}">
        ''' + logoimg('r',34,10) + '''
        <div style="min-width: 0; display: flex; flex-direction: column; gap: 2px"><span style="font-size: 14px; font-weight: 800">{{ r.co }} <span style="color: #12805C">{{ r.amt }}</span></span><span style="font-size: 12px; color: #5B6A85">{{ r.next }}</span></div>
        <div class="hideS" style="display: flex; flex-direction: column; gap: 6px"><div style="display: flex; gap: 4px"><sc-for list="{{ r.trSegs }}" as="g" hint-placeholder-count="4"><span style="{{ g.st }}"></span></sc-for></div><div style="display: grid; grid-template-columns: repeat(4,1fr); font-size: 11px; font-weight: 700; color: #8A93A6"><span>Filed</span><span>In review</span><span>Approved</span><span>Paid</span></div></div>
        <span style="{{ r.pill }}; justify-self: end">{{ r.stLabel }}</span>
      </div></sc-for>
    </section>
    </sc-if>
    <sc-if value="{{ isSet }}" hint-placeholder-val="{{ false }}">
      <div style="display: flex; flex-direction: column; gap: 4px"><h1 style="margin: 0; font-size: 22px; letter-spacing: -0.5px">Settings</h1><span style="font-size: 13px; color: #5B6862">Make Claimclub look and work the way you like.</span></div>
      <section style="background: #FFFFFF; border-radius: 18px; box-shadow: 0 0 0 1px #E3EAE6; padding: 16px; display: flex; flex-direction: column; gap: 12px">
        <div style="display: flex; flex-direction: column; gap: 2px"><h2 style="margin: 0; font-size: 16px">Display size</h2><span style="font-size: 12px; color: #5B6862">Changes the size of text and cards on your dashboard. It saves on this device.</span></div>
        <div style="display: flex; gap: 10px"><sc-for list="{{ scales }}" as="z" hint-placeholder-count="3"><button onClick="{{ z.tap }}" aria-pressed="{{ z.on }}" style="{{ z.st }}"><span style="{{ z.aa }}">Aa</span>{{ z.t }}</button></sc-for></div>
      </section>
      <section style="background: #FFFFFF; border-radius: 18px; box-shadow: 0 0 0 1px #E3EAE6; padding: 16px; display: flex; flex-direction: column; gap: 12px">
        <div style="display: flex; flex-direction: column; gap: 2px"><h2 style="margin: 0; font-size: 16px">Appearance</h2><span style="font-size: 12px; color: #5B6862">Light, dark, or match your device.</span></div>
        <div style="display: flex; gap: 10px"><sc-for list="{{ themes }}" as="t" hint-placeholder-count="3"><button onClick="{{ t.tap }}" aria-pressed="{{ t.on }}" style="{{ t.st }}"><span style="{{ t.pv }}"><span style="{{ t.pv1 }}"></span><span style="{{ t.pv2 }}"></span></span>{{ t.t }}</button></sc-for></div>
      </section>
      <section style="background: #FFFFFF; border-radius: 18px; box-shadow: 0 0 0 1px #E3EAE6; padding: 6px 16px">
        <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 0; border-bottom: 1px solid #EEF2F0"><div style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 14px; font-weight: 800">Text alerts</span><span style="font-size: 12px; color: #5B6862">Approvals, payouts and new matches</span></div><span style="width: 42px; height: 24px; border-radius: 99px; background: #12805C; position: relative; flex: none"><span style="position: absolute; right: 3px; top: 3px; width: 18px; height: 18px; border-radius: 50%; background: #FFFFFF"></span></span></div>
        <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 0; border-bottom: 1px solid #EEF2F0"><div style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 14px; font-weight: 800">Email receipts</span><span style="font-size: 12px; color: #5B6862">A copy of every claim we file</span></div><span style="width: 42px; height: 24px; border-radius: 99px; background: #12805C; position: relative; flex: none"><span style="position: absolute; right: 3px; top: 3px; width: 18px; height: 18px; border-radius: 50%; background: #FFFFFF"></span></span></div>
        <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 0"><div style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 14px; font-weight: 800">Membership</span><span style="font-size: 12px; color: #5B6862">Monthly · $9.99/month</span></div><button style="min-height: 34px; padding: 0 14px; border-radius: 99px; background: #EEF2F0; color: #0A0F0D; font-size: 13px; font-weight: 800">Manage membership</button></div>
      </section>
    </sc-if>
    </div>
  </main>
'''+SHEET+NOTE+'</div>\n'+TAIL

# ---------------- B: Pipeline board ----------------
B_CSS='.bcol{flex:1 1 0;min-width:170px;display:flex;flex-direction:column;gap:10px;background:#EAEFEC;border-radius:20px;padding:12px;box-sizing:border-box;min-height:0}\n.bcol.ready{flex:1.35 1 0;background:#0F3B2E}\n.bcard button{min-width:0 !important;min-height:40px !important;padding:0 18px !important;font-size:14px !important}\n.bcard{background:#FFFFFF;border-radius:16px;padding:14px;display:flex;flex-direction:column;gap:10px;box-shadow:0 1px 2px rgba(10,15,13,.06)}'
def bcol(key,title,n,cnt_style,cls=''):
    return f'''      <section class="bcol {cls}" aria-label="{title}"><div style="display: flex; align-items: center; justify-content: space-between; padding: 4px 6px 6px"><h2 style="margin: 0; font-size: 15px; {"color: #FFFFFF" if cls else ""}">{title}</h2><span style="{cnt_style}">{{{{ {n} }}}}</span></div>
        <div class="scroll" style="display: flex; flex-direction: column; gap: 10px; overflow-y: auto; min-height: 0">
          <sc-for list="{{{{ {key} }}}}" as="r" hint-placeholder-count="2"><div class="bcard {{{{ r.cardCls }}}}"><div style="display: flex; align-items: center; gap: 10px">{logoimg('r',38,11)}<div style="flex: 1 1 auto; min-width: 0; display: flex; flex-direction: column"><span style="font-size: 15px; font-weight: 800; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{{{ r.co }}}}</span><span style="font-size: 12px; color: #5B6862; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{{{ r.title }}}}</span></div><span style="flex: none; max-width: 80px; text-align: right; font-size: 14px; font-weight: 800; color: #12805C; line-height: 1.15">{{{{ r.amt }}}}</span></div>
            {"<div style='display: flex; align-items: center; justify-content: space-between; gap: 8px'><span style='{{ r.dlStyle }}'>{{ r.dl }}</span>"+fb('r')+"</div><sc-if value='{{ r.isAuto }}' hint-placeholder-val='{{ false }}'><span style='font-size: 12px; color: #5B6862'>Paid automatically. File to track it.</span></sc-if>" if key=='colReady' else "<span style='font-size: 12px; color: #5B6862'>{{ r.next }}</span>"}
          </div></sc-for>
        </div></section>
'''
cnt='font-size: 12px; font-weight: 800; padding: 3px 9px; border-radius: 99px; background: #FFFFFF; color: #43504A'
B=HEAD%('Dashboard option B · Pipeline board',B_CSS)+ROOT+side(0)+'''  <main style="flex-grow: 1; min-width: 0; padding: 26px 30px 26px; box-sizing: border-box; display: flex; flex-direction: column; gap: 18px; min-height: 0">
    <div style="display: flex; flex-wrap: wrap; align-items: center; gap: 16px">
      <h1 style="margin: 0; font-size: 28px; letter-spacing: -0.8px; margin-right: auto">Your claims</h1>
      <div style="display: flex; align-items: center; gap: 18px; padding: 10px 18px; border-radius: 16px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; font-size: 14px"><span><span style="color: #5B6862">Estimated</span> <b>{{ estTotal }}</b></span><span style="width: 1px; height: 18px; background: #E3EAE6"></span><span><span style="color: #5B6862">Pending</span> <b>{{ pendingTotal }}</b></span><span style="width: 1px; height: 18px; background: #E3EAE6"></span><span><span style="color: #5B6862">Paid</span> <b style="color: #12805C">{{ paidTotal }}</b></span></div>
    </div>
    <div class="scroll" style="flex-grow: 1; min-height: 0; display: flex; gap: 14px; overflow-x: auto">
'''+bcol('colReady','Ready to file','readyN','font-size: 12px; font-weight: 800; padding: 3px 9px; border-radius: 99px; background: #3DDC97; color: #0A0F0D','ready')+bcol('colFiled','Filed','nFiled',cnt)+bcol('colReview','In review','nReview',cnt)+bcol('colApproved','Approved','nApproved',cnt)+bcol('colPaid','Paid','nPaid',cnt)+'''    </div>
  </main>
'''+NOTE+'</div>\n'+TAIL
B=B.replace("<div style='display: flex; align-items: center; justify-content: space-between; gap: 8px'><span style='{{ r.dlStyle }}'>","<div style=\"display: flex; align-items: center; justify-content: space-between; gap: 8px\"><span style=\"{{ r.dlStyle }}\">").replace("<sc-if value='{{ r.isAuto }}' hint-placeholder-val='{{ false }}'><span style='font-size: 12px; color: #5B6862'>","<sc-if value=\"{{ r.isAuto }}\" hint-placeholder-val=\"{{ false }}\"><span style=\"font-size: 12px; color: #5B6862\">").replace("<span style='font-size: 12px; color: #5B6862'>{{ r.next }}</span>","<span style=\"font-size: 12px; color: #5B6862\">{{ r.next }}</span>")

# ---------------- C: Focus ----------------
C_CSS='.cgrid{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(360px,1fr);gap:22px;align-items:start}@media (max-width:1100px){.cgrid{grid-template-columns:minmax(0,1fr)}}\n.crow{display:flex;align-items:center;gap:12px;padding:12px 4px;border-top:1px solid #EEF2F0}'
C=HEAD%('Dashboard option C · One at a time',C_CSS)+ROOT+side(0)+'''  <main class="scroll" style="flex-grow: 1; min-width: 0; overflow-y: auto; padding: 28px 36px 40px; box-sizing: border-box; display: flex; flex-direction: column; gap: 20px">
    <div style="display: flex; flex-wrap: wrap; align-items: flex-end; justify-content: space-between; gap: 16px">
      <div style="display: flex; flex-direction: column; gap: 4px"><span style="font-size: 14px; font-weight: 700; color: #5B6862">Hi Henry</span><h1 style="margin: 0; font-family: 'Instrument Serif', serif; font-weight: 400; font-size: 44px; line-height: 1; letter-spacing: -0.5px">{{ readyN }} claims waiting <em style="color: #12805C">for you</em></h1></div>
      <div style="width: 320px; max-width: 100%; display: flex; flex-direction: column; gap: 6px"><div style="display: flex; justify-content: space-between; font-size: 13px; font-weight: 800"><span>{{ trackN }} of {{ all.length }} filed</span><span style="color: #12805C">{{ filedPct }}%</span></div><div style="height: 10px; border-radius: 99px; background: #DDE5E0; overflow: hidden"><div style="{{ donePctStyle }}"></div></div></div>
    </div>
    <div class="cgrid">
      <div style="display: flex; flex-direction: column; gap: 16px">
        <sc-if value="{{ hasCur }}" hint-placeholder-val="{{ true }}"><section class="cardin" style="position: relative; overflow: hidden; border-radius: 28px; padding: 30px; background: radial-gradient(120% 120% at 100% 0%, #2A8B66 0%, #0F3B2E 48%, #0A1F18 100%); color: #FFFFFF; display: flex; flex-direction: column; gap: 18px">
          <div style="display: flex; justify-content: space-between; align-items: center"><span style="font-size: 12px; font-weight: 800; letter-spacing: 1.4px; color: #9FE8C4">NEXT UP · {{ curIdx }} OF {{ curOf }}</span><span style="{{ cur.dlStyle }}">{{ cur.dl }}</span></div>
          <div style="display: flex; align-items: center; gap: 18px"><img src="{{ cur.logo }}" alt="" style="width: 76px; height: 76px; flex: none; border-radius: 22px; background: #FFFFFF; padding: 13px; box-sizing: border-box; object-fit: contain"><div style="display: flex; flex-direction: column; gap: 4px; min-width: 0"><span style="font-size: 28px; font-weight: 800; letter-spacing: -0.6px">{{ cur.co }}</span><span style="font-size: 15px; color: #CFE5DA">{{ cur.title }}</span></div><span style="margin-left: auto; font-size: 40px; font-weight: 800; letter-spacing: -1.2px; color: #3DDC97">{{ cur.amt }}</span></div>
          <div style="display: flex; flex-direction: column; gap: 6px; padding: 14px 16px; border-radius: 16px; background: rgba(255,255,255,.08)"><span style="font-size: 13px; font-weight: 800; color: #9FE8C4">WHY YOU QUALIFY</span><span style="font-size: 15px">{{ cur.why }}</span><span style="font-size: 13px; color: #B9CCC2">{{ cur.kindNote }}</span></div>
          <div style="display: flex; gap: 10px; align-items: center"><button onClick="{{ cur.file }}" style="flex-grow: 1; min-height: 56px; border-radius: 99px; background: #3DDC97; color: #0A0F0D; font-size: 17px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 10px"><sc-if value="{{ cur.busy }}" hint-placeholder-val="{{ false }}"><span class="spin" style="border-color: rgba(10,15,13,.25); border-top-color: #0A0F0D"></span>Filing your claim</sc-if><sc-if value="{{ cur.idle }}" hint-placeholder-val="{{ true }}">File this claim</sc-if></button><button onClick="{{ skip }}" style="min-height: 56px; padding: 0 22px; border-radius: 99px; background: rgba(255,255,255,.12); color: #FFFFFF; font-size: 15px; font-weight: 800">Skip for now</button></div>
        </section></sc-if>
        <sc-if value="{{ noCur }}" hint-placeholder-val="{{ false }}"><section style="border-radius: 28px; padding: 40px 30px; background: #FFFFFF; box-shadow: 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; align-items: center; gap: 8px; text-align: center"><span style="font-size: 40px">🎉</span><h2 style="margin: 0; font-size: 24px">Everything is filed</h2><span style="font-size: 15px; color: #5B6862">We'll track every claim and tell you when new settlements match you.</span></section></sc-if>
        <sc-if value="{{ hasReady }}" hint-placeholder-val="{{ true }}"><div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap"><span style="font-size: 13px; font-weight: 800; color: #5B6862; margin-right: 4px">UP NEXT</span><sc-for list="{{ queue }}" as="q" hint-placeholder-count="5"><button onClick="{{ q.pick }}" aria-label="Show {{ q.co }}" style="{{ q.qStyle }}"><img src="{{ q.logo }}" alt="" style="width: 100%; height: 100%; object-fit: contain"></button></sc-for></div></sc-if>
      </div>
      <div style="display: flex; flex-direction: column; gap: 16px">
        <section style="border-radius: 22px; padding: 20px; background: #FFFFFF; box-shadow: 0 0 0 1px #E3EAE6; display: grid; grid-template-columns: 1fr 1fr; gap: 12px">
          <div style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 13px; color: #5B6862; font-weight: 700">On the way</span><span style="font-size: 26px; font-weight: 800">{{ pendingTotal }}</span></div>
          <div style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 13px; color: #5B6862; font-weight: 700">Paid to you</span><span style="font-size: 26px; font-weight: 800; color: #12805C">{{ paidTotal }}</span></div>
        </section>
        <section style="border-radius: 22px; padding: 18px 20px 8px; background: #FFFFFF; box-shadow: 0 0 0 1px #E3EAE6">
          <h2 style="margin: 0 0 6px; font-size: 17px">Your filed claims</h2>
          <sc-for list="{{ track }}" as="r" hint-placeholder-count="5"><div class="crow {{ r.rowCls }}">''' + logoimg('r',38,11) + '''<div style="flex-grow: 1; min-width: 0; display: flex; flex-direction: column; gap: 5px"><div style="display: flex; justify-content: space-between; gap: 8px"><span style="font-size: 15px; font-weight: 800">{{ r.co }} <span style="color: #12805C">{{ r.amt }}</span></span><span style="{{ r.pill }}">{{ r.stLabel }}</span></div><div style="display: flex; gap: 3px"><sc-for list="{{ r.segs }}" as="g" hint-placeholder-count="4"><span style="{{ g.st }}"></span></sc-for></div></div></div></sc-for>
        </section>
      </div>
    </div>
  </main>
'''+NOTE+'</div>\n'+TAIL
M_CSS='\n.amain{padding:14px 14px 20px !important}.amain>div{gap:12px !important}\n.shWrap{align-items:flex-end !important}.shCard{width:100% !important;max-width:none !important;max-height:92% !important;border-radius:22px 22px 0 0 !important}\n.greet h1{font-size:20px !important}.greet>div:last-child{width:100%}.greet>div:last-child>span{flex:1}\n.setupRow{flex-wrap:wrap;gap:10px !important;padding:12px !important}.setupProg{width:100% !important}.setupDiv{display:none}.curLbl{white-space:normal !important}\n.hideM{display:none}\n.arow{grid-template-columns:34px minmax(0,1fr) auto auto !important;gap:10px !important;padding:9px 10px !important}.arow>.hideS{display:none !important}\n.trow{grid-template-columns:34px minmax(0,1fr) auto !important;gap:10px !important;padding:10px 14px !important}.trow>.hideS{display:none !important}\n.curBox{flex:1 1 0 !important;flex-wrap:wrap;row-gap:4px !important}\n.moreGrid{display:flex !important;overflow-x:auto;scroll-snap-type:x mandatory;margin:0 -16px;padding:0 16px;scrollbar-width:none}.moreGrid::-webkit-scrollbar{display:none}.moreGrid>*{flex:0 0 82%;scroll-snap-align:start}\n.findBtns{width:100%;flex-direction:column}.findBtns button{justify-content:center}\n.note{left:12px !important;right:12px !important;bottom:78px !important;width:auto !important}\n'
TOP='  <header style="flex: none; display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; background: #FFFFFF; border-bottom: 1px solid #E3EAE6"><div style="display: flex; align-items: center; gap: 7px"><svg width="24" height="24" viewBox="0 0 100 100" aria-hidden="true"><path fill="#0A0F0D" d="M81.4 83.6A46 46 0 0 1 51.6 96.0L51.2 83.0A33 33 0 0 0 72.5 74.1Z"></path><path fill="#0A0F0D" d="M48.4 96.0A46 46 0 0 1 18.6 83.6L27.5 74.1A33 33 0 0 0 48.8 83.0Z"></path><path fill="#0A0F0D" d="M16.4 81.4A46 46 0 0 1 4.0 51.6L17.0 51.2A33 33 0 0 0 25.9 72.5Z"></path><path fill="#0A0F0D" d="M4.0 48.4A46 46 0 0 1 16.4 18.6L25.9 27.5A33 33 0 0 0 17.0 48.8Z"></path><path fill="#0A0F0D" d="M18.6 16.4A46 46 0 0 1 48.4 4.0L48.8 17.0A33 33 0 0 0 27.5 25.9Z"></path><path fill="#12805C" d="M51.6 4.0A46 46 0 0 1 81.4 16.4L72.5 25.9A33 33 0 0 0 51.2 17.0Z"></path></svg><span style="font-size: 17px; font-weight: 800; letter-spacing: -0.4px">claim<span style="font-weight: 500">club</span><span style="font-size: .72em; font-weight: 600; color: #12805C; margin-left: -0.06em">.io</span></span></div><span style="width: 32px; height: 32px; border-radius: 50%; background: #0F3B2E; color: #FFFFFF; font-size: 13px; font-weight: 800; display: flex; align-items: center; justify-content: center">H</span></header>\n'
NAV='  <nav style="flex: none; display: flex; justify-content: space-around; padding: 8px 6px 14px; background: #FFFFFF; border-top: 1px solid #E3EAE6"><span style="display: flex; flex-direction: column; align-items: center; gap: 3px; font-size: 11px; font-weight: 800; color: #0F3B2E"><svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3h7v9H3z M14 3h7v5h-7z M14 12h7v9h-7z M3 16h7v5H3z"></path></svg>Claims</span><span style="display: flex; flex-direction: column; align-items: center; gap: 3px; font-size: 11px; font-weight: 800; color: #8A968F"><svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M8 6h13 M8 12h13 M8 18h13 M3 6h.01 M3 12h.01 M3 18h.01"></path></svg>Settlements</span><span style="display: flex; flex-direction: column; align-items: center; gap: 3px; font-size: 11px; font-weight: 800; color: #8A968F"><svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2 M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z"></path></svg>Your info</span><span style="display: flex; flex-direction: column; align-items: center; gap: 3px; font-size: 11px; font-weight: 800; color: #8A968F"><svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-2.82 1.17V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-2.82-1.17l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 3 13.17H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.17-2.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9.91 3V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 2.82 1.17l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 21 9.91V10a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>Settings</span></nav>\n'
AM=A.replace('<title>Dashboard option A · To-do inbox</title>','<title>Dashboard option A · mobile</title>').replace('</style>\n</helmet>',M_CSS+'</style>\n</helmet>',1)
AM=AM.replace('min-height: 640px; box-sizing: border-box; background: #F3F6F4; color: #0A0F0D; font-family: Manrope, sans-serif; display: flex; overflow: hidden','min-height: 640px; box-sizing: border-box; background: #F3F6F4; color: #0A0F0D; font-family: Manrope, sans-serif; display: flex; flex-direction: column; overflow: hidden',1)
AM=AM.replace(sideA(),TOP,1).replace('  </main>\n','  </main>\n'+NAV,1).replace('{"width":1440,"height":900}','{"width":390,"height":844}')
NAVC=NAV.replace('<span style="display: flex; flex-direction: column; align-items: center; gap: 3px; font-size: 11px; font-weight: 800; color: #0F3B2E">','<button onClick="{{ goDash }}" style="{{ mDash }}">',1)
NAVC=re.sub(r'(<button onClick="\{\{ goDash \}\}".*?)</span>',r'\1</button>',NAVC,count=1,flags=re.S)
k=NAVC.index('Settings</span>'); a=NAVC.rindex('<span style=',0,k); NAVC=NAVC[:a]+'<button onClick="{{ goSet }}" style="{{ mSet }}">'+NAVC[NAVC.index('>',a)+1:k]+'Settings</button>'+NAVC[k+len('Settings</span>'):]
AM=AM.replace(NAV,NAVC,1)
assert TOP in AM and NAVC in AM
for name,src in [('DashA',A),('DashAM',AM)]:
    open(f'/home/claude/cc/project/{name}.dc.html','w').write(src)
print('written')
