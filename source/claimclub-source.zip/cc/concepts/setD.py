# Public settlement pages (Nov 21 2026, canvas only, not live).
# Henry wants sublinks under a "claimclub" Google search and traffic from "<brand> settlement" searches.
# SetDir = /settlements directory, SetA/SetB/SetC = three directions for one settlement page (/settlements/<id>),
# each desktop plus phone. Data comes from sets.json and data/filing_specs.json. Canvas page "Settlement pages".
import os, json, re, base64, datetime
from how4 import HEAD, JS, OUT
from perksD import ic, LU

HERE = os.path.dirname(os.path.abspath(__file__)); CC = os.path.join(HERE, '..')
INK, MUTE, LINE, MINT, GREEN, DARK, BG = '#0A0F0D', '#5B6862', '#E3EAE6', '#3DDC97', '#12805C', '#0F3B2E', '#F6F8F7'
LU.update({
    'cal': 'M8 2v4 M16 2v4 M3 10h18 M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z',
    'clock': 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20z M12 6v6l4 2',
    'file': 'M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z M14 2v4a2 2 0 0 0 2 2h4 M9 15l2 2 4-4',
    'coins': 'M8 14a6 6 0 1 0 0-12 6 6 0 0 0 0 12z M18.09 10.37A6 6 0 1 1 10.34 18 M7 6h1v4 M16.71 13.88l.7.71-2.82 2.82',
    'users': 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M22 21v-2a4 4 0 0 0-3-3.87 M16 3.13a4 4 0 0 1 0 7.75',
    'scale': 'm16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z m-14 0 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z M7 21h10 M12 3v18 M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2',
    'ext': 'M15 3h6v6 M10 14 21 3 M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6',
    'shield': 'M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z m-11 -1 2 2 4-4',
    'menu': 'M4 6h16 M4 12h16 M4 18h16',
    'plus': 'M12 5v14 M5 12h14',
    'ok': 'M20 6 9 17l-5-5',
    'down': 'm6 9 6 6 6-6',
    'zap': 'M13 2 3 14h9l-1 8 10-12h-9z',
})

TODAY = datetime.date(2026, 11, 21)
SETS = json.load(open(os.path.join(HERE, 'sets.json')))
SPEC = {x['id']: x for x in json.load(open(os.path.join(CC, 'data', 'filing_specs.json')))}
CLOSED = set('tyson walgreens disney google youtube openai ubereats flo bn sandoz equinox pork fanatics lemonade cone duke ey hirevue alo apollomd xactus vesync brookside bailbond'.split())
TOP = re.findall(r"'([\w-]+)'", re.search(r"const TOP = \[([^\]]+)\]", open(os.path.join(CC, 'src', 'landing.js')).read()).group(1))
NAT = [s for s in SETS if not s.get('st') and s['id'] not in CLOSED and s['cat'] != 'arb' and (s.get('dl') or '9') >= TODAY.isoformat()]
NAT.sort(key=lambda s: (TOP.index(s['id']) if s['id'] in TOP else 999, s.get('dl') or '9'))
BY = {s['id']: s for s in SETS}
CAT = {'apps': 'Tech and apps', 'bank': 'Banking and money', 'privacy': 'Data breach', 'products': 'Products', 'auto': 'Cars', 'invest': 'Investments', 'health': 'Health', 'arb': 'Arbitration'}

def days(s): return (datetime.date.fromisoformat(s['dl']) - TODAY).days if s.get('dl') else None
def dfmt(iso): d = datetime.date.fromisoformat(iso); return d.strftime('%b ') + str(d.day) + d.strftime(', %Y')
def pay(s):
    m = s.get('max') or s.get('amt')
    return f'Up to ${m:,}' if m else 'Share of the fund'

def tile(i, sz=44):
    p = os.path.join(CC, 'tiles', i + '.svg')
    r = f'{sz * .26:.0f}px'
    if os.path.exists(p):
        u = 'data:image/svg+xml;base64,' + base64.b64encode(open(p, 'rb').read()).decode()
        return f'<img src="{u}" alt="" style="width: {sz}px; height: {sz}px; flex: none; border-radius: {r}">'
    return f'<span style="width: {sz}px; height: {sz}px; flex: none; border-radius: {r}; background: #E3F6EC; color: {GREEN}; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: {sz * .42:.0f}px">{BY[i]["co"][0]}</span>'
def chip(t, kind='g', icon=None):
    c = {'g': ('#0F6B4C', '#E3F6EC'), 'r': ('#A12E35', '#FDECEC'), 'n': ('#43504A', '#EEF2F0'), 'd': ('#CFE9DD', 'rgba(255,255,255,.12)')}[kind]
    return (f'<span style="display: inline-flex; align-items: center; gap: 5px; font-size: 12.5px; font-weight: 800; padding: 5px 10px; border-radius: 99px; background: {c[1]}; color: {c[0]}; white-space: nowrap">'
            + (ic(icon, 13, c[0], 2.4) if icon else '') + f'{t}</span>')
def btn(t, kind='mint', h=52, full=False, icon=None):
    st = {'mint': f'background: {MINT}; color: {DARK}', 'dark': f'background: {DARK}; color: #FFFFFF', 'line': f'background: #FFFFFF; color: {INK}; box-shadow: inset 0 0 0 1.5px {LINE}'}[kind]
    return (f'<span style="height: {h}px; padding: 0 {h * .46:.0f}px; border-radius: 99px; {st}; display: {"flex" if full else "inline-flex"}; align-items: center; justify-content: center; gap: 8px; font-size: {15 if h < 50 else 16}px; font-weight: 800; white-space: nowrap; flex: none">'
            + f'{t}' + (ic(icon, 17, 'currentColor', 2.4) if icon else '') + '</span>')

# ---------- frames ----------
def nav(m=False, dark=False, on='Settlements'):
    fg = '#FFFFFF' if dark else INK
    logo = f'<b style="font-size: {18 if m else 20}px; letter-spacing: -.5px; color: {fg}">claimclub<span style="color: {MINT if dark else GREEN}">.io</span></b>'
    if m:
        return (f'<div style="height: 60px; flex: none; display: flex; align-items: center; gap: 10px; padding: 0 16px; {"" if dark else "background: #FFFFFF; border-bottom: 1px solid " + LINE}">{logo}'
                f'<span style="margin-left: auto">{btn("Get started", "mint", 38)}</span>{ic("menu", 24, fg, 2.2)}</div>')
    l = lambda t, on=False: f'<span style="font-size: 15px; font-weight: 700; color: {fg}; {"opacity: 1" if on else "opacity: .72"}; {"border-bottom: 2px solid " + (MINT if dark else GREEN) + "; padding-bottom: 4px" if on else ""}">{t}</span>'
    return (f'<div style="height: 72px; flex: none; display: flex; align-items: center; gap: 30px; padding: 0 48px; {"" if dark else "background: #FFFFFF; border-bottom: 1px solid " + LINE}">{logo}'
            f'<span style="display: flex; gap: 28px; margin-left: 24px">{l("Settlements", on == "Settlements")}{l("How it works", on == "How it works")}{l("About", on == "About")}</span>'
            f'<span style="margin-left: auto; display: flex; align-items: center; gap: 22px">{l("Log in")}{btn("Get started", "mint", 44)}</span></div>')
def foot(m=False):
    return (f'<div style="background: {DARK}; color: #B9D3C7; padding: {"28px 16px" if m else "36px 48px"}; display: flex; flex-direction: column; gap: 10px; font-size: 13px; line-height: 1.5; font-weight: 600">'
            f'<b style="color: #FFFFFF; font-size: 17px">claimclub<span style="color: {MINT}">.io</span></b>'
            '<span>Claimclub is not a law firm and is not part of any settlement or its administrator. You can always file for free on the official settlement site. Payout amounts are estimates, not guaranteed.</span>'
            '<span style="color: #FFFFFF; opacity: .8">Settlements · How it works · About · Terms · Privacy · support@mail.claimclub.io</span></div>')
def desk(body, h, top=None):
    return (f'<div style="width: 1280px; height: {h}px; flex: none; border-radius: 16px; overflow: hidden; background: #FFFFFF; box-shadow: 0 20px 50px rgba(10,15,13,.14); display: flex; flex-direction: column">'
            f'<div style="height: 30px; flex: none; background: #EEF2F0; display: flex; align-items: center; padding: 0 14px; gap: 6px"><i style="width: 10px; height: 10px; border-radius: 9px; background: #D5DDD9"></i><i style="width: 10px; height: 10px; border-radius: 9px; background: #D5DDD9"></i><i style="width: 10px; height: 10px; border-radius: 9px; background: #D5DDD9"></i>'
            f'<span style="margin-left: 16px; font-size: 12px; font-weight: 700; color: {MUTE}; background: #FFFFFF; padding: 3px 14px; border-radius: 99px">claimclub.io{top or "/settlements"}</span></div>'
            f'<div style="flex: 1; overflow: hidden; display: flex; flex-direction: column">{body}</div></div>')
def phone(body, h):
    return (f'<div style="width: 390px; height: {h}px; flex: none; border-radius: 40px; overflow: hidden; background: #FFFFFF; box-shadow: 0 0 0 10px #1C2420, 0 24px 50px rgba(10,15,13,.25); display: flex; flex-direction: column">'
            f'<div style="height: 40px; flex: none"></div><div style="flex: 1; overflow: hidden; display: flex; flex-direction: column">{body}</div></div>')

# ---------- shared pieces ----------
def card(s, m=False):
    d = days(s)
    soon = d is not None and d <= 14
    return (f'<div style="background: #FFFFFF; border-radius: 18px; box-shadow: inset 0 0 0 1px {LINE}; padding: {16 if m else 20}px; display: flex; flex-direction: column; gap: 12px">'
            f'<div style="display: flex; align-items: center; gap: 12px">{tile(s["id"], 40 if m else 44)}<span style="display: flex; flex-direction: column; gap: 2px; min-width: 0">'
            f'<span style="font-size: 12.5px; font-weight: 800; color: {MUTE}">{s["co"]}</span><b style="font-size: {15 if m else 16}px; line-height: 1.25">{s["title"]}</b></span></div>'
            f'<span style="font-size: 13.5px; color: #43504A; font-weight: 600; line-height: 1.45; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden">{s["who"]}</span>'
            f'<div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-top: auto">'
            f'<b style="font-size: 17px; color: {GREEN}; margin-right: auto">{pay(s)}</b>'
            + (chip('No proof', 'g') if s.get('proof') == 'No proof' else '')
            + (chip(f'{d} days left' if soon else 'Closes ' + dfmt(s['dl'])[:-6], 'r' if soon else 'n', 'clock') if s.get('dl') else chip('No deadline listed', 'n', 'clock')) + '</div></div>')
def qcard(s, m=False, dark=False, tight=False):
    q = (SPEC.get(s['id'], {}).get('qualify') or [{'q': 'Does this sound like you? ' + s['who']}])[0]['q']
    bg = '#FFFFFF'
    return (f'<div style="background: {bg}; color: {INK}; border-radius: 22px; padding: {20 if m else 26}px; display: flex; flex-direction: column; gap: 14px; {"box-shadow: 0 24px 50px rgba(0,0,0,.28)" if dark else "box-shadow: inset 0 0 0 2px " + MINT + ", 0 12px 30px rgba(18,128,92,.10)"}">'
            f'<span style="display: flex; align-items: center; gap: 8px; font-size: 12px; font-weight: 800; letter-spacing: 1.1px; color: {GREEN}">{ic("check", 15, GREEN, 2.6)}DO YOU QUALIFY?</span>'
            f'<b style="font-size: {18 if m else 21}px; line-height: 1.3; letter-spacing: -.3px">{q}</b>'
            f'<div style="display: flex; gap: 10px">'
            f'<span style="flex: 1; height: 54px; border-radius: 16px; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; align-items: center; justify-content: center; gap: 8px; font-size: 16px; font-weight: 800">{ic("x", 18, "#B8333A", 2.6)}No</span>'
            f'<span style="flex: 1; height: 54px; border-radius: 16px; background: {MINT}; color: {DARK}; display: flex; align-items: center; justify-content: center; gap: 8px; font-size: 16px; font-weight: 800">{ic("ok", 18, DARK, 2.8)}Yes</span></div>'
            f'<span style="font-size: 12.5px; color: {MUTE}; font-weight: 600; text-align: center">Free to check. Yes takes you to a 1 minute check for this and other settlements.</span></div>')
def sec(t, body, m=False):
    return (f'<div style="display: flex; flex-direction: column; gap: 10px"><h2 style="margin: 0; font-size: {20 if m else 24}px; letter-spacing: -.4px">{t}</h2>'
            f'<div style="font-size: {15 if m else 16}px; line-height: 1.6; color: #2A3530; font-weight: 500">{body}</div></div>')
def how_file(s, m=False):
    sp = SPEC.get(s['id'], {})
    url = (sp.get('form_url') or '').replace('https://', '').replace('www.', '').rstrip('/')
    opt = lambda ico, h, b, foot, hl=False: (
        f'<div style="flex: 1; border-radius: 18px; padding: 18px; display: flex; flex-direction: column; gap: 8px; {"background: #E9F6EF; box-shadow: inset 0 0 0 1.5px " + MINT if hl else "background: " + BG}">'
        f'<span style="display: flex; align-items: center; gap: 8px">{ic(ico, 18, GREEN, 2.2)}<b style="font-size: 16px">{h}</b></span>'
        f'<span style="font-size: 14px; line-height: 1.5; color: #43504A; font-weight: 600">{b}</span><span style="font-size: 13px; font-weight: 800; color: {GREEN}; margin-top: auto">{foot}</span></div>')
    return (f'<div style="display: flex; gap: 12px; {"flex-direction: column" if m else ""}">'
            + opt('zap', 'We file it for you', 'Answer a few questions once. We fill in the claim form, submit it and track it until it pays. You keep 100% of the payout.', 'Check if I qualify', True)
            + opt('ext', 'File it yourself', f'Claims are free to file on the official settlement site{", " + url if url else ""}. You will need about 10 minutes and your details.', 'Official site' + (' · ' + url if url else '')) + '</div>')
def timeline(s, m=False):
    d = datetime.date.fromisoformat(s['dl'])
    pts = [('ok', 'Settlement approved', 'Open for claims now', True), ('cal', 'Claim deadline', dfmt(s['dl']), True),
           ('coins', 'Payments expected', (d + datetime.timedelta(days=180)).strftime('%B %Y') + ' or later', False)]
    out = ''
    for i, (k, t, sub, on) in enumerate(pts):
        out += (f'<div style="display: flex; gap: 14px; position: relative; padding-bottom: {0 if i == 2 else 18}px">'
                + (f'<i style="position: absolute; left: 15px; top: 32px; bottom: 0; width: 2px; background: {LINE}"></i>' if i < 2 else '')
                + f'<span style="width: 32px; height: 32px; flex: none; border-radius: 99px; background: {"#E3F6EC" if on else BG}; display: flex; align-items: center; justify-content: center">{ic(k, 16, GREEN if on else MUTE, 2.3)}</span>'
                f'<span style="display: flex; flex-direction: column; gap: 2px; padding-top: 5px"><b style="font-size: 15px">{t}</b><span style="font-size: 14px; color: {MUTE}; font-weight: 600">{sub}</span></span></div>')
    return out
def faq(s, m=False):
    qs = [(f'Is the {s["co"]} settlement real?', 'Yes. It was approved by a court and is run by a settlement administrator. Claimclub is not part of the case.'),
          ('Do I need proof?', 'No proof is needed. You confirm under oath that you qualify.' if s.get('proof') == 'No proof' else 'Yes. Keep receipts or account records that show you qualify.'),
          ('When will I get paid?', 'After the deadline and any appeals, usually 6 to 12 months. The settlement pays you directly.')]
    out = ''
    for i, (q, a) in enumerate(qs):
        out += (f'<div style="border-top: 1px solid {LINE}; padding: 14px 0; display: flex; flex-direction: column; gap: 6px">'
                f'<span style="display: flex; align-items: center; gap: 10px"><b style="font-size: {15 if m else 16}px; flex: 1">{q}</b>{ic("down", 18, MUTE, 2.2)}</span>'
                + (f'<span style="font-size: 14.5px; color: #43504A; font-weight: 600; line-height: 1.5">{a}</span>' if i == 0 else '') + '</div>')
    return out
def related(s, m=False, n=3):
    rel = [x for x in NAT if x['cat'] == s['cat'] and x['id'] != s['id']][:n]
    return (f'<div style="display: flex; flex-direction: column; gap: 14px"><span style="display: flex; align-items: baseline"><h2 style="margin: 0; font-size: {20 if m else 24}px; letter-spacing: -.4px; flex: 1">More {CAT[s["cat"]].lower()} settlements</h2>'
            f'<b style="font-size: 14px; color: {GREEN}">See all</b></span>'
            f'<div style="display: grid; grid-template-columns: {"1fr" if m else "repeat(3, 1fr)"}; gap: 14px">{"".join(card(x, m) for x in rel)}</div></div>')
def crumbs(s, dark=False):
    c = '#B9D3C7' if dark else MUTE
    return f'<span style="font-size: 13.5px; font-weight: 700; color: {c}">Settlements  ›  {CAT[s["cat"]]}  ›  <span style="color: {"#FFFFFF" if dark else INK}">{s["co"]}</span></span>'

# ---------- directory ----------
CHIPS = [('All', len(NAT)), ('No proof needed', sum(1 for s in NAT if s.get('proof') == 'No proof')), ('Closing soon', sum(1 for s in NAT if (days(s) or 99) <= 21))] + \
        [(CAT[k], sum(1 for s in NAT if s['cat'] == k)) for k in ('apps', 'bank', 'privacy', 'products', 'auto', 'invest')]
def chiprow(m=False):
    return ''.join(f'<span style="flex: none; font-size: 14px; font-weight: 800; padding: 9px 14px; border-radius: 99px; {"background: " + DARK + "; color: #FFFFFF" if i == 0 else "background: #FFFFFF; box-shadow: inset 0 0 0 1px " + LINE + "; color: #2A3530"}">{t} <span style="opacity: .55">{n}</span></span>' for i, (t, n) in enumerate(CHIPS))
def search(m=False):
    return (f'<div style="height: {52 if m else 58}px; flex: {'none' if m else '1'}; border-radius: 99px; background: #FFFFFF; box-shadow: 0 1px 0 {LINE}, 0 8px 24px rgba(10,15,13,.06); display: flex; align-items: center; gap: 10px; padding: 0 20px">'
            f'{ic("search", 19, MUTE, 2.3)}<span style="font-size: 15.5px; color: #8A968F; font-weight: 600">Search a company, like Apple or Visa</span></div>')
def dir_d():
    hero = (f'<div style="background: linear-gradient(180deg, #E9F6EF, {BG}); padding: 48px 48px 30px; display: flex; flex-direction: column; gap: 18px">'
            f'<span style="font-size: 12.5px; font-weight: 800; letter-spacing: 1.2px; color: {GREEN}">UPDATED NOV 21, 2026</span>'
            f'<h1 style="margin: 0; font-size: 52px; letter-spacing: -1.6px; line-height: 1.05; max-width: 760px">Open class action settlements</h1>'
            f'<span style="font-size: 18px; color: #43504A; font-weight: 600; max-width: 720px; line-height: 1.5">{len(NAT)} nationwide settlements you can claim right now. See who qualifies, how much each one pays and when it closes.</span>'
            f'<div style="display: flex; gap: 12px; max-width: 900px; margin-top: 6px">{search()}{btn("Check what I qualify for", "mint", 58)}</div>'
            f'<div style="display: flex; gap: 8px; flex-wrap: wrap; margin-top: 6px">{chiprow()}</div></div>')
    grid = f'<div style="padding: 10px 48px 30px; background: {BG}; display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px">{"".join(card(s) for s in NAT[:12])}</div>'
    more = (f'<div style="background: {BG}; padding: 0 48px 40px; display: flex; justify-content: center; gap: 8px">'
            + ''.join(f'<span style="width: 40px; height: 40px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 14px; {"background: " + DARK + "; color: #FFFFFF" if p == "1" else "background: #FFFFFF; box-shadow: inset 0 0 0 1px " + LINE}">{p}</span>' for p in ['1', '2', '3', '…', str(-(-len(NAT) // 12))]) + '</div>')
    return desk(nav() + hero + grid + more + foot(), 1640)
def dir_m():
    hero = (f'<div style="background: linear-gradient(180deg, #E9F6EF, {BG}); padding: 22px 16px 14px; display: flex; flex-direction: column; gap: 12px">'
            f'<span style="font-size: 11.5px; font-weight: 800; letter-spacing: 1.1px; color: {GREEN}">UPDATED NOV 21, 2026</span>'
            f'<h1 style="margin: 0; font-size: 32px; letter-spacing: -1px; line-height: 1.08">Open class action settlements</h1>'
            f'<span style="font-size: 15px; color: #43504A; font-weight: 600; line-height: 1.5">{len(NAT)} nationwide settlements you can claim right now.</span>'
            f'{search(True)}<div style="display: flex; gap: 8px; overflow: hidden; margin-right: -16px">{chiprow(True)}</div></div>')
    lst = f'<div style="padding: 6px 16px 20px; background: {BG}; display: flex; flex-direction: column; gap: 12px">{"".join(card(s, True) for s in NAT[:6])}</div>'
    return phone(nav(True) + hero + lst, 1640)

# ---------- settlement page directions ----------
S = BY['apple']
def facts(s, m=False, cols=4):
    sp = SPEC.get(s['id'], {})
    cells = [('coins', 'Payout', pay(s)), ('cal', 'Deadline', dfmt(s['dl'])), ('file', 'Proof', 'Not needed' if s.get('proof') == 'No proof' else s.get('proof')),
             ('scale', 'Fund', s.get('fund') or 'Not stated')]
    return (f'<div style="display: grid; grid-template-columns: repeat({2 if m else cols}, 1fr); gap: 1px; background: {LINE}; border-radius: 16px; overflow: hidden; box-shadow: inset 0 0 0 1px {LINE}">'
            + ''.join(f'<div style="background: #FFFFFF; padding: {14 if m else 16}px; display: flex; flex-direction: column; gap: 6px"><span style="display: flex; align-items: center; gap: 6px; font-size: 12.5px; font-weight: 800; color: {MUTE}">{ic(k, 14, MUTE, 2.3)}{t}</span><b style="font-size: {15 if m else 17}px">{v}</b></div>' for k, t, v in cells) + '</div>')
def body_secs(s, m=False):
    sp = SPEC.get(s['id'], {})
    return (sec('What this case is about', sp.get('about', ''), m) + sec('Who qualifies', sp.get('who', s['who']), m)
            + sec('How to file', how_file(s, m), m) + sec('Key dates', timeline(s, m), m) + sec('Common questions', faq(s, m), m))

def setA_d(s=S):
    d = days(s)
    side = (f'<div style="width: 340px; flex: none; display: flex; flex-direction: column; gap: 14px">'
            f'<div style="background: #FFFFFF; border-radius: 22px; box-shadow: inset 0 0 0 1px {LINE}, 0 14px 34px rgba(10,15,13,.08); padding: 24px; display: flex; flex-direction: column; gap: 12px">'
            f'<span style="font-size: 13px; font-weight: 800; color: {MUTE}">You could get</span><b style="font-size: 44px; letter-spacing: -1.4px; line-height: 1; color: {GREEN}">{pay(s)}</b>'
            f'<span style="display: flex; gap: 6px; flex-wrap: wrap">{chip(f"{d} days left", "r" if d <= 14 else "n", "clock")}{chip("No proof needed", "g") if s.get("proof") == "No proof" else ""}</span>'
            f'{btn("Check if I qualify", "mint", 54, True)}<span style="font-size: 12.5px; color: {MUTE}; font-weight: 600; text-align: center">Free to check · about 1 minute</span></div>'
            f'<span style="display: flex; align-items: flex-start; gap: 8px; font-size: 13px; color: {MUTE}; font-weight: 600; line-height: 1.45; padding: 0 6px">{ic("shield", 16, GREEN, 2.2)}Claimclub is not a law firm and is not part of this case. Filing on the official site is always free.</span></div>')
    main = (f'<div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 30px">'
            f'<div style="display: flex; flex-direction: column; gap: 14px">{crumbs(s)}'
            f'<div style="display: flex; align-items: center; gap: 16px">{tile(s["id"], 64)}<span style="display: flex; flex-direction: column; gap: 4px"><span style="font-size: 15px; font-weight: 800; color: {MUTE}">{s["co"]}</span>'
            f'<h1 style="margin: 0; font-size: 40px; letter-spacing: -1.2px; line-height: 1.08">{s["title"]}</h1></span></div>'
            f'<span style="font-size: 17px; color: #43504A; font-weight: 600; line-height: 1.5">{s["who"]}. Here is who qualifies, how much it pays and how to file before {dfmt(s["dl"])}.</span></div>'
            f'{facts(s)}{qcard(s)}{body_secs(s)}</div>')
    page = f'<div style="padding: 36px 48px 48px; display: flex; gap: 40px; align-items: flex-start; background: #FFFFFF">{main}{side}</div>'
    rel = f'<div style="padding: 36px 48px 44px; background: {BG}">{related(s)}</div>'
    return desk(nav() + page + rel + foot(), 2240, '/settlements/apple')
def setA_m(s=S):
    d = days(s)
    top = (f'<div style="padding: 18px 16px 8px; display: flex; flex-direction: column; gap: 14px">{crumbs(s)}'
           f'<div style="display: flex; align-items: center; gap: 12px">{tile(s["id"], 52)}<span style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 13px; font-weight: 800; color: {MUTE}">{s["co"]}</span>'
           f'<h1 style="margin: 0; font-size: 26px; letter-spacing: -.8px; line-height: 1.1">{s["title"]}</h1></span></div>'
           f'<span style="display: flex; align-items: baseline; gap: 10px"><b style="font-size: 30px; color: {GREEN}; letter-spacing: -1px">{pay(s)}</b>{chip(f"{d} days left", "n", "clock")}</span>'
           f'{facts(s, True)}{qcard(s, True)}</div>')
    rest = f'<div style="padding: 16px 16px 24px; display: flex; flex-direction: column; gap: 26px">{body_secs(s, True)}</div>'
    bar = (f'<div style="position: sticky; bottom: 0; background: rgba(255,255,255,.94); border-top: 1px solid {LINE}; padding: 10px 16px 18px">{btn("Check if I qualify", "mint", 52, True)}</div>')
    return phone(nav(True) + f'<div style="flex: 1; overflow: hidden; position: relative">{top}{rest}</div>' + bar, 2240)

def setB_d(s=S):
    d = days(s)
    band = (f'<div style="background: radial-gradient(120% 140% at 0% 0%, #1E7A55 0%, {DARK} 55%, #072619 100%); color: #FFFFFF; display: flex; flex-direction: column">'
            + nav(dark=True) +
            f'<div style="padding: 30px 48px 56px; display: flex; gap: 56px; align-items: center">'
            f'<div style="flex: 1; display: flex; flex-direction: column; gap: 18px">{crumbs(s, True)}'
            f'<span style="display: flex; align-items: center; gap: 14px">{tile(s["id"], 56)}<b style="font-size: 18px">{s["co"]}</b></span>'
            f'<h1 style="margin: 0; font-size: 50px; letter-spacing: -1.6px; line-height: 1.04">{s["title"]}</h1>'
            f'<span style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 14px; font-weight: 700; color: #B9D3C7">You could get</span><b style="font-size: 64px; letter-spacing: -2px; line-height: 1; color: {MINT}">{pay(s)}</b></span>'
            f'<span style="display: flex; gap: 8px; flex-wrap: wrap">{chip("Closes " + dfmt(s["dl"]), "d", "cal")}{chip(f"{d} days left", "d", "clock")}{chip("No proof needed", "d", "ok") if s.get("proof") == "No proof" else ""}{chip((s.get("fund") or "") + " fund", "d", "scale") if s.get("fund") else ""}</span></div>'
            f'<div style="width: 440px; flex: none">{qcard(s, dark=True)}</div></div></div>')
    sp = SPEC.get(s['id'], {})
    three = (f'<div style="padding: 36px 48px 6px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px">'
             + ''.join(f'<div style="background: {BG}; border-radius: 18px; padding: 20px; display: flex; flex-direction: column; gap: 8px"><span style="width: 38px; height: 38px; border-radius: 12px; background: #E3F6EC; display: flex; align-items: center; justify-content: center">{ic(k, 19, GREEN, 2.2)}</span><b style="font-size: 17px">{t}</b><span style="font-size: 14.5px; color: #43504A; font-weight: 600; line-height: 1.5">{b}</span></div>'
                       for k, t, b in [('users', 'Who qualifies', sp.get('who', s['who'])), ('coins', 'What you get', sp.get('about', '').split('. ')[-1].rstrip('.') + '.'), ('file', 'What you need', 'No proof. Just your iPhone serial number, or the Apple Account used on it.')]) + '</div>')
    body = (f'<div style="padding: 30px 48px 40px; display: flex; gap: 48px; align-items: flex-start"><div style="flex: 1; display: flex; flex-direction: column; gap: 30px">'
            + sec('What this case is about', sp.get('about', '')) + sec('How to file', how_file(s)) + sec('Common questions', faq(s)) + '</div>'
            f'<div style="width: 340px; flex: none; background: {BG}; border-radius: 20px; padding: 22px; display: flex; flex-direction: column; gap: 14px"><b style="font-size: 17px">Key dates</b>{timeline(s)}</div></div>')
    rel = f'<div style="padding: 36px 48px 44px; background: {BG}">{related(s)}</div>'
    return desk(band + three + body + rel + foot(), 1980, '/settlements/apple')
def setB_m(s=S):
    d = days(s)
    band = (f'<div style="background: radial-gradient(140% 120% at 0% 0%, #1E7A55 0%, {DARK} 55%, #072619 100%); color: #FFFFFF; display: flex; flex-direction: column">'
            + nav(True, True) +
            f'<div style="padding: 12px 16px 24px; display: flex; flex-direction: column; gap: 14px">'
            f'<span style="display: flex; align-items: center; gap: 10px">{tile(s["id"], 40)}<b style="font-size: 15px">{s["co"]}</b></span>'
            f'<h1 style="margin: 0; font-size: 30px; letter-spacing: -1px; line-height: 1.08">{s["title"]}</h1>'
            f'<b style="font-size: 42px; letter-spacing: -1.4px; line-height: 1; color: {MINT}">{pay(s)}</b>'
            f'<span style="display: flex; gap: 6px; flex-wrap: wrap">{chip(f"{d} days left", "d", "clock")}{chip("No proof needed", "d", "ok")}</span>'
            f'{qcard(s, True, True)}</div></div>')
    sp = SPEC.get(s['id'], {})
    rest = (f'<div style="padding: 24px 16px; display: flex; flex-direction: column; gap: 26px">'
            + sec('Who qualifies', sp.get('who', ''), True) + sec('What this case is about', sp.get('about', ''), True) + sec('How to file', how_file(s, True), True) + sec('Key dates', timeline(s, True), True) + '</div>')
    return phone(band + rest, 1980)

def answer_box(s, m=False):
    sp = SPEC.get(s['id'], {})
    url = (sp.get('form_url') or '').replace('https://', '').replace('www.', '').rstrip('/')
    rows = [('users', 'Who can claim', sp.get('who', s['who'])), ('coins', 'How much', sp.get('about', '').split('. ')[-1].rstrip('.') if 'pays' in sp.get('about', '') else pay(s)),
            ('cal', 'Deadline', dfmt(s['dl']) + f' ({days(s)} days left)'), ('file', 'Proof needed', 'None' if s.get('proof') == 'No proof' else s.get('proof')),
            ('ext', 'Official site', url), ('scale', 'Administrator', sp.get('admin', ''))]
    return (f'<div style="border-radius: 20px; box-shadow: inset 0 0 0 1px {LINE}; overflow: hidden">'
            f'<div style="background: {DARK}; color: #FFFFFF; padding: {14 if m else 16}px {16 if m else 22}px; display: flex; align-items: center; gap: 10px"><b style="font-size: {15 if m else 16}px; flex: 1">{s["co"]} settlement at a glance</b><span style="font-size: 12px; font-weight: 800; color: {MINT}">CHECKED NOV 21</span></div>'
            + ''.join(f'<div style="display: flex; {"flex-direction: column; gap: 3px" if m else "gap: 16px"}; padding: {12 if m else 14}px {16 if m else 22}px; {"border-top: 1px solid " + LINE if i else ""}; background: #FFFFFF">'
                      f'<span style="{"" if m else "width: 170px; flex: none;"} display: flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 800; color: {MUTE}">{ic(k, 15, MUTE, 2.3)}{t}</span>'
                      f'<span style="font-size: {14.5 if m else 15.5}px; font-weight: 700; line-height: 1.45; {"color: " + GREEN if t == "How much" else ""}">{v}</span></div>' for i, (k, t, v) in enumerate(rows)) + '</div>')
def check_bar(s, m=False):
    return (f'<div style="background: #E9F6EF; border-radius: 20px; padding: {16 if m else 20}px {16 if m else 24}px; display: flex; {"flex-direction: column; gap: 12px" if m else "align-items: center; gap: 18px"}">'
            f'<span style="display: flex; align-items: center; gap: 12px; flex: 1">{tile(s["id"], 44)}<span style="display: flex; flex-direction: column; gap: 2px"><b style="font-size: 17px">See if you qualify in 1 minute</b><span style="font-size: 14px; color: #43504A; font-weight: 600">We check this and {len(NAT) - 1} other open settlements. Free.</span></span></span>'
            f'{btn("Check if I qualify", "mint", 52, m, "right")}</div>')
def setC_d(s=S):
    sp = SPEC.get(s['id'], {})
    toc = ''.join(f'<span style="font-size: 14px; font-weight: 700; color: {INK if i == 0 else MUTE}; padding: 6px 0 6px 12px; border-left: 2px solid {GREEN if i == 0 else LINE}">{t}</span>' for i, t in enumerate(['At a glance', 'What happened', 'Who qualifies', 'How to file', 'Key dates', 'Questions', 'Similar settlements']))
    main = (f'<div style="width: 760px; display: flex; flex-direction: column; gap: 28px">'
            f'<div style="display: flex; flex-direction: column; gap: 12px">{crumbs(s)}'
            f'<h1 style="margin: 0; font-size: 42px; letter-spacing: -1.3px; line-height: 1.08">{s["co"]} settlement: who can claim, how much and the deadline</h1>'
            f'<span style="display: flex; align-items: center; gap: 10px; font-size: 14px; font-weight: 700; color: {MUTE}">{tile(s["id"], 28)}{s["title"]} · Updated Nov 21, 2026</span></div>'
            f'{answer_box(s)}{check_bar(s)}'
            + sec('What happened', sp.get('about', '')) + sec('Who qualifies', sp.get('who', '')) + sec('How to file', how_file(s)) + sec('Key dates', timeline(s)) + sec('Common questions', faq(s)) + '</div>')
    page = (f'<div style="padding: 36px 48px 44px; display: flex; gap: 56px; align-items: flex-start">'
            f'<div style="width: 200px; flex: none; display: flex; flex-direction: column; gap: 2px; padding-top: 120px"><span style="font-size: 12px; font-weight: 800; letter-spacing: 1px; color: {MUTE}; margin-bottom: 8px">ON THIS PAGE</span>{toc}</div>{main}</div>')
    rel = f'<div style="padding: 36px 48px 44px; background: {BG}">{related(s)}</div>'
    return desk(nav() + page + rel + foot(), 2420, '/settlements/apple')
def setC_m(s=S):
    sp = SPEC.get(s['id'], {})
    top = (f'<div style="padding: 18px 16px 24px; display: flex; flex-direction: column; gap: 18px">{crumbs(s)}'
           f'<h1 style="margin: 0; font-size: 27px; letter-spacing: -.8px; line-height: 1.1">{s["co"]} settlement: who can claim, how much and the deadline</h1>'
           f'{answer_box(s, True)}{check_bar(s, True)}' + sec('What happened', sp.get('about', ''), True) + sec('How to file', how_file(s, True), True) + sec('Key dates', timeline(s, True), True) + sec('Common questions', faq(s, True), True) + '</div>')
    return phone(nav(True) + top, 2420)

# ---------- boards ----------
def board(name, label, note, d, m, H):
    page = (f'<div data-board style="width: 1840px; height: {H + 200}px; box-sizing: border-box; padding: 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: {INK}; display: flex; flex-direction: column; gap: 28px">'
            f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: {GREEN}">{label}</span>'
            f'<span style="font-size: 16px; color: #43504A; font-weight: 600; max-width: 1300px; line-height: 1.45">{note}</span></div>'
            f'<div style="display: flex; gap: 60px; align-items: flex-start">{d}{m}</div></div>\n</x-dc>\n')
    open(os.path.join(OUT, f'{name}.dc.html'), 'w').write(HEAD % label.title() + page + JS.replace('"width":1926,"height":980', f'"width":1840,"height":{H + 200}'))
    return H + 200

if __name__ == '__main__':
    B = [('SetDir', 'SETTLEMENTS DIRECTORY · /settlements', f'Every open nationwide settlement ({len(NAT)}), most popular first, with search and filter chips. Each card links to its own page. Plain page numbers so Google can crawl every case. Local cases (members only) and mass arbitration cases are left out, since they are not settlements.', dir_d(), dir_m(), 1640),
         ('SetA', 'SETTLEMENT PAGE · A · ARTICLE WITH A STICKY CARD', 'Reads like a guide: title, facts strip, the qualify question right on the page, then what happened, who qualifies, how to file (us or yourself for free), key dates, questions and similar cases. A sticky card on the right keeps the payout and the button in view.', setA_d(), setA_m(), 2240),
         ('SetB', 'SETTLEMENT PAGE · B · BRAND HERO', 'Dark green hero like the homepage: big payout, deadline chips and the qualify question card on the right. Under it three plain cards (who qualifies, what you get, what you need), then the details with key dates on the side.', setB_d(), setB_m(), 1980),
         ('SetC', 'SETTLEMENT PAGE · C · QUICK ANSWER', 'Built for Google: the title matches what people search ("Apple settlement: who can claim, how much and the deadline") and an at-a-glance table answers it straight away, then one check bar and the details. On this page links on the left.', setC_d(), setC_m(), 2420)]
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    if not any(pg['id'] == 'setp' for pg in c['pages']): c['pages'].append({'id': 'setp', 'name': 'Settlement pages'})
    x = 0
    for nm, label, note, d, m, H in B:
        h = board(nm, label, note, d, m, H)
        c['boards'][nm + '.dc.html'] = {'x': x, 'y': 0, 'w': 1840, 'h': h, 'title': label.title(), 'page': 'setp', 'is_interactive': False}
        if nm + '.dc.html' not in c['order']: c['order'].append(nm + '.dc.html')
        x += 1940
    c['notes']['tSetp'] = {'x': 0, 'y': -300, 'page': 'setp', 'text': 'Public settlement pages · directory plus 3 page directions', 'kind': 'title1', 'maxW': 7600, 'w': 240}
    if 'tSetp' not in c['noteOrder']: c['noteOrder'].append('tSetp')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w'))
    print('ok', len(NAT))
