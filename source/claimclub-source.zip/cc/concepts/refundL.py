# Refund Club homepage, 3 iterations (Nov 14), styled like the Claim money homepage: green hero tile with the nav inside, realistic iPhone,
# section rhythm (what we get back, how it works with three phones, trust tiles, membership tile). Boards RefundL1..3 (desktop 1440 + mobile 390). Not live.
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from how4 import iphone, ic, IC, LOGO, HEAD, JS, OUT
IC['lock'] = '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path>'
from refundC import logo, mark, brand, navbar, scr_found, KINDS, CONTROL, MESH, MINT, DARK, GREEN, FOUND, SUBS

# ---------- phone screens ----------
def scr_question():
    return ('<div style="display: flex; flex-direction: column; height: 100%; padding: 6px 2px 12px; box-sizing: border-box; gap: 16px">'
            '<div style="display: flex; gap: 3px">' + ''.join(f'<span style="flex: 1; height: 4px; border-radius: 99px; background: {GREEN if i < 2 else "#DDE5E0"}"></span>' for i in range(8)) + '</div>'
            f'<div style="flex: 1; display: flex; flex-direction: column; justify-content: center; gap: 16px">{mark("logos2/netflix.svg", "Netflix", "hand", 68)}'
            '<span style="font-size: 24px; font-weight: 800; letter-spacing: -.6px; line-height: 1.15">Were you charged by Netflix after you canceled?</span></div>'
            f'<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px"><span style="height: 54px; border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px #E3EAE6; font-size: 18px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 6px"><span style="color: #B8333A; display: flex">{ic("x", 20, 3)}</span>No</span>'
            f'<span style="height: 54px; border-radius: 18px; background: {MINT}; color: {DARK}; font-size: 18px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 6px">{ic("check", 20, 3)}Yes</span></div></div>')
def scr_fight():
    rows = ''.join(f'<div style="display: flex; align-items: center; gap: 9px; padding: 9px; border-radius: 14px; background: #FFFFFF">{mark(src, nm, "hand", 32)}<span style="flex: 1; min-width: 0; display: flex; flex-direction: column"><b style="font-size: 13px">{nm} <span style="color: {GREEN}">{amt}</span></b><span style="font-size: 10.5px; color: #5B6862; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{why}</span></span>'
                   + (f'<span style="padding: 6px 9px; border-radius: 99px; background: #E3F8EE; color: {GREEN}; font-size: 11px; font-weight: 800; display: flex; align-items: center; gap: 3px">{ic("check", 12, 3)}Sent</span>' if i < 2 else f'<span style="padding: 6px 10px; border-radius: 99px; background: {MINT}; color: {DARK}; font-size: 11px; font-weight: 800">Fight it</span>') + '</div>'
                   for i, (k, src, nm, why, amt) in enumerate(FOUND[:4]))
    return ('<div style="display: flex; flex-direction: column; height: 100%; padding: 12px 0; box-sizing: border-box; gap: 10px">'
            '<span style="font-size: 11px; font-weight: 800; letter-spacing: 1px; color: #5B6862">CLAIM A REFUND</span><span style="font-size: 22px; font-weight: 800; letter-spacing: -.5px; line-height: 1.15">Approve and we fight it</span>'
            f'<div style="display: flex; flex-direction: column; gap: 6px">{rows}</div></div>')
def scr_paid():
    notes = [('$47.97', 'Netflix'), ('$32.18', 'Amazon'), ('$24.60', 'Uber Eats')]
    note = lambda amt, co: (f'<div style="display: flex; gap: 10px; align-items: center; padding: 11px; border-radius: 18px; background: rgba(255,255,255,.92); box-shadow: 0 12px 26px rgba(10,15,13,.16); text-align: left">'
                            f'<span style="width: 38px; height: 38px; flex: none; border-radius: 10px; background: {DARK}; display: flex; align-items: center; justify-content: center">{LOGO.format(s=23, c="#FFFFFF")}</span>'
                            f'<span style="flex: 1; display: flex; flex-direction: column; gap: 1px"><span style="display: flex; justify-content: space-between"><b style="font-size: 13px">Claimclub</b><span style="font-size: 11px; color: #6E7A73">now</span></span><span style="font-size: 12.5px; line-height: 1.3"><b>Refund sent: {amt}</b> from {co}, back on your card.</span></span></div>')
    return ('<div style="position: absolute; inset: 0; background: linear-gradient(170deg, #CFF3E1 0%, #8FE0B9 45%, #3DB884 100%)"></div>'
            '<div style="position: relative; display: flex; flex-direction: column; align-items: center; height: 100%; padding-top: 18px; box-sizing: border-box; color: #0F3B2E">'
            '<span style="font-size: 15px; font-weight: 700">Saturday, March 6</span><span style="font-size: 72px; font-weight: 700; letter-spacing: -3px; line-height: 1">9:41</span>'
            '<div style="width: 100%; margin-top: 22px; display: flex; flex-direction: column; gap: 8px">' + ''.join(note(*n) for n in notes) + '</div></div>')
def scr_subs():
    rows = ''.join(f'<div style="display: flex; align-items: center; gap: 9px; padding: 9px; border-radius: 14px; background: #FFFFFF">{mark(src, nm, "repeat", 32)}<span style="flex: 1; min-width: 0; display: flex; flex-direction: column"><b style="font-size: 13px">{nm}</b><span style="font-size: 10.5px; font-weight: 700; color: {"#B8333A" if st == "unused" else "#17603F"}">{use}</span></span>'
                   + (f'<span style="padding: 6px 9px; border-radius: 99px; background: #0A0F0D; color: #FFFFFF; font-size: 10.5px; font-weight: 800">Cancel</span>' if st == 'unused' else f'<b style="font-size: 12px">${amt:.2f}</b>') + '</div>'
                   for src, nm, plan, amt, use, st in sorted(SUBS, key=lambda x: x[5] != 'unused')[:5])
    return ('<div style="display: flex; flex-direction: column; height: 100%; padding: 12px 0; box-sizing: border-box; gap: 9px">'
            '<span style="font-size: 11px; font-weight: 800; letter-spacing: 1px; color: #5B6862; text-align: center">SUBSCRIPTION MANAGER</span>'
            '<span style="display: flex; gap: 6px"><span style="flex: 1; padding: 9px; border-radius: 12px; background: #FFFFFF; display: flex; flex-direction: column"><span style="font-size: 10px; font-weight: 800; color: #5B6862">PER MONTH</span><b style="font-size: 18px">$147.44</b></span>'
            '<span style="flex: 1; padding: 9px; border-radius: 12px; background: #FDECEC; display: flex; flex-direction: column"><span style="font-size: 10px; font-weight: 800; color: #B8333A">NOT USED</span><b style="font-size: 18px; color: #B8333A">$73.97</b></span></span>'
            f'<div style="display: flex; flex-direction: column; gap: 6px">{rows}</div></div>')
ph = lambda scr, w=270: iphone(scr, w, '#F3F6F4')
def note_card(top, sub, w=340):
    return (f'<div style="width: {w}px; display: flex; align-items: center; gap: 12px; padding: 14px 16px; border-radius: 20px; background: #FFFFFF; box-shadow: 0 24px 50px rgba(0,0,0,.28); transform: rotate(-2deg)">'
            f'<span style="width: 44px; height: 44px; flex: none; border-radius: 12px; background: {DARK}; display: flex; align-items: center; justify-content: center">{LOGO.format(s=26, c="#FFFFFF")}</span>'
            f'<span style="flex: 1; display: flex; flex-direction: column"><span style="display: flex; justify-content: space-between"><b style="font-size: 15px; color: #0A0F0D">{top}</b><span style="font-size: 12px; color: #8A968F">now</span></span><span style="font-size: 13.5px; color: #43504A">{sub}</span></span></div>')

# ---------- shared sections ----------
H2 = lambda t, m, c=DARK, center=False: f'<h2 style="margin: 0; font-size: {30 if m else 46}px; letter-spacing: -1.4px; line-height: 1.08; color: {c}; {"text-align: center" if center else ""}">{t}</h2>'
def wrap(inner, m, bg='#FFFFFF', pad=(48, 96)):
    return f'<section style="background: {bg}; padding: {pad[0] if m else pad[1]}px {16 if m else 40}px"><div style="max-width: 1360px; margin: 0 auto; display: flex; flex-direction: column; gap: {20 if m else 32}px">{inner}</div></section>'
def kinds_grid(m):
    tile = lambda k, t, d: (f'<div style="display: flex; flex-direction: column; gap: 10px; padding: {16 if m else 22}px; border-radius: 22px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6">'
                            f'<span style="width: 44px; height: 44px; border-radius: 14px; background: #E9F6EF; color: {GREEN}; display: flex; align-items: center; justify-content: center">{ic(k, 22, 2.2)}</span><b style="font-size: {15 if m else 17}px; letter-spacing: -.3px">{t}</b><span style="font-size: 14px; line-height: 1.5; color: #5B6862">{d}</span></div>')
    return f'<div style="display: grid; grid-template-columns: repeat({2 if m else 4}, minmax(0, 1fr)); gap: {10 if m else 16}px">' + ''.join(tile(*x) for x in KINDS) + '</div>'
HOW = [('Answer a few questions', 'Tap yes or no. Takes about a minute.', scr_question), ('Approve and we fight it', 'We cancel, write to the company and follow up.', scr_fight), ('Get it back on your card', "We'll tell you the moment a refund is sent.", scr_paid)]
def how_phones(m, dark=True):
    num = lambda i: f'<span style="width: 32px; height: 32px; flex: none; border-radius: 50%; background: {DARK}; color: #FFFFFF; font-weight: 800; font-size: 15px; display: flex; align-items: center; justify-content: center">{i + 1}</span>'
    cols = ''.join(f'<div style="flex: 1 1 0; display: flex; flex-direction: column; align-items: center; gap: 16px">'
                   f'<span style="display: inline-flex; align-items: center; gap: 10px; padding: 8px 18px 8px 8px; border-radius: 99px; background: #FFFFFF; color: #0A0F0D; box-shadow: 0 10px 24px rgba(0,0,0,.18)">{num(i)}<b style="font-size: 16px">{t}</b></span>'
                   + ('' if m else f'<p style="margin: -6px 0 0; font-size: 15px; color: {"#C9D6CF" if dark else "#5B6862"}; text-align: center">{d}</p>') + f'{ph(fn(), 250 if m else 270)}</div>' for i, (t, d, fn) in enumerate(HOW))
    inner = H2('How Refund Club works', m, '#FFFFFF' if dark else DARK, True) + f'<div style="display: flex; {"flex-direction: column; gap: 36px" if m else "gap: 32px"}">{cols}</div>'
    return f'<section style="{MESH if dark else "background: #F3F6F4"}; padding: {48 if m else 96}px {16 if m else 40}px"><div style="max-width: 1240px; margin: 0 auto; display: flex; flex-direction: column; gap: {28 if m else 48}px">{inner}</div></section>'
def trust(m):
    t = lambda k, h, d, bg, fg, sub: (f'<div style="flex: 1 1 0; min-width: 0; padding: 26px; border-radius: 26px; background: {bg}; color: {fg}; display: flex; flex-direction: column; gap: 12px; min-height: {0 if m else 240}px; box-sizing: border-box">'
                                      f'<span style="width: 48px; height: 48px; border-radius: 15px; background: rgba(255,255,255,.55); display: flex; align-items: center; justify-content: center">{ic(k, 24, 2.2)}</span><b style="font-size: {22 if m else 24}px; letter-spacing: -.6px; line-height: 1.15; margin-top: auto">{h}</b><span style="font-size: 15px; line-height: 1.5; color: {sub}">{d}</span></div>')
    cards = (t('check', 'You approve every request', 'Nothing is sent to a company until you say yes.', MINT, DARK, '#1F4A3B')
             + t('lock', 'Read-only access', 'We can see charges. We can never move your money.', DARK, '#FFFFFF', '#C9D6CF')
             + t('ban', 'Cancel anytime', 'One tap in Settings. No calls, no fees.', '#E9F6EF', DARK, '#43504A'))
    return wrap(H2('Why people trust Refund Club', m) + f'<div style="display: flex; {"flex-direction: column" if m else ""}; gap: 14px">{cards}</div>', m, '#F3F6F4')
def member(m):
    perks = [('receipt', 'Claim a refund', 'We fight every charge you approve.'), ('repeat', 'Subscription Manager', 'Cancel what you do not use, with one tap.'), ('file', 'Claim money', 'We file every class action settlement you match.'), ('bell', 'Alerts', 'Trials about to renew, new refunds, new settlements.')]
    p = ''.join(f'<div style="display: flex; gap: 12px; align-items: flex-start"><span style="color: {MINT}; display: flex; margin-top: 2px">{ic("check", 18, 2.6)}</span><span style="display: flex; flex-direction: column; gap: 2px"><b style="font-size: 16px">{a}</b><span style="font-size: 14px; color: #C9D6CF">{b}</span></span></div>' for k, a, b in perks)
    card = (f'<div style="flex: 0 1 420px; background: #FFFFFF; color: #0A0F0D; border-radius: 26px; padding: 28px; box-sizing: border-box; display: flex; flex-direction: column; gap: 14px">'
            f'<span style="font-size: 12px; font-weight: 800; letter-spacing: 1.4px; color: {GREEN}">FREE REFUND CHECK</span><b style="font-size: 27px; line-height: 1.12; letter-spacing: -.8px">See what you could get back, right now.</b>'
            + ''.join(f'<span style="display: flex; gap: 10px; align-items: center; font-size: 15px; font-weight: 600; color: #43504A"><span style="width: 26px; height: 26px; border-radius: 50%; background: #E9F6EF; color: {GREEN}; display: flex; align-items: center; justify-content: center">{ic("check", 14, 2.6)}</span>{x}</span>' for x in ('Answer a few yes or no questions', 'See every charge you can get back', 'No card needed to check')) +
            f'<span style="min-height: 56px; border-radius: 99px; background: {MINT}; color: {DARK}; font-size: 17px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px">Find my refunds{ic("arrow", 18, 2.4)}</span>'
            '<span style="font-size: 13px; color: #6E7A73; text-align: center">Takes about a minute. One Claimclub membership covers refunds and claims.</span></div>')
    box = (f'<div style="border-radius: 32px; padding: {26 if m else 56}px; box-sizing: border-box; background: {DARK}; color: #FFFFFF; display: flex; flex-wrap: wrap; gap: {24 if m else 48}px; align-items: center; justify-content: space-between">'
           f'<div style="flex: 1 1 380px; display: flex; flex-direction: column; gap: 20px"><span style="font-size: 13px; font-weight: 800; letter-spacing: 1.6px; color: #CFE5DA">MEMBERSHIP</span>'
           f'<h2 style="margin: 0; font-size: {30 if m else 46}px; line-height: 1.05; letter-spacing: -1.4px">One membership. <span style="font-family: \'Instrument Serif\', serif; font-style: italic; font-weight: 400; color: {MINT}">Every dollar you are owed.</span></h2>{p}</div>{card}</div>')
    return f'<section style="padding: 0 {16 if m else 40}px {48 if m else 100}px; background: #F3F6F4"><div style="max-width: 1360px; margin: 0 auto">{box}</div></section>'
def footer(m):
    return (f'<footer style="background: #FFFFFF; border-top: 1px solid #E3EAE6; padding: 28px {16 if m else 40}px; font-size: 13px; color: #5B6862; line-height: 1.7"><div style="max-width: 1360px; margin: 0 auto">'
            'Refund Club is part of Claimclub. We are not a bank or a law firm. Companies decide every refund; amounts shown are examples. Questions? support@mail.claimclub.io</div></footer>')
def buttons(m, a='Find my refunds', b='See what we can get back', center=False):
    return (f'<div style="display: flex; {"flex-direction: column; width: 100%" if m else ""}; gap: 12px; {"justify-content: center" if center else ""}"><span style="min-height: 58px; padding: 0 30px; border-radius: 99px; background: #FFFFFF; color: {DARK}; font-size: 17px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px">{a}{ic("arrow", 18, 2.4)}</span>'
            f'<span style="min-height: 58px; padding: 0 24px; border-radius: 99px; box-shadow: inset 0 0 0 1.5px rgba(255,255,255,.4); color: #FFFFFF; font-size: 16px; font-weight: 700; display: flex; align-items: center; justify-content: center">{b}</span></div>')
H1 = lambda a, b, m, center=False: (f'<h1 style="margin: 0; font-size: {38 if m else 60}px; line-height: 1.02; font-weight: 800; letter-spacing: -0.045em; color: #FFFFFF; {"text-align: center" if center or m else ""}">{a}'
                                     f'<span style="display: block; margin-top: 0.22em; font-family: \'Instrument Serif\', serif; font-style: italic; font-weight: 400; letter-spacing: -0.02em; color: {MINT}">{b}</span></h1>')
proof = lambda m, center=False: (f'<div style="display: flex; flex-wrap: wrap; gap: 8px 20px; font-size: 14px; font-weight: 700; color: #DCD3FA; color: #CFE5DA; {"justify-content: center" if center or m else ""}">'
                                 + ''.join(f'<span style="display: flex; align-items: center; gap: 6px"><span style="color: {MINT}; display: flex">{ic("check", 15, 3)}</span>{t}</span>' for t in ('Free to check', 'You approve every request', 'Part of Claimclub membership')) + '</div>')

# ---------- iteration 1: found refunds phone (mirrors the claim homepage hero) ----------
def v1(m):
    phone = f'<div style="position: relative; display: flex; justify-content: center; {"zoom: .78; margin-top: 8px" if m else ""}">{ph(scr_found(5), 300)}<div style="position: absolute; left: {-40 if m else -120}px; top: 54%">{note_card("Refund sent", "We got back $47.97 from Netflix.", 320)}</div></div>'
    hero = (f'<section style="{MESH}; overflow: hidden">{navbar("refund", m)}<div style="max-width: 1440px; margin: 0 auto; padding: {28 if m else 48}px {16 if m else 40}px 0; display: flex; {"flex-direction: column; gap: 22px; align-items: center" if m else "justify-content: space-between; gap: 40px"}">'
            f'<div style="display: flex; flex-direction: column; gap: {16 if m else 26}px; {"align-items: center" if m else "max-width: 640px; padding-bottom: 80px"}">{H1("Companies charge you for things you never wanted.", "We get your money back.", m)}'
            + ('' if m else '<p style="margin: 0; font-size: 18px; line-height: 1.6; color: #CFE5DA; max-width: 540px">Refund Club finds charges you can get back, like subscriptions you canceled, double charges and fees. Approve one tap, and we fight it for you.</p>')
            + f'{buttons(m)}{proof(m)}</div><div style="align-self: flex-end; margin-bottom: -150px">{phone}</div></div></section>')
    kinds = wrap(H2('What we can get back', m) + kinds_grid(m), m, '#F3F6F4', (48, 96))
    return f'<div style="font-family: Manrope, sans-serif; color: #0A0F0D">{hero}{kinds}{how_phones(m)}{trust(m)}{member(m)}{footer(m)}</div>'

# ---------- iteration 2: centered headline over a big refund receipt ----------
def receipt(m):
    items = [(nm, amt) for k, src, nm, why, amt in FOUND]
    return (f'<div style="width: {320 if m else 460}px; margin: 0 auto; position: relative; padding: 24px 24px 20px; border-radius: 10px 10px 0 0; background: #FFFFFF; box-shadow: 0 30px 70px rgba(0,0,0,.35); transform: rotate(-1.5deg); display: flex; flex-direction: column; gap: 10px; font-family: ui-monospace, Menlo, monospace; color: #0A0F0D">'
            f'<div style="display: flex; justify-content: space-between; align-items: center"><span style="display: flex; align-items: center; gap: 6px; font-family: Manrope, sans-serif; font-weight: 800; font-size: 14px; letter-spacing: .5px">{LOGO.format(s=20, c="#0A0F0D")}REFUND CLUB</span><span style="font-size: 11px; color: #8A968F">YOUR REFUNDS</span></div>'
            '<div style="display: flex; flex-direction: column; gap: 6px; font-size: 13.5px; padding: 10px 0; border-top: 1px dashed #C9D3CD; border-bottom: 1px dashed #C9D3CD">' + ''.join(f'<span style="display: flex; justify-content: space-between"><span>{a}</span><span>{b}</span></span>' for a, b in items) + '</div>'
            f'<div style="display: flex; justify-content: space-between; align-items: baseline"><span style="font-size: 12px; font-weight: 700">TOTAL BACK</span><b style="font-family: Manrope, sans-serif; font-size: {34 if m else 44}px; letter-spacing: -1.5px; color: {GREEN}">$158.73</b></div>'
            '<span style="position: absolute; left: 0; right: 0; bottom: -10px; height: 10px; background: linear-gradient(-45deg, transparent 6px, #FFFFFF 0) 0 0/12px 10px, linear-gradient(45deg, transparent 6px, #FFFFFF 0) 0 0/12px 10px"></span></div>')
STORY = [('repeat', 'Charged after you canceled', 'Often $10 to $50 a month'), ('hourglass', 'Free trial turned paid', 'Often $8 to $20'), ('copy', 'Charged twice', 'The full second charge'),
         ('ban', 'A gym you cannot cancel', 'We cancel it for you'), ('truck', 'Order late or missing', 'Often the delivery fee or more'), ('landmark', 'Overdraft and bank fees', 'Often $25 to $35 each')]
def v2(m):
    hero = (f'<section style="{MESH}; overflow: hidden">{navbar("refund", m)}<div style="max-width: 1100px; margin: 0 auto; padding: {28 if m else 56}px {16 if m else 40}px {40 if m else 90}px; display: flex; flex-direction: column; gap: {20 if m else 28}px; align-items: center; text-align: center">'
            f'{H1("Money you lost to subscriptions, fees and double charges.", "Get it back.", m, True)}'
            + ('' if m else '<p style="margin: 0; font-size: 18px; line-height: 1.6; color: #CFE5DA; max-width: 620px">Answer a few questions and see your refund receipt. Approve it and we fight every charge for you.</p>')
            + f'{buttons(m, "Find my refunds", "How it works", True)}<div style="margin-top: {10 if m else 24}px">{receipt(m)}</div></div></section>')
    rows = ''.join(f'<div style="display: flex; align-items: center; gap: 14px; padding: {14 if m else 18}px 0; border-top: 1px solid #E3EAE6"><span style="width: 44px; height: 44px; flex: none; border-radius: 14px; background: #E9F6EF; color: {GREEN}; display: flex; align-items: center; justify-content: center">{ic(k, 22, 2.2)}</span>'
                   f'<b style="flex: 1; font-size: {16 if m else 20}px; letter-spacing: -.3px">{t}</b><span style="font-size: {13 if m else 15}px; font-weight: 700; color: {GREEN}; text-align: right">{d}</span></div>' for k, t, d in STORY)
    lst = wrap(H2('Charges we fight every day', m) + f'<div>{rows}</div>', m, '#FFFFFF')
    steps = ''.join(f'<div style="flex: 1 1 0; display: flex; flex-direction: column; gap: 10px; padding: 24px; border-radius: 24px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6">'
                    f'<span style="font-size: 54px; font-weight: 800; letter-spacing: -2px; color: {GREEN}; line-height: 1">0{i + 1}</span><b style="font-size: 20px; letter-spacing: -.4px">{t}</b><span style="font-size: 15px; color: #5B6862; line-height: 1.5">{d}</span></div>' for i, (t, d, fn) in enumerate(HOW))
    how = wrap(H2('Three steps. We do the rest.', m) + f'<div style="display: flex; {"flex-direction: column" if m else ""}; gap: 14px">{steps}</div>', m, '#F3F6F4')
    return f'<div style="font-family: Manrope, sans-serif; color: #0A0F0D">{hero}{lst}{how}{trust(m)}{member(m)}{footer(m)}</div>'

# ---------- iteration 3: Subscription Manager first ----------
def v3(m):
    phone = f'<div style="position: relative; display: flex; justify-content: center; {"zoom: .78; margin-top: 8px" if m else ""}">{ph(scr_subs(), 300)}<div style="position: absolute; left: {-40 if m else -140}px; top: 60%">{note_card("Canceled City Fitness", "And we asked for the last $39.99 back.", 320)}</div></div>'
    hero = (f'<section style="{MESH}; overflow: hidden">{navbar("refund", m)}<div style="max-width: 1440px; margin: 0 auto; padding: {28 if m else 48}px {16 if m else 40}px 0; display: flex; {"flex-direction: column; gap: 22px; align-items: center" if m else "justify-content: space-between; gap: 40px"}">'
            f'<div style="display: flex; flex-direction: column; gap: {16 if m else 26}px; {"align-items: center" if m else "max-width: 640px; padding-bottom: 80px"}">{H1("Stop paying for things you do not use.", "And get the last charge back.", m)}'
            + ('' if m else '<p style="margin: 0; font-size: 18px; line-height: 1.6; color: #CFE5DA; max-width: 540px">Subscription Manager shows every subscription you pay for. Tap cancel, and Refund Club asks for your money back when you did not use it.</p>')
            + f'{buttons(m, "Find my refunds", "See Subscription Manager")}{proof(m)}</div><div style="align-self: flex-end; margin-bottom: -150px">{phone}</div></div></section>')
    big = [('repeat', 'Unused subscriptions', 'We spot the ones you have not opened in months, cancel them and ask for the last charge back.'),
           ('bell', 'Trials about to renew', 'We remind you 3 days before a free trial turns paid, so you never pay for one again.'),
           ('receipt', 'Charges you never wanted', 'Double charges, fees and orders that never came. Approve and we fight it.')]
    tiles = ''.join(f'<div style="flex: 1 1 0; display: flex; flex-direction: column; gap: 12px; padding: 26px; border-radius: 26px; background: {bg}; color: {fg}"><span style="width: 48px; height: 48px; border-radius: 15px; background: rgba(255,255,255,.55); display: flex; align-items: center; justify-content: center">{ic(k, 24, 2.2)}</span>'
                    f'<b style="font-size: 24px; letter-spacing: -.6px">{t}</b><span style="font-size: 15px; line-height: 1.5; color: {sub}">{d}</span></div>' for (k, t, d), (bg, fg, sub) in zip(big, [(MINT, DARK, '#1F4A3B'), (DARK, '#FFFFFF', '#C9D6CF'), ('#E9F6EF', DARK, '#43504A')]))
    watch = wrap(H2('What we watch for you', m) + f'<div style="display: flex; {"flex-direction: column" if m else ""}; gap: 14px">{tiles}</div>', m, '#F3F6F4', (48, 96))
    kinds = wrap(H2('Everything we can get back', m) + kinds_grid(m), m, '#FFFFFF')
    return f'<div style="font-family: Manrope, sans-serif; color: #0A0F0D">{hero}{watch}{how_phones(m)}{kinds}{member(m)}{footer(m)}</div>'

VARS = [('RefundL1', 'Refund Club homepage · 1 · Found refunds phone (like the Claim money hero)', v1), ('RefundL2', 'Refund Club homepage · 2 · Centered headline over a refund receipt', v2),
        ('RefundL3', 'Refund Club homepage · 3 · Subscription Manager first', v3)]
if __name__ == '__main__':
    for name, title, fn in VARS:
        page = (f'<div style="width: 1926px; height: 980px; box-sizing: border-box; padding: 24px; background: #E7ECE9; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 14px">'
                f'<div style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #43504A">{title.upper()}</div><div style="display: flex; gap: 48px; align-items: flex-start">'
                f'<div class="scroll" style="width: 1440px; height: 900px; flex: none; overflow-y: auto; border-radius: 18px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{fn(False)}</div>'
                f'<div class="scroll" style="width: 390px; height: 844px; flex: none; overflow-y: auto; border-radius: 28px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{fn(True)}</div></div></div>\n</x-dc>\n')
        open(os.path.join(OUT, name + '.dc.html'), 'w').write(HEAD % title + page + JS)
    print('built', [v[0] for v in VARS])
