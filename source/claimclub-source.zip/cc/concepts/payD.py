# Three drafts of an in-page payment step for the claim flow (Nov 15 2026): Stripe's Apple Pay and Google Pay
# buttons plus a card form, without leaving claimclub.io. Writes PayD1..3.dc.html (desktop and phone side by side).
import os
from how4 import HEAD, JS, OUT
APPLE = open('/tmp/apple_path.txt').read().strip()
G = [('#EA4335', 'M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z'),
     ('#4285F4', 'M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z'),
     ('#FBBC05', 'M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z'),
     ('#34A853', 'M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z')]
LU = {'lock': 'M5 11h14a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2z M7 11V7a5 5 0 0 1 10 0v4', 'check': 'M20 6 9 17l-5-5',
      'back': 'm15 18-6-6 6-6', 'x': 'M18 6 6 18 M6 6l12 12', 'card': 'M4 5h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z M2 10h20',
      'down': 'm6 9 6 6 6-6', 'right': 'm9 18 6-6-6-6', 'shield': 'M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z M9 12l2 2 4-4',
      'mail': 'M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z m18 2-10 7L2 6'}
def ic(k, sz=16, c='currentColor', sw=2.2): return f'<svg width="{sz}" height="{sz}" viewBox="0 0 24 24" fill="none" stroke="{c}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex: none"><path d="{LU[k]}"></path></svg>'
CLAIMS = [('Apple', '$95'), ('Visa & Mastercard', 'Up to $1,000'), ('Google Play', '$100'), ('CVS', '$5+')]
INK, MUTE, LINE, MINT, GREEN = '#0A0F0D', '#5B6862', '#DDE5E0', '#3DDC97', '#12805C'

def apple_btn(h=50, fs=20, grow=True):
    return (f'<div style="height: {h}px; border-radius: 12px; background: #000000; color: #FFFFFF; display: flex; align-items: center; justify-content: center; gap: 6px; font-size: {fs}px; font-weight: 600; letter-spacing: -0.3px; flex: ' + ('1' if grow else 'none') + '">'
            f'<svg width="{fs}" height="{fs}" viewBox="0 0 24 24" aria-hidden="true" style="margin-top: -3px"><path fill="#FFFFFF" d="{APPLE}"></path></svg>Pay</div>')
def gpay_btn(h=50, fs=20, grow=True):
    g = ''.join(f'<path fill="{c}" d="{p}"></path>' for c, p in G)
    return (f'<div style="height: {h}px; border-radius: 12px; background: #000000; color: #FFFFFF; display: flex; align-items: center; justify-content: center; gap: 7px; font-size: {fs}px; font-weight: 500; flex: ' + ('1' if grow else 'none') + '">'
            f'<svg width="{fs - 2}" height="{fs - 2}" viewBox="0 0 48 48" aria-hidden="true">{g}</svg>Pay</div>')
def wallets(row=True, h=50, fs=20):
    return f'<div style="display: flex; flex-direction: {"row" if row else "column"}; gap: 10px">{apple_btn(h, fs, row)}{gpay_btn(h, fs, row)}</div>'
def orline(t='or pay with card'):
    return f'<div style="display: flex; align-items: center; gap: 12px; color: #8A968F; font-size: 12.5px; font-weight: 700"><span style="flex: 1; height: 1px; background: {LINE}"></span>{t}<span style="flex: 1; height: 1px; background: {LINE}"></span></div>'
def field(label, ph, extra=''):
    return (f'<div style="display: flex; flex-direction: column; gap: 6px; flex: 1; min-width: 0"><span style="font-size: 13px; font-weight: 700; color: #43504A">{label}</span>'
            f'<div style="height: 48px; border-radius: 12px; border: 1.5px solid {LINE}; background: #FFFFFF; display: flex; align-items: center; padding: 0 14px; gap: 8px; font-size: 15px; color: #9AA59F; font-weight: 600; box-sizing: border-box">{ph}{extra}</div></div>')
def brands():
    b = lambda t, bg, c: f'<span style="font-size: 9px; font-weight: 900; letter-spacing: .3px; padding: 3px 5px; border-radius: 4px; background: {bg}; color: {c}">{t}</span>'
    return '<span style="margin-left: auto; display: flex; gap: 4px">' + b('VISA', '#1A1F71', '#FFFFFF') + b('MC', '#EB001B', '#FFFFFF') + b('AMEX', '#2E77BC', '#FFFFFF') + '</span>'
def cardform(compact=False):
    return ('<div style="display: flex; flex-direction: column; gap: 12px">' + field('Card number', '1234 1234 1234 1234', brands())
            + '<div style="display: flex; gap: 10px">' + field('Expiry', 'MM / YY') + field('CVC', '123') + field('ZIP', '98101') + '</div></div>')
def paybtn(t='Pay $7.99 and start filing', bg=MINT, fg=INK, h=54):
    return f'<div style="height: {h}px; border-radius: 99px; background: {bg}; color: {fg}; display: flex; align-items: center; justify-content: center; gap: 8px; font-size: 16px; font-weight: 800">{ic("lock", 16, fg, 2.4)}{t}</div>'
def fine(t='Renews at $29.99 a month on Dec 15, 2026. Cancel anytime in your dashboard.'):
    return f'<span style="font-size: 12.5px; color: {MUTE}; line-height: 1.5; text-align: center; font-weight: 600">{t}</span>'
def secure():
    return f'<div style="display: flex; align-items: center; justify-content: center; gap: 6px; font-size: 12px; color: #8A968F; font-weight: 700">{ic("shield", 14, "#8A968F")}Payments are encrypted and processed by Stripe. We never see your card number.</div>'
def seg(sel=0, m=False):
    P = [('1 month', '$29.99/mo'), ('3 months', '$24.99/mo'), ('6 months', '$19.99/mo')]
    out = ''
    for i, (a, b) in enumerate(P):
        on = i == sel
        out += (f'<div style="flex: 1; padding: {8 if m else 10}px 6px; border-radius: 12px; text-align: center; display: flex; flex-direction: column; gap: 1px; '
                + (f'background: #FFFFFF; box-shadow: 0 1px 3px rgba(10,15,13,.12)' if on else 'background: transparent') + f'"><span style="font-size: {13 if m else 14}px; font-weight: 800">{a}</span><span style="font-size: 11.5px; color: {MUTE}; font-weight: 700">{b}</span></div>')
    return f'<div style="display: flex; gap: 4px; padding: 4px; border-radius: 16px; background: #E6ECE8">{out}</div>'
def summary(big=False):
    return (f'<div style="display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 14px 16px; border-radius: 16px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}">'
            f'<span style="display: flex; flex-direction: column; gap: 2px"><b style="font-size: 15px">Claimclub membership · 1 month</b><span style="font-size: 12.5px; color: {MUTE}; font-weight: 600">75% off your first month, then $29.99 a month</span></span>'
            f'<span style="display: flex; flex-direction: column; align-items: flex-end"><b style="font-size: {26 if big else 22}px; letter-spacing: -0.6px">$7.99</b><span style="font-size: 12px; color: #8A968F; font-weight: 700; text-decoration: line-through">$29.99</span></span></div>')
def email_row():
    return f'<div style="display: flex; align-items: center; gap: 8px; font-size: 13px; color: {MUTE}; font-weight: 600">{ic("mail", 14, MUTE)}Receipt to <b style="color: {INK}">ana@gmail.com</b></div>'

LOGO = '<span style="font-size: 20px; font-weight: 800; letter-spacing: -0.5px">claim<span style="font-weight: 500">club</span><span style="color: #12805C">.io</span></span>'
def d_frame(right, left_title='You matched 4 claims', left_sub='Worth up to $1,200 together. File them all with membership.'):
    rows = ''.join(f'<div style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; border-radius: 14px; background: rgba(255,255,255,.08)"><span style="display: flex; align-items: center; gap: 10px; font-weight: 700">{ic("check", 16, MINT, 2.6)}{c}</span><b style="color: {MINT}">{v}</b></div>' for c, v in CLAIMS)
    left = (f'<div style="flex: 0 0 520px; background: radial-gradient(140% 100% at 100% 0%, #1F7A57 0%, rgba(31,122,87,0) 55%), #0B2A20; color: #FFFFFF; padding: 40px; display: flex; flex-direction: column; gap: 18px; box-sizing: border-box">'
            f'<span style="font-size: 20px; font-weight: 800; letter-spacing: -0.5px">claim<span style="font-weight: 500">club</span><span style="color: {MINT}">.io</span></span>'
            f'<div style="margin-top: 60px; display: flex; flex-direction: column; gap: 8px"><span style="font-size: 12px; font-weight: 800; letter-spacing: 1.2px; color: {MINT}">YOUR MATCHES</span><b style="font-size: 34px; letter-spacing: -1px; line-height: 1.1">{left_title}</b><span style="font-size: 15px; color: rgba(255,255,255,.75); line-height: 1.5">{left_sub}</span></div>'
            f'<div style="display: flex; flex-direction: column; gap: 8px">{rows}</div></div>')
    top = (f'<div style="display: flex; align-items: center; gap: 14px; padding: 22px 48px 0"><span style="width: 36px; height: 36px; border-radius: 99px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; align-items: center; justify-content: center">{ic("back", 18, INK)}</span>'
           f'<div style="flex: 1; display: flex; gap: 6px">' + ''.join(f'<span style="flex: 1; height: 5px; border-radius: 99px; background: {GREEN if i < 4 else LINE}"></span>' for i in range(5)) + '</div></div>')
    return (f'<div style="width: 1440px; height: 900px; flex: none; border-radius: 22px; overflow: hidden; background: #F3F6F4; display: flex; box-shadow: 0 30px 80px rgba(10,15,13,.14)">{left}'
            f'<div style="flex: 1; display: flex; flex-direction: column; min-width: 0">{top}<div style="flex: 1; display: flex; justify-content: center; overflow: hidden; padding: 0 48px"><div style="width: 520px; display: flex; flex-direction: column; gap: 16px; padding: 26px 0">{right}</div></div></div></div>')
def m_frame(inner, foot='', top=True, overlay=''):
    t = (f'<div style="display: flex; align-items: center; gap: 12px; padding: 54px 18px 8px"><span style="width: 34px; height: 34px; border-radius: 99px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; align-items: center; justify-content: center">{ic("back", 17, INK)}</span>'
         + '<div style="flex: 1; display: flex; gap: 5px">' + ''.join(f'<span style="flex: 1; height: 5px; border-radius: 99px; background: {GREEN if i < 4 else LINE}"></span>' for i in range(5)) + '</div></div>') if top else ''
    f = f'<div style="padding: 12px 18px 30px; background: #F3F6F4; box-shadow: 0 -10px 24px rgba(10,15,13,.06); display: flex; flex-direction: column; gap: 8px">{foot}</div>' if foot else ''
    return (f'<div style="width: 390px; height: 844px; flex: none; border-radius: 44px; overflow: hidden; background: #F3F6F4; display: flex; flex-direction: column; position: relative; box-shadow: 0 0 0 10px #1A1D1C, 0 30px 80px rgba(10,15,13,.2)">'
            f'<div style="position: absolute; top: 12px; left: 50%; transform: translateX(-50%); width: 120px; height: 34px; border-radius: 99px; background: #000000; z-index: 5"></div>'
            f'{t}<div style="flex: 1; overflow: hidden; padding: 6px 18px 0; display: flex; flex-direction: column; gap: 14px">{inner}</div>{f}{overlay}</div>')
def h1(t, sz=28): return f'<b style="font-size: {sz}px; letter-spacing: -0.8px; line-height: 1.15">{t}</b>'

# ---------- Design 1: all on one page ----------
def d1():
    right = (h1('Start filing for $7.99') + f'<span style="font-size: 15px; color: {MUTE}; margin-top: -8px; font-weight: 600">Pick a plan and pay right here. No new page.</span>' + seg(0)
             + summary() + wallets(True) + orline() + cardform() + email_row() + paybtn() + fine())
    mob = (h1('Start filing for $7.99', 24) + seg(0, True) + summary() + wallets(True, 48, 18) + orline() + cardform())
    return d_frame(right), m_frame(mob, foot=paybtn() + fine('Renews at $29.99 a month. Cancel anytime.'))
# ---------- Design 2: slide-up sheet (like Lunis) ----------
def d2():
    right = (f'<div style="display: flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 800; color: {MUTE}">{ic("back", 16, MUTE)}Back to plans</div>'
             + h1('Checkout') + summary(True) + f'<span style="font-size: 12px; font-weight: 800; letter-spacing: 1px; color: #8A968F">EXPRESS CHECKOUT</span>' + wallets(False, 52, 20) + orline() + cardform() + email_row() + paybtn('Pay $7.99') + secure())
    behind = (h1('Choose your plan', 24) + seg(0, True) + summary() + '<div style="height: 220px; border-radius: 18px; background: #FFFFFF"></div>')
    sheet = (f'<div style="position: absolute; inset: 0; background: rgba(10,15,13,.45); z-index: 3"></div>'
             f'<div style="position: absolute; left: 0; right: 0; bottom: 0; height: 600px; z-index: 4; background: #FFFFFF; border-radius: 28px 28px 0 0; padding: 10px 18px 30px; box-sizing: border-box; display: flex; flex-direction: column; gap: 14px">'
             f'<span style="width: 40px; height: 5px; border-radius: 99px; background: #D5DDD8; align-self: center"></span>'
             f'<div style="display: flex; align-items: center; justify-content: space-between"><b style="font-size: 20px">Pay $7.99</b><span style="width: 32px; height: 32px; border-radius: 99px; background: #EEF2F0; display: flex; align-items: center; justify-content: center">{ic("x", 16, INK)}</span></div>'
             f'<span style="font-size: 13px; color: {MUTE}; font-weight: 600; margin-top: -8px">Claimclub membership · then $29.99 a month, cancel anytime</span>'
             + wallets(False, 50, 19) + orline() + cardform() + paybtn('Pay $7.99') + secure().replace('font-size: 12px', 'font-size: 11px') + '</div>')
    return d_frame(right), m_frame(behind, overlay=sheet)
# ---------- Design 3: receipt and wallet first ----------
def receipt(m=False):
    rows = ''.join(f'<div style="display: flex; justify-content: space-between; font-size: 14px; padding: 6px 0"><span style="display: flex; align-items: center; gap: 8px; font-weight: 700">{ic("check", 15, GREEN, 2.6)}{c} claim</span><span style="color: {MUTE}; font-weight: 700">{v}</span></div>' for c, v in CLAIMS)
    return (f'<div style="border-radius: 20px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}; padding: 18px; display: flex; flex-direction: column; gap: 4px">'
            f'<span style="font-size: 12px; font-weight: 800; letter-spacing: 1px; color: #8A968F">YOUR ORDER</span>{rows}'
            f'<div style="height: 1px; background: #EEF2F0; margin: 8px 0"></div>'
            f'<div style="display: flex; justify-content: space-between; font-size: 14px; font-weight: 700"><span>Membership, first month</span><span><span style="color: #8A968F; text-decoration: line-through; margin-right: 6px">$29.99</span>$7.99</span></div>'
            f'<div style="display: flex; justify-content: space-between; align-items: baseline; margin-top: 8px"><b style="font-size: 16px">Today</b><b style="font-size: 30px; letter-spacing: -1px">$7.99</b></div>'
            f'<span style="font-size: 12.5px; color: {MUTE}; font-weight: 600">Then $29.99 a month from Dec 15. Cancel anytime.</span></div>')
def d3():
    cardrow = (f'<div style="display: flex; align-items: center; gap: 12px; padding: 0 16px; height: 56px; border-radius: 14px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}; font-size: 15px; font-weight: 800">'
               f'{ic("card", 20, INK)}Pay with card{brands()}{ic("down", 18, MUTE)}</div>')
    right = (h1('One tap and we start filing') + receipt() + wallets(False, 60, 23) + cardrow + secure())
    chip = (f'<div style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; border-radius: 16px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}">'
            f'<span style="display: flex; flex-direction: column"><b style="font-size: 15px">4 claims · membership</b><span style="font-size: 12.5px; color: {MUTE}; font-weight: 600">Then $29.99 a month. Cancel anytime.</span></span>'
            f'<span style="display: flex; align-items: center; gap: 6px"><b style="font-size: 22px; letter-spacing: -0.6px">$7.99</b>{ic("down", 18, MUTE)}</span></div>')
    mob = (h1('One tap and we start filing', 26) + receipt(True))
    foot = wallets(False, 56, 22) + cardrow.replace('height: 56px', 'height: 52px') + secure().replace('font-size: 12px', 'font-size: 11px')
    return d_frame(right), m_frame(mob, foot=foot)

INFO = {
 1: ('PAYMENT DESIGN 1 · ALL ON ONE PAGE', 'The plan step becomes the checkout. Plan switch, price, Apple Pay and Google Pay, then the card form and one Pay button, all on one screen. Fewest taps. The page is longer, so on phones the Pay button sticks to the bottom.'),
 2: ('PAYMENT DESIGN 2 · SLIDE-UP SHEET (LIKE LUNIS)', 'The plan page stays as it is. "Start getting paid" slides a payment sheet up over it on phones, and turns the right column into Checkout on a computer, with a way back to plans. Same pattern as Lunis, so one shared approach for both sites.'),
 3: ('PAYMENT DESIGN 3 · RECEIPT AND WALLET FIRST', 'Shows exactly what they are buying (their claims, the membership, today\'s price) and makes Apple Pay and Google Pay the big buttons. The card form stays folded until tapped. Fastest for people on phones with a wallet set up.'),
}
NOTE = 'Stripe only shows the wallet buttons a device supports (Apple Pay in Safari on Apple devices, Google Pay in Chrome), and may also offer Link. The same design covers the $49.99 filing fee. Buttons and fields here are mockups of what Stripe draws.'
for n, fn in [(1, d1), (2, d2), (3, d3)]:
    dsk, mob = fn(); title, desc = INFO[n]
    page = ('<div data-board style="width: 1926px; height: 1080px; box-sizing: border-box; padding: 36px 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 26px">'
            f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #12805C">{title}</span>'
            f'<span style="font-size: 16px; color: #43504A; max-width: 1500px; line-height: 1.5; font-weight: 600">{desc}</span><span style="font-size: 13px; color: #8A968F; font-weight: 600">{NOTE}</span></div>'
            f'<div style="display: flex; gap: 46px; align-items: flex-start">{dsk}<div style="padding-top: 28px">{mob}</div></div></div>\n</x-dc>\n')
    open(os.path.join(OUT, f'PayD{n}.dc.html'), 'w').write(HEAD % f'Payment design {n}' + page + JS.replace('"width":1926,"height":980', '"width":1926,"height":1080'))
print('ok')

# ---------- Chosen direction (Nov 15): design 1 layout plus an earnings receipt; membership and filing fee versions ----------
def zig(bg='#FFFFFF'):
    return (f'<div aria-hidden="true" style="height: 12px; background: linear-gradient(135deg, {bg} 33.3%, transparent 33.3%) 0 0 / 16px 16px, linear-gradient(225deg, {bg} 33.3%, transparent 33.3%) 0 0 / 16px 16px"></div>')
def receipt_e(fee, fee_label, fee_sub, dark=False, m=False):
    lines = ''.join(f'<div style="display: flex; justify-content: space-between; gap: 10px; padding: {5 if m else 6}px 0; font-size: {13.5 if m else 14.5}px"><span style="display: flex; align-items: center; gap: 8px; font-weight: 700">{ic("check", 15, GREEN, 2.6)}{c}</span><span style="font-weight: 800; color: {GREEN}">{v}</span></div>' for c, v in CLAIMS)
    dash = '<div style="border-top: 2px dashed #DDE5E0; margin: 10px 0"></div>'
    bar = (f'<div style="display: flex; flex-direction: column; gap: 6px; margin-top: 4px">'
           f'<div style="display: flex; height: 12px; border-radius: 99px; overflow: hidden; background: #E9F6EF"><span style="width: {max(2, round(float(fee.strip("$")) / 1200 * 100, 1))}%; min-width: 6px; background: {INK}"></span><span style="flex: 1; background: linear-gradient(90deg, {MINT}, {GREEN})"></span></div>'
           f'<div style="display: flex; justify-content: space-between; font-size: 11.5px; font-weight: 800; color: {MUTE}"><span>{fee} fee</span><span style="color: {GREEN}">Up to $1,200 to you</span></div></div>')
    return (f'<div style="display: flex; flex-direction: column; filter: drop-shadow(0 18px 30px rgba(0,0,0,{.35 if dark else .1}))">'
            f'<div style="background: #FFFFFF; border-radius: 18px 18px 0 0; padding: {16 if m else 22}px {16 if m else 22}px 12px; display: flex; flex-direction: column; color: {INK}">'
            f'<div style="display: flex; justify-content: space-between; align-items: center"><span style="font-size: 11.5px; font-weight: 800; letter-spacing: 1.2px; color: #8A968F">YOUR CLAIMS RECEIPT</span><span style="font-size: 11.5px; font-weight: 700; color: #8A968F">Nov 15, 2026</span></div>'
            f'<div style="display: flex; flex-direction: column; margin: 8px 0 2px"><span style="font-size: 13px; font-weight: 700; color: {MUTE}">Expected earnings</span><b style="font-size: {38 if m else 46}px; letter-spacing: -1.6px; line-height: 1.05; color: {GREEN}">Up to $1,200</b><span style="font-size: 12.5px; color: {MUTE}; font-weight: 600">From 4 settlements you qualify for. Paid straight to you.</span></div>'
            + dash + lines + dash +
            f'<div style="display: flex; justify-content: space-between; align-items: baseline; gap: 10px"><span style="display: flex; flex-direction: column"><b style="font-size: 15px">{fee_label}</b><span style="font-size: 12px; color: {MUTE}; font-weight: 600">{fee_sub}</span></span><b style="font-size: {26 if m else 30}px; letter-spacing: -1px">{fee}</b></div>'
            f'<div style="display: flex; justify-content: space-between; font-size: 13.5px; font-weight: 800; margin-top: 8px"><span>Your share of every payout</span><span style="color: {GREEN}">100%</span></div>'
            + bar +
            f'<div style="margin-top: 12px; padding: 10px 12px; border-radius: 12px; background: #F3F6F4; font-size: 12px; color: #43504A; line-height: 1.45; font-weight: 600">This is a filing fee, not a cut. Each settlement pays you directly, and we never take a share of what you get.</div>'
            f'</div>{zig()}</div>')
def receipt_m(fee, fee_label, fee_sub):
    # Phone receipt: fewer lines, more room. Total, claims, today's fee, and that they keep everything.
    lines = ''.join(f'<div style="display: flex; justify-content: space-between; gap: 12px; padding: 9px 0; font-size: 15px"><span style="font-weight: 700">{c}</span><span style="font-weight: 800; color: {GREEN}">{v}</span></div>' for c, v in CLAIMS)
    dash = '<div style="border-top: 2px dashed #DDE5E0; margin: 12px 0"></div>'
    return (f'<div style="display: flex; flex-direction: column; filter: drop-shadow(0 12px 22px rgba(10,15,13,.08))">'
            f'<div style="background: #FFFFFF; border-radius: 20px 20px 0 0; padding: 22px 20px 16px; display: flex; flex-direction: column; color: {INK}">'
            f'<span style="font-size: 12px; font-weight: 800; letter-spacing: 1.2px; color: #8A968F">YOUR RECEIPT</span>'
            f'<span style="font-size: 14px; font-weight: 700; color: {MUTE}; margin-top: 12px">Expected earnings</span>'
            f'<b style="font-size: 40px; letter-spacing: -1.4px; line-height: 1.1; color: {GREEN}">Up to $1,200</b>'
            + dash + lines + dash +
            f'<div style="display: flex; justify-content: space-between; align-items: center; gap: 12px"><span style="display: flex; flex-direction: column; gap: 3px"><b style="font-size: 15px">{fee_label}</b><span style="font-size: 13px; color: {MUTE}; font-weight: 600">{fee_sub}</span></span><b style="font-size: 26px; letter-spacing: -0.8px">{fee}</b></div>'
            f'<div style="display: flex; align-items: center; gap: 10px; margin-top: 16px; padding: 12px 14px; border-radius: 14px; background: #E9F6EF; color: #17603F">{ic("check", 18, GREEN, 2.6)}<span style="display: flex; flex-direction: column; gap: 2px"><b style="font-size: 14px">You keep 100% of every payout</b><span style="font-size: 12.5px; font-weight: 600">This is a filing fee, not a cut.</span></span></div>'
            f'</div>{zig()}</div>')
def d_frame_r(right, rec):
    left = (f'<div style="flex: 0 0 520px; background: radial-gradient(140% 100% at 100% 0%, #1F7A57 0%, rgba(31,122,87,0) 55%), #0B2A20; color: #FFFFFF; padding: 36px 40px; display: flex; flex-direction: column; gap: 22px; box-sizing: border-box">'
            f'<span style="font-size: 20px; font-weight: 800; letter-spacing: -0.5px">claim<span style="font-weight: 500">club</span><span style="color: {MINT}">.io</span></span>{rec}</div>')
    top = (f'<div style="display: flex; align-items: center; gap: 14px; padding: 22px 48px 0"><span style="width: 36px; height: 36px; border-radius: 99px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; align-items: center; justify-content: center">{ic("back", 18, INK)}</span>'
           f'<div style="flex: 1; display: flex; gap: 6px">' + ''.join(f'<span style="flex: 1; height: 5px; border-radius: 99px; background: {GREEN if i < 4 else LINE}"></span>' for i in range(5)) + '</div></div>')
    return (f'<div style="width: 1440px; height: 900px; flex: none; border-radius: 22px; overflow: hidden; background: #F3F6F4; display: flex; box-shadow: 0 30px 80px rgba(10,15,13,.14)">{left}'
            f'<div style="flex: 1; display: flex; flex-direction: column; min-width: 0">{top}<div style="flex: 1; display: flex; justify-content: center; overflow: hidden; padding: 0 48px"><div style="width: 520px; display: flex; flex-direction: column; gap: 16px; padding: 30px 0">{right}</div></div></div></div>')
def e_member():
    rec = receipt_e('$7.99', 'Membership, first month', '75% off, then $29.99 a month. Cancel anytime.', dark=True)
    right = (h1('Start filing for $7.99') + f'<span style="font-size: 15px; color: {MUTE}; margin-top: -8px; font-weight: 600">Pick a plan and pay right here. We start filing today.</span>' + seg(0)
             + wallets(True) + orline() + cardform() + email_row() + paybtn() + fine())
    mob = (receipt_m('$7.99', 'Membership, first month', 'Then $29.99 a month') + h1('Pick your plan', 22) + seg(0, True) + wallets(True, 48, 18) + orline() + cardform())
    return d_frame_r(right, rec), m_frame(mob, foot=paybtn() + fine('Renews at $29.99 a month. Cancel anytime.'))
def e_fee():
    rec = receipt_e('$49.99', 'Filing fee, one time', 'Covers all 4 claims. No subscription.', dark=True)
    upsell = (f'<div style="display: flex; align-items: center; gap: 12px; padding: 12px 14px; border-radius: 16px; background: #E9F6EF">'
              f'<span style="flex: 1; display: flex; flex-direction: column"><b style="font-size: 14px">Or join for $7.99 and file free</b><span style="font-size: 12.5px; color: {MUTE}; font-weight: 600">Membership files these 4 plus every new claim you qualify for.</span></span>'
              f'<span style="font-size: 13.5px; font-weight: 800; color: {GREEN}; white-space: nowrap; display: flex; align-items: center; gap: 4px">Switch{ic("right", 15, GREEN, 2.6)}</span></div>')
    right = (h1('File all 4 claims for $49.99') + f'<span style="font-size: 15px; color: {MUTE}; margin-top: -8px; font-weight: 600">One payment, no subscription. We file every claim on this receipt.</span>'
             + wallets(True) + orline() + cardform() + email_row() + paybtn('Pay $49.99 and start filing') + upsell)
    mob = (receipt_m('$49.99', 'Filing fee, one time', 'Covers all 4 claims') + h1('Pay the filing fee', 22) + wallets(True, 48, 18) + orline() + cardform() + upsell)
    return d_frame_r(right, rec), m_frame(mob, foot=paybtn('Pay $49.99 and start filing') + fine('One-time payment. No subscription.'))
INFO_E = {
 1: ('CHOSEN DIRECTION · MEMBERSHIP', 'Design 1 layout (plan, wallets, card form and Pay on one page) with a receipt of what they are filing for: every claim with its expected payout, "Up to $1,200" in total, today\'s fee and "Your share of every payout: 100%". The bar shows how small the fee is next to the payout. On phones the receipt sits on top and the page scrolls to pay.'),
 2: ('CHOSEN DIRECTION · FILING FEE ONLY', 'Same page for people who only want these claims filed: a one-time $49.99 fee, no plan switch, the same earnings receipt, and a quiet "Or join for $7.99 and file free" option under the Pay button.'),
}
for n, fn in [(1, e_member), (2, e_fee)]:
    dsk, mob = fn(); title, desc = INFO_E[n]
    page = ('<div data-board style="width: 1926px; height: 1260px; box-sizing: border-box; padding: 36px 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 26px">'
            f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #12805C">{title}</span>'
            f'<span style="font-size: 16px; color: #43504A; max-width: 1500px; line-height: 1.5; font-weight: 600">{desc}</span><span style="font-size: 13px; color: #8A968F; font-weight: 600">{NOTE}</span></div>'
            f'<div style="display: flex; gap: 46px; align-items: flex-start">{dsk}<div style="padding-top: 28px">{mob.replace("height: 844px", "height: 1060px")}</div></div></div>\n</x-dc>\n')
    open(os.path.join(OUT, f'PayE{n}.dc.html'), 'w').write(HEAD % f'Payment, chosen direction {n}' + page + JS.replace('"width":1926,"height":980', '"width":1926,"height":1260'))
print('ok E')

# ---------- Sheet direction (Nov 15): Design 2 slide-up sheet, receipt stays on the page ----------
# Phones: step A is the receipt plus plan and one sticky button; step B is the sheet sliding up over it,
# with a short receipt strip on top so the numbers stay in view while paying.
# Desktop: the receipt stays in the left panel, the right column turns into Checkout.
def strip(fee):
    return (f'<div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 12px 14px; border-radius: 16px; background: #E9F6EF">'
            f'<span style="display: flex; flex-direction: column; gap: 1px"><span style="font-size: 12px; font-weight: 700; color: #17603F">Expected earnings</span><b style="font-size: 22px; letter-spacing: -0.6px; color: {GREEN}">Up to $1,200</b></span>'
            f'<span style="display: flex; flex-direction: column; align-items: flex-end; gap: 3px"><span style="display: flex; align-items: center; gap: 5px; font-size: 12.5px; font-weight: 800; color: #17603F">{ic("check", 14, GREEN, 2.8)}You keep 100%</span>'
            f'<span style="font-size: 12px; font-weight: 700; color: {MUTE}">4 claims · {fee} today</span></span></div>')
def sheet(fee, sub, h=640):
    return (f'<div style="position: absolute; inset: 0; background: rgba(10,15,13,.45); z-index: 3"></div>'
            f'<div style="position: absolute; left: 0; right: 0; bottom: 0; height: {h}px; z-index: 4; background: #FFFFFF; border-radius: 28px 28px 0 0; padding: 10px 18px 30px; box-sizing: border-box; display: flex; flex-direction: column; gap: 14px; box-shadow: 0 -20px 40px rgba(10,15,13,.18)">'
            f'<span style="width: 40px; height: 5px; border-radius: 99px; background: #D5DDD8; align-self: center"></span>'
            f'<div style="display: flex; align-items: center; justify-content: space-between"><span style="display: flex; flex-direction: column; gap: 2px"><b style="font-size: 20px">Pay {fee}</b><span style="font-size: 13px; color: {MUTE}; font-weight: 600">{sub}</span></span>'
            f'<span style="width: 32px; height: 32px; border-radius: 99px; background: #EEF2F0; display: flex; align-items: center; justify-content: center">{ic("x", 16, INK)}</span></div>'
            + strip(fee) + wallets(False, 50, 19) + orline() + cardform() + paybtn(f'Pay {fee}') + secure().replace('font-size: 12px', 'font-size: 11px') + '</div>')
def phone_label(t):
    return f'<span style="font-size: 13px; font-weight: 800; letter-spacing: 1px; color: #8A968F; text-align: center">{t}</span>'
def f_member():
    rec = receipt_e('$7.99', 'Membership, first month', '75% off, then $29.99 a month. Cancel anytime.', dark=True)
    right = (f'<div style="display: flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 800; color: {MUTE}">{ic("back", 16, MUTE)}Back to plans</div>'
             + h1('Pay $7.99') + f'<span style="font-size: 15px; color: {MUTE}; margin-top: -8px; font-weight: 600">Membership, 1 month. Then $29.99 a month, cancel anytime.</span>'
             + f'<span style="font-size: 12px; font-weight: 800; letter-spacing: 1px; color: #8A968F">EXPRESS CHECKOUT</span>' + wallets(False, 52, 20) + orline() + cardform() + email_row() + paybtn('Pay $7.99') + secure())
    a = receipt_m('$7.99', 'Membership, first month', 'Then $29.99 a month') + h1('Pick your plan', 22) + seg(0, True)
    pa = m_frame(a, foot=paybtn('Start getting paid · $7.99 today', h=56) + fine('Renews at $29.99 a month. Cancel anytime.'))
    pb = m_frame(a, overlay=sheet('$7.99', 'Membership · then $29.99 a month'))
    return d_frame_r(right, rec), pa, pb
def f_fee():
    rec = receipt_e('$49.99', 'Filing fee, one time', 'Covers all 4 claims. No subscription.', dark=True)
    upsell = (f'<div style="display: flex; align-items: center; gap: 12px; padding: 12px 14px; border-radius: 16px; background: #E9F6EF">'
              f'<span style="flex: 1; display: flex; flex-direction: column"><b style="font-size: 14px">Or join for $7.99 and file free</b><span style="font-size: 12.5px; color: {MUTE}; font-weight: 600">Membership files these 4 plus every new claim you qualify for.</span></span>'
              f'<span style="font-size: 13.5px; font-weight: 800; color: {GREEN}; white-space: nowrap; display: flex; align-items: center; gap: 4px">Switch{ic("right", 15, GREEN, 2.6)}</span></div>')
    right = (f'<div style="display: flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 800; color: {MUTE}">{ic("back", 16, MUTE)}Back</div>'
             + h1('Pay $49.99') + f'<span style="font-size: 15px; color: {MUTE}; margin-top: -8px; font-weight: 600">Filing fee, one time. Covers all 4 claims, no subscription.</span>'
             + f'<span style="font-size: 12px; font-weight: 800; letter-spacing: 1px; color: #8A968F">EXPRESS CHECKOUT</span>' + wallets(False, 52, 20) + orline() + cardform() + email_row() + paybtn('Pay $49.99') + secure())
    a = receipt_m('$49.99', 'Filing fee, one time', 'Covers all 4 claims') + upsell
    pa = m_frame(a, foot=paybtn('File my 4 claims · $49.99', h=56) + fine('One-time payment. No subscription.'))
    pb = m_frame(a, overlay=sheet('$49.99', 'Filing fee · one time, no subscription'))
    return d_frame_r(right, rec), pa, pb
INFO_F = {
 1: ('SHEET DIRECTION · MEMBERSHIP', 'Design 2\'s slide-up sheet with the receipt kept. The page stays clean: the receipt, the plan switch and one button. Tapping it slides the payment sheet up, and the top of the sheet keeps the key numbers in view (Up to $1,200, you keep 100%, $7.99 today). On a computer the receipt stays in the left panel and the right column turns into Checkout.'),
 2: ('SHEET DIRECTION · FILING FEE ONLY', 'Same pattern for the one-time $49.99 fee. The page shows the receipt and the "Or join for $7.99 and file free" option; the button opens the same payment sheet.'),
}
for n, fn in [(1, f_member), (2, f_fee)]:
    dsk, pa, pb = fn(); title, desc = INFO_F[n]
    col = lambda lab, ph: f'<div style="display: flex; flex-direction: column; gap: 22px; padding-top: 10px">{phone_label(lab)}{ph}</div>'
    page = ('<div data-board style="width: 2420px; height: 1100px; box-sizing: border-box; padding: 36px 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 26px">'
            f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #12805C">{title}</span>'
            f'<span style="font-size: 16px; color: #43504A; max-width: 1600px; line-height: 1.5; font-weight: 600">{desc}</span><span style="font-size: 13px; color: #8A968F; font-weight: 600">{NOTE}</span></div>'
            f'<div style="display: flex; gap: 46px; align-items: flex-start">{dsk}<div style="display: flex; gap: 40px">{col("1 · THE PAGE", pa)}{col("2 · TAP THE BUTTON", pb)}</div></div></div>\n</x-dc>\n')
    open(os.path.join(OUT, f'PayF{n}.dc.html'), 'w').write(HEAD % f'Payment, sheet direction {n}' + page + JS.replace('"width":1926,"height":980', '"width":2420,"height":1100'))
print('ok F')
