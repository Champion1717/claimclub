s=open('make.py').read()
def rep(o,n,cnt=1):
    global s
    assert o in s,o[:80]; s=s.replace(o,n,cnt)
# ---- state ----
rep("info: '', ans: {} };","info: '', ans: {}, sheet: null, form: {}, view: 'dash', scale: 'm', bankAsk: false };")
# ---- claims needing details ----
rep("{ id: 'apple', co: 'Apple', title: 'Siri Privacy Settlement', amt: '$95', n: 95, days: 39, kind: 'here', why: 'You owned an Apple device with Siri, 2014 to 2024' },",
    "{ id: 'apple', co: 'Apple', title: 'Siri Privacy Settlement', amt: '$95', n: 95, days: 39, kind: 'here', need: true, why: 'You owned an Apple device with Siri, 2014 to 2024' },")
rep("{ id: 'googleplay', co: 'Google Play', title: 'App Store Settlement', amt: '$100', n: 100, days: 29, kind: 'here', why: 'You bought apps or in-app items on Google Play' },",
    "{ id: 'googleplay', co: 'Google Play', title: 'App Store Settlement', amt: '$100', n: 100, days: 29, kind: 'here', need: true, why: 'You bought apps or in-app items on Google Play' },")
rep("kindNote: c.kind === 'auto' ?","kindNote: c.need ? 'Needs a few details · about 1 min' : c.kind === 'auto' ?")
rep("isAuto: c.kind === 'auto',","isAuto: c.kind === 'auto', needs: !!c.need, oneTap: !c.need,")
# ---- file routing ----
rep("""  file(id) {
    if (this.state.busy) return;""","""  forms() {
    return {
      apple: { qs: [{ k: 'q1', t: 'Did you own an Apple device with Siri between Sept 17, 2014 and Dec 31, 2024?' }, { k: 'q2', t: 'Did Siri ever turn on by itself during a private conversation?' }],
        fields: [{ k: 'dev', type: 'multi', label: 'Which Siri devices did you own?', hint: '$20 per device, up to 5 devices.', opts: ['iPhone', 'iPad', 'Mac', 'Apple Watch', 'HomePod', 'Apple TV'] },
          { k: 'sn', type: 'text', label: 'Serial number or Apple ID email', hint: 'Optional. It can speed up approval.', ph: 'e.g. F2LXK1ABCD12', optional: true }],
        est: (f) => '$' + Math.min(5, (f.dev || []).length) * 20, sum: (f) => (f.dev || []).join(', ') },
      googleplay: { qs: [{ k: 'q1', t: 'Did you buy apps or in-app items on Google Play between Aug 16, 2016 and Sept 30, 2023?' }, { k: 'q2', t: 'Were you living in the U.S. when you made those purchases?' }],
        fields: [{ k: 'acct', type: 'text', label: 'Google account email you used', hint: 'The administrator uses it to look up your purchases.', ph: 'name@gmail.com' },
          { k: 'spend', type: 'single', label: 'About how much did you spend in total?', hint: 'A rough estimate is fine.', opts: ['Under $50', '$50 to $200', '$200 to $1,000', 'Over $1,000'] }],
        est: (f) => 'Up to $100', sum: (f) => [f.acct, f.spend].filter(Boolean).join(' · ') }
    };
  }
  file(id) {
    const c = this.claims().find(x => x.id === id);
    if (c && c.need) { this.setState({ sheet: { id, step: 1 }, form: {}, bankAsk: false }); return; }
    this.doFile(id);
  }
  setForm(k, v) { this.setState({ form: Object.assign({}, this.state.form, { [k]: v }) }); }
  sheetVals() {
    const s = this.state, sh = s.sheet;
    const chip = (on) => 'min-height:36px;padding:0 14px;border-radius:99px;font-size:13px;font-weight:800;' + (on ? 'background:#0F3B2E;color:#FFFFFF' : 'background:#FFFFFF;color:#0A0F0D;box-shadow:inset 0 0 0 1.5px #DDE5E0');
    if (!sh) return { sheetOpen: false, sh: { s1: false, s2: false, s3: false, qs: [], fields: [], pay: [] } };
    const c = this.claims().find(x => x.id === sh.id), F = this.forms()[sh.id], f = s.form;
    const qs = F.qs.map(q => ({ t: q.t, yes: () => this.setForm(q.k, 'yes'), no: () => this.setForm(q.k, 'no'), yesSt: chip(f[q.k] === 'yes'), noSt: chip(f[q.k] === 'no') }));
    const anyNo = F.qs.some(q => f[q.k] === 'no'), ok1 = F.qs.every(q => f[q.k] === 'yes');
    const fields = F.fields.map(x => ({ label: x.label, hint: x.hint, ph: x.ph || '', isText: x.type === 'text', isChips: x.type !== 'text', optional: !!x.optional, val: f[x.k] || '',
      onIn: (e) => this.setForm(x.k, e.target.value),
      opts: (x.opts || []).map(o => { const on = x.type === 'multi' ? (f[x.k] || []).indexOf(o) >= 0 : f[x.k] === o; return { o, st: chip(on), tap: () => { if (x.type === 'multi') { const a = (f[x.k] || []).slice(), i = a.indexOf(o); i >= 0 ? a.splice(i, 1) : a.push(o); this.setForm(x.k, a); } else this.setForm(x.k, o); } }; }) }));
    const ok2 = F.fields.every(x => x.optional || (x.type === 'multi' ? (f[x.k] || []).length > 0 : x.type === 'text' ? /@/.test(f[x.k] || '') : !!f[x.k]));
    const bank = !!s.acct.bank, pm = f.pay || (bank ? 'Direct deposit' : '');
    const needBank = pm === 'Direct deposit' && !bank;
    const ok3 = !!pm && !needBank && !!f.sign;
    const step = sh.step, can = step === 1 ? ok1 : step === 2 ? ok2 : ok3;
    const titles = ['Confirm you qualify', 'A few details', 'Review and sign'];
    return {
      sheetOpen: true,
      sh: {
        co: c.co, title: c.title, logo: this.logos()[c.id], amt: c.amt, step, s1: step === 1, s2: step === 2, s3: step === 3, stepTitle: titles[step - 1],
        dots: [1, 2, 3].map(i => ({ st: 'flex:1;height:5px;border-radius:99px;background:' + (i <= step ? '#12805C' : '#E3EAE6') })),
        qs, anyNo, fields, est: F.est(f), summary: F.sum(f) || '',
        pay: ['Direct deposit', 'PayPal', 'Check'].map(o => ({ o, st: chip(pm === o), tap: () => this.setForm('pay', o) })), needBank,
        connectBank: () => this.setState({ acct: Object.assign({}, s.acct, { bank: 1 }) }),
        sign: !!f.sign, signTap: () => this.setForm('sign', !f.sign), signBox: 'width:22px;height:22px;flex:none;border-radius:7px;display:flex;align-items:center;justify-content:center;' + (f.sign ? 'background:#12805C' : 'box-shadow:inset 0 0 0 2px #C9D3CD;background:#FFFFFF'),
        hasBack: step > 1, back: () => this.setState({ sheet: { id: sh.id, step: step - 1 } }),
        nextLabel: step === 3 ? 'Submit claim' : 'Continue',
        nextSt: 'flex:1;min-height:46px;border-radius:99px;font-size:15px;font-weight:800;transition:opacity .15s;' + (step === 3 ? 'background:#3DDC97;color:#0A0F0D' : 'background:#0A0F0D;color:#FFFFFF') + (can ? '' : ';opacity:.35;cursor:not-allowed'),
        next: () => { if (!can) return; if (step < 3) this.setState({ sheet: { id: sh.id, step: step + 1 } }); else { this.setState({ sheet: null }); this.doFile(sh.id); } },
        close: () => this.setState({ sheet: null }),
        remove: () => { this.setState({ sheet: null, st: Object.assign({}, s.st, { [sh.id]: 'gone' }) }); }
      }
    };
  }
  doFile(id) {
    if (this.state.busy) return;""")
# exclude 'gone' from lists
rep("const all = this.claims().map(row);","const all = this.claims().filter(c => s.st[c.id] !== 'gone').map(row);")
# view + scale values
rep("      ...this.setupVals(),","""      ...this.setupVals(), ...this.sheetVals(),
      isDash: s.view === 'dash', isSet: s.view === 'settings', goDash: () => this.setState({ view: 'dash' }), goSet: () => this.setState({ view: 'settings' }),
      navDash: 'display:flex;align-items:center;gap:12px;padding:11px 12px;border-radius:12px;font-size:15px;font-weight:700;' + (s.view === 'dash' ? 'background:#EAF2EE;color:#0F3B2E' : 'background:transparent;color:#43504A'),
      navSet: 'display:flex;align-items:center;gap:12px;padding:11px 12px;border-radius:12px;font-size:15px;font-weight:700;' + (s.view === 'settings' ? 'background:#EAF2EE;color:#0F3B2E' : 'background:transparent;color:#43504A'),
      mDash: 'display:flex;flex-direction:column;align-items:center;gap:3px;font-size:11px;font-weight:800;background:transparent;color:' + (s.view === 'dash' ? '#0F3B2E' : '#8A968F'),
      mSet: 'display:flex;flex-direction:column;align-items:center;gap:3px;font-size:11px;font-weight:800;background:transparent;color:' + (s.view === 'settings' ? '#0F3B2E' : '#8A968F'),
      zoomSt: 'display:flex;flex-direction:column;gap:14px;zoom:' + ({ s: 0.86, m: 1, l: 1.14 }[s.scale]),
      scales: [['s', 'Small', 13], ['m', 'Medium', 17], ['l', 'Large', 22]].map(([k, t, px]) => ({ t, aa: 'font-size:' + px + 'px;font-weight:800;line-height:1', on: s.scale === k, tap: () => this.setState({ scale: k }),
        st: 'flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;min-height:84px;border-radius:14px;font-weight:800;font-size:13px;' + (s.scale === k ? 'background:#EAF2EE;color:#0F3B2E;box-shadow:inset 0 0 0 2px #12805C' : 'background:#FFFFFF;color:#43504A;box-shadow:inset 0 0 0 1.5px #DDE5E0') })),""")
open('make.py','w').write(s)
print('logic ok')
