# "How fast should we file?" phone iterations (Nov 21 2026, design only). Henry picked B3 (speed first).
# Board OfferG2mS: S1 = B3 exactly, S2 = B3 with tags, radio and refunds line, S3 = speed race bars.
import os
from perksD import LU
LU.setdefault('clock', 'M12 2a10 10 0 1 0 0 20a10 10 0 1 0 0-20 M12 6v6l4 2')
import tierGm2 as G
from tierGm2 import P, FOOT, li, price, pill, radio, board, b3
from tierE import mob, h, ic, INK, MUTE, LINE, MINT, GREEN, DARK

SUB = f'<span style="font-size: 13px; font-weight: 600; color: {MUTE}; margin-top: -6px">How fast we file your claims after you join.</span>'

def s2():
    feats = {'std': P['std']['feats'][1:3], 'fast': P['fast']['feats'][1:4], 'pri': [P['pri']['feats'][1], P['pri']['feats'][2], 'Refunds + subscriptions']}
    def card(k):
        p = P[k]; dark = k == 'pri'; sel = k == 'fast'
        bg = DARK if dark else '#FFFFFF'
        ring = f'inset 0 0 0 2px {MINT}, 0 12px 26px rgba(18,128,92,.16)' if sel else ('0 12px 26px rgba(10,15,13,.18)' if dark else f'inset 0 0 0 1px {LINE}')
        fg = '#FFFFFF' if dark else INK; mu = '#9FC3B4' if dark else MUTE
        num, unit = p['speed'].split(' ')
        blk = ('background: ' + MINT + '; color: ' + DARK) if sel else (('background: rgba(61,220,151,.16); color: #FFFFFF') if dark else 'background: #F1F4F2; color: ' + INK)
        icc = DARK if sel else (MINT if dark else MUTE)
        tag = pill(p['tag'], MINT, DARK) if sel else (pill(p['tag'], 'rgba(61,220,151,.18)', MINT) if dark else '')
        return (f'<div style="border-radius: 18px; padding: 12px; background: {bg}; box-shadow: {ring}; color: {fg}; display: flex; gap: 12px; align-items: stretch">'
                f'<div style="width: 76px; flex: none; border-radius: 12px; {blk}; display: flex; flex-direction: column; align-items: center; justify-content: center">'
                f'{ic("zap" if k != "std" else "clock", 15, icc, 2.4)}<b style="font-size: 27px; letter-spacing: -1px; line-height: 1.1">{num}</b><span style="font-size: 10.5px; font-weight: 800; opacity: .8">{unit.upper()}</span></div>'
                f'<div style="flex: 1; display: flex; flex-direction: column; gap: 6px; padding: 2px 0"><div style="display: flex; align-items: center; gap: 7px">{radio(sel, dark)}<b style="font-size: 16px">{p["name"]}</b>{tag}<span style="flex: 1"></span>{price(p, fg, mu, 18)}</div>'
                + ''.join(li(f, MINT if dark else GREEN, '#E6EEEA' if dark else INK, 12.5) for f in feats[k]) + '</div></div>')
    return mob(h('How fast should we file?', 23, False) + SUB + card('std') + card('fast') + card('pri'), FOOT())

def s3():
    W = {'std': 100, 'fast': 22, 'pri': 9}
    feats = {'std': ['Auto-filed claims only', '3 of your 6 claims'], 'fast': ['All 173 nationwide claims', 'Reminders on new claims'], 'pri': ['All 270 claims, incl. local', 'Refunds + subscriptions']}
    def card(k):
        p = P[k]; dark = k == 'pri'; sel = k == 'fast'
        bg = DARK if dark else '#FFFFFF'; fg = '#FFFFFF' if dark else INK; mu = '#9FC3B4' if dark else MUTE
        ring = f'inset 0 0 0 2px {MINT}' if sel else ('none' if dark else f'inset 0 0 0 1px {LINE}')
        bar = MINT if k != 'std' else '#C9D3CD'
        tag = pill(p['tag'], MINT, DARK) if sel else (pill(p['tag'], 'rgba(61,220,151,.18)', MINT) if dark else '')
        track = (f'<div style="display: flex; align-items: center; gap: 10px"><div style="flex: 1; height: 10px; border-radius: 99px; background: {"rgba(255,255,255,.1)" if dark else "#EEF3F0"}; position: relative">'
                 f'<div style="position: absolute; left: 0; top: 0; bottom: 0; width: {W[k]}%; border-radius: 99px; background: {bar}"></div></div>'
                 f'<b style="font-size: 14px; white-space: nowrap; color: {MINT if dark else (GREEN if sel else INK)}">{p["speed"]}</b></div>')
        return (f'<div style="border-radius: 18px; padding: 13px 14px; background: {bg}; box-shadow: {ring}; color: {fg}; display: flex; flex-direction: column; gap: 9px">'
                f'<div style="display: flex; align-items: center; gap: 7px">{radio(sel, dark)}<b style="font-size: 16px">{p["name"]}</b>{tag}<span style="flex: 1"></span>{price(p, fg, mu, 19)}</div>'
                f'<span style="font-size: 10.5px; font-weight: 800; letter-spacing: .6px; color: {mu}; margin-bottom: -4px">TIME TO FILE</span>{track}'
                f'<div style="display: flex; flex-wrap: wrap; gap: 4px 14px">{"".join(li(f, MINT if dark else GREEN, "#E6EEEA" if dark else INK, 12) for f in feats[k])}</div></div>')
    return mob(h('How fast should we file?', 23, False) + SUB + card('std') + card('fast') + card('pri'), FOOT())

if __name__ == '__main__':
    board('OfferG2mS', 'HOW FAST SHOULD WE FILE? · 3 ITERATIONS', [
        ('S1 · B3 AS IS', 'The one you picked, unchanged: filing time block on the left, then name, price and three features.', b3()),
        ('S2 · B3 WITH TAGS', 'Adds tags, a pick circle, a mint time block on the picked plan and refunds on Priority.', s2()),
        ('S3 · RACE BARS', 'Each card shows a bar for how long filing takes: a full bar for 30 days, a short one for 3 days, a sliver for 24 hours.', s3())])
    print('ok')
