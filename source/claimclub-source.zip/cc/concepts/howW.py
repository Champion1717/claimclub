# How it works on white, right after the hero (Nov 22 2026, canvas only). Builds HowW1..3 (desktop D, phone M) on the
# Homepage canvas page from HomeD/HomeM (the 1:1 live copies): the How it works section moves above the brand band and
# is redrawn on white. 1 = the live phones on white, 2 = three light cards with cropped phones, 3 = icon timeline, no phones.
import re, os
from artIcons import uri
P = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'project')
INK, DARK, MINT, GREEN, MUTE, LINE = '#0A0F0D', '#0F3B2E', '#3DDC97', '#12805C', '#5B6862', '#E3EAE6'

def block(h, start):
    # the balanced <div>...</div> starting at index start
    d, i = 0, start
    while True:
        a, b = h.find('<div', i), h.find('</div>', i)
        if a != -1 and a < b: d += 1; i = a + 4
        else:
            d -= 1; i = b + 6
            if d == 0: return h[start:i]

def parts(h):
    i = h.index('<section id="how"'); j = h.index('</section>', i) + 10
    sec = h[i:j]
    phones = []; k = 0
    while True:
        k = sec.find('<div class="iph"', k)
        if k == -1 or len(phones) == 3: break
        p = block(sec, k); phones.append(p); k += len(p)
    titles = re.findall(r'<b style="font-size: 16px">([^<]+)</b></span><p class="howDesc"', sec)
    descs = re.findall(r'<p class="howDesc"[^>]*>([^<]+)</p>', sec)
    return i, j, list(zip(titles, descs, phones))

HEAD = (f'<div style="display: flex; flex-direction: column; align-items: center; gap: 12px; text-align: center; margin-bottom: 48px" class="hwHead">'
        f'<span style="font-size: 13px; font-weight: 800; letter-spacing: 1.2px; color: {GREEN}">HOW IT WORKS</span>'
        f'<h2 style="margin: 0; font-size: clamp(32px, 3.4vw, 46px); line-height: 1.05; letter-spacing: -1.4px; color: {INK}">How Claimclub works</h2>'
        f'<p style="margin: 0; font-size: 17px; line-height: 1.5; color: {MUTE}; max-width: 520px">Three steps. You answer, we file, the settlement pays you.</p></div>')
CTA = (f'<div style="display: flex; justify-content: center; margin-top: 44px"><a href="FlowC.dc.html" style="background: {DARK}; color: #FFFFFF; text-decoration: none; font-size: 17px; font-weight: 800; padding: 17px 30px; border-radius: 999px">Claim my money</a></div>')
num = lambda n, bg=DARK, fg=MINT, sz=36: f'<span style="width: {sz}px; height: {sz}px; flex: none; border-radius: 50%; background: {bg}; color: {fg}; font-weight: 800; font-size: {sz * .44:.0f}px; display: flex; align-items: center; justify-content: center">{n}</span>'

def v1(S):  # live phones on white
    cols = ''.join(f'<div class="hw1c" style="flex: 1 1 0; display: flex; flex-direction: column; align-items: center; gap: 16px; text-align: center">'
                   f'<span style="display: inline-flex; align-items: center; gap: 10px; padding: 7px 18px 7px 7px; border-radius: 99px; background: #F3F6F4; color: {INK}">{num(n + 1, sz=32)}<b style="font-size: 16px">{t}</b></span>'
                   f'<p style="margin: -4px 0 6px; font-size: 15px; line-height: 1.5; color: {MUTE}; max-width: 300px">{d}</p>'
                   f'<div class="hw1p" style="filter: drop-shadow(0 24px 40px rgba(10,15,13,.16))">{p}</div></div>' for n, (t, d, p) in enumerate(S))
    css = '@media (max-width:900px){.hw1row{flex-direction:column !important;align-items:center !important;gap:44px !important}.hw1p{zoom:.82}.hwSec{padding:56px 16px 64px !important}}'
    return f'<style>{css}</style><section id="how" class="hwSec" style="padding: 88px 4vw 96px; background: #FFFFFF">{HEAD}<div class="hw1row" style="display: flex; gap: 32px; align-items: flex-start; max-width: 1240px; margin: 0 auto">{cols}</div></section>'

def v2(S):  # light cards, phone cropped at the bottom
    cards = ''.join(f'<div class="hw2c" style="flex: 1 1 0; min-width: 0; border-radius: 28px; background: {"#E9F6EF" if n == 1 else "#F3F6F4"}; padding: 30px 28px 0; display: flex; flex-direction: column; gap: 10px; overflow: hidden">'
                    f'{num(n + 1)}<b style="font-size: 22px; letter-spacing: -.4px; color: {INK}; margin-top: 6px">{t}</b><span style="font-size: 15px; line-height: 1.5; color: {MUTE}">{d}</span>'
                    f'<div style="height: 330px; margin-top: 18px; display: flex; justify-content: center; overflow: hidden; -webkit-mask-image: linear-gradient(180deg,#000 75%,transparent); mask-image: linear-gradient(180deg,#000 75%,transparent)"><div style="zoom: .82">{p}</div></div></div>' for n, (t, d, p) in enumerate(S))
    css = '@media (max-width:900px){.hw2row{flex-direction:column !important;gap:14px !important}.hwSec{padding:56px 16px 4px !important}.hw2c{flex:none !important;padding:24px 22px 0 !important}}'
    return f'<style>{css}</style><section id="how" class="hwSec" style="padding: 88px 4vw 96px; background: #FFFFFF">{HEAD}<div class="hw2row" style="display: flex; gap: 18px; max-width: 1240px; margin: 0 auto">{cards}</div>{CTA}</section>'

def v3(S):  # icon timeline, no phones
    icons = ['check', 'file', 'paid']
    steps = ''.join(f'<div class="hw3s" style="flex: 1 1 0; display: flex; flex-direction: column; align-items: center; text-align: center; gap: 12px; position: relative; z-index: 1">'
                    f'<img src="{uri(icons[n])}" alt="" width="96" height="96" style="width: 96px; height: 96px; border-radius: 26px; box-shadow: 0 0 0 10px #FFFFFF, 0 16px 34px rgba(10,15,13,.10)">'
                    f'<span class="hw3t" style="display: flex; flex-direction: column; align-items: center; gap: 8px"><span style="font-size: 13px; font-weight: 800; letter-spacing: 1.1px; color: {GREEN}">STEP {n + 1}</span>'
                    f'<b style="font-size: 22px; letter-spacing: -.4px; color: {INK}">{t}</b><span style="font-size: 15.5px; line-height: 1.5; color: {MUTE}; max-width: 280px">{d}</span></span></div>' for n, (t, d, p) in enumerate(S))
    line = f'<i class="hw3l" style="position: absolute; left: 16.6%; right: 16.6%; top: 48px; height: 2px; background: repeating-linear-gradient(90deg,{LINE} 0 10px,transparent 10px 18px)"></i>'
    css = ('@media (max-width:900px){.hwSec{padding:56px 20px 64px !important}.hw3row{flex-direction:column !important;gap:30px !important}.hw3s{flex-direction:row !important;align-items:flex-start !important;text-align:left !important;gap:18px !important}'
           '.hw3s img{width:64px !important;height:64px !important;border-radius:18px !important}.hw3t{align-items:flex-start !important}.hw3t b{font-size:19px !important}.hw3l{left:31px !important;right:auto !important;top:32px !important;bottom:32px;width:2px !important;height:auto !important;background:repeating-linear-gradient(180deg,#E3EAE6 0 10px,transparent 10px 18px) !important}}')
    return (f'<style>{css}</style><section id="how" class="hwSec" style="padding: 88px 4vw 96px; background: #FFFFFF">{HEAD}'
            f'<div class="hw3row" style="display: flex; gap: 40px; max-width: 1100px; margin: 0 auto; position: relative">{line}{steps}</div>{CTA}</section>')

def make(src, variant):
    h = open(os.path.join(P, src)).read()
    i, j, S = parts(h)
    assert len(S) == 3, len(S)
    h = h[:i] + h[j:]
    b = h.index('<!-- OPEN SETTLEMENTS BAND')
    new = variant(S)
    return h[:b] + '<!-- HOW IT WORKS on white (canvas draft) -->\n  ' + new + '\n\n  ' + h[b:]

if __name__ == '__main__':
    for n, v in ((1, v1), (2, v2), (3, v3)):
        for s, t in (('HomeD', 'D'), ('HomeM', 'M')):
            h = make(s + '.dc.html', v)
            h = re.sub(r'<title>[^<]*</title>', f'<title>Claimclub · How it works on white {n} ({"desktop" if t == "D" else "mobile"})</title>', h, count=1)
            open(os.path.join(P, f'HowW{n}{t}.dc.html'), 'w').write(h)
    print('ok')
