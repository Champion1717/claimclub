# Find claims, simpler drafts (Nov 21 2026, design only). Henry: the live Find claims page feels busy
# (pill on every row, black Check buttons, category chip row, truncated payout text). Three calmer takes:
#   FindS1  Plain list: one line of plain-English "who qualifies", amount and deadline on the right, nothing else.
#   FindS2  By deadline: grouped into Closing this week / This month / Later, small round add buttons.
#   FindS3  Cards: two columns of quiet cards (amount first), one "No proof needed" switch instead of chips.
# Each board shows the desktop page (with the member top bar) next to the phone version.
import os, re
from tierE import HEAD, JS, OUT
from perksD import ic, LU

LU.update({'plus': 'M5 12h14 M12 5v14', 'chev': 'm9 18 6-6-6-6', 'down': 'm6 9 6 6 6-6'})
INK, MUTE, LINE, MINT, GREEN, DARK, BG = '#0A0F0D', '#5B6862', '#E3EAE6', '#3DDC97', '#12805C', '#0F3B2E', '#F3F6F4'

# logos uploaded to the canvas on Nov 18 (simpleD.py)
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'simpleD.py')).read()
A = re.search(r"_A='([^']+)'", src).group(1).split(); N = re.search(r"_N='([^']+)'", src).group(1).split()
T = {n: '/_blob/' + a for n, a in zip(N, A)}
T['realpage'] = '/_blob/2d4f1edaf50be1a307d253137d434b65'; T['cvs'] = '/_blob/348f9378ec1a0f51e4ca5405e83b40d1'

# sample settlements: id, company, plain who line, amount, days left, proof needed?, mine
S = [('amazon', 'Amazon', 'You returned something and got less back than you paid', 'Paid automatically', 11, False, 'ready'),
     ('toyota', 'Toyota', 'You owned a Toyota with a recalled airbag', '$250 or more', 752, True, 'filing'),
     ('kia', 'Kia', 'You paid to fix a Kia power window', 'Up to $400', 3, True, None),
     ('equifax', 'Equifax', 'You disputed something on your Equifax credit report', 'Up to $400', 8, False, None),
     ('visa', 'Visa and Mastercard', 'You paid an ATM fee with your card', 'Up to $1,000', 81, False, None),
     ('apple', 'Apple', 'You used Siri on an iPhone, iPad or Mac', 'Up to $95', 31, False, None),
     ('googleplay', 'Google Play', 'You bought apps or in-app items on Android', 'Up to $100', 21, False, None),
     ('cvs', 'CVS', 'You filled prescriptions at CVS with insurance', '$5 or more', 44, False, None),
     ('realpage', 'RealPage', 'You rented an apartment from a big landlord', 'Up to $100', 70, False, None)]

def logo(i, sz=40):
    return f'<img src="{T[i]}" alt="" style="width: {sz}px; height: {sz}px; flex: none; border-radius: {sz * .28:.0f}px; object-fit: contain; background: #FFFFFF; box-shadow: inset 0 0 0 1px {LINE}">'
def due(d):
    if d <= 7: return f'<span style="color: #B8333A">{d} days left</span>'
    if d > 365: return 'Open until 2028'
    return f'{d} days left'
def mine(st):
    return {'ready': 'In your claims', 'filing': 'Filing'}.get(st, '')

def search(w='100%', ph='Search a company or product'):
    return (f'<div style="width: {w}; height: 48px; box-sizing: border-box; border-radius: 14px; background: #FFFFFF; box-shadow: inset 0 0 0 1px {LINE}; display: flex; align-items: center; gap: 10px; padding: 0 16px; color: #8A968F">'
            f'{ic("search", 18, "#8A968F")}<span style="font-size: 15px; font-weight: 600">{ph}</span></div>')
def tabs(items, on=0, sz=15):
    return ('<div style="display: flex; gap: 22px">' + ''.join(
        f'<span style="font-size: {sz}px; font-weight: 800; padding-bottom: 8px; {"color: " + INK + "; box-shadow: inset 0 -2px 0 " + GREEN if i == on else "color: #8A968F"}">{t}</span>' for i, t in enumerate(items)) + '</div>')
def title(sub, sz=34):
    return (f'<div style="display: flex; flex-direction: column; gap: 4px"><b style="font-size: {sz}px; letter-spacing: -1px">Find claims</b>'
            f'<span style="font-size: 15px; font-weight: 600; color: {MUTE}">{sub}</span></div>')

# ---------- frames ----------
def topbar():
    t = lambda s, on=False: f'<span style="font-size: 14px; font-weight: 800; padding: 8px 14px; border-radius: 99px; {"background: #E9F6EF; color: " + GREEN if on else "color: #43504A"}">{s}</span>'
    return (f'<div style="height: 64px; flex: none; background: #FFFFFF; border-bottom: 1px solid {LINE}; display: flex; align-items: center; padding: 0 24px; gap: 8px">'
            f'<b style="font-size: 19px; letter-spacing: -.5px; margin-right: auto">claimclub<span style="color: {GREEN}">.io</span></b>'
            + t('Your claims') + t('Find claims', True) + t('Claim refunds') + t('Manage subscriptions')
            + f'<span style="margin-left: auto; width: 34px; height: 34px; border-radius: 99px; background: {DARK}; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 14px">A</span></div>')
def desk(body, h=980):
    return (f'<div style="width: 1120px; height: {h}px; flex: none; border-radius: 18px; overflow: hidden; background: {BG}; box-shadow: 0 20px 50px rgba(10,15,13,.14); display: flex; flex-direction: column">'
            + topbar() + f'<div style="flex: 1; overflow: hidden; padding: 30px 0"><div style="width: 760px; margin: 0 auto; display: flex; flex-direction: column; gap: 18px">{body}</div></div></div>')
def phone(body, h=980):
    nav = ''.join(f'<span style="flex: 1; text-align: center; font-size: 11px; font-weight: 800; color: {GREEN if t == "Find" else "#8A968F"}">{t}</span>' for t in ('Claims', 'Find', 'Refunds', 'Subscriptions'))
    return (f'<div style="width: 390px; height: {h}px; flex: none; border-radius: 40px; overflow: hidden; background: {BG}; box-shadow: 0 0 0 10px #1C2420, 0 24px 50px rgba(10,15,13,.25); display: flex; flex-direction: column">'
            f'<div style="height: 44px; flex: none"></div><div style="flex: 1; overflow: hidden; padding: 6px 16px 16px; display: flex; flex-direction: column; gap: 14px">{body}</div>'
            f'<div style="height: 64px; flex: none; background: #FFFFFF; border-top: 1px solid {LINE}; display: flex; align-items: center; padding-bottom: 8px">{nav}</div></div>')

# ---------- F1: plain list ----------
def f1_rows(m=False, n=9):
    out = []
    for i, co, who, amt, d, proof, st in S[:n]:
        right = (f'<span style="display: flex; flex-direction: column; align-items: flex-end; gap: 3px; flex: none; text-align: right"><b style="font-size: {14 if m else 15}px; color: {GREEN}">{amt}</b>'
                 f'<span style="font-size: 12.5px; font-weight: 600; color: {MUTE}">{mine(st) or due(d)}</span></span>')
        out.append(f'<div style="display: flex; align-items: center; gap: {12 if m else 14}px; padding: {12 if m else 14}px 2px; border-top: 1px solid {LINE}">{logo(i, 38 if m else 42)}'
                   f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><b style="font-size: {15 if m else 16}px">{co}</b>'
                   f'<span style="font-size: {13 if m else 14}px; font-weight: 600; color: {MUTE}; line-height: 1.35">{who}</span></span>{right}</div>')
    return '<div style="display: flex; flex-direction: column; border-bottom: 1px solid ' + LINE + '">' + ''.join(out) + '</div>'
def f1(m=False):
    top = title('149 open settlements. Tap one to see if you qualify.', 28 if m else 34) + search() + tabs(['Nationwide', 'Near you'], 0, 14 if m else 15)
    return top + f1_rows(m, 7 if m else 9)

# ---------- F2: by deadline ----------
def f2_row(r, m=False):
    i, co, who, amt, d, proof, st = r
    btn = (f'<span style="font-size: 12.5px; font-weight: 800; color: {GREEN}; flex: none">{mine(st)}</span>' if st else
           f'<span style="width: 34px; height: 34px; flex: none; border-radius: 99px; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; align-items: center; justify-content: center; background: #FFFFFF">{ic("plus", 16, INK, 2.4)}</span>')
    return (f'<div style="display: flex; align-items: center; gap: 12px; padding: 12px 14px">{logo(i, 36)}'
            f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px"><span style="font-size: 15px; font-weight: 800">{co} <span style="color: {GREEN}">· {amt}</span></span>'
            f'<span style="font-size: 13px; font-weight: 600; color: {MUTE}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{who}</span></span>{btn}</div>')
def f2_group(t, rows, m=False, red=False):
    return (f'<div style="display: flex; flex-direction: column; gap: 8px"><span style="font-size: 12.5px; font-weight: 800; letter-spacing: 1px; color: {"#B8333A" if red else MUTE}">{t}</span>'
            f'<div style="background: #FFFFFF; border-radius: 16px; box-shadow: inset 0 0 0 1px {LINE}; display: flex; flex-direction: column">'
            + f'<div style="height: 1px; background: {LINE}; margin: 0 14px"></div>'.join(f2_row(r, m) for r in rows) + '</div></div>')
def f2(m=False):
    by = lambda lo, hi: [r for r in S if lo <= r[4] < hi]
    head = title('Sorted by deadline, so nothing slips by.', 28 if m else 34) + search()
    return head + f2_group('CLOSING THIS WEEK', by(0, 8), m, True) + f2_group('THIS MONTH', by(8, 32), m) + f2_group('LATER', by(32, 9999)[: 3 if m else 4], m)

# ---------- F3: cards ----------
def toggle(on=True):
    return (f'<span style="display: inline-flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 700; color: #43504A">'
            f'<span style="width: 38px; height: 22px; border-radius: 99px; background: {GREEN if on else "#C9D3CD"}; position: relative; display: inline-block"><span style="position: absolute; top: 3px; {"right" if on else "left"}: 3px; width: 16px; height: 16px; border-radius: 99px; background: #FFFFFF"></span></span>No proof needed</span>')
def f3_card(r):
    i, co, who, amt, d, proof, st = r
    foot = f'<span style="color: {GREEN}">{mine(st)}</span>' if st else due(d)
    return (f'<div style="background: #FFFFFF; border-radius: 18px; box-shadow: inset 0 0 0 1px {LINE}; padding: 16px; display: flex; flex-direction: column; gap: 10px">'
            f'<div style="display: flex; align-items: center; gap: 10px">{logo(i, 34)}<b style="font-size: 15px">{co}</b></div>'
            f'<b style="font-size: 22px; letter-spacing: -.5px">{amt}</b>'
            f'<span style="font-size: 13.5px; font-weight: 600; color: {MUTE}; line-height: 1.4; min-height: 38px">{who}</span>'
            f'<span style="font-size: 12.5px; font-weight: 700; color: {MUTE}; padding-top: 10px; border-top: 1px solid {LINE}">{foot}</span></div>')
def f3(m=False):
    rows = [r for r in S if not r[5]]
    head = title('Only showing claims that need no receipts.', 28 if m else 34)
    bar = (f'<div style="display: flex; align-items: center; gap: 14px; flex-wrap: wrap">' + search('100%' if m else '420px') + toggle() + '</div>')
    cols = 1 if m else 2
    grid = f'<div style="display: grid; grid-template-columns: repeat({cols}, minmax(0, 1fr)); gap: 12px">' + ''.join(f3_card(r) for r in rows[: 4 if m else 6]) + '</div>'
    return head + bar + grid

def board(name, label, note, d, m):
    page = (f'<div data-board style="width: 1720px; height: 1180px; box-sizing: border-box; padding: 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: {INK}; display: flex; flex-direction: column; gap: 26px">'
            f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: {GREEN}">{label}</span>'
            f'<span style="font-size: 16px; color: #43504A; font-weight: 600; max-width: 1100px; line-height: 1.45">{note}</span></div>'
            f'<div style="display: flex; gap: 60px; align-items: flex-start">{desk(d)}{phone(m)}</div></div>\n</x-dc>\n')
    open(os.path.join(OUT, f'{name}.dc.html'), 'w').write(HEAD % label.title() + page + JS.replace('"width":1926,"height":980', '"width":1720,"height":1180'))

if __name__ == '__main__':
    board('FindS1', 'FIND CLAIMS · S1 · PLAIN LIST', 'One list, no pills or buttons. Each row says who qualifies in plain words, with the payout and deadline on the right. The whole row opens the claim. Categories and sort move into search.', f1(), f1(True))
    board('FindS2', 'FIND CLAIMS · S2 · BY DEADLINE', 'Grouped by how soon each one closes, so the urgent ones are on top. A small + adds a claim; claims you already have say so instead.', f2(), f2(True))
    board('FindS3', 'FIND CLAIMS · S3 · QUIET CARDS', 'Cards lead with the payout, then who qualifies and the deadline. One "No proof needed" switch replaces the category chips.', f3(), f3(True))
    print('ok')
