# Find claims, simpler drafts (Nov 21 2026, design only). Henry: the live Find claims page feels busy
# (pill on every row, black Check buttons, category chip row, truncated payout text). Three calmer takes:
#   FindS1  Plain list: one line of plain-English "who qualifies", amount and deadline on the right, nothing else.
#   FindS2  By deadline: grouped into Closing this week / This month / Later, small round add buttons.
#   FindS3  Cards: two columns of quiet cards (amount first), one "No proof needed" switch instead of chips.
# Each board shows the desktop page (with the member top bar) next to the phone version.
import os, re
from tierE import HEAD, JS, OUT
from perksD import ic, LU

LU.update({'plus': 'M5 12h14 M12 5v14', 'chev': 'm9 18 6-6-6-6', 'down': 'm6 9 6 6 6-6'})
INK, MUTE, LINE, MINT, GREEN, DARK, BG = '#0A0F0D', '#5B6862', '#E3EAE6', '#3DDC97', '#12805C', '#0F3B2E', '#F3F6F4'

# logos uploaded to the canvas on Nov 18 (simpleD.py)
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'simpleD.py')).read()
A = re.search(r"_A='([^']+)'", src).group(1).split(); N = re.search(r"_N='([^']+)'", src).group(1).split()
T = {n: '/_blob/' + a for n, a in zip(N, A)}
T['realpage'] = '/_blob/2d4f1edaf50be1a307d253137d434b65'; T['cvs'] = '/_blob/348f9378ec1a0f51e4ca5405e83b40d1'

# sample settlements: id, company, plain who line, amount, days left, proof needed?, mine
S = [('amazon', 'Amazon', 'You returned something and got less back than you paid', 'Paid automatically', 11, False, 'ready'),
     ('toyota', 'Toyota', 'You owned a Toyota with a recalled airbag', '$250 or more', 752, True, 'filing'),
     ('kia', 'Kia', 'You paid to fix a Kia power window', 'Up to $400', 3, True, None),
     ('equifax', 'Equifax', 'You disputed something on your Equifax credit report', 'Up to $400', 8, False, None),
     ('visa', 'Visa and Mastercard', 'You paid an ATM fee with your card', 'Up to $1,000', 81, False, None),
     ('apple', 'Apple', 'You used Siri on an iPhone, iPad or Mac', 'Up to $95', 31, False, None),
     ('googleplay', 'Google Play', 'You bought apps or in-app items on Android', 'Up to $100', 21, False, None),
     ('cvs', 'CVS', 'You filled prescriptions at CVS with insurance', '$5 or more', 44, False, None),
     ('realpage', 'RealPage', 'You rented an apartment from a big landlord', 'Up to $100', 70, False, None)]

def logo(i, sz=40):
    return f'<img src="{T[i]}" alt="" style="width: {sz}px; height: {sz}px; flex: none; border-radius: {sz * .28:.0f}px; object-fit: contain; background: #FFFFFF; box-shadow: inset 0 0 0 1px {LINE}">'
def due(d):
    if d <= 7: return f'<span style="color: #B8333A">{d} days left</span>'
    if d > 365: return 'Open until 2028'
    return f'{d} days left'
def mine(st):
    return {'ready': 'In your claims', 'filing': 'Filing'}.get(st, '')

def search(w='100%', ph='Search a company or product'):
    return (f'<div style="width: {w}; height: 48px; box-sizing: border-box; border-radius: 14px; background: #FFFFFF; box-shadow: inset 0 0 0 1px {LINE}; display: flex; align-items: center; gap: 10px; padding: 0 16px; color: #8A968F">'
            f'{ic("search", 18, "#8A968F")}<span style="font-size: 15px; font-weight: 600">{ph}</span></div>')
def tabs(items, on=0, sz=15):
    return ('<div style="display: flex; gap: 22px">' + ''.join(
        f'<span style="font-size: {sz}px; font-weight: 800; padding-bottom: 8px; {"color: " + INK + "; box-shadow: inset 0 -2px 0 " + GREEN if i == on else "color: #8A968F"}">{t}</span>' for i, t in enumerate(items)) + '</div>')
def title(sub, sz=34):
    return (f'<div style="display: flex; flex-direction: column; gap: 4px"><b style="font-size: {sz}px; letter-spacing: -1px">Find claims</b>'
            f'<span style="font-size: 15px; font-weight: 600; color: {MUTE}">{sub}</span></div>')

# ---------- frames ----------
def topbar():
    t = lambda s, on=False: f'<span style="font-size: 14px; font-weight: 800; padding: 8px 14px; border-radius: 99px; {"background: #E9F6EF; color: " + GREEN if on else "color: #43504A"}">{s}</span>'
    return (f'<div style="height: 64px; flex: none; background: #FFFFFF; border-bottom: 1px solid {LINE}; display: flex; align-items: center; padding: 0 24px; gap: 8px">'
            f'<b style="font-size: 19px; letter-spacing: -.5px; margin-right: auto">claimclub<span style="color: {GREEN}">.io</span></b>'
            + t('Your claims') + t('Find claims', True) + t('Claim refunds') + t('Manage subscriptions')
            + f'<span style="margin-left: auto; width: 34px; height: 34px; border-radius: 99px; background: {DARK}; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 14px">A</span></div>')
def desk(body, h=980):
    return (f'<div style="width: 1120px; height: {h}px; flex: none; border-radius: 18px; overflow: hidden; background: {BG}; box-shadow: 0 20px 50px rgba(10,15,13,.14); display: flex; flex-direction: column">'
            + topbar() + f'<div style="flex: 1; overflow: hidden; padding: 30px 0"><div style="width: 760px; margin: 0 auto; display: flex; flex-direction: column; gap: 18px">{body}</div></div></div>')
def phone(body, h=980):
    nav = ''.join(f'<span style="flex: 1; text-align: center; font-size: 11px; font-weight: 800; color: {GREEN if t == "Find" else "#8A968F"}">{t}</span>' for t in ('Claims', 'Find', 'Refunds', 'Subscriptions'))
    return (f'<div style="width: 390px; height: {h}px; flex: none; border-radius: 40px; overflow: hidden; background: {BG}; box-shadow: 0 0 0 10px #1C2420, 0 24px 50px rgba(10,15,13,.25); display: flex; flex-direction: column">'
            f'<div style="height: 44px; flex: none"></div><div style="flex: 1; overflow: hidden; padding: 6px 16px 16px; display: flex; flex-direction: column; gap: 14px">{body}</div>'
            f'<div style="height: 64px; flex: none; background: #FFFFFF; border-top: 1px solid {LINE}; display: flex; align-items: center; padding-bottom: 8px">{nav}</div></div>')

# ---------- F1: plain list ----------
def f1_rows(m=False, n=9):
    out = []
    for i, co, who, amt, d, proof, st in S[:n]:
        right = (f'<span style="display: flex; flex-direction: column; align-items: flex-end; gap: 3px; flex: none; text-align: right"><b style="font-size: {14 if m else 15}px; color: {GREEN}">{amt}</b>'
                 f'<span style="font-size: 12.5px; font-weight: 600; color: {MUTE}">{mine(st) or due(d)}</span></span>')
        out.append(f'<div style="display: flex; align-items: center; gap: {12 if m else 14}px; padding: {12 if m else 14}px 2px; border-top: 1px solid {LINE}">{logo(i, 38 if m else 42)}'
                   f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><b style="font-size: {15 if m else 16}px">{co}</b>'
                   f'<span style="font-size: {13 if m else 14}px; font-weight: 600; color: {MUTE}; line-height: 1.35">{who}</span></span>{right}</div>')
    return '<div style="display: flex; flex-direction: column; border-bottom: 1px solid ' + LINE + '">' + ''.join(out) + '</div>'
def f1(m=False):
    top = title('149 open settlements. Tap one to see if you qualify.', 28 if m else 34) + search() + tabs(['Nationwide', 'Near you'], 0, 14 if m else 15)
    return top + f1_rows(m, 7 if m else 9)

# ---------- F2: by deadline ----------
def f2_row(r, m=False):
    i, co, who, amt, d, proof, st = r
    btn = (f'<span style="font-size: 12.5px; font-weight: 800; color: {GREEN}; flex: none">{mine(st)}</span>' if st else
           f'<span style="width: 34px; height: 34px; flex: none; border-radius: 99px; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; align-items: center; justify-content: center; background: #FFFFFF">{ic("plus", 16, INK, 2.4)}</span>')
    return (f'<div style="display: flex; align-items: center; gap: 12px; padding: 12px 14px">{logo(i, 36)}'
            f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px"><span style="font-size: 15px; font-weight: 800">{co} <span style="color: {GREEN}">· {amt}</span></span>'
            f'<span style="font-size: 13px; font-weight: 600; color: {MUTE}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{who}</span></span>{btn}</div>')
def f2_group(t, rows, m=False, red=False):
    return (f'<div style="display: flex; flex-direction: column; gap: 8px"><span style="font-size: 12.5px; font-weight: 800; letter-spacing: 1px; color: {"#B8333A" if red else MUTE}">{t}</span>'
            f'<div style="background: #FFFFFF; border-radius: 16px; box-shadow: inset 0 0 0 1px {LINE}; display: flex; flex-direction: column">'
            + f'<div style="height: 1px; background: {LINE}; margin: 0 14px"></div>'.join(f2_row(r, m) for r in rows) + '</div></div>')
def f2(m=False):
    by = lambda lo, hi: [r for r in S if lo <= r[4] < hi]
    head = title('Sorted by deadline, so nothing slips by.', 28 if m else 34) + search()
    return head + f2_group('CLOSING THIS WEEK', by(0, 8), m, True) + f2_group('THIS MONTH', by(8, 32), m) + f2_group('LATER', by(32, 9999)[: 3 if m else 4], m)

# ---------- F3: cards ----------
def toggle(on=True):
    return (f'<span style="display: inline-flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 700; color: #43504A">'
            f'<span style="width: 38px; height: 22px; border-radius: 99px; background: {GREEN if on else "#C9D3CD"}; position: relative; display: inline-block"><span style="position: absolute; top: 3px; {"right" if on else "left"}: 3px; width: 16px; height: 16px; border-radius: 99px; background: #FFFFFF"></span></span>No proof needed</span>')
def f3_card(r):
    i, co, who, amt, d, proof, st = r
    foot = f'<span style="color: {GREEN}">{mine(st)}</span>' if st else due(d)
    return (f'<div style="background: #FFFFFF; border-radius: 18px; box-shadow: inset 0 0 0 1px {LINE}; padding: 16px; display: flex; flex-direction: column; gap: 10px">'
            f'<div style="display: flex; align-items: center; gap: 10px">{logo(i, 34)}<b style="font-size: 15px">{co}</b></div>'
            f'<b style="font-size: 22px; letter-spacing: -.5px">{amt}</b>'
            f'<span style="font-size: 13.5px; font-weight: 600; color: {MUTE}; line-height: 1.4; min-height: 38px">{who}</span>'
            f'<span style="font-size: 12.5px; font-weight: 700; color: {MUTE}; padding-top: 10px; border-top: 1px solid {LINE}">{foot}</span></div>')
def f3(m=False):
    rows = [r for r in S if not r[5]]
    head = title('Only showing claims that need no receipts.', 28 if m else 34)
    bar = (f'<div style="display: flex; align-items: center; gap: 14px; flex-wrap: wrap">' + search('100%' if m else '420px') + toggle() + '</div>')
    cols = 1 if m else 2
    grid = f'<div style="display: grid; grid-template-columns: repeat({cols}, minmax(0, 1fr)); gap: 12px">' + ''.join(f3_card(r) for r in rows[: 4 if m else 6]) + '</div>'
    return head + bar + grid

def board(name, label, note, d, m):
    page = (f'<div data-board style="width: 1720px; height: 1180px; box-sizing: border-box; padding: 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: {INK}; display: flex; flex-direction: column; gap: 26px">'
            f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: {GREEN}">{label}</span>'
            f'<span style="font-size: 16px; color: #43504A; font-weight: 600; max-width: 1100px; line-height: 1.45">{note}</span></div>'
            f'<div style="display: flex; gap: 60px; align-items: flex-start">{desk(d)}{phone(m)}</div></div>\n</x-dc>\n')
    open(os.path.join(OUT, f'{name}.dc.html'), 'w').write(HEAD % label.title() + page + JS.replace('"width":1926,"height":980', '"width":1720,"height":1180'))

if __name__ == '__main__':
    board('FindS1', 'FIND CLAIMS · S1 · PLAIN LIST', 'One list, no pills or buttons. Each row says who qualifies in plain words, with the payout and deadline on the right. The whole row opens the claim. Categories and sort move into search.', f1(), f1(True))
    board('FindS2', 'FIND CLAIMS · S2 · BY DEADLINE', 'Grouped by how soon each one closes, so the urgent ones are on top. A small + adds a claim; claims you already have say so instead.', f2(), f2(True))
    board('FindS3', 'FIND CLAIMS · S3 · QUIET CARDS', 'Cards lead with the payout, then who qualifies and the deadline. One "No proof needed" switch replaces the category chips.', f3(), f3(True))
    print('ok')

# ---------- round 2 (Nov 21 2026): Henry likes the deadline timeline, default sort Popular. S1 dropped. ----------
POP = ['apple', 'amazon', 'visa', 'googleplay', 'equifax', 'cvs', 'toyota', 'kia', 'realpage']
SP = sorted(S, key=lambda r: POP.index(r[0]))
def seg(items, on=0):
    return (f'<div style="display: inline-flex; padding: 4px; border-radius: 12px; background: #E3EAE6; gap: 2px">' + ''.join(
        f'<span style="font-size: 13.5px; font-weight: 800; padding: 7px 14px; border-radius: 9px; {"background: #FFFFFF; color: " + INK + "; box-shadow: 0 1px 2px rgba(10,15,13,.08)" if i == on else "color: " + MUTE}">{t}</span>' for i, t in enumerate(items)) + '</div>')
def bar(m=False, on=0):
    return search() + (f'<div style="display: flex; align-items: center; justify-content: space-between; gap: 10px">{seg(["Popular", "Closing soon"], on)}'
                       f'<span style="font-size: 13.5px; font-weight: 700; color: {MUTE}">{"Nationwide" if m else "Nationwide · Near you"}</span></div>')
def groups(rows):
    return [('CLOSING THIS WEEK', [r for r in rows if r[4] < 8], True), ('THIS MONTH', [r for r in rows if 8 <= r[4] < 32], False), ('LATER', [r for r in rows if r[4] >= 32], False)]

# S2a: timeline groups, popular first inside each group
def s2a(m=False):
    out = title('Most popular first, grouped by deadline.', 28 if m else 34) + bar(m)
    for t, rs, red in groups(SP):
        out += f2_group(t, rs[: 3 if m and t == 'LATER' else 9], m, red)
    return out
# S2b: popular list with a deadline label on the left of each row (one list, timeline chips)
def s2b_row(r):
    i, co, who, amt, d, proof, st = r
    when = ('This week', '#FDECEC', '#B8333A') if d < 8 else ('This month', '#FFF4DB', '#8A5A00') if d < 32 else ('Later', '#EEF2F0', '#43504A')
    btn = (f'<span style="font-size: 12.5px; font-weight: 800; color: {GREEN}; flex: none">{mine(st)}</span>' if st else
           f'<span style="width: 34px; height: 34px; flex: none; border-radius: 99px; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; align-items: center; justify-content: center; background: #FFFFFF">{ic("plus", 16, INK, 2.4)}</span>')
    return (f'<div style="display: flex; align-items: center; gap: 12px; padding: 12px 14px">{logo(i, 36)}'
            f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 3px"><span style="font-size: 15px; font-weight: 800">{co} <span style="color: {GREEN}">· {amt}</span></span>'
            f'<span style="font-size: 13px; font-weight: 600; color: {MUTE}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{who}</span>'
            f'<span style="align-self: flex-start; font-size: 11.5px; font-weight: 800; padding: 2px 8px; border-radius: 6px; background: {when[1]}; color: {when[2]}">{when[0]} · {d if d < 365 else "700+"} days</span></span>{btn}</div>')
def s2b(m=False):
    rows = SP[: 7 if m else 9]
    lst = (f'<div style="background: #FFFFFF; border-radius: 16px; box-shadow: inset 0 0 0 1px {LINE}; display: flex; flex-direction: column">'
           + f'<div style="height: 1px; background: {LINE}; margin: 0 14px"></div>'.join(s2b_row(r) for r in rows) + '</div>')
    return title('One list, most popular first. The tag says when it closes.', 28 if m else 34) + bar(m) + lst
# S2c: vertical timeline with dots, popular first inside each stop
def s2c(m=False):
    out = title('A timeline of what closes when, most popular first.', 28 if m else 34) + bar(m)
    for t, rs, red in groups(SP):
        rs = rs[: 3 if m and t == 'LATER' else 9]
        dot = '#B8333A' if red else GREEN
        items = ''.join(f'<div style="background: #FFFFFF; border-radius: 14px; box-shadow: inset 0 0 0 1px {LINE}">{f2_row(r, m)}</div>' for r in rs)
        out += (f'<div style="display: flex; gap: 14px"><div style="width: 14px; flex: none; display: flex; flex-direction: column; align-items: center"><span style="width: 12px; height: 12px; border-radius: 99px; background: {dot}; margin-top: 3px"></span><span style="flex: 1; width: 2px; background: {LINE}; margin-top: 4px"></span></div>'
                f'<div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 8px; padding-bottom: 6px"><span style="font-size: 12.5px; font-weight: 800; letter-spacing: 1px; color: {dot if red else MUTE}">{t}</span>{items}</div></div>')
    return out

# S3a: cards with Popular / Closing soon switch, popular first
def s3a(m=False):
    grid = f'<div style="display: grid; grid-template-columns: repeat({1 if m else 2}, minmax(0, 1fr)); gap: 12px">' + ''.join(f3_card(r) for r in SP[: 3 if m else 6]) + '</div>'
    return title('Most popular first.', 28 if m else 34) + bar(m) + grid
# S3b: one big "most claimed" card, then the grid
def s3b(m=False):
    i, co, who, amt, d, proof, st = SP[0]
    hero = (f'<div style="border-radius: 20px; background: {DARK}; color: #FFFFFF; padding: 20px; display: flex; {"flex-direction: column; gap: 12px" if m else "align-items: center; gap: 18px"}">'
            f'{logo(i, 52)}<span style="flex: 1; display: flex; flex-direction: column; gap: 4px"><span style="font-size: 12px; font-weight: 800; letter-spacing: 1px; color: {MINT}">MOST CLAIMED THIS WEEK</span>'
            f'<b style="font-size: 22px">{co} · {amt}</b><span style="font-size: 14px; font-weight: 600; color: #B7CEC4">{who}</span></span>'
            f'<span style="min-height: 44px; padding: 0 20px; border-radius: 99px; background: {MINT}; color: {DARK}; font-weight: 800; font-size: 15px; display: inline-flex; align-items: center; justify-content: center; flex: none">Check if I qualify</span></div>')
    grid = f'<div style="display: grid; grid-template-columns: repeat({1 if m else 2}, minmax(0, 1fr)); gap: 12px">' + ''.join(f3_card(r) for r in SP[1: 3 if m else 5]) + '</div>'
    return title('Most popular first.', 28 if m else 34) + bar(m) + hero + grid
# S3c: shelves you scroll sideways: Popular, Closing this week, No proof needed
def mini(r, w=230):
    i, co, who, amt, d, proof, st = r
    return (f'<div style="width: {w}px; flex: none; background: #FFFFFF; border-radius: 16px; box-shadow: inset 0 0 0 1px {LINE}; padding: 14px; display: flex; flex-direction: column; gap: 8px">'
            f'<div style="display: flex; align-items: center; gap: 8px">{logo(i, 28)}<b style="font-size: 14px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{co}</b></div>'
            f'<b style="font-size: 19px; letter-spacing: -.4px">{amt}</b><span style="font-size: 12.5px; font-weight: 600; color: {MUTE}; line-height: 1.35; min-height: 34px">{who}</span>'
            f'<span style="font-size: 12px; font-weight: 700; color: {MUTE}">{mine(st) or due(d)}</span></div>')
def shelf(t, rows, m, red=False):
    return (f'<div style="display: flex; flex-direction: column; gap: 10px"><div style="display: flex; justify-content: space-between; align-items: baseline"><b style="font-size: 17px; {"color: #B8333A" if red else ""}">{t}</b><span style="font-size: 13px; font-weight: 800; color: {GREEN}">See all</span></div>'
            f'<div style="display: flex; gap: 10px; overflow: hidden">' + ''.join(mini(r, 200 if m else 236) for r in rows) + '</div></div>')
def s3c(m=False):
    return (title('Most popular first, then what closes soon.', 28 if m else 34) + search()
            + shelf('Most popular', SP[:4], m) + shelf('Closing soon', [r for r in sorted(SP, key=lambda r: r[4]) if r[4] < 32], m, True) + shelf('No proof needed', [r for r in SP if not r[5]][2:6], m))

if __name__ == '__main__':
    import sys
    if 'r2' in sys.argv:
        for f in ('FindS1',): pass
        board('FindT1', 'TIMELINE · T1 · GROUPS, POPULAR INSIDE', 'Popular is the default. Claims stay grouped by when they close; inside each group the most popular come first. Closing soon switches to strict date order.', s2a(), s2a(True))
        board('FindT2', 'TIMELINE · T2 · ONE LIST WITH CLOSING TAGS', 'One list in popularity order. A small tag under each claim says This week, This month or Later, with the days left.', s2b(), s2b(True))
        board('FindT3', 'TIMELINE · T3 · VERTICAL TIMELINE', 'A line runs down the page with a stop for each period. Most popular first inside each stop.', s2c(), s2c(True))
        board('FindC1', 'CARDS · C1 · POPULAR / CLOSING SOON', 'Quiet cards in popularity order, with a Popular / Closing soon switch on top.', s3a(), s3a(True))
        board('FindC2', 'CARDS · C2 · MOST CLAIMED FIRST', 'The most claimed settlement gets one big dark card with Check if I qualify, then the rest as quiet cards.', s3b(), s3b(True))
        board('FindC3', 'CARDS · C3 · SHELVES', 'Three rows you scroll sideways: Most popular, Closing soon, No proof needed. See all opens the full list.', s3c(), s3c(True))
        print('r2 ok')

# ---------- round 3 (Nov 21 2026): Henry picked T3. Always grouped by deadline; sort inside groups Popular or A to Z.
# Nationwide / Near you made explicit: what each one means, counts, and which places Near you checks. ----------
LU.update({'globe': 'M12 2a10 10 0 1 0 0 20a10 10 0 1 0 0-20 M2 12h20 M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z',
           'pin2': 'M20 10c0 4.99-5.54 10.19-7.4 11.8a1 1 0 0 1-1.2 0C9.54 20.19 4 14.99 4 10a8 8 0 0 1 16 0 M12 7a3 3 0 1 0 0 6a3 3 0 1 0 0-6',
           'home': 'M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8 M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'})
LOCAL = [('l1', 'Austin Energy', 'You paid an Austin Energy bill from 2019 to 2024', 'Up to $60', 6, 'TX', '#B07A12', 'Austin, TX'),
         ('l2', 'Texas toll roads', 'You were charged a TxTag fee you did not owe', 'Up to $150', 24, 'TX', '#2C4FA8', 'Texas'),
         ('l3', 'Dallas apartments', 'You rented from a large Dallas landlord since 2020', 'Up to $250', 40, 'TX', '#4B33B5', 'Dallas, TX'),
         ('l4', 'Denver parking', 'You paid a Denver parking ticket from 2021 to 2023', '$35 per ticket', 95, 'CO', '#B8333A', 'Denver, CO')]
def ltile(c, sz=36):
    return f'<span style="width: {sz}px; height: {sz}px; flex: none; border-radius: {sz * .28:.0f}px; background: {c}; color: #FFFFFF; display: flex; align-items: center; justify-content: center">{ic("pin2", sz * .5, "#FFFFFF", 2.2)}</span>'
def lrow(r):
    i, co, who, amt, d, st, col, where = r
    return (f'<div style="background: #FFFFFF; border-radius: 14px; box-shadow: inset 0 0 0 1px {LINE}"><div style="display: flex; align-items: center; gap: 12px; padding: 12px 14px">{ltile(col)}'
            f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px"><span style="font-size: 15px; font-weight: 800">{co} <span style="color: {GREEN}">· {amt}</span></span>'
            f'<span style="font-size: 13px; font-weight: 600; color: {MUTE}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{who}</span>'
            f'<span style="font-size: 11.5px; font-weight: 800; color: #43504A; display: flex; align-items: center; gap: 4px">{ic("pin2", 12, "#43504A", 2.4)}{where}</span></span>'
            f'<span style="width: 34px; height: 34px; flex: none; border-radius: 99px; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; align-items: center; justify-content: center; background: #FFFFFF">{ic("plus", 16, INK, 2.4)}</span></div></div>')

def scope(near, m=False):
    def tab(on, icon, t, n, sub):
        st = (f'background: #FFFFFF; box-shadow: inset 0 0 0 2px {GREEN}, 0 6px 16px rgba(18,128,92,.10)' if on else f'background: transparent; box-shadow: inset 0 0 0 1px {LINE}')
        return (f'<div style="flex: 1; min-width: 0; border-radius: 16px; padding: {12 if m else 14}px; {st}; display: flex; gap: 10px; align-items: flex-start">'
                f'<span style="width: 34px; height: 34px; flex: none; border-radius: 10px; background: {"#E9F6EF" if on else "#EEF2F0"}; display: flex; align-items: center; justify-content: center">{ic(icon, 18, GREEN if on else MUTE, 2.2)}</span>'
                f'<span style="display: flex; flex-direction: column; gap: 2px; min-width: 0"><span style="font-size: 15px; font-weight: 800; color: {INK if on else "#43504A"}">{t} <span style="color: {MUTE}; font-weight: 700">{n}</span></span>'
                f'<span style="font-size: 12.5px; font-weight: 600; color: {MUTE}; line-height: 1.35">{sub}</span></span></div>')
    return (f'<div style="display: flex; gap: 10px">' + tab(not near, 'globe', 'Nationwide', '149', 'Open to anyone in the US' if m else 'Open to anyone in the US who qualifies')
            + tab(near, 'pin2', 'Near you', '4', 'Places you have lived' if m else 'Only for people who lived in a certain city or state') + '</div>')
def places(m=False):
    chip = lambda t, home=False: (f'<span style="display: inline-flex; align-items: center; gap: 6px; font-size: 13px; font-weight: 800; padding: 6px 11px; border-radius: 99px; background: #FFFFFF; box-shadow: inset 0 0 0 1px {LINE}">'
                                  f'{ic("home" if home else "pin2", 13, GREEN, 2.4)}{t}</span>')
    return (f'<div style="border-radius: 16px; background: #E9F6EF; padding: 14px 16px; display: flex; flex-direction: column; gap: 10px">'
            f'<span style="font-size: 14px; font-weight: 700; color: {DARK}; line-height: 1.45">Some settlements only pay people who lived in one city or state. We check every place on your profile, now and in the past.</span>'
            f'<div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center">{chip("Austin, TX (home)", True)}{chip("Dallas, TX")}{chip("Denver, CO")}'
            f'<span style="font-size: 13px; font-weight: 800; color: {GREEN}; margin-left: 4px">+ Add a place you lived</span></div></div>')
def sorter(on=0):
    return (f'<div style="display: flex; align-items: center; justify-content: flex-end; gap: 8px"><span style="font-size: 13px; font-weight: 700; color: {MUTE}">Sort</span>{seg(["Popular", "A to Z"], on)}</div>')
def timeline(rows, row, m=False):
    out = ''
    for t, rs, red in rows:
        if not rs: continue
        dot = '#B8333A' if red else GREEN
        out += (f'<div style="display: flex; gap: 14px"><div style="width: 14px; flex: none; display: flex; flex-direction: column; align-items: center"><span style="width: 12px; height: 12px; border-radius: 99px; background: {dot}; margin-top: 3px"></span><span style="flex: 1; width: 2px; background: {LINE}; margin-top: 4px"></span></div>'
                f'<div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 8px; padding-bottom: 6px"><span style="font-size: 12.5px; font-weight: 800; letter-spacing: 1px; color: {dot if red else MUTE}">{t} <span style="color: #8A968F">· {len(rs)}</span></span>'
                + ''.join(row(r) for r in rs) + '</div></div>')
    return out
def lgroups(rows):
    return [('CLOSING THIS WEEK', [r for r in rows if r[4] < 8], True), ('THIS MONTH', [r for r in rows if 8 <= r[4] < 32], False), ('LATER', [r for r in rows if r[4] >= 32], False)]
def t3v2(m=False, near=False):
    head = title('Grouped by when each one closes.', 28 if m else 34) + search() + scope(near, m)
    if near:
        return head + places(m) + sorter() + timeline(lgroups(LOCAL), lrow, m)
    nat = [(t, rs[: 3 if m and t == 'LATER' else 9], red) for t, rs, red in groups(SP)]
    return head + sorter() + timeline(nat, lambda r: f'<div style="background: #FFFFFF; border-radius: 14px; box-shadow: inset 0 0 0 1px {LINE}">{f2_row(r, m)}</div>', m)

def board2(name, label, note, d, m, h=1500):
    page = (f'<div data-board style="width: 1720px; height: {h}px; box-sizing: border-box; padding: 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: {INK}; display: flex; flex-direction: column; gap: 26px">'
            f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: {GREEN}">{label}</span>'
            f'<span style="font-size: 16px; color: #43504A; font-weight: 600; max-width: 1100px; line-height: 1.45">{note}</span></div>'
            f'<div style="display: flex; gap: 60px; align-items: flex-start">{desk(d, h - 200)}{phone(m, h - 200)}</div></div>\n</x-dc>\n')
    open(os.path.join(OUT, f'{name}.dc.html'), 'w').write(HEAD % label.title() + page + JS.replace('"width":1926,"height":980', f'"width":1720,"height":{h}'))

if __name__ == '__main__':
    import sys
    if 'r3' in sys.argv:
        board2('FindV1', 'FIND CLAIMS · T3 · NATIONWIDE', 'Always grouped by deadline: Closing this week, This month, Later. The Sort switch (Popular or A to Z) orders claims inside each group. Nationwide and Near you are two big tabs that say who each list is for.', t3v2(), t3v2(True))
        board2('FindV2', 'FIND CLAIMS · T3 · NEAR YOU', 'Near you explains itself: a green note says some settlements only pay people from one city or state, and lists every place we check (home plus past addresses) with + Add a place you lived. Each local claim says which place it matched.', t3v2(near=True), t3v2(True, True))
        print('r3 ok')
