# Mobile-only drafts for "How Claimclub works" (desktop keeps the three phones). Board HowN.dc.html: 4 phones side by side, each playable.
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from how4 import ic, HEAD, OUT
import howS
from howS import STEPS, phone, crop, num, MINT, DARK, GREEN

BAND = 'background: radial-gradient(120% 80% at 100% 0%, #5BE7AC 0%, rgba(91,231,172,0) 60%), linear-gradient(170deg, #3DDC97 0%, #2FC787 100%)'
HEADM = lambda t='How Claimclub works': f'<h2 style="margin: 0 0 18px; font-size: 30px; letter-spacing: -1.2px; line-height: 1.08; color: {DARK}; text-align: center">{t}</h2>'
wrap = lambda inner: f'<section style="{BAND}; padding: 44px 16px 48px; box-sizing: border-box">{inner}</section>'
ctx = lambda t: f'<div style="padding: 36px 20px; font-size: 13px; font-weight: 800; letter-spacing: 1px; color: #A3AEA8; text-align: center">{t}</div>'

# N1: tabs. Three step pills, one phone, auto-advances with a progress fill.
def n1():
    pills = ''.join(f'<button data-i="{i}" class="tb" style="position: relative; overflow: hidden; flex: 1; border: 0; border-radius: 14px; padding: 10px 6px; background: rgba(255,255,255,.55); color: {DARK}; font: 800 12.5px Manrope, sans-serif; line-height: 1.2; cursor: pointer">'
                    f'<span class="tf" style="position: absolute; left: 0; bottom: 0; height: 3px; width: 0; background: {DARK}"></span>{i + 1}. {("Answer", "We file", "Get paid")[i]}</button>' for i, (t, d) in enumerate(STEPS))
    views = ''.join(f'<div class="tv" style="display: {"flex" if i == 0 else "none"}; flex-direction: column; align-items: center; gap: 14px"><p style="margin: 0; font-size: 15px; font-weight: 700; color: #0F3B2E; text-align: center">{d}</p>{phone(i, 250)}</div>' for i, (t, d) in enumerate(STEPS))
    return wrap(HEADM() + f'<div class="tabsN" style="display: flex; flex-direction: column; gap: 16px"><div style="display: flex; gap: 6px; padding: 5px; border-radius: 18px; background: rgba(255,255,255,.35)">{pills}</div>{views}</div>')

# N2: compact rows. Cropped phone on the left, step text on the right. Short to scroll past.
def n2():
    rows = ''.join(f'<div style="display: flex; align-items: center; gap: 14px; padding: 14px 14px 0 14px; border-radius: 24px; background: #FFFFFF; box-shadow: 0 10px 24px rgba(10,15,13,.08); overflow: hidden">'
                   f'<div style="flex: none; width: 128px; align-self: flex-end">{crop(i, 190, 128)}</div>'
                   f'<div style="display: flex; flex-direction: column; gap: 6px; padding-bottom: 14px">{num(i, DARK, "#FFFFFF")}<b style="font-size: 18px; letter-spacing: -.3px; line-height: 1.2; color: {DARK}">{t}</b><span style="font-size: 14px; color: #43504A; line-height: 1.4">{d}</span></div></div>' for i, (t, d) in enumerate(STEPS))
    return wrap(HEADM() + f'<div style="display: flex; flex-direction: column; gap: 12px">{rows}</div>')

# N3: swipe carousel. One step per slide, dots follow the swipe.
def n3():
    slides = ''.join(f'<div class="cs" style="flex: 0 0 290px; scroll-snap-align: center; display: flex; flex-direction: column; align-items: center; gap: 14px">'
                     f'<span style="display: inline-flex; align-items: center; gap: 10px; padding: 8px 16px 8px 8px; border-radius: 99px; background: #FFFFFF; box-shadow: 0 6px 16px rgba(10,15,13,.07)">{num(i, DARK, "#FFFFFF")}<b style="font-size: 15px">{t}</b></span>{phone(i, 240)}</div>' for i, (t, d) in enumerate(STEPS))
    dots = ''.join(f'<span class="cd" style="width: {22 if i == 0 else 8}px; height: 8px; border-radius: 99px; background: {DARK if i == 0 else "rgba(15,59,46,.25)"}; transition: all .2s"></span>' for i in range(3))
    return wrap(HEADM() + f'<div class="carN"><div class="ct" style="display: flex; gap: 14px; overflow-x: auto; scroll-snap-type: x mandatory; margin: 0 -16px; padding: 4px 34px 16px; scrollbar-width: none">{slides}</div>'
                f'<div style="display: flex; justify-content: center; align-items: center; gap: 6px">{dots}<span style="margin-left: 10px; font-size: 12px; font-weight: 800; color: {DARK}; opacity: .6">Swipe</span></div></div>')

# N4: story. One phone with three progress bars; plays by itself, tap left or right side to go back or forward.
def n4():
    bars = ''.join(f'<span style="flex: 1; height: 4px; border-radius: 99px; background: rgba(15,59,46,.18); overflow: hidden"><span class="sb" style="display: block; height: 100%; width: 0; background: {DARK}"></span></span>' for i in range(3))
    caps = ''.join(f'<div class="sc" style="display: {"flex" if i == 0 else "none"}; flex-direction: column; align-items: center; gap: 4px; text-align: center"><b style="font-size: 20px; letter-spacing: -.4px; color: {DARK}">{i + 1}. {t}</b><span style="font-size: 14.5px; color: #1F4A3B; font-weight: 600">{d}</span></div>' for i, (t, d) in enumerate(STEPS))
    phones = ''.join(f'<div class="sp" style="display: {"block" if i == 0 else "none"}">{phone(i, 250)}</div>' for i in range(3))
    return wrap(HEADM() + f'<div class="storyN" style="display: flex; flex-direction: column; align-items: center; gap: 14px"><div style="display: flex; gap: 5px; width: 250px">{bars}</div>{caps}'
                f'<div style="position: relative">{phones}<button class="sl" aria-label="Back" style="position: absolute; left: 0; top: 0; width: 40%; height: 100%; border: 0; background: none; cursor: pointer"></button><button class="sr" aria-label="Next" style="position: absolute; right: 0; top: 0; width: 60%; height: 100%; border: 0; background: none; cursor: pointer"></button></div>'
                f'<span style="font-size: 12px; font-weight: 800; color: {DARK}; opacity: .6">Tap the phone to skip</span></div>')

DESIGNS = [('1 · Tabs, one phone', n1), ('2 · Compact rows', n2), ('3 · Swipe carousel', n3), ('4 · Story, plays by itself', n4)]

PLAY = r"""
  componentDidMount() {
    const roots = [document]; document.querySelectorAll('*').forEach((el) => { if (el.shadowRoot) roots.push(el.shadowRoot); });
    const all = (s) => roots.flatMap((r) => [...r.querySelectorAll(s)]);
    all('.tabsN').forEach((f) => { if (f._p) return; f._p = 1;
      const b = [...f.querySelectorAll('.tb')], v = [...f.querySelectorAll('.tv')]; let i = 0, t0 = performance.now(), D = 3800;
      const go = (k) => { i = k; t0 = performance.now(); v.forEach((x, n) => { x.style.display = n === i ? 'flex' : 'none'; }); b.forEach((x, n) => { x.style.background = n === i ? '#FFFFFF' : 'rgba(255,255,255,.55)'; }); };
      b.forEach((x, n) => x.addEventListener('click', () => go(n))); go(0);
      const tick = (now) => { const p = Math.min(1, (now - t0) / D); b.forEach((x, n) => { x.querySelector('.tf').style.width = n === i ? (p * 100) + '%' : '0'; }); if (p >= 1) go((i + 1) % 3); requestAnimationFrame(tick); }; requestAnimationFrame(tick); });
    all('.carN').forEach((f) => { if (f._p) return; f._p = 1;
      const t = f.querySelector('.ct'), d = [...f.querySelectorAll('.cd')];
      t.addEventListener('scroll', () => { const k = Math.round(t.scrollLeft / 304); d.forEach((x, n) => { x.style.width = n === k ? '22px' : '8px'; x.style.background = n === k ? '#0F3B2E' : 'rgba(15,59,46,.25)'; }); }); });
    all('.storyN').forEach((f) => { if (f._p) return; f._p = 1;
      const sb = [...f.querySelectorAll('.sb')], sc = [...f.querySelectorAll('.sc')], sp = [...f.querySelectorAll('.sp')]; let i = 0, t0 = performance.now(), D = 4200;
      const go = (k) => { i = (k + 3) % 3; t0 = performance.now(); sc.forEach((x, n) => { x.style.display = n === i ? 'flex' : 'none'; }); sp.forEach((x, n) => { x.style.display = n === i ? 'block' : 'none'; }); };
      f.querySelector('.sl').addEventListener('click', () => go(i - 1)); f.querySelector('.sr').addEventListener('click', () => go(i + 1));
      const tick = (now) => { const p = Math.min(1, (now - t0) / D); sb.forEach((x, n) => { x.style.width = n < i ? '100%' : n === i ? (p * 100) + '%' : '0'; }); if (p >= 1) go(i + 1); requestAnimationFrame(tick); }; requestAnimationFrame(tick); });
  }
"""

def build():
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    W = 24 * 2 + 4 * 390 + 3 * 40
    y0 = max(b['y'] + b['h'] for k, b in c['boards'].items() if k != 'HowN.dc.html') + 260
    c['notes']['tHN'] = {'x': 0, 'y': y0, 'text': 'How it works on phones · 4 new designs (desktop stays the same). Scroll and tap inside each phone.', 'kind': 'title1', 'maxW': W, 'w': 240}
    if 'tHN' not in c['noteOrder']: c['noteOrder'].append('tHN')
    frames = ''.join(f'<div style="display: flex; flex-direction: column; gap: 10px"><div style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #43504A">{t.upper()}</div>'
                     f'<div class="scroll" style="width: 390px; height: 844px; flex: none; overflow-y: auto; border-radius: 28px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{ctx("SETTLEMENTS ABOVE")}{fn()}{ctx("REVIEWS BELOW")}</div></div>' for t, fn in DESIGNS)
    page = (f'<div style="width: {W}px; height: 940px; box-sizing: border-box; padding: 24px; background: #E7ECE9; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; gap: 40px">{frames}</div>\n</x-dc>\n')
    js = '''<script type="text/x-dc" data-dc-script data-props='{"$preview":{"width":%d,"height":940}}'>
class Component extends DCLogic { renderVals() { return {}; }''' % W + PLAY + '''}
</script>
</body>
</html>
'''
    title = 'How it works on phones · 4 designs'
    open(os.path.join(OUT, 'HowN.dc.html'), 'w').write(HEAD % title + page + js)
    c['boards']['HowN.dc.html'] = {'x': 0, 'y': y0 + 220, 'w': W, 'h': 940, 'is_interactive': True, 'title': title}
    if 'HowN.dc.html' not in c['order']: c['order'].append('HowN.dc.html')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w'))
    print('built HowN y0', y0, 'w', W)

if __name__ == '__main__':
    build()
