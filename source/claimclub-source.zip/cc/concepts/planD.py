# "Choose your plan" drafts (Nov 15 2026): every plan's pricing visible at once (today, per month, renewal,
# savings), so nobody has to tap through the 1/3/6 month switch. Writes PlanD1..3.dc.html (desktop with the
# flow's side panel, plus a phone).
import os
from how4 import HEAD, JS, OUT
from perksD import ic, phone, LU, INK, MUTE, LINE, MINT, GREEN, DARK
from choiceD import LOGO, mint_btn

# exact numbers: first period is 75% off; renewal per month = full price / months; savings vs paying monthly
PLANS = [
    dict(id='1m', name='1 month', today='$7.99', per='$7.99', perlab='first month', then='Then $29.99 a month', thenmo='$29.99/mo', save='', tag=''),
    dict(id='3m', name='3 months', today='$18.99', per='$6.33', perlab='a month for 3 months', then='Then $74.99 every 3 months', thenmo='$25.00/mo', save='Save 17%', tag='MOST POPULAR'),
    dict(id='6m', name='6 months', today='$29.99', per='$5.00', perlab='a month for 6 months', then='Then $119.99 every 6 months', thenmo='$20.00/mo', save='Save 33%', tag='BEST VALUE'),
]
SEL = 1  # drafts show the 3 month plan selected

def side():
    pts = ''.join(f'<div style="display: flex; align-items: center; gap: 10px; font-size: 15px; font-weight: 700; color: #FFFFFF"><span style="width: 6px; height: 6px; border-radius: 99px; background: {MINT}"></span>{t}</div>'
                  for t in ['Every settlement is court-approved', 'We pre-fill and submit your claims', 'Payouts come straight from the settlement', 'Cancel anytime'])
    return (f'<div style="width: 400px; flex: none; padding: 36px; box-sizing: border-box; background: radial-gradient(120% 70% at 100% 0%, rgba(61,220,151,.22), transparent 55%), linear-gradient(170deg, #1B5A44, #0A2A20); display: flex; flex-direction: column; gap: 10px">'
            f'<span style="font-size: 12px; font-weight: 800; letter-spacing: 1.4px; color: #CFE9DD">YOUR ESTIMATE SO FAR</span><b style="font-size: 52px; letter-spacing: -2px; color: #FFFFFF; line-height: 1">$1,400</b>'
            f'<span style="font-size: 15px; font-weight: 700; color: #CFE9DD">6 claims ready to file</span><div style="display: flex; flex-direction: column; gap: 12px; margin-top: 14px">{pts}</div></div>')
def desk(main):
    return (f'<div style="width: 1280px; height: 860px; flex: none; border-radius: 16px; overflow: hidden; background: #F7F9F8; box-shadow: 0 30px 80px rgba(10,15,13,.18); display: flex; flex-direction: column">'
            f'<div style="height: 72px; flex: none; display: flex; align-items: center; justify-content: space-between; padding: 0 36px; border-bottom: 1px solid #E8EEEA; background: #FFFFFF">'
            f'<span style="display: flex; align-items: center; gap: 16px"><span style="width: 42px; height: 42px; border-radius: 12px; background: #F1F4F2; display: flex; align-items: center; justify-content: center">{ic("back", 18, INK, 2.4)}</span>{LOGO}</span>'
            f'<span style="font-size: 13.5px; font-weight: 700; color: {MUTE}">Not a law firm · Free to check</span></div>'
            f'<div style="flex: 1; display: flex; min-height: 0">{side()}<div style="flex: 1; display: flex; justify-content: center; align-items: center; padding: 24px 40px"><div style="width: 780px; display: flex; flex-direction: column; gap: 16px">{main}</div></div></div></div>')
def mob(inner, foot):
    return phone(f'<div style="padding: 56px 18px 0; display: flex; align-items: center; gap: 12px"><span style="width: 34px; height: 34px; border-radius: 99px; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; align-items: center; justify-content: center">{ic("back", 17, INK, 2.4)}</span>{LOGO}</div>'
                 f'<div style="flex: 1; overflow: hidden; padding: 12px 18px 0; display: flex; flex-direction: column; gap: 12px">{inner}</div>'
                 f'<div style="padding: 12px 18px 30px; background: #FFFFFF; box-shadow: 0 -10px 24px rgba(10,15,13,.06); display: flex; flex-direction: column; gap: 8px">{foot}</div>', bg='#F3F6F4')
def head(center=True, sz=32):
    a = 'center' if center else 'flex-start'
    return (f'<div style="display: flex; flex-direction: column; align-items: {a}; gap: 6px; text-align: {a if center else "left"}"><b style="font-size: {sz}px; letter-spacing: -1px; line-height: 1.12">Choose your plan</b>'
            f'<span style="font-size: {15 if sz < 30 else 16}px; font-weight: 600; color: {MUTE}">Every plan files your 6 claims and every new one. Cancel anytime.</span></div>')
def cta(p=None):
    p = p or PLANS[SEL]
    return mint_btn(f'{ic("lock", 16, DARK, 2.4)}Start getting paid · {p["today"]} today')
def fine(p=None):
    p = p or PLANS[SEL]
    return f'<span style="text-align: center; font-size: 12.5px; font-weight: 600; color: {MUTE}">{p["then"]}. Cancel anytime in your dashboard.</span>'
def radio(on):
    return (f'<span style="width: 22px; height: 22px; flex: none; border-radius: 99px; box-shadow: inset 0 0 0 2px {GREEN if on else "#C9D3CE"}; display: flex; align-items: center; justify-content: center">'
            + (f'<span style="width: 12px; height: 12px; border-radius: 99px; background: {GREEN}"></span>' if on else '') + '</span>')
def tag(t, dark=False):
    return f'<span style="padding: 4px 9px; border-radius: 99px; background: {GREEN if not dark else MINT}; color: {"#FFFFFF" if not dark else DARK}; font-size: 11px; font-weight: 800; letter-spacing: .4px; white-space: nowrap">{t}</span>' if t else ''
def save(t):
    return f'<span style="padding: 3px 8px; border-radius: 99px; background: #FFF4DB; color: #8A5A00; font-size: 12px; font-weight: 800; white-space: nowrap">{t}</span>' if t else ''

# ---------- 1: three cards side by side; phones get three stacked rows ----------
def card1(p, on):
    return (f'<div style="flex: 1; position: relative; border-radius: 20px; padding: 22px 18px 18px; background: #FFFFFF; box-shadow: {"0 0 0 2.5px " + GREEN + ", 0 14px 30px rgba(18,128,92,.16)" if on else "inset 0 0 0 1.5px " + LINE}; display: flex; flex-direction: column; gap: 10px">'
            + (f'<span style="position: absolute; top: -11px; left: 18px">{tag(p["tag"])}</span>' if p['tag'] else '') +
            f'<span style="display: flex; justify-content: space-between; align-items: center"><b style="font-size: 18px">{p["name"]}</b>{radio(on)}</span>'
            f'<span style="display: flex; align-items: baseline; gap: 4px"><b style="font-size: 36px; letter-spacing: -1.2px; line-height: 1">{p["per"]}</b><span style="font-size: 13px; font-weight: 700; color: {MUTE}">/mo</span></span>'
            f'<span style="font-size: 13px; font-weight: 600; color: {MUTE}; margin-top: -4px">{p["today"]} today, {p["perlab"]}</span>'
            f'<div style="height: 1px; background: #EEF1EF; margin: 2px 0"></div>'
            f'<span style="font-size: 13px; font-weight: 700; color: {INK}">{p["then"]}</span>'
            f'<span style="display: flex; align-items: center; gap: 6px; font-size: 12.5px; font-weight: 600; color: {MUTE}">{p["thenmo"]} after {save(p["save"])}</span></div>')
def row1(p, on):
    return (f'<div style="position: relative; border-radius: 18px; padding: 14px 14px 12px; background: #FFFFFF; box-shadow: {"0 0 0 2.5px " + GREEN if on else "inset 0 0 0 1.5px " + LINE}; display: flex; gap: 12px; align-items: flex-start">'
            + (f'<span style="position: absolute; top: -10px; right: 14px">{tag(p["tag"])}</span>' if p['tag'] else '') + radio(on) +
            f'<span style="flex: 1; display: flex; flex-direction: column; gap: 3px"><span style="display: flex; justify-content: space-between; align-items: baseline"><b style="font-size: 16px">{p["name"]}</b><span><b style="font-size: 20px; letter-spacing: -0.5px">{p["today"]}</b><span style="font-size: 12px; font-weight: 700; color: {MUTE}"> today</span></span></span>'
            f'<span style="font-size: 12.5px; font-weight: 600; color: {MUTE}">{p["per"]}/mo now · {p["then"].replace("Then ", "then ")}</span>'
            + (f'<span style="margin-top: 2px">{save(p["save"])}</span>' if p['save'] else '') + '</span></div>')
def v1():
    d = desk(head() + f'<div style="display: flex; gap: 14px; margin-top: 10px">' + ''.join(card1(p, i == SEL) for i, p in enumerate(PLANS)) + '</div>' + cta() + fine())
    m = mob(head(False, 26) + '<div style="display: flex; flex-direction: column; gap: 12px; margin-top: 6px">' + ''.join(row1(p, i == SEL) for i, p in enumerate(PLANS)) + '</div>', cta() + fine())
    return d, m

# ---------- 2: comparison table, the chosen column highlighted ----------
ROWS = [('Pay today', 'today'), ('Per month now', 'per'), ('Renews at', 'then'), ('Per month after', 'thenmo'), ('You save', 'save')]
def cell(p, k):
    v = p[k]
    if k == 'then': v = v.replace('Then ', '').replace(' a month', '/mo').replace('every 3 months', '/3 mo').replace('every 6 months', '/6 mo')
    if k == 'save': v = v.replace('Save ', '') if v else '-'
    if k == 'per': v = v + '/mo'
    return v
def table(m=False):
    w = '84px' if m else '1fr'
    cols = f'grid-template-columns: {"96px" if m else "1.1fr"} {w} {w} {w}'
    top = ''.join(f'<div style="padding: {10 if m else 14}px 6px; text-align: center; display: flex; flex-direction: column; align-items: center; gap: 4px; {"background: " + GREEN + "; color: #FFFFFF; border-radius: 16px 16px 0 0" if i == SEL else ""}">'
                  f'<span style="height: 16px; font-size: {9.5 if m else 10.5}px; font-weight: 800; letter-spacing: .3px; color: {MINT if i == SEL else GREEN}">{(p["tag"].replace("MOST ", "").replace(" VALUE", "") if m else p["tag"])}</span><b style="font-size: {14 if m else 17}px">{p["name"]}</b></div>' for i, p in enumerate(PLANS))
    body = ''
    for r, (lab, k) in enumerate(ROWS):
        big = k in ('today',)
        body += (f'<div style="display: grid; {cols}; align-items: center; {"border-top: 1px solid #EEF1EF" if r else ""}"><span style="padding: {11 if m else 14}px {10 if m else 16}px; font-size: {12 if m else 14}px; font-weight: 700; color: {MUTE}">{lab}</span>'
                 + ''.join(f'<span style="padding: {11 if m else 14}px 4px; text-align: center; font-size: {(17 if m else 22) if big else (12.5 if m else 14.5)}px; font-weight: 800; letter-spacing: {"-0.5px" if big else "0"}; color: {(GREEN if k == "save" and p[k] else INK)}; {"background: #F1FAF5; align-self: stretch; display: flex; align-items: center; justify-content: center" if i == SEL else ""}">{cell(p, k)}</span>' for i, p in enumerate(PLANS)) + '</div>')
    pick = (f'<div style="display: grid; {cols}; align-items: center; border-top: 1px solid #EEF1EF"><span></span>'
            + ''.join(f'<span style="padding: {10 if m else 14}px 6px; display: flex; justify-content: center; {"background: #F1FAF5; border-radius: 0 0 16px 16px" if i == SEL else ""}">' +
                      (f'<span style="padding: 7px {10 if m else 16}px; border-radius: 99px; background: {GREEN}; color: #FFFFFF; font-size: {12 if m else 13.5}px; font-weight: 800; display: flex; align-items: center; gap: 5px">{ic("check", 13, "#FFFFFF", 3)}{"Picked" if m else "Selected"}</span>' if i == SEL
                       else f'<span style="padding: 7px {12 if m else 18}px; border-radius: 99px; box-shadow: inset 0 0 0 1.5px {INK}; font-size: {12 if m else 13.5}px; font-weight: 800">Pick</span>') + '</span>' for i, p in enumerate(PLANS)) + '</div>')
    return (f'<div style="display: flex; flex-direction: column"><div style="display: grid; {cols}; align-items: end"><span></span>{top}</div>'
            f'<div style="border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}; overflow: hidden">{body}{pick}</div></div>')
def v2():
    d = desk(head() + table() + cta() + fine())
    m = mob(head(False, 26) + table(True), cta() + fine())
    return d, m

# ---------- 3: list of plans, per-month price big, the chosen one opens to show today + renewal ----------
def row3(p, on, m=False):
    detail = (f'<div style="display: flex; justify-content: space-between; align-items: center; gap: 10px; margin-top: 10px; padding: 10px 12px; border-radius: 12px; background: #F1FAF5">'
              f'<span style="display: flex; flex-direction: column; gap: 1px"><span style="font-size: 12px; font-weight: 700; color: {MUTE}">Pay today</span><b style="font-size: {20 if m else 22}px; letter-spacing: -0.5px">{p["today"]}</b></span>'
              f'<span style="display: flex; flex-direction: column; gap: 1px; text-align: right"><span style="font-size: 12px; font-weight: 700; color: {MUTE}">After that</span><b style="font-size: {13 if m else 14.5}px">{p["then"].replace("Then ", "")}</b></span></div>') if on else ''
    return (f'<div style="border-radius: 18px; padding: {14 if m else 16}px {14 if m else 18}px; background: #FFFFFF; box-shadow: {"0 0 0 2.5px " + GREEN + ", 0 12px 26px rgba(18,128,92,.14)" if on else "inset 0 0 0 1.5px " + LINE}">'
            f'<div style="display: flex; align-items: center; gap: 12px">{radio(on)}<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 3px"><span style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap"><b style="font-size: {16 if m else 17}px">{p["name"]}</b>{tag(p["tag"])}</span>'
            f'<span style="font-size: 12.5px; font-weight: 600; color: {MUTE}">{p["today"]} today · {p["thenmo"]} after {"" if m else save(p["save"])}</span></span>'
            f'<span style="flex: none; text-align: right; display: flex; flex-direction: column"><b style="font-size: {22 if m else 26}px; letter-spacing: -0.8px; line-height: 1.1">{p["per"]}</b><span style="font-size: 11.5px; font-weight: 700; color: {MUTE}">a month now</span></span></div>{detail}</div>')
def v3():
    d = desk(head() + '<div style="display: flex; flex-direction: column; gap: 12px; margin-top: 8px">' + ''.join(row3(p, i == SEL) for i, p in enumerate(PLANS)) + '</div>' + cta() + fine())
    m = mob(head(False, 26) + '<div style="display: flex; flex-direction: column; gap: 10px; margin-top: 4px">' + ''.join(row3(p, i == SEL, True) for i, p in enumerate(PLANS)) + '</div>', cta() + fine())
    return d, m

INFO = {
 1: ('PLAN PAGE · DRAFT 1 · THREE CARDS', 'All three plans side by side. Each card shows the monthly price big, what you pay today, the renewal and how much it saves. The 3 month plan is marked Most popular and the 6 month plan Best value. Phones get the same three plans as stacked rows.', v1),
 2: ('PLAN PAGE · DRAFT 2 · COMPARISON TABLE', 'One table with a column per plan and a row for each price: pay today, per month now, renews at, per month after, and you save. The picked plan\'s column is green; tap Pick under another column to switch.', v2),
 3: ('PLAN PAGE · DRAFT 3 · PLAN LIST', 'Three rows with the monthly price big on the right and today\'s price and the renewal in one line. The picked plan opens to show "Pay today" and "After that" side by side.', v3),
}
if __name__ == '__main__':
    for n, (title, desc, fn) in INFO.items():
        d, m = fn()
        page = ('<div data-board style="width: 1840px; height: 1060px; box-sizing: border-box; padding: 36px 40px; background: #E9EEEB; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 26px">'
                f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #12805C">{title}</span>'
                f'<span style="font-size: 16px; color: #43504A; max-width: 1640px; line-height: 1.5; font-weight: 600">{desc}</span>'
                '<span style="font-size: 13px; color: #8A968F; font-weight: 600">Exact prices: first period is 75% off; after that $29.99 a month, $74.99 every 3 months ($25.00/mo) or $119.99 every 6 months ($20.00/mo). Savings compare with paying monthly.</span></div>'
                f'<div style="display: flex; gap: 46px; align-items: flex-start">{d}{m}</div></div>\n</x-dc>\n')
        open(os.path.join(OUT, f'PlanD{n}.dc.html'), 'w').write(HEAD % f'Plan page draft {n}' + page + JS.replace('"width":1926,"height":980', '"width":1840,"height":1060'))
    print('ok')
