# Member dashboard iterations (Nov 14): one shell for the whole membership, then 3 iterations each of the Dashboard overview,
# Claim a refund and Subscription Manager pages. Boards DashD1..3, RefundR1..3, SubsS1..3 (desktop 1440 + mobile 390). Design only.
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from how4 import ic, IC, HEAD, JS, OUT
from refundC import mark, brand, FOUND, SUBS, PROG, STAGES, CLAIMS, MINT, DARK, GREEN
IC.update({'lock': '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path>', 'chevd': '<path d="m6 9 6 6 6-6"></path>',
           'logout': '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" x2="9" y1="12" y2="12"></line>',
           'card': '<rect width="20" height="14" x="2" y="5" rx="2"></rect><line x1="2" x2="22" y1="10" y2="10"></line>', 'cal': '<rect width="18" height="18" x="3" y="4" rx="2"></rect><path d="M16 2v4 M8 2v4 M3 10h18"></path>',
           'trend': '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline><polyline points="16 7 22 7 22 13"></polyline>'})
fmt = lambda v: '$' + format(v, ',.2f')
F = [(k, src, nm, why, float(a[1:])) for k, src, nm, why, a in FOUND]
UNUSED = [x for x in SUBS if x[5] == 'unused']; TOTAL_S = sum(x[3] for x in SUBS); WASTE = sum(x[3] for x in UNUSED)
NAV = [('home', 'grid', 'Dashboard', ''), ('claims', 'file', 'Your claims', '5'), ('find', 'list', 'Find claims', ''), ('refunds', 'receipt', 'Claim a refund', '5'), ('subs', 'repeat', 'Subscription Manager', '3')]
MNAV = [('home', 'grid', 'Dashboard'), ('claims', 'file', 'Claims'), ('find', 'search', 'Find'), ('refunds', 'receipt', 'Refunds'), ('subs', 'repeat', 'Subscriptions')]

# ---------- shell ----------
def avatar(s=40, ring=71):
    C = 2 * 3.1416 * (s / 2 - 3)
    return (f'<span style="position: relative; width: {s}px; height: {s}px; flex: none" role="img" aria-label="Account {ring}% complete"><svg width="{s}" height="{s}" viewBox="0 0 {s} {s}" aria-hidden="true" style="position: absolute; inset: 0">'
            f'<circle cx="{s/2}" cy="{s/2}" r="{s/2-3}" fill="none" stroke="#DDE5E0" stroke-width="3"></circle><circle cx="{s/2}" cy="{s/2}" r="{s/2-3}" fill="none" stroke="{GREEN}" stroke-width="3" stroke-linecap="round" transform="rotate(-90 {s/2} {s/2})" stroke-dasharray="{C:.1f}" stroke-dashoffset="{C*(1-ring/100):.1f}"></circle></svg>'
            f'<span style="position: absolute; inset: 5px; border-radius: 50%; background: {DARK}; color: #FFFFFF; font-size: {round(s*.34)}px; font-weight: 800; display: flex; align-items: center; justify-content: center">H</span></span>')
def menu():
    row = lambda k, t, sub='': f'<span style="display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 12px; font-size: 14px; font-weight: 700; color: #26302B">{ic(k, 18, 2)}<span style="flex: 1">{t}</span><span style="font-size: 12px; color: #8A968F; font-weight: 700">{sub}</span></span>'
    return (f'<div style="position: absolute; right: 0; top: 52px; z-index: 5; width: 280px; padding: 8px; border-radius: 18px; background: #FFFFFF; box-shadow: 0 24px 60px rgba(10,15,13,.18), 0 0 0 1px #E3EAE6; display: flex; flex-direction: column">'
            f'<span style="display: flex; align-items: center; gap: 10px; padding: 10px 12px 12px; border-bottom: 1px solid #EEF2F0; margin-bottom: 4px">{avatar(44)}<span style="display: flex; flex-direction: column"><b style="font-size: 14.5px">Henry Sidwell</b><span style="font-size: 12px; color: #5B6862; font-weight: 600">Account 71% complete</span></span></span>'
            + row('user', 'Your info', '2 left') + row('shield', 'Settings') + row('card', 'Membership', 'Active') + row('logout', 'Log out') + '</div>')
def shell(m, page, body, title, sub='', show_menu=False):
    if m:
        nav = ('<nav style="flex: none; display: flex; justify-content: space-around; padding: 8px 4px 14px; background: #FFFFFF; border-top: 1px solid #E3EAE6">' + ''.join(
            f'<span style="flex: 1; display: flex; flex-direction: column; align-items: center; gap: 3px; font-size: 10.5px; font-weight: 800; white-space: nowrap; color: {DARK if k == page else "#8A968F"}">{ic(i, 21, 2.2 if k == page else 2)}{t}</span>' for k, i, t in MNAV) + '</nav>')
        top = f'<header style="flex: none; display: flex; align-items: center; justify-content: space-between; padding: 10px 16px; background: #FFFFFF; border-bottom: 1px solid #E3EAE6">{brand(22, "#0A0F0D")}{avatar(38)}</header>'
        head = f'<div style="display: flex; flex-direction: column; gap: 3px"><h1 style="margin: 0; font-size: 22px; letter-spacing: -.5px">{title}</h1>' + (f'<span style="font-size: 13px; color: #5B6862">{sub}</span>' if sub else '') + '</div>'
        return f'<div style="height: 100%; display: flex; flex-direction: column; background: #F3F6F4; font-family: Manrope, sans-serif; color: #0A0F0D">{top}<main style="flex: 1; min-height: 0; overflow-y: auto; padding: 16px; display: grid; grid-template-columns: minmax(0, 1fr); grid-auto-rows: max-content; align-content: start; gap: 14px">{head}{body}</main>{nav}</div>'
    grp = lambda t: f'<span style="padding: 18px 12px 6px; font-size: 11px; font-weight: 800; letter-spacing: 1.1px; color: #8A968F; white-space: nowrap">{t}</span>'
    item = lambda k, i, t, badge: (f'<span style="display: flex; align-items: center; gap: 11px; padding: 10px 12px; border-radius: 12px; font-size: 14.5px; font-weight: 700; white-space: nowrap; {"background: #EAF2EE; color: #0F3B2E" if k == page else "color: #43504A"}">{ic(i, 19, 2)}<span style="flex: 1">{t}</span>'
                                   + (f'<span style="padding: 2px 7px; border-radius: 99px; background: {MINT}; color: {DARK}; font-size: 11px; font-weight: 800">{badge}</span>' if badge else '') + '</span>')
    side = (f'<aside style="width: 276px; flex: none; display: flex; flex-direction: column; gap: 2px; padding: 22px 14px; background: #FFFFFF; border-right: 1px solid #E3EAE6; box-sizing: border-box"><span style="padding: 0 10px 18px">{brand(26, "#0A0F0D")}</span>'
            + item(*NAV[0]) + grp('GET MONEY IN') + item(*NAV[1]) + item(*NAV[2]) + grp('GET MONEY BACK') + item(*NAV[3]) + item(*NAV[4]) +
            f'<div style="margin-top: auto; padding: 14px; border-radius: 16px; background: #F3F6F4; display: flex; flex-direction: column; gap: 4px"><span style="font-size: 13px; font-weight: 800">Membership <span style="color: #17603F">Active</span></span><span style="font-size: 12px; color: #5B6862">Claims, refunds and subscriptions. Renews Dec 15.</span></div></aside>')
    topbar = (f'<div style="display: flex; align-items: flex-start; justify-content: space-between; gap: 16px"><div style="display: flex; flex-direction: column; gap: 4px"><h1 style="margin: 0; font-size: 24px; letter-spacing: -.6px">{title}</h1>'
              + (f'<span style="font-size: 13.5px; color: #5B6862">{sub}</span>' if sub else '') + '</div>'
              f'<span style="position: relative; display: flex; align-items: center; gap: 8px; padding: 4px 10px 4px 4px; border-radius: 99px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6">{avatar(38)}<b style="font-size: 14px">Henry</b>{ic("chevd", 16, 2.4, "#8A968F")}{menu() if show_menu else ""}</span></div>')
    return f'<div style="height: 100%; display: flex; background: #F3F6F4; font-family: Manrope, sans-serif; color: #0A0F0D">{side}<main style="flex: 1; min-width: 0; overflow-y: auto; padding: 24px 32px; display: grid; grid-template-columns: minmax(0, 1fr); grid-auto-rows: max-content; align-content: start; gap: 16px">{topbar}{body}</main></div>'

# ---------- small pieces ----------
card = lambda inner, pad=16, extra='': f'<div style="border-radius: 22px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; padding: {pad}px; {extra}">{inner}</div>'
def stat(t, v, sub, c='#0A0F0D', icon='wallet', m=False):
    return (f'<div style="flex: 1 1 0; min-width: {130 if m else 0}px; padding: 14px 16px; border-radius: 20px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; gap: 3px">'
            f'<span style="display: flex; align-items: center; gap: 8px; font-size: 12.5px; font-weight: 800; color: #5B6862"><span style="width: 26px; height: 26px; border-radius: 8px; background: #E9F6EF; color: {GREEN}; display: flex; align-items: center; justify-content: center">{ic(icon, 14, 2.4)}</span>{t}</span>'
            f'<b style="font-size: {22 if m else 28}px; letter-spacing: -.8px; color: {c}">{v}</b><span style="font-size: 12px; color: #8A968F; font-weight: 600">{sub}</span></div>')
stats = lambda items, m: f'<div style="display: flex; gap: 10px; {"flex-wrap: wrap" if m else ""}">' + ''.join(stat(*x, m=m) for x in items) + '</div>'
pill = lambda t, kind='mint': {'mint': f'<span style="min-height: 36px; padding: 0 14px; border-radius: 99px; background: {MINT}; color: {DARK}; font-size: 13.5px; font-weight: 800; display: flex; align-items: center; white-space: nowrap">{t}</span>',
                               'dark': f'<span style="min-height: 36px; padding: 0 14px; border-radius: 99px; background: #0A0F0D; color: #FFFFFF; font-size: 13.5px; font-weight: 800; display: flex; align-items: center; white-space: nowrap">{t}</span>',
                               'soft': f'<span style="min-height: 36px; padding: 0 14px; border-radius: 99px; background: #EEF2F0; color: #0A0F0D; font-size: 13.5px; font-weight: 800; display: flex; align-items: center; white-space: nowrap">{t}</span>'}[kind]
tag = lambda t, good=True: f'<span style="font-size: 11.5px; font-weight: 800; padding: 3px 8px; border-radius: 99px; white-space: nowrap; {"background: #E9F6EF; color: #17603F" if good else "background: #EEF2F0; color: #43504A"}">{t}</span>'
def row(src, nm, why, amt, right, s=38, ico='receipt'):
    return (f'<div style="display: flex; align-items: center; gap: 12px; padding: 10px 14px; border-top: 1px solid #EEF2F0">{mark(src, nm, ico, s)}'
            f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column"><b style="font-size: 14.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{nm} <span style="color: {GREEN}">{amt}</span></b><span style="font-size: 12.5px; color: #5B6862; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{why}</span></span>{right}</div>')
def listcard(title, n, rows, note='', dark=False):
    head = f'<div style="display: flex; align-items: center; gap: 8px; padding: 14px 16px"><b style="font-size: 17px">{title}</b>' + (f'<span style="padding: 2px 9px; border-radius: 99px; background: #E8EEFB; color: #2C4FA8; font-size: 12px; font-weight: 800">{n}</span>' if n else '') + (f'<span style="margin-left: auto; font-size: 12.5px; color: #5B6862; font-weight: 600">{note}</span>' if note else '') + '</div>'
    return f'<div style="border-radius: 22px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; overflow: hidden">{head}{"".join(rows)}</div>'
two = lambda a, b, m, w='320px': f'<div style="display: grid; grid-template-columns: {"minmax(0, 1fr)" if m else "minmax(0, 1fr) " + w}; gap: 16px; align-items: start">{a}{b}</div>'
col = lambda *xs: '<div style="display: flex; flex-direction: column; gap: 16px; min-width: 0">' + ''.join(xs) + '</div>'
def bars(at):
    return '<span style="display: flex; gap: 4px; width: 100%">' + ''.join(f'<span style="flex: 1; display: flex; flex-direction: column; gap: 4px"><span style="height: 5px; border-radius: 99px; background: {GREEN if j < at else "#E3EAE6"}"></span><span style="font-size: 11px; font-weight: 700; color: {"#0A0F0D" if j < at else "#8A968F"}">{st}</span></span>' for j, st in enumerate(STAGES)) + '</span>'

# ---------- Dashboard overview ----------
def hero_total(m):
    return (f'<div style="padding: {20 if m else 26}px; border-radius: 26px; background: {DARK}; color: #FFFFFF; display: flex; {"flex-direction: column; gap: 14px" if m else "align-items: center; justify-content: space-between; gap: 24px"}">'
            f'<span style="display: flex; flex-direction: column; gap: 4px"><span style="font-size: 12.5px; font-weight: 800; letter-spacing: 1.2px; color: #B9CCC2">MONEY CLAIMCLUB IS GETTING YOU</span><b style="font-size: {40 if m else 52}px; letter-spacing: -2px; line-height: 1">$673.73</b><span style="font-size: 13.5px; color: #C9D6CF">$515 from claims and $158.73 in refunds. Plus {fmt(WASTE)} a month in subscriptions you could cut.</span></span>'
            f'<span style="display: flex; gap: 8px; flex-wrap: wrap">{pill("File 5 claims")}<span style="min-height: 36px; padding: 0 14px; border-radius: 99px; background: rgba(255,255,255,.12); font-size: 13.5px; font-weight: 800; display: flex; align-items: center">Fight 5 refunds</span></span></div>')
STATS_HOME = [('Paid to you', '$31.45', '$25 claims, $6.45 refunds', GREEN, 'check'), ('In progress', '$227.64', '5 claims, 3 refunds', '#2C4FA8', 'clock'), ('Subscriptions', fmt(TOTAL_S) + '/mo', fmt(WASTE) + ' a month not used', '#0A0F0D', 'repeat')]
def preview(title, icon, sub, rows, cta):
    return (f'<div style="flex: 1 1 0; min-width: 0; border-radius: 22px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; display: flex; flex-direction: column; overflow: hidden">'
            f'<div style="display: flex; align-items: center; gap: 10px; padding: 14px 16px"><span style="width: 32px; height: 32px; border-radius: 10px; background: #E9F6EF; color: {GREEN}; display: flex; align-items: center; justify-content: center">{ic(icon, 17, 2.2)}</span><span style="flex: 1; display: flex; flex-direction: column"><b style="font-size: 16px; white-space: nowrap">{title}</b><span style="font-size: 12px; color: #5B6862; font-weight: 600">{sub}</span></span>{ic("arrow", 16, 2.4, "#8A968F")}</div>'
            + ''.join(rows) + f'<span style="margin: auto 16px 14px; padding-top: 10px; font-size: 13px; font-weight: 800; color: {GREEN}">{cta}</span></div>')
def prev_rows():
    c = [row(src, nm, why, amt, tag(st, st == 'Ready to file'), 32, 'file') for src, nm, why, amt, st in CLAIMS]
    r = [row(src, nm, why, fmt(a), tag('Ready to fight'), 32, 'hand') for k, src, nm, why, a in F[:3]]
    s = [row(src, nm, use, fmt(amt) + '/mo', tag('Cancel for me'), 32, 'repeat') for src, nm, plan, amt, use, st in UNUSED]
    return c, r, s
def d1(m):
    c, r, s = prev_rows()
    grid = f'<div style="display: flex; {"flex-direction: column" if m else ""}; gap: 12px">' + preview('Your claims', 'file', 'Get money in', c, 'See all claims') + preview('Claim a refund', 'receipt', 'Get money back', r, 'See all refunds') + preview('Subscription Manager', 'repeat', 'Get money back', s, 'Manage subscriptions') + '</div>'
    return shell(m, 'home', hero_total(m) + stats(STATS_HOME, m) + grid, 'Hi Henry', 'Everything Claimclub is getting you, in one place.', show_menu=not m)
TODO = [('file', 'File 5 claims', 'Worth up to $300. 1 closes this week.', 'File now', 'mint', 'Your claims'), ('receipt', 'Fight 5 refunds', 'We found $158.73 you can get back.', 'Review', 'mint', 'Claim a refund'),
        ('repeat', 'Cancel 3 subscriptions', 'You have not used them in 60+ days. Save ' + fmt(WASTE) + ' a month.', 'Review', 'dark', 'Subscription Manager'), ('user', 'Finish your account', 'Add your date of birth and phone so we can file faster.', 'Add', 'soft', 'Your info')]
def d2(m):
    todo = listcard('Your to-do list', '4', [f'<div style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-top: 1px solid #EEF2F0"><span style="width: 40px; height: 40px; flex: none; border-radius: 12px; background: #E9F6EF; color: {GREEN}; display: flex; align-items: center; justify-content: center">{ic(k, 20, 2.2)}</span>'
                                              f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column"><b style="font-size: 15px">{t}</b><span style="font-size: 12.5px; color: #5B6862; font-weight: 600">{d}</span>' + ('' if m else f'<span style="font-size: 11.5px; color: #8A968F; font-weight: 700; margin-top: 2px">{where}</span>') + f'</span>{pill(b, kind)}</div>' for k, t, d, b, kind, where in TODO], 'Do these and we handle the rest')
    split = ('<div style="display: flex; flex-direction: column; gap: 10px">'
             f'<span style="display: flex; justify-content: space-between; font-size: 13px; font-weight: 800"><span>Where your $673.73 comes from</span></span><span style="display: flex; height: 14px; border-radius: 99px; overflow: hidden"><span style="flex: 515; background: {GREEN}"></span><span style="flex: 158.73; background: {MINT}"></span></span>'
             f'<span style="display: flex; flex-direction: column; gap: 6px; font-size: 13px; font-weight: 700">' + ''.join(f'<span style="display: flex; align-items: center; gap: 8px"><span style="width: 10px; height: 10px; border-radius: 3px; background: {c}"></span><span style="flex: 1">{t}</span><b>{v}</b></span>' for c, t, v in ((GREEN, 'Claims', '$515.00'), (MINT, 'Refunds', '$158.73'))) + '</span></div>')
    act = [('Today', 'Starbucks refunded $6.45 to your card'), ('Yesterday', 'SeatGeek replied to your refund request'), ('Nov 12', 'Netflix claim filed with the administrator'), ('Nov 12', 'Dr. Squatch paid $25 to your PayPal')]
    feed = ''.join(f'<div style="display: flex; gap: 10px; padding: 10px 0; border-top: 1px solid #EEF2F0"><span style="width: 8px; height: 8px; margin-top: 6px; border-radius: 50%; background: {GREEN}; flex: none"></span><span style="display: flex; flex-direction: column"><span style="font-size: 13.5px; font-weight: 700">{t}</span><span style="font-size: 12px; color: #8A968F; font-weight: 700">{d}</span></span></div>' for d, t in act)
    right = col(card(f'<span style="font-size: 12.5px; font-weight: 800; letter-spacing: 1px; color: #5B6862">TOTAL COMING TO YOU</span><b style="display: block; font-size: 40px; letter-spacing: -1.5px; margin: 4px 0 14px">$673.73</b>{split}'),
                card(f'<b style="font-size: 16px">Recent activity</b><div style="margin-top: 8px">{feed}</div>'))
    return shell(m, 'home', two(col(stats(STATS_HOME, m), todo), right, m, '340px'), 'Hi Henry', '4 things to do. Everything else we handle.')
def d3(m):
    half = lambda title, icon, big, sub, rows, ctas, bg: (f'<div style="flex: 1 1 0; min-width: 0; border-radius: 26px; background: {bg}; padding: 18px; display: flex; flex-direction: column; gap: 12px">'
        f'<span style="display: flex; align-items: center; gap: 10px"><span style="width: 36px; height: 36px; border-radius: 11px; background: #FFFFFF; color: {GREEN}; display: flex; align-items: center; justify-content: center">{ic(icon, 19, 2.2)}</span><b style="font-size: 18px; letter-spacing: -.3px">{title}</b></span>'
        f'<span style="display: flex; flex-direction: column"><b style="font-size: {34 if m else 42}px; letter-spacing: -1.5px; line-height: 1.05">{big}</b><span style="font-size: 13px; color: #43504A; font-weight: 600">{sub}</span></span>'
        f'<div style="border-radius: 18px; background: #FFFFFF; overflow: hidden">{"".join(rows)}</div><div style="display: flex; gap: 8px; flex-wrap: wrap">{ctas}</div></div>')
    c, r, s = prev_rows()
    a = half('Get money in', 'trend', '$515.00', 'From 10 claims. Payouts expected Jan to Jul 2027.', c, pill('Your claims', 'dark') + pill('Find claims', 'soft'), '#E9F6EF')
    b = half('Get money back', 'receipt', '$158.73', 'In refunds, plus ' + fmt(WASTE) + ' a month in subscriptions you could cut.', r[:2] + s[:1], pill('Claim a refund', 'dark') + pill('Subscription Manager', 'soft'), '#EEF2F8')
    months = [('Dec', 6.45, 'Starbucks refund'), ('Jan', 140, 'Apple, CVS'), ('Feb', 100, 'Google Play'), ('Mar', 95, 'Kroger'), ('Apr', 40, 'GoodRx'), ('May', 180, 'Netflix, RealPage')]
    mx = max(x[1] for x in months)
    tl = card('<b style="font-size: 16px">Expected payouts</b><span style="display: block; font-size: 12.5px; color: #5B6862; font-weight: 600">Estimates from settlement and refund timelines</span>'
              f'<div style="display: flex; align-items: flex-end; gap: {8 if m else 14}px; height: 150px; margin-top: 14px">' + ''.join(f'<span style="flex: 1; display: flex; flex-direction: column; align-items: center; gap: 6px"><b style="font-size: 11.5px">${v:,.0f}</b><span style="width: 100%; height: {max(8, v / mx * 100):.0f}px; border-radius: 8px 8px 4px 4px; background: {GREEN if i == 0 else MINT}"></span><span style="font-size: 12px; font-weight: 800; color: #5B6862">{mo}</span></span>' for i, (mo, v, w) in enumerate(months)) + '</div>')
    return shell(m, 'home', f'<div style="display: flex; {"flex-direction: column" if m else ""}; gap: 14px">{a}{b}</div>' + tl, 'Hi Henry', 'Money coming in, and money coming back.')

# ---------- Claim a refund ----------
STATS_R = [('Found', '$158.73', '5 charges', '#0A0F0D', 'search'), ('In progress', '$127.64', '3 requests', '#2C4FA8', 'clock'), ('Refunded', '$6.45', '1 so far', GREEN, 'check')]
def add_card(m):
    return card(f'<b style="font-size: 16px">Add a charge yourself</b><span style="display: block; font-size: 13px; color: #5B6862; margin: 2px 0 10px">Anything we did not spot from your card.</span>'
                + ''.join(f'<span style="display: flex; height: 42px; margin-bottom: 8px; border-radius: 12px; box-shadow: inset 0 0 0 1.5px #DDE5E0; padding: 0 12px; align-items: center; font-size: 13.5px; font-weight: 600; color: #8A968F">{p}</span>' for p in ('Company, like Planet Fitness', 'Amount, like $39.99', 'What happened?')) + pill(ic('plus', 15, 2.6) + ' Add charge', 'soft'))
def scan_card():
    return card(f'<span style="width: 40px; height: 40px; border-radius: 12px; background: #E9F6EF; color: {GREEN}; display: flex; align-items: center; justify-content: center">{ic("link", 20, 2.2)}</span><b style="display: block; font-size: 16px; margin: 10px 0 4px">Scan for more refunds</b><span style="display: block; font-size: 13px; color: #5B6862; line-height: 1.5; margin-bottom: 12px">Connect a card, read-only. We check 90 days of charges and keep watching.</span>' + pill('Connect a card', 'dark'))
def r1(m):
    fight = (f'<div style="border-radius: 24px; background: {DARK}; padding: 14px; display: flex; flex-direction: column; gap: 8px"><div style="display: flex; align-items: center; gap: 8px; padding: 4px 6px 6px; color: #FFFFFF"><b style="font-size: 18px">Ready to fight</b><span style="padding: 2px 9px; border-radius: 99px; background: {MINT}; color: {DARK}; font-size: 12px; font-weight: 800">5</span>'
             + ('' if m else '<span style="margin-left: auto; font-size: 13px; color: #B9CCC2; font-weight: 600">You approve each one before we send it</span>') + '</div>'
             + ''.join(f'<div style="display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: 16px; background: #FFFFFF">{mark(src, nm, "hand", 38)}<span style="flex: 1; min-width: 0; display: flex; flex-direction: column"><b style="font-size: 15px">{nm} <span style="color: {GREEN}">{fmt(a)}</span></b><span style="font-size: 12.5px; color: #5B6862; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{why}</span></span>'
                       + ('' if m else '<span style="font-size: 12px; font-weight: 800; color: #5B6862; padding: 4px 9px; border-radius: 99px; background: #EEF2F0">Not now</span>') + f'{pill("Fight it")}</div>' for k, src, nm, why, a in F) + '</div>')
    prog = listcard('In progress', '3', [f'<div style="display: flex; {"flex-direction: column; align-items: stretch" if m else "align-items: center"}; gap: 12px; padding: 12px 16px; border-top: 1px solid #EEF2F0"><span style="display: flex; align-items: center; gap: 12px; flex: 1; min-width: 0">{mark(src, nm, "hand", 36)}<span style="display: flex; flex-direction: column"><b style="font-size: 15px">{nm} <span style="color: {GREEN}">{amt}</span></b><span style="font-size: 12.5px; color: #5B6862; font-weight: 600">{why}</span></span></span><span style="{"" if m else "width: 340px"}">{bars(at)}</span></div>' for src, nm, why, amt, at in PROG])
    return shell(m, 'refunds', stats(STATS_R, m) + two(col(fight, prog), col(scan_card(), add_card(m)), m, '300px'), 'Claim a refund', 'Charges you can get back. You approve each one, then we cancel and request the refund.')
def r2(m):
    cols = [('Found', '5', [(src, nm, why, fmt(a)) for k, src, nm, why, a in F[:3]], 'Fight it'), ('Requested', '1', [(PROG[0][0], PROG[0][1], PROG[0][2], PROG[0][3])], ''),
            ('Company replied', '1', [(PROG[1][0], PROG[1][1], PROG[1][2], PROG[1][3])], ''), ('Refunded', '1', [(PROG[2][0], PROG[2][1], PROG[2][2], PROG[2][3])], '')]
    lane = lambda t, n, items, btn, i: (f'<div style="flex: {"none" if m else "1 1 0"}; width: {270 if m else "auto"}{"px" if m else ""}; min-width: 0; border-radius: 22px; background: {"#E9F6EF" if i == 3 else "#E6ECE8"}; padding: 10px; display: flex; flex-direction: column; gap: 8px">'
        f'<span style="display: flex; align-items: center; gap: 8px; padding: 4px 6px"><b style="font-size: 14.5px">{t}</b><span style="padding: 1px 8px; border-radius: 99px; background: #FFFFFF; font-size: 12px; font-weight: 800">{n}</span></span>'
        + ''.join(f'<div style="padding: 12px; border-radius: 16px; background: #FFFFFF; display: flex; flex-direction: column; gap: 8px"><span style="display: flex; align-items: center; gap: 10px">{mark(src, nm, "hand", 34)}<span style="display: flex; flex-direction: column; min-width: 0"><b style="font-size: 14.5px">{nm}</b><span style="font-size: 12px; color: #5B6862; font-weight: 600">{why}</span></span></span>'
                  f'<span style="display: flex; align-items: center; justify-content: space-between"><b style="font-size: 18px; color: {GREEN}">{amt}</b>{pill(btn) if btn else tag("Refunded" if i == 3 else "Waiting on " + nm, i == 3)}</span></div>' for src, nm, why, amt in items)
        + (f'<span style="padding: 6px; font-size: 12.5px; font-weight: 800; color: {GREEN}">+ 2 more</span>' if i == 0 else '') + '</div>')
    board = f'<div style="display: flex; gap: 12px; {"overflow-x: auto; margin: 0 -16px; padding: 0 16px 6px" if m else ""}">' + ''.join(lane(*c, i) for i, c in enumerate(cols)) + '</div>'
    tools = f'<div style="display: flex; {"flex-direction: column" if m else ""}; gap: 16px"><div style="flex: 1">{scan_card()}</div><div style="flex: 1">{add_card(m)}</div></div>'
    return shell(m, 'refunds', stats(STATS_R, m) + board + tools, 'Claim a refund', 'Every refund from found to paid, at a glance.')
def r3(m):
    k, src, nm, why, a = F[0]
    focus = (f'<div style="border-radius: 26px; background: #FFFFFF; box-shadow: 0 18px 40px rgba(10,15,13,.08), inset 0 0 0 1px #E3EAE6; padding: {20 if m else 28}px; display: flex; flex-direction: column; gap: 16px">'
             f'<span style="display: flex; justify-content: space-between; align-items: center"><span style="font-size: 12.5px; font-weight: 800; letter-spacing: 1px; color: #5B6862">1 OF 5 TO REVIEW</span><span style="display: flex; gap: 4px">' + ''.join(f'<span style="width: 22px; height: 5px; border-radius: 99px; background: {GREEN if i == 0 else "#E3EAE6"}"></span>' for i in range(5)) + '</span></span>'
             f'<span style="display: flex; align-items: center; gap: 14px">{mark(src, nm, "hand", 60)}<span style="display: flex; flex-direction: column; gap: 6px"><b style="font-size: 16px; color: #43504A">{nm}</b><span style="display: flex; gap: 6px">{tag("About " + fmt(a) + " back")}{tag("Charged Oct 14", False)}</span></span></span>'
             f'<b style="font-size: {24 if m else 32}px; letter-spacing: -.9px; line-height: 1.15">Netflix charged you $15.99 three times after you canceled in July.</b>'
             '<span style="font-size: 14px; color: #5B6862; line-height: 1.5">We will ask Netflix for all three charges back and make sure the account stays closed.</span>'
             f'<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px"><span style="min-height: 58px; border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px #DDE5E0; font-size: 17px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 6px"><span style="color: #B8333A; display: flex">{ic("x", 18, 3)}</span>Not now</span>'
             f'<span style="min-height: 58px; border-radius: 18px; background: {MINT}; color: {DARK}; font-size: 17px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 10px 24px rgba(61,220,151,.35)">{ic("check", 18, 3)}Fight it</span></div></div>')
    nxt = listcard('Up next', '4', [row(src, nm, why, fmt(a), tag('To review', False), 34, 'hand') for k, src, nm, why, a in F[1:]])
    prog = listcard('In progress', '3', [f'<div style="display: flex; flex-direction: column; gap: 10px; padding: 12px 16px; border-top: 1px solid #EEF2F0"><span style="display: flex; align-items: center; gap: 10px">{mark(src, nm, "hand", 32)}<b style="font-size: 14.5px">{nm} <span style="color: {GREEN}">{amt}</span></b></span>{bars(at)}</div>' for src, nm, why, amt, at in PROG])
    return shell(m, 'refunds', two(col(focus, nxt), col(stats(STATS_R[:1] + STATS_R[2:], m), prog, add_card(m)), m, '340px'), 'Claim a refund', 'One charge at a time. Approve it and we handle the rest.')

# ---------- Subscription Manager ----------
STATS_S = [('Per month', fmt(TOTAL_S), f'{len(SUBS)} subscriptions', '#0A0F0D', 'repeat'), ('Not used', fmt(WASTE), 'a month you could save', '#B8333A', 'ban'), ('Next renewal', 'Dec 2', 'YouTube Premium, $22.99', '#0A0F0D', 'cal')]
def s1(m):
    rows = [row(src, nm, plan + ' · ' + fmt(amt) + '/mo', '', (f'<span style="font-size: 12px; font-weight: 800; color: #B8333A; white-space: nowrap; {"display: none" if m else ""}">{use}</span>' if st == 'unused' else f'<span style="font-size: 12px; font-weight: 800; color: #17603F; white-space: nowrap; {"display: none" if m else ""}">{use}</span>') + (pill('Cancel for me', 'dark') if st == 'unused' else pill('Keep', 'soft')), 40, 'repeat')
            for src, nm, plan, amt, use, st in sorted(SUBS, key=lambda x: x[5] != 'unused')]
    tip = f'<div style="display: flex; align-items: center; gap: 12px; padding: 14px 16px; border-radius: 18px; background: #E9F6EF; color: #17603F; font-size: 14px; font-weight: 700">{ic("bell", 18, 2.2)}We tell you 3 days before any free trial turns paid, and before yearly plans renew.</div>'
    return shell(m, 'subs', stats(STATS_S, m) + tip + listcard('Your subscriptions', str(len(SUBS)), rows, 'Unused ones first'), 'Subscription Manager', 'Everything you pay for every month, from your connected card.')
def s2(m):
    chips = ''.join(f'<span style="flex: none; min-height: 36px; padding: 0 14px; border-radius: 99px; font-size: 13px; font-weight: 800; display: flex; align-items: center; {"background: #0F3B2E; color: #FFFFFF" if i == 0 else "background: #FFFFFF; color: #43504A; box-shadow: inset 0 0 0 1.5px #DDE5E0"}">{t}</span>' for i, t in enumerate(('All 7', 'Not used 3', 'Free trials 1', 'Yearly 1', 'Streaming 3')))
    use = {'Netflix': 92, 'City Fitness': 0, 'Disney+': 4, 'Amazon Prime': 80, 'YouTube Premium': 70, 'MyFitnessPal': 0, 'ChatGPT Plus': 96}
    tile = lambda src, nm, plan, amt, u, st: (f'<div style="border-radius: 22px; background: #FFFFFF; box-shadow: inset 0 0 0 {"2px #F3B8BB" if st == "unused" else "1px #E3EAE6"}; padding: 16px; display: flex; flex-direction: column; gap: 12px">'
        f'<span style="display: flex; align-items: center; gap: 10px">{mark(src, nm, "repeat", 40)}<span style="flex: 1; min-width: 0; display: flex; flex-direction: column"><b style="font-size: 15px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{nm}</b><span style="font-size: 12px; color: #5B6862; font-weight: 600">{plan}</span></span><b style="font-size: 16px">{fmt(amt)}</b></span>'
        f'<span style="display: flex; flex-direction: column; gap: 5px"><span style="display: flex; justify-content: space-between; font-size: 12px; font-weight: 800"><span style="color: #5B6862">How much you use it</span><span style="color: {"#B8333A" if st == "unused" else "#17603F"}">{u}</span></span>'
        f'<span style="height: 6px; border-radius: 99px; background: #EEF2F0; overflow: hidden"><span style="display: block; height: 100%; width: {max(3, use[nm])}%; background: {"#E5484D" if st == "unused" else GREEN}"></span></span></span>'
        + (pill('Cancel for me', 'dark') if st == 'unused' else pill('Keep', 'soft')) + '</div>')
    grid = f'<div style="display: grid; grid-template-columns: repeat({1 if m else 3}, minmax(0, 1fr)); gap: 12px">' + ''.join(tile(*x) for x in sorted(SUBS, key=lambda x: x[5] != 'unused')) + '</div>'
    ren = [('Dec 2', 'YouTube Premium', '$22.99'), ('Dec 6', 'Disney+', '$13.99'), ('Dec 9', 'Netflix', '$15.49'), ('Dec 14', 'City Fitness', '$39.99'), ('Mar 2', 'Amazon Prime', '$179.88 yearly')]
    strip = card('<b style="font-size: 16px">Renewing soon</b><div style="display: flex; gap: 10px; overflow-x: auto; margin-top: 10px">' + ''.join(f'<span style="flex: none; min-width: 120px; padding: 10px 12px; border-radius: 14px; background: #F3F6F4; display: flex; flex-direction: column"><span style="font-size: 12px; font-weight: 800; color: {GREEN}">{d}</span><b style="font-size: 13.5px">{n}</b><span style="font-size: 12px; color: #5B6862">{a}</span></span>' for d, n, a in ren) + '</div>')
    return shell(m, 'subs', stats(STATS_S, m) + strip + f'<div style="display: flex; gap: 8px; overflow-x: auto">{chips}</div>' + grid, 'Subscription Manager', 'How much you use each subscription, and what it costs you.')
def s3(m):
    colors = ['#12805C', '#3DDC97', '#0F3B2E', '#8FE0B9', '#2C4FA8', '#E5484D', '#F0B850']
    srt = sorted(SUBS, key=lambda x: -x[3])
    bar = '<span style="display: flex; height: 18px; border-radius: 99px; overflow: hidden; margin: 10px 0 12px">' + ''.join(f'<span style="flex: {x[3]}; background: {colors[i]}"></span>' for i, x in enumerate(srt)) + '</span>'
    legend = '<div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 6px 16px">' + ''.join(f'<span style="display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 700"><span style="width: 10px; height: 10px; border-radius: 3px; background: {colors[i]}"></span><span style="flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{x[1]}</span><b>{fmt(x[3])}</b></span>' for i, x in enumerate(srt)) + '</div>'
    spend = card(f'<span style="font-size: 12.5px; font-weight: 800; letter-spacing: 1px; color: #5B6862">YOU SPEND EVERY MONTH</span><b style="display: block; font-size: {38 if m else 48}px; letter-spacing: -1.6px">{fmt(TOTAL_S)}</b><span style="font-size: 13px; color: #5B6862; font-weight: 600">{fmt(TOTAL_S * 12)} a year</span>{bar}{legend}', 18)
    save = (f'<div style="border-radius: 24px; background: {DARK}; color: #FFFFFF; padding: 18px; display: flex; flex-direction: column; gap: 10px"><span style="font-size: 12.5px; font-weight: 800; letter-spacing: 1px; color: #B9CCC2">CUT THESE AND SAVE</span><b style="font-size: 36px; letter-spacing: -1.4px">{fmt(WASTE * 12)} a year</b>'
            + ''.join(f'<span style="display: flex; align-items: center; gap: 10px; padding: 10px; border-radius: 14px; background: rgba(255,255,255,.08)"><span style="width: 22px; height: 22px; border-radius: 7px; background: {MINT}; color: {DARK}; display: flex; align-items: center; justify-content: center">{ic("check", 14, 3)}</span>{mark(src, nm, "repeat", 30)}<span style="flex: 1; display: flex; flex-direction: column"><b style="font-size: 14px">{nm}</b><span style="font-size: 12px; color: #B9CCC2">{use}</span></span><b style="font-size: 14px">{fmt(amt)}/mo</b></span>' for src, nm, plan, amt, use, st in UNUSED)
            + f'<span style="min-height: 48px; border-radius: 99px; background: {MINT}; color: {DARK}; font-size: 15px; font-weight: 800; display: flex; align-items: center; justify-content: center">Cancel 3 for me</span><span style="font-size: 12px; color: #B9CCC2; text-align: center">We cancel and ask for the last charge back on each one.</span></div>')
    keep = listcard('Keeping', '4', [row(src, nm, use, fmt(amt) + '/mo', tag('Used', True), 34, 'repeat') for src, nm, plan, amt, use, st in SUBS if st == 'used'])
    return shell(m, 'subs', two(col(spend, keep), save, m, '360px'), 'Subscription Manager', 'Where your subscription money goes, and what to cut.')

BOARDS = [('DashD1', 'Dashboard · 1 · Total on top, three preview cards (profile menu shown open)', d1), ('DashD2', 'Dashboard · 2 · To-do list first, activity on the side', d2), ('DashD3', 'Dashboard · 3 · Get money in and Get money back side by side', d3),
          ('RefundR1', 'Claim a refund · 1 · Ready to fight list', r1), ('RefundR2', 'Claim a refund · 2 · Board from found to refunded', r2), ('RefundR3', 'Claim a refund · 3 · One charge at a time', r3),
          ('SubsS1', 'Subscription Manager · 1 · List with cancel or keep', s1), ('SubsS2', 'Subscription Manager · 2 · Cards with how much you use each', s2), ('SubsS3', 'Subscription Manager · 3 · Spending breakdown and what to cut', s3)]
if __name__ == '__main__':
    for name, title, fn in BOARDS:
        page = (f'<div style="width: 1926px; height: 980px; box-sizing: border-box; padding: 24px; background: #E7ECE9; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 14px">'
                f'<div style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #43504A">{title.upper()}</div><div style="display: flex; gap: 48px; align-items: flex-start">'
                f'<div style="width: 1440px; height: 900px; flex: none; overflow: hidden; border-radius: 18px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{fn(False)}</div>'
                f'<div style="width: 390px; height: 844px; flex: none; overflow: hidden; border-radius: 28px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{fn(True)}</div></div></div>\n</x-dc>\n')
        open(os.path.join(OUT, name + '.dc.html'), 'w').write(HEAD % title + page + JS)
    print('built', [b[0] for b in BOARDS])
