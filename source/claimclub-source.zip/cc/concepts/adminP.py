# Admin panel, all pages in the chosen "Today" style (Henry, Nov 23 2026: picked A, dropped B and C).
# Boards on the canvas page "Admin": AdminA (Overview, from adminD.py) plus AdminQueue, AdminFile, AdminCases,
# AdminRefunds, AdminMembers, AdminMember, AdminFunnel, AdminSettings. Desktop + phone each, sample data.
from adminD import *
import adminD

def page_desk(body, on, h=1000):
    return desk(body, on=on, h=h)
def tabs(items, on=0):
    return (f'<div style="display: inline-flex; background: #FFFFFF; border-radius: 12px; box-shadow: inset 0 0 0 1px {LINE}; padding: 4px; gap: 2px">' + ''.join(
        f'<span style="height: 32px; display: inline-flex; align-items: center; gap: 6px; padding: 0 12px; border-radius: 9px; font-size: 13px; font-weight: 800; white-space: nowrap; background: {INK if i == on else "transparent"}; color: {"#FFFFFF" if i == on else MUTE}">{t}</span>'
        for i, t in enumerate(items)) + '</div>')
def fchip(t, on=False, icn=None, col=None):
    c = col or INK
    return (f'<span style="display: inline-flex; align-items: center; gap: 6px; height: 34px; padding: 0 12px; border-radius: 10px; font-size: 13px; font-weight: 800; white-space: nowrap; '
            f'background: {"#E9F6EF" if on else "#FFFFFF"}; color: {GREEN if on else c}; box-shadow: inset 0 0 0 1px {GREEN if on else LINE}">{ic(icn, 14, GREEN if on else c) if icn else ""}{t}</span>')
def searchbox(ph, w=260):
    return f'<span style="display: inline-flex; align-items: center; gap: 8px; height: 40px; padding: 0 14px; border-radius: 12px; background: #FFFFFF; box-shadow: inset 0 0 0 1px {LINE}; font-size: 13.5px; font-weight: 600; color: #8A968F; width: {w}px; box-sizing: border-box">{ic("search", 16, "#8A968F")}{ph}</span>'
def mini(icn, col, bg, n, t, sub=''):
    return (f'<div style="flex: 1; min-width: 0; background: #FFFFFF; border-radius: 16px; box-shadow: inset 0 0 0 1px {LINE}; padding: 14px 16px; display: flex; align-items: center; gap: 12px">'
            f'<span style="width: 36px; height: 36px; flex: none; border-radius: 11px; background: {bg}; display: flex; align-items: center; justify-content: center">{ic(icn, 18, col)}</span>'
            f'<div style="display: flex; flex-direction: column; gap: 1px; min-width: 0"><b style="font-size: 21px; letter-spacing: -.5px">{n}</b><span style="font-size: 12.5px; font-weight: 700; color: {MUTE}; white-space: nowrap">{t}</span></div>'
            + (f'<span style="margin-left: auto; font-size: 12px; font-weight: 700; color: #8A968F; white-space: nowrap">{sub}</span>' if sub else '') + '</div>')
def grid(cols, head, rows, pad='12px 0'):
    hd = f'<div style="display: grid; grid-template-columns: {cols}; gap: 12px; font-size: 11.5px; font-weight: 800; letter-spacing: .6px; color: #8A968F; padding-bottom: 8px">' + ''.join(f'<span>{h}</span>' for h in head) + '</div>'
    bd = ''.join(f'<div style="display: grid; grid-template-columns: {cols}; align-items: center; gap: 12px; padding: {pad}; border-top: 1px solid {LINE}; font-size: 13.5px; font-weight: 600; {"background: #F7FBF9; margin: 0 -20px; padding-left: 20px; padding-right: 20px; box-shadow: inset 3px 0 0 " + GREEN if r[0] == "*" else ""}">' + ''.join(r[1:] if r[0] == '*' else r) + '</div>' for r in rows)
    return '<div>' + hd + bd + '</div>'
def who(n, sub, sz=30):
    return f'<span style="display: flex; align-items: center; gap: 10px; min-width: 0">{avatar(n, sz)}<span style="display: flex; flex-direction: column; gap: 1px; min-width: 0"><b style="font-size: 13.5px; white-space: nowrap">{n}</b><span style="font-size: 12px; font-weight: 600; color: #8A968F; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{sub}</span></span></span>'
FILER = {'va': ('Team files', '#EAF1FF', '#2F5BD3'), 'bot': ('Bot files', '#E9F6EF', GREEN), 'member': ('Member files', '#F1ECFF', '#6B46C1'), 'auto': ('Auto pay', '#EEF2F0', MUTE), 'captcha': ('CAPTCHA · team', '#FFF4E0', AMB)}
def filer(k): t, b, f = FILER[k]; return chip(t, b, f)
PLAN = {'Priority': ('#0F3B2E', '#FFFFFF'), 'Fast': ('#E9F6EF', GREEN), 'Yearly': ('#EEF2F0', INK), 'Monthly': ('#EEF2F0', INK), 'Trial': ('#FFF4E0', AMB), 'Cancelled': ('#FDECEB', RED), 'None': ('#EEF2F0', MUTE)}
def plan(t): b, f = PLAN.get(t, ('#EEF2F0', INK)); return chip(t, b, f)
def due(t, k='n'):
    c = {'late': RED, 'soon': AMB}.get(k, MUTE)
    return f'<span style="font-size: 13px; font-weight: 800; color: {c}; white-space: nowrap">{t}</span>'
def signed(ok=True):
    return f'<span style="display: inline-flex; align-items: center; gap: 5px; font-size: 12.5px; font-weight: 800; color: {GREEN if ok else RED}">{ic("circle-check" if ok else "circle-alert", 15, GREEN if ok else RED)}{"Signed" if ok else "Missing"}</span>'
def ph_head(t, sub='', right=None):
    r = right if right is not None else avatar('H', 36, MINT, INK)
    return (f'<div style="display: flex; align-items: center; justify-content: space-between; gap: 10px"><div style="display: flex; flex-direction: column; gap: 2px"><b style="font-size: 24px; letter-spacing: -.6px">{t}</b>'
            + (f'<span style="font-size: 13px; font-weight: 600; color: {MUTE}">{sub}</span>' if sub else '') + f'</div>{r}</div>')
def ph_row(left, right, sub2=''):
    return f'<div style="display: flex; align-items: center; gap: 12px; padding: 12px 0; border-top: 1px solid {LINE}">{left}<div style="margin-left: auto; display: flex; flex-direction: column; align-items: flex-end; gap: 4px">{right}{sub2}</div></div>'
def scrollrow(items):
    return '<div style="display: flex; gap: 6px; overflow: hidden; margin: 0 -16px; padding: 0 16px">' + ''.join(items) + '</div>'
def pill2(t, on=False):
    return f'<span style="flex: none; display: inline-flex; align-items: center; height: 34px; padding: 0 13px; border-radius: 99px; font-size: 13px; font-weight: 800; white-space: nowrap; background: {INK if on else "#FFFFFF"}; color: {"#FFFFFF" if on else INK}; box-shadow: inset 0 0 0 1px {LINE}">{t}</span>'
def toggle(on=True, dis=False):
    return (f'<span style="flex: none; width: 50px; height: 28px; border-radius: 99px; background: {GREEN if on else "#C9D3CD"}; position: relative; opacity: {.5 if dis else 1}; display: block">'
            f'<span style="position: absolute; top: 3px; left: {25 if on else 3}px; width: 22px; height: 22px; border-radius: 99px; background: #FFFFFF; box-shadow: 0 1px 3px rgba(0,0,0,.2)"></span></span>')
def field(label, val, copy=True, mono=False):
    return (f'<div style="display: grid; grid-template-columns: 96px minmax(0, 1fr) auto; align-items: center; gap: 10px; padding: 9px 0; border-top: 1px solid {LINE}">'
            f'<span style="font-size: 12.5px; font-weight: 700; color: #8A968F">{label}</span><span style="font-size: 13.5px; font-weight: 700; {"font-family: ui-monospace, monospace; font-size: 12.5px;" if mono else ""}">{val}</span>'
            + (f'<span title="Copy" style="display: inline-flex; align-items: center; justify-content: center; width: 28px; height: 28px; border-radius: 8px; background: #F3F6F4">{ic("copy", 14, MUTE)}</span>' if copy else '<span></span>') + '</div>')

# =============== Filing queue ===============
Q = [('*', 'Maria Lopez', 'maria.l@gmail.com', 'Equifax data breach', 'Deadline Dec 8', 'Priority', 'va', ('3h late', 'late'), True),
     ('', 'James Carter', 'jcarter@yahoo.com', 'Apple Siri privacy', 'Deadline Jan 30', 'Fast', 'bot', ('Due in 5h', 'soon'), True),
     ('', 'Ana Ruiz', 'ana.ruiz@gmail.com', 'Visa and Mastercard ATM fees', 'Member replied 20m ago', 'Fast', 'va', ('Due in 9h', 'soon'), True),
     ('', 'Derek Shaw', 'dshaw@outlook.com', 'Google Play Store', 'Deadline Dec 14', 'Monthly', 'captcha', ('Due tomorrow', 'n'), True),
     ('', 'Kim Nguyen', 'kim.n@gmail.com', 'RealPage rent pricing', 'Deadline Feb 2', 'Yearly', 'bot', ('Due in 2 days', 'n'), True),
     ('', 'Tom Becker', 'tbecker@gmail.com', 'CVS generic drug pricing', 'Deadline Jan 6', 'Yearly', 'va', ('Due in 2 days', 'n'), False),
     ('', 'Rosa Diaz', 'rosa.d@icloud.com', 'Toyota airbag recall', 'Deadline 2028', 'Monthly', 'va', ('Due in 3 days', 'n'), True),
     ('', 'Leo Grant', 'leog@gmail.com', 'Kia window motor', 'Deadline Dec 20', 'Fast', 'bot', ('Due in 3 days', 'n'), True)]
def queue_desk():
    top = head('Filing queue', 'Claims members asked us to file. Priority first, then by due time.', btn('Open next claim', 'arrow-right'))
    stats = '<div style="display: flex; gap: 14px">' + mini('clock-alert', RED, '#FDECEB', '1', 'Late') + mini('clock', AMB, '#FFF4E0', '3', 'Due today') + mini('bot', GREEN, '#E9F6EF', '5', 'Bot can file') + mini('shield-alert', AMB, '#FFF4E0', '2', 'CAPTCHA, team files') + mini('circle-check', GREEN, '#E9F6EF', '38', 'Filed this week', '+11') + '</div>'
    bar = (f'<div style="display: flex; align-items: center; gap: 10px">' + tabs(['To do · 12', 'Member filing or auto pay · 7', 'Filed · 49', 'Approved and paid · 20']) + '<span style="flex: 1"></span>'
           + fchip('Late', icn='clock-alert', col=RED) + fchip('Priority') + fchip('Team files') + fchip('Bot files') + searchbox('Member or settlement', 220) + '</div>')
    rows = [[r[0], who(r[1], r[2]), f'<span style="display: flex; flex-direction: column; gap: 1px; min-width: 0"><b style="font-size: 13.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{r[3]}</b><span style="font-size: 12px; font-weight: 600; color: {GREEN if "replied" in r[4] else "#8A968F"}">{r[4]}</span></span>',
             plan(r[5]), filer(r[6]), due(*r[7]), signed(r[8]), f'<span style="justify-self: end; display: inline-flex; align-items: center; gap: 4px; font-size: 13px; font-weight: 800; color: {GREEN}">Open{ic("chevron-right", 14, GREEN)}</span>'] for r in Q]
    tbl = card(grid('1.5fr 1.7fr .8fr 1fr .9fr .8fr 60px', ['MEMBER', 'SETTLEMENT', 'PLAN', 'FILED BY', 'DUE', 'SIGNED', ''], rows) + f'<span style="font-size: 12.5px; font-weight: 700; color: #8A968F">Showing 8 of 12 · Tom Becker has not signed, so his claim cannot be filed yet.</span>')
    return desk(top + stats + bar + tbl, on=1)
def queue_phone():
    t = ph_head('Filing queue', '12 to do · 1 late')
    f = scrollrow([pill2('To do 12', True), pill2('Late 1'), pill2('Priority'), pill2('Team files'), pill2('Bot files')])
    rows = ''.join(ph_row(who(r[1], r[3], 34), st('late') if r[7][1] == 'late' else plan(r[5]), due(*r[7])) for r in Q[:7])
    return phone(t + f + card(f'<div style="margin: -6px 0">{rows}</div>', pad=16, extra='gap: 0'), on=1)

# =============== Filing a claim ===============
FORM = [('First name', 'Maria', True), ('Last name', 'Lopez', True), ('Email', 'maria.l@gmail.com', True), ('Phone', '(619) 555-0148', True),
        ('Street address', '2210 Grand Ave, Apt 4', True), ('City, State, ZIP', 'San Diego, CA 92109', False), ('Notice ID', 'EQF-7N2K-91QX', False),
        ('PIN', '4417', False), ('Were you notified of the breach?', 'Yes', False), ('Payment method', 'PayPal · maria.l@gmail.com', False), ('Signature', 'Maria Lopez', False)]
def file_desk():
    crumb = f'<span style="display: inline-flex; align-items: center; gap: 4px; font-size: 13px; font-weight: 800; color: {MUTE}">{ic("chevron-left", 14, MUTE)}Filing queue</span>'
    title = (f'<div style="display: flex; align-items: flex-end; justify-content: space-between; gap: 16px"><div style="display: flex; flex-direction: column; gap: 6px">{crumb}'
             f'<div style="display: flex; align-items: center; gap: 10px"><b style="font-size: 26px; letter-spacing: -.7px">Equifax data breach</b>{filer("va")}{st("late")}</div>'
             f'<span style="font-size: 14px; font-weight: 600; color: {MUTE}">For <b style="color: {INK}">Maria Lopez</b> · Priority · requested Nov 22 · claim deadline <b style="color: {INK}">Dec 8</b></span></div>'
             f'<div style="display: flex; align-items: center; gap: 12px"><span style="font-size: 13px; font-weight: 700; color: {MUTE}">1 of 12</span><div style="width: 120px; height: 6px; border-radius: 99px; background: #E3EAE6"><div style="width: 8%; height: 100%; border-radius: 99px; background: {GREEN}"></div></div>{btn("Skip", "skip-forward", False)}</div></div>')
    member = card(h2('Member', chip('Signed Nov 22', '#E9F6EF', GREEN)) + '<div style="margin-top: -6px">' + ''.join(field(*x) for x in [('Legal name', 'Maria Lopez'), ('Email', 'maria.l@gmail.com'), ('Phone', '(619) 555-0148'), ('Date of birth', '04/12/1988'), ('Address', '2210 Grand Ave, Apt 4, San Diego, CA 92109'), ('Payout', 'PayPal · maria.l@gmail.com')]) + '</div>', pad=18)
    ent = card(h2('What she entered') + f'<div style="display: flex; flex-direction: column; gap: 8px; font-size: 13px; font-weight: 600; color: #2B3631"><span>Got a notice: <b>Yes</b> · Notice ID EQF-7N2K-91QX · PIN 4417</span><span style="display: flex; align-items: center; gap: 6px">{ic("paperclip", 14, MUTE)}<b>equifax_letter.pdf</b> · 212 KB</span></div>', pad=18)
    left = f'<div style="flex: 1.05; min-width: 0; display: flex; flex-direction: column; gap: 14px">{member}{ent}</div>'
    rows = ''.join(f'<div style="display: grid; grid-template-columns: 22px 150px 1fr auto; align-items: center; gap: 10px; padding: 9px 0; border-top: 1px solid {LINE}; {"opacity: .55" if d else ""}">'
                   f'<span style="width: 18px; height: 18px; border-radius: 6px; {"background: " + GREEN if d else "box-shadow: inset 0 0 0 1.5px #B9C6BF"}; display: flex; align-items: center; justify-content: center">{ic("check", 12, "#FFFFFF", 3) if d else ""}</span>'
                   f'<span style="font-size: 12.5px; font-weight: 700; color: #8A968F">{k}</span><span style="font-size: 13.5px; font-weight: 700; {"text-decoration: line-through" if d else ""}">{v}</span>'
                   f'<span style="display: inline-flex; align-items: center; gap: 4px; height: 26px; padding: 0 8px; border-radius: 8px; background: #F3F6F4; font-size: 11.5px; font-weight: 800; color: {MUTE}">{ic("copy", 12, MUTE)}Copy</span></div>' for k, v, d in FORM)
    form = card(h2('Claim form, in order', f'<span style="display: flex; align-items: center; gap: 12px"><span style="font-size: 12.5px; font-weight: 800; color: {GREEN}">5 of 11 done</span>{link("Edit spec")}</span>') + f'<div>{rows}</div>', pad=18, extra='flex: 1.35; min-width: 0')
    steps = ''.join(f'<div style="display: flex; gap: 10px; align-items: flex-start"><span style="width: 22px; height: 22px; flex: none; border-radius: 99px; background: {GREEN if i < 2 else "#EEF2F0"}; color: {"#FFFFFF" if i < 2 else MUTE}; font-size: 11.5px; font-weight: 800; display: flex; align-items: center; justify-content: center">{ic("check", 12, "#FFFFFF", 3) if i < 1 else i + 1}</span>'
                    f'<div style="display: flex; flex-direction: column; gap: 1px"><b style="font-size: 13px">{t}</b><span style="font-size: 12px; font-weight: 600; color: #8A968F">{s}</span></div></div>'
                    for i, (t, s) in enumerate([('Open the claim form', 'equifaxbreachsettlement.com'), ('Enter every field', 'Copy from the middle. Tick as you go.'), ('Submit', 'Solve the CAPTCHA if there is one.'), ('Record it', 'Paste the claim ID below.')]))
    inp = lambda l, v, ph=False, h=40: f'<div style="display: flex; flex-direction: column; gap: 5px"><span style="font-size: 12px; font-weight: 800; color: {MUTE}">{l}</span><span style="height: {h}px; box-sizing: border-box; border-radius: 11px; box-shadow: inset 0 0 0 1px {LINE}; background: #FFFFFF; padding: 10px 12px; font-size: 13px; font-weight: 600; color: {"#A9B5AF" if ph else INK}">{v}</span></div>'
    fileit = card(h2('File it') + f'<span style="display: flex; align-items: center; justify-content: center; gap: 8px; height: 44px; border-radius: 12px; background: {INK}; color: #FFFFFF; font-size: 14px; font-weight: 800">{ic("external-link", 16, "#FFFFFF")}Open claim form</span>'
                  + f'<div style="display: flex; flex-direction: column; gap: 12px">{steps}</div>' + inp('Claim ID from the administrator', 'e.g. EQX-1234567', True) + inp('Note to member (for Needs info)', 'Optional', True, 64)
                  + f'<span style="display: flex; align-items: center; justify-content: center; height: 46px; border-radius: 12px; background: {MINT}; color: {INK}; font-size: 14px; font-weight: 800">Mark filed and email member</span>'
                  + f'<span style="display: flex; align-items: center; justify-content: center; height: 40px; border-radius: 12px; background: #FFFFFF; box-shadow: inset 0 0 0 1px {LINE}; font-size: 13.5px; font-weight: 800">Needs info from member</span>', pad=18, extra='flex: .95; min-width: 0')
    return desk(title + f'<div style="display: flex; gap: 14px; align-items: flex-start">{left}{form}{fileit}</div>', on=1)
def file_phone():
    t = (f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="display: inline-flex; align-items: center; gap: 4px; font-size: 13px; font-weight: 800; color: {MUTE}">{ic("chevron-left", 14, MUTE)}Queue · 1 of 12</span>'
         f'<b style="font-size: 22px; letter-spacing: -.5px">Equifax data breach</b><span style="display: flex; gap: 6px">{st("late")}{filer("va")}{chip("Signed", "#E9F6EF", GREEN)}</span></div>')
    seg = scrollrow([pill2('Form', True), pill2('Member'), pill2('File it')])
    rows = ''.join(f'<div style="display: flex; align-items: center; gap: 10px; padding: 10px 0; border-top: 1px solid {LINE}; {"opacity: .55" if d else ""}"><span style="width: 18px; height: 18px; flex: none; border-radius: 6px; {"background: " + GREEN if d else "box-shadow: inset 0 0 0 1.5px #B9C6BF"}; display: flex; align-items: center; justify-content: center">{ic("check", 12, "#FFFFFF", 3) if d else ""}</span>'
                   f'<div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px"><span style="font-size: 11.5px; font-weight: 700; color: #8A968F">{k}</span><b style="font-size: 13.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{v}</b></div>{ic("copy", 16, MUTE)}</div>' for k, v, d in FORM[:8])
    bottom = f'<span style="display: flex; align-items: center; justify-content: center; height: 48px; border-radius: 14px; background: {MINT}; color: {INK}; font-size: 14.5px; font-weight: 800">Mark filed</span>'
    return phone(t + seg + card(h2('Claim form', f'<span style="font-size: 12.5px; font-weight: 800; color: {GREEN}">5 of 11</span>') + f'<div style="margin-top: -6px">{rows}</div>', pad=16, extra='gap: 8px') + bottom, on=1)

# =============== New cases ===============
CASES = [('*', 'Laboratory Services Cooperative data breach', 'Top Class Actions', 'Up to $5,000', 'Nov 24', 'va', 'New'),
         ('', 'Jack\'s Family Restaurants data breach', 'ClaimDepot', 'Up to $3,500', 'Nov 30', 'va', 'New'),
         ('', 'Knott\'s Berry Farm ticket fees', 'OpenClassActions', 'Up to $20', 'Dec 22', 'auto', 'New'),
         ('', 'Apple Siri privacy', 'ClassAction.org', 'Deadline moved', 'Jan 30', 'bot', 'Change'),
         ('', 'New York School of Interior Design breach', 'Top Class Actions', 'Up to $2,500', 'Jan 12', 'member', 'New')]
def cases_desk():
    top = head('New cases', 'Found by the case finder. Nothing goes live until you approve it.', btn('Run now', 'refresh-cw'))
    srcs = '<div style="display: flex; gap: 14px">' + ''.join(
        f'<div style="flex: 1; background: #FFFFFF; border-radius: 16px; box-shadow: inset 0 0 0 1px {LINE}; padding: 14px 16px; display: flex; align-items: center; gap: 12px"><span style="width: 10px; height: 10px; border-radius: 99px; background: {GREEN if ok else RED}"></span>'
        f'<div style="display: flex; flex-direction: column; gap: 1px"><b style="font-size: 13.5px">{s}</b><span style="font-size: 12px; font-weight: 600; color: {MUTE}">{n}</span></div></div>'
        for s, n, ok in [('Top Class Actions', '2 new · today 7:17 AM', True), ('ClaimDepot', '1 new · today 7:17 AM', True), ('OpenClassActions', '1 new · today 7:17 AM', True), ('ClassAction.org', '1 change · today 7:17 AM', True)]) + '</div>'
    bar = '<div style="display: flex; align-items: center; gap: 10px">' + tabs(['To review · 5', 'New · 4', 'Changes · 1', 'Approved', 'Ignored']) + '</div>'
    rows = [[r[0], f'<span style="display: flex; flex-direction: column; gap: 2px; min-width: 0"><b style="font-size: 13.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{r[1]}</b><span style="font-size: 12px; font-weight: 600; color: #8A968F">{r[2]}</span></span>',
             f'<span style="font-weight: 800">{r[3]}</span>', f'<span>{r[4]}</span>', filer(r[5]) if r[5] != 'va' else chip('We file it', '#EAF1FF', '#2F5BD3'), chip(r[6], '#FFF4E0' if r[6] == 'Change' else '#F1ECFF', AMB if r[6] == 'Change' else '#6B46C1')] for r in CASES]
    lst = card(grid('2.2fr 1fr .7fr 1fr .7fr', ['CASE', 'PAYOUT', 'DEADLINE', 'SUGGESTED', ''], rows), extra='flex: 1.5; min-width: 0')
    inp = lambda l, v: f'<div style="display: flex; flex-direction: column; gap: 5px; flex: 1"><span style="font-size: 12px; font-weight: 800; color: {MUTE}">{l}</span><span style="height: 40px; box-sizing: border-box; border-radius: 11px; box-shadow: inset 0 0 0 1px {LINE}; padding: 10px 12px; font-size: 13px; font-weight: 700">{v}</span></div>'
    panel = card(f'<div style="display: flex; flex-direction: column; gap: 4px"><span style="font-size: 11.5px; font-weight: 800; letter-spacing: 1px; color: #6B46C1">NEW CASE</span><b style="font-size: 18px; letter-spacing: -.3px; line-height: 1.25">Laboratory Services Cooperative data breach</b><span style="font-size: 12.5px; font-weight: 600; color: {MUTE}">Found on Top Class Actions · {link("Official site")}</span></div>'
                 + f'<span style="font-size: 13px; font-weight: 600; line-height: 1.5; color: #2B3631">People whose data was exposed in the 2023 LSC breach can claim up to $5,000 in documented losses or a $50 cash payment.</span>'
                 + f'<div style="display: flex; gap: 10px">{inp("Short name", "LSC data breach")}{inp("Deadline", "Nov 24, 2026")}</div><div style="display: flex; gap: 10px">{inp("Payout", "Up to $5,000")}{inp("Category", "Data breach")}</div>'
                 + f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 12px; font-weight: 800; color: {MUTE}">Who files it</span>{tabs(["We file", "Member files", "Auto pay"])}</div>'
                 + f'<div style="display: flex; gap: 10px"><span style="flex: 1; display: flex; align-items: center; justify-content: center; height: 44px; border-radius: 12px; background: {MINT}; font-size: 14px; font-weight: 800">Approve and publish</span><span style="display: flex; align-items: center; justify-content: center; height: 44px; padding: 0 18px; border-radius: 12px; background: #FFFFFF; box-shadow: inset 0 0 0 1px {LINE}; font-size: 14px; font-weight: 800">Ignore</span></div>', pad=20, extra='flex: 1; min-width: 0')
    return desk(top + srcs + bar + f'<div style="display: flex; gap: 14px; align-items: flex-start">{lst}{panel}</div>', on=2)
def cases_phone():
    t = ph_head('New cases', '5 to review · ran 7:17 AM')
    f = scrollrow([pill2('To review 5', True), pill2('New 4'), pill2('Changes 1'), pill2('Approved')])
    cards = ''.join(card(f'<div style="display: flex; justify-content: space-between; gap: 8px"><b style="font-size: 14.5px; line-height: 1.3">{r[1]}</b>{chip(r[6], "#FFF4E0" if r[6] == "Change" else "#F1ECFF", AMB if r[6] == "Change" else "#6B46C1")}</div>'
                         f'<span style="font-size: 12.5px; font-weight: 700; color: {MUTE}">{r[3]} · closes {r[4]} · {r[2]}</span>'
                         f'<div style="display: flex; gap: 8px"><span style="flex: 1; display: flex; align-items: center; justify-content: center; height: 38px; border-radius: 11px; background: {MINT}; font-size: 13px; font-weight: 800">Review</span><span style="display: flex; align-items: center; justify-content: center; height: 38px; padding: 0 14px; border-radius: 11px; box-shadow: inset 0 0 0 1px {LINE}; font-size: 13px; font-weight: 800">Ignore</span></div>', pad=14, extra='gap: 8px') for r in CASES[:4])
    return phone(t + f + cards, tabs=('Today', 'Queue', 'Members', 'Funnel', 'More'), on=4)

# =============== Refunds ===============
REF = [('*', 'Lena Park', 'lena.p@gmail.com', 'Planet Fitness', '$24.99', 'Charged after I cancelled in September', 'requested', '2h ago'),
       ('', 'Chris Hale', 'chale@gmail.com', 'Wells Fargo', '$35.00', 'Overdraft fee on a pending deposit', 'requested', 'Yesterday'),
       ('', 'Mia Torres', 'miat@yahoo.com', 'Hulu', '$17.99', 'Cancel subscription', 'cancel', 'Yesterday'),
       ('', 'Sam Ortiz', 'sam.o@gmail.com', 'DoorDash', '$46.20', 'Order never arrived', 'replied', '3 days ago'),
       ('', 'Jo Kim', 'jokim@gmail.com', 'Spirit Airlines', '$65.00', 'Charged twice for a seat', 'replied', '4 days ago')]
RS = {'requested': ('Requested', '#EAF1FF', '#2F5BD3'), 'replied': ('Company replied', '#F1ECFF', '#6B46C1'), 'cancel': ('Cancel for me', '#FFF4E0', AMB)}
def rs(k): t, b, f = RS[k]; return chip(t, b, f)
def refunds_desk():
    top = head('Refunds', 'Charges members asked us to get back, and subscriptions to cancel. Members see each update.', '')
    stats = '<div style="display: flex; gap: 14px">' + mini('inbox', '#2F5BD3', '#EAF1FF', '3', 'To ask the company') + mini('message-square', '#6B46C1', '#F1ECFF', '2', 'Company replied') + mini('badge-dollar-sign', GREEN, '#E9F6EF', '$412', 'Refunded this month', '9 requests') + mini('circle-x', RED, '#FDECEB', '2', 'Not refunded', 'this month') + '</div>'
    bar = '<div style="display: flex; align-items: center; gap: 10px">' + tabs(['To do · 5', 'Refunded · 9', 'Closed · 4']) + '<span style="flex: 1"></span>' + fchip('Refunds') + fchip('Cancellations') + searchbox('Member or company', 220) + '</div>'
    rows = [[r[0], who(r[1], r[2]), f'<b>{r[3]}</b>', f'<b>{r[4]}</b>', f'<span style="color: #2B3631; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{r[5]}</span>', rs(r[6]), f'<span style="color: #8A968F; font-weight: 700; white-space: nowrap">{r[7]}</span>'] for r in REF]
    lst = card(grid('1.4fr .9fr .6fr 1.6fr 1fr .7fr', ['MEMBER', 'COMPANY', 'AMOUNT', 'WHAT HAPPENED', 'STATUS', 'ADDED'], rows), extra='flex: 1.7; min-width: 0')
    draft = (f'<div style="border-radius: 12px; background: #F7FBF9; box-shadow: inset 0 0 0 1px {LINE}; padding: 12px; font-size: 12.5px; font-weight: 600; line-height: 1.55; color: #2B3631">Hi, I am writing for Lena Park about a $24.99 charge on Nov 1. She cancelled her membership on Sep 14 (confirmation attached). Please refund the charge to the card on file.</div>')
    panel = card(f'<div style="display: flex; justify-content: space-between; align-items: flex-start"><div style="display: flex; flex-direction: column; gap: 3px"><b style="font-size: 18px">Planet Fitness · $24.99</b><span style="font-size: 12.5px; font-weight: 600; color: {MUTE}">Lena Park · added 2h ago</span></div>{rs("requested")}</div>'
                 + f'<div style="display: flex; flex-direction: column; gap: 4px"><span style="font-size: 12px; font-weight: 800; color: {MUTE}">What happened</span><span style="font-size: 13.5px; font-weight: 600">Charged after I cancelled in September</span></div>'
                 + f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 12px; font-weight: 800; color: {MUTE}; display: flex; justify-content: space-between">Message to the company {link("Copy")}</span>{draft}</div>'
                 + f'<div style="display: flex; flex-direction: column; gap: 6px"><span style="font-size: 12px; font-weight: 800; color: {MUTE}">Update status</span>{tabs(["Requested", "Replied", "Refunded", "Not refunded"])}</div>'
                 + f'<span style="display: flex; align-items: center; justify-content: center; height: 44px; border-radius: 12px; background: {INK}; color: #FFFFFF; font-size: 14px; font-weight: 800">Save and update member</span>', pad=20, extra='flex: 1; min-width: 0')
    return desk(top + stats + bar + f'<div style="display: flex; gap: 14px; align-items: flex-start">{lst}{panel}</div>', on=3)
def refunds_phone():
    t = ph_head('Refunds', '5 to do · $412 back this month')
    f = scrollrow([pill2('To do 5', True), pill2('Refunded 9'), pill2('Closed 4')])
    rows = ''.join(ph_row(who(r[3] + ' · ' + r[4], r[1], 34), rs(r[6]), f'<span style="font-size: 11.5px; font-weight: 700; color: #8A968F">{r[7]}</span>') for r in REF)
    return phone(t + f + card(f'<div style="margin: -6px 0">{rows}</div>', pad=16, extra='gap: 0'), on=4)

# =============== Members ===============
M = [('*', 'Kim Nguyen', 'kim.n@gmail.com · (858) 555-0110', ('Trial', 'ends Nov 26'), 4, 2, '$0', 'Today', 'H'),
     ('', 'Maria Lopez', 'maria.l@gmail.com · (619) 555-0148', ('Priority', '$30/mo'), 6, 1, '$90', 'Oct 30', 'G'),
     ('', 'James Carter', 'jcarter@yahoo.com', ('Fast', '$15/mo'), 3, 1, '$30', 'Nov 2', 'G'),
     ('', 'Ana Ruiz', 'ana.ruiz@gmail.com', ('Yearly', '$49.99/yr'), 5, 1, '$49.99', 'Nov 9', 'H'),
     ('', 'Derek Shaw', 'dshaw@outlook.com', ('Monthly', '$19.99/mo'), 2, 1, '$19.99', 'Nov 12', 'F'),
     ('', 'Lee Wong', 'lee.w@yahoo.com', ('Cancelled', 'Nov 21'), 3, 0, '$0', 'Nov 18', 'F'),
     ('', 'Tom Becker', 'tbecker@gmail.com', ('Yearly', '$49.99/yr'), 4, 1, '$49.99', 'Nov 15', 'H'),
     ('', 'Rosa Diaz', 'rosa.d@icloud.com', ('Monthly', '$19.99/mo'), 1, 1, '$39.98', 'Oct 21', 'F')]
def members_desk():
    top = head('Members', 'Everyone with an account. Open a member for their info, claims, signed forms and payments.', btn('Export CSV', 'download', False))
    stats = '<div style="display: flex; gap: 14px">' + mini('users', GREEN, '#E9F6EF', '214', 'Accounts', '+31 this week') + mini('hourglass', AMB, '#FFF4E0', '23', 'In trial', '9 end this week') + mini('badge-dollar-sign', GREEN, '#E9F6EF', '71', 'Paying') + mini('user-x', RED, '#FDECEB', '12', 'Cancelled', 'last 30 days') + '</div>'
    bar = '<div style="display: flex; align-items: center; gap: 10px">' + searchbox('Search name, email or phone', 300) + fchip('All', True) + fchip('In trial') + fchip('Paying') + fchip('Cancelled') + fchip('Has claims to file') + '<span style="flex: 1"></span>' + fchip('Newest first', icn='arrow-down-up') + '</div>'
    rows = [[r[0], who(r[1], r[2]), f'<span style="display: flex; flex-direction: column; gap: 3px; align-items: flex-start">{plan(r[3][0])}<span style="font-size: 11.5px; font-weight: 700; color: #8A968F">{r[3][1]}</span></span>',
             f'<span style="font-weight: 800">{r[8]}</span>', f'<b>{r[4]}</b>', f'<span>{chip(str(r[5]) + " to file", "#FFF4E0", AMB) if r[5] else "<span style=color:#A9B5AF>None</span>"}</span>', f'<b>{r[6]}</b>', f'<span style="color: #8A968F; font-weight: 700">{r[7]}</span>'] for r in M]
    tbl = card(grid('2.2fr 1fr .5fr .6fr .9fr .7fr .7fr', ['MEMBER', 'PLAN', 'OFFER', 'CLAIMS', 'TO FILE', 'PAID US', 'JOINED'], rows))
    return desk(top + stats + bar + tbl, on=4)
def members_phone():
    t = ph_head('Members', '214 accounts · 71 paying')
    s = f'<div style="margin-top: -4px">{searchbox("Name, email or phone", 358)}</div>'
    f = scrollrow([pill2('All', True), pill2('In trial 23'), pill2('Paying 71'), pill2('Cancelled')])
    rows = ''.join(ph_row(who(r[1], r[2].split(' · ')[0], 34), plan(r[3][0]), f'<span style="font-size: 11.5px; font-weight: 700; color: #8A968F">{r[7]}</span>') for r in M[:7])
    return phone(t + s + f + card(f'<div style="margin: -6px 0">{rows}</div>', pad=16, extra='gap: 0'), on=2)

# =============== Member detail ===============
def member_desk():
    crumb = f'<span style="display: inline-flex; align-items: center; gap: 4px; font-size: 13px; font-weight: 800; color: {MUTE}">{ic("chevron-left", 14, MUTE)}Members</span>'
    hd = (f'<div style="display: flex; flex-direction: column; gap: 10px">{crumb}<div style="display: flex; align-items: center; gap: 16px">{avatar("Maria", 56)}'
          f'<div style="display: flex; flex-direction: column; gap: 4px; flex: 1"><div style="display: flex; align-items: center; gap: 10px"><b style="font-size: 26px; letter-spacing: -.7px">Maria Lopez</b>{plan("Priority")}{chip("Offer G", "#EEF2F0", INK)}</div>'
          f'<span style="font-size: 13.5px; font-weight: 600; color: {MUTE}">maria.l@gmail.com · (619) 555-0148 · joined Oct 30 from Meta on iPhone</span></div>'
          f'<div style="display: flex; gap: 8px">{btn("Email", "mail", False)}{btn("Open in Stripe", "external-link", False)}</div></div></div>')
    stats = '<div style="display: flex; gap: 14px">' + mini('folder-open', GREEN, '#E9F6EF', '6', 'Claims', '1 to file') + mini('badge-dollar-sign', GREEN, '#E9F6EF', '$90', 'Paid us', '3 payments') + mini('hand-coins', GREEN, '#E9F6EF', '$62', 'Paid out to her', '1 claim') + mini('pen-line', GREEN, '#E9F6EF', '6 of 6', 'Claims signed') + '</div>'
    tb = tabs(['Overview', 'Claims · 6', 'Signed forms · 6', 'Payments · 3', 'Emails · 9', 'History'])
    info = card(h2('Saved info') + '<div style="margin-top: -6px">' + ''.join(field(*x) for x in [('Legal name', 'Maria Lopez'), ('Date of birth', '04/12/1988'), ('Address', '2210 Grand Ave, Apt 4, San Diego, CA 92109'), ('Past addresses', '88 Elm St, Austin, TX 78701'), ('Payout', 'PayPal · maria.l@gmail.com (preferred)'), ('Email updates', 'On', False)]) + '</div>', pad=18, extra='flex: 1; min-width: 0')
    cl = [('Equifax data breach', 'late', 'Requested Nov 22', ''), ('Meta pixel privacy', 'paid', 'Paid $62 on Nov 19', 'MPX-22190'), ('Apple Siri privacy', 'filed', 'Filed Nov 12', 'SIRI-40021'), ('T-Mobile data breach', 'approved', 'Pays in Jan', 'TMO-55102'), ('Google Play Store', 'review', 'Filed Nov 3', 'GP-10087')]
    claims = card(h2('Claims', link('All 6')) + '<div>' + ''.join(f'<div style="display: grid; grid-template-columns: 1.6fr 1fr 1.1fr .9fr; align-items: center; gap: 10px; padding: 10px 0; border-top: 1px solid {LINE}; font-size: 13.5px; font-weight: 700"><b>{n}</b><span>{st(s)}</span><span style="color: {MUTE}">{w}</span><span style="font-family: ui-monospace, monospace; font-size: 12px; color: #8A968F">{c}</span></div>' for n, s, w, c in cl) + '</div>', pad=18)
    tl = [('credit-card', GREEN, 'Paid $30.00 · Priority monthly', 'Nov 22'), ('file-check', GREEN, 'Apple Siri claim filed by Henry', 'Nov 12'), ('mail', '#2F5BD3', 'Email sent: We filed your claim', 'Nov 12'), ('hand-coins', GREEN, 'Meta pixel claim paid, $62', 'Nov 19'), ('user-plus', '#2F5BD3', 'Joined, offer G, Priority', 'Oct 30')]
    hist = card(h2('Recent history') + '<div>' + ''.join(f'<div style="display: flex; gap: 12px; align-items: center; padding: 9px 0; border-top: 1px solid {LINE}"><span style="width: 28px; height: 28px; flex: none; border-radius: 9px; background: #F3F6F4; display: flex; align-items: center; justify-content: center">{ic(i, 14, c)}</span><span style="flex: 1; font-size: 13px; font-weight: 700">{t}</span><span style="font-size: 12px; font-weight: 700; color: #8A968F">{d}</span></div>' for i, c, t, d in tl) + '</div>', pad=18)
    right = f'<div style="flex: 1.35; min-width: 0; display: flex; flex-direction: column; gap: 14px">{claims}{hist}</div>'
    return desk(hd + stats + tb + f'<div style="display: flex; gap: 14px; align-items: flex-start">{info}{right}</div>', on=4)
def member_phone():
    t = (f'<div style="display: flex; flex-direction: column; gap: 10px"><span style="display: inline-flex; align-items: center; gap: 4px; font-size: 13px; font-weight: 800; color: {MUTE}">{ic("chevron-left", 14, MUTE)}Members</span>'
         f'<div style="display: flex; align-items: center; gap: 12px">{avatar("Maria", 48)}<div style="display: flex; flex-direction: column; gap: 3px"><b style="font-size: 21px; letter-spacing: -.5px">Maria Lopez</b><span style="display: flex; gap: 6px">{plan("Priority")}{chip("6 claims", "#EEF2F0", INK)}</span></div></div></div>')
    seg = scrollrow([pill2('Overview', True), pill2('Claims 6'), pill2('Signed 6'), pill2('Payments 3'), pill2('Emails')])
    info = card(h2('Saved info') + '<div style="margin-top: -6px">' + ''.join(
        f'<div style="display: flex; align-items: center; gap: 10px; padding: 9px 0; border-top: 1px solid {LINE}"><div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px"><span style="font-size: 11.5px; font-weight: 700; color: #8A968F">{k}</span><b style="font-size: 13.5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{v}</b></div>{ic("copy", 16, MUTE)}</div>'
        for k, v in [('Email', 'maria.l@gmail.com'), ('Phone', '(619) 555-0148'), ('Date of birth', '04/12/1988'), ('Address', '2210 Grand Ave, Apt 4, San Diego'), ('Payout', 'PayPal · maria.l@gmail.com')]) + '</div>', pad=16, extra='gap: 8px')
    ks = '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px">' + mini('badge-dollar-sign', GREEN, '#E9F6EF', '$90', 'Paid us') + mini('hand-coins', GREEN, '#E9F6EF', '$62', 'Paid out') + '</div>'
    return phone(t + seg + ks + info, on=2)

# =============== Funnel ===============
def funnel_desk():
    top = head('Funnel', 'October 25 to November 23 · compared with the 30 days before', '<div style="display: flex; gap: 10px; align-items: center">' + tabs(['Today', '7 days', '30 days', '90 days', 'Custom'], 2) + btn('Export CSV', 'download', False) + '</div>')
    sw = '<div style="display: flex; align-items: center; gap: 10px">' + tabs(['Results', 'Currently running']) + '<span style="flex: 1"></span>' + fchip('All offers', True) + fchip('Meta') + fchip('Google Ads') + fchip('iPhone') + fchip('Android') + fchip('Desktop') + '</div>'
    alert = (f'<div style="display: flex; align-items: center; gap: 12px; background: #FFF4E0; border-radius: 14px; padding: 12px 16px; font-size: 13.5px; font-weight: 700; color: #6B4A10">'
             f'{ic("triangle-alert", 18, AMB)}Saw offer to Opened payment dropped from 38% to 32% on phones since Nov 20.<span style="margin-left: auto">{link("See by device")}</span></div>')
    ks = '<div style="display: flex; gap: 14px">' + ''.join(kpi(t, v, d, sp) for t, v, d, sp in [('Visitors', '12,480', '24%', SPARK['vis']), ('Trials started', '512', '31%', SPARK['trial']), ('Trial to paid', '41%', '3 pts', SPARK['conv']), ('Revenue', '$6,920', '27%', SPARK['rev']), ('Cost per trial', '$8.03', '$1.10', [11, 10.5, 10, 9.8, 9.4, 9.6, 9.1, 8.8, 8.9, 8.5, 8.4, 8.2, 8.1, 8.03])]) + '</div>'
    fun = card(h2('Claim flow funnel', link('By offer')) + f'<div style="display: flex; flex-direction: column; gap: 9px">{adminD.funnel_()}</div>', extra='flex: 1; min-width: 0')
    off = card(h2('Offer test', chip('F and H live · 50 / 50', '#E9F6EF', GREEN)) + adminD.table(['OFFER', 'VISITORS', 'TRIALS', 'TO PAID', '$ / VISITOR'], [['H · $49.99/yr', '6,240', '262', '44%', '$0.92'], ['F · $19.99/mo', '6,240', '250', '38%', '$0.61']], ['1.6fr', '1fr', '1fr', '1fr', '1fr'])
               + h2('By source') + adminD.table(['SOURCE', 'VISITORS', 'TRIALS', 'SPEND', 'PER TRIAL'], [['Meta', '7,920', '301', '$2,940', '$9.77'], ['Google Ads', '2,880', '142', '$1,170', '$8.24'], ['Organic', '1,280', '58', '$0', '$0']], ['1.4fr', '1fr', '1fr', '1fr', '1fr']), extra='flex: 1; min-width: 0')
    return desk(top + sw + alert + ks + f'<div style="display: flex; gap: 14px; align-items: flex-start">{fun}{off}</div>', on=5)
def funnel_phone():
    t = ph_head('Funnel', '', f'<span style="display: inline-flex; align-items: center; gap: 6px; height: 34px; padding: 0 12px; border-radius: 99px; background: #FFFFFF; box-shadow: inset 0 0 0 1px {LINE}; font-size: 13px; font-weight: 800">30 days{ic("chevron-down", 14, INK)}</span>')
    seg = scrollrow([pill2('Results', True), pill2('Currently running'), pill2('Meta'), pill2('Google')])
    ks = '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px">' + ''.join(
        f'<div style="background: #FFFFFF; border-radius: 14px; box-shadow: inset 0 0 0 1px {LINE}; padding: 12px; display: flex; flex-direction: column; gap: 4px"><span style="font-size: 11.5px; font-weight: 700; color: {MUTE}">{t}</span><b style="font-size: 20px; letter-spacing: -.5px">{v}</b>{spark(sp, 140, 24)}</div>'
        for t, v, sp in [('Visitors', '12,480', SPARK['vis']), ('Trials', '512', SPARK['trial']), ('Trial to paid', '41%', SPARK['conv']), ('Revenue', '$6,920', SPARK['rev'])]) + '</div>'
    fun = card(h2('Funnel') + f'<div style="display: flex; flex-direction: column; gap: 8px">{adminD.funnel_(True)}</div>', pad=16)
    return phone(t + seg + ks + fun, on=3)

# =============== Settings ===============
def srow(t, d, right, first=False):
    return (f'<div style="display: flex; align-items: center; gap: 18px; padding: 14px 0; {"" if first else "border-top: 1px solid " + LINE}"><div style="flex: 1; display: flex; flex-direction: column; gap: 3px"><b style="font-size: 14px">{t}</b>'
            f'<span style="font-size: 12.5px; font-weight: 600; color: {MUTE}; line-height: 1.45">{d}</span></div>{right}</div>')
def settings_desk():
    top = head('Settings', 'Switches that change what visitors and members see. Changes go live within a minute.', '')
    offers = card(h2('Offer test', chip('2 on · 50% each', '#E9F6EF', GREEN)) + '<div style="margin-top: -6px">' + ''.join(
        srow(t, d, toggle(on), i == 0) for i, (t, d, on) in enumerate([('F · Free 3 days, then $19.99 a month', 'Live since Nov 22 · 6,240 visitors', True), ('H · Free 3 days, then $49.99 a year', 'Live since Nov 22 · 6,240 visitors', True),
                                                                        ('G · Standard, Fast, Priority plans', 'Off since Nov 22', False), ('Flow C · A, B, C', 'Off · preview at /check?offer=A', False), ('A to E · older offers', '5 offers, all off', False)])) + '</div>', extra='flex: 1; min-width: 0')
    conn = card(h2('Connections') + '<div style="margin-top: -6px">' + srow('Card connections (Plaid)', 'Claim a refund and Subscription Manager. Admins can always test it.', toggle(False), True) + srow('Bank step in the claim flow', 'Asks new members to connect a bank for payout alerts.', toggle(False)) + '</div>')
    bot = card(h2('Filing bot', chip('Practice', '#FFF4E0', AMB)) + f'<span style="font-size: 12.5px; font-weight: 600; color: {MUTE}; line-height: 1.45; margin-top: -6px">Practice fills the form and stops before Submit so you approve each one.</span>'
               + tabs(['Off', 'Practice', 'Submit automatically'], 1) + f'<div style="display: flex; flex-wrap: wrap; gap: 8px">' + ''.join(fchip(t, on) for t, on in [('Angeion · 21', True), ('Simpluris · 58', False), ('Kroll · 31', False), ('Epiq · 7', False), ('JND · 4', False), ('Everyone else', False)]) + '</div>')
    left = f'<div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 14px">{offers}{conn}</div>'
    admins = card(h2('Admins', f'<span style="display: inline-flex; align-items: center; gap: 4px; font-size: 13px; font-weight: 800; color: {GREEN}">{ic("plus", 14, GREEN)}Add admin</span>') + '<div style="margin-top: -6px">' + ''.join(
        f'<div style="display: flex; align-items: center; gap: 12px; padding: 11px 0; {"border-top: 1px solid " + LINE if i else ""}">{who(n, e)}<span style="margin-left: auto">{chip(r, "#0F3B2E" if r == "Owner" else "#EEF2F0", "#FFFFFF" if r == "Owner" else INK)}</span></div>'
        for i, (n, e, r) in enumerate([('Henry Sidwell', 'sidwellh17@gmail.com', 'Owner'), ('Zach Sidwell', 'sidwell.zach@gmail.com', 'Admin')])) + '</div>')
    mail = card(h2('Member emails', chip('Working', '#E9F6EF', GREEN)) + f'<span style="font-size: 12.5px; font-weight: 600; color: {MUTE}; line-height: 1.45; margin-top: -6px">Status emails go out from updates@claimclub.io. Replies go to support@mail.claimclub.io.</span>'
                + f'<div style="display: flex; gap: 8px">{btn("Send me a test email", "send", False)}{btn("Email log", "list", False)}</div>')
    right = f'<div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 14px">{bot}{admins}{mail}</div>'
    return desk(top + f'<div style="display: flex; gap: 14px; align-items: flex-start">{left}{right}</div>', on=6)
def settings_phone():
    t = ph_head('Settings')
    offers = card(h2('Offer test', chip('2 on', '#E9F6EF', GREEN)) + '<div style="margin-top: -6px">' + ''.join(srow(a, b, toggle(c), i == 0) for i, (a, b, c) in enumerate([('F · $19.99 a month', 'Free 3 days first', True), ('H · $49.99 a year', 'Free 3 days first', True), ('G · Plans', 'Off since Nov 22', False)])) + '</div>', pad=16, extra='gap: 8px')
    conn = card(h2('Connections') + '<div style="margin-top: -6px">' + srow('Card connections', 'Refunds and subscriptions', toggle(False), True) + srow('Bank step', 'In the claim flow', toggle(False)) + '</div>', pad=16, extra='gap: 8px')
    bot = card(h2('Filing bot', chip('Practice', '#FFF4E0', AMB)) + tabs(['Off', 'Practice', 'Auto'], 1), pad=16)
    return phone(t + offers + conn + bot, on=4)

if __name__ == '__main__':
    adminD.board('AdminA', 'ADMIN · OVERVIEW', 'Opens on what needs you: claims to file (late ones in red), member replies, new cases, refunds and failed emails, each one tap away. Below that, five numbers with 14-day trend lines, the next claims in the queue with their due time, the live offer test and recent activity. Sample numbers.', a_desk(), a_phone())
    B = [('AdminQueue', 'ADMIN · FILING QUEUE', 'Counts on top (late, due today, bot can file, CAPTCHA, filed this week), tabs for each stage, quick filters, then one row per claim with plan, who files it, due time and whether it is signed. Priority and late claims first.', queue_desk(), queue_phone()),
         ('AdminFile', 'ADMIN · FILING A CLAIM', 'Everything to file one claim on one screen: member info with copy buttons, the claim form fields in order with tick boxes, and File it on the right (open form, steps, claim ID, Mark filed). Progress through the queue and Skip at the top right.', file_desk(), file_phone()),
         ('AdminCases', 'ADMIN · NEW CASES', 'Case finder sources with their last run, tabs for To review, New, Changes, Approved and Ignored, and the picked case open on the right with its details, who files it and Approve or Ignore.', cases_desk(), cases_phone()),
         ('AdminRefunds', 'ADMIN · REFUNDS', 'Counts for what to ask, what the company answered and what came back this month. The list on the left, the picked request on the right with a ready message to the company and the status switch.', refunds_desk(), refunds_phone()),
         ('AdminMembers', 'ADMIN · MEMBERS', 'Account, trial, paying and cancelled counts, search and filters, then one row per member with plan, offer, claims, claims to file, what they paid us and when they joined.', members_desk(), members_phone()),
         ('AdminMember', 'ADMIN · ONE MEMBER', 'A full page instead of a side drawer: header with plan and offer, Email and Open in Stripe, four numbers, tabs for claims, signed forms, payments, emails and history. Overview shows saved info with copy buttons, claims and recent history.', member_desk(), member_phone()),
         ('AdminFunnel', 'ADMIN · FUNNEL', 'Results and Currently running as tabs, date range, offer, source and device filters, an alert line for big moves, five numbers with trends, the funnel with the drop at each step, the offer test and results by source.', funnel_desk(), funnel_phone()),
         ('AdminSettings', 'ADMIN · SETTINGS', 'Grouped cards: Offer test switches with the split, Connections, Filing bot mode and administrators, Admins (with Add admin) and Member emails with a test button.', settings_desk(), settings_phone())]
    for b in B: adminD.board(*b)
    print('ok')
