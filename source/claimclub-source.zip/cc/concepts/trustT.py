# Draft: the 4 trust points under reviews as tiles (4 across on desktop, one full screen each on mobile). Board TrustT.dc.html.
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from how4 import ic, LOGO, HEAD, JS, OUT, IC

MINT, DARK, GREEN = '#3DDC97', '#0F3B2E', '#12805C'
IC.update({
    'scale': '<path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"></path><path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"></path><path d="M7 21h10"></path><path d="M12 3v18"></path><path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2"></path>',
    'lock': '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path>',
    'landmark': '<line x1="3" x2="21" y1="22" y2="22"></line><line x1="6" x2="6" y1="18" y2="11"></line><line x1="10" x2="10" y1="18" y2="11"></line><line x1="14" x2="14" y1="18" y2="11"></line><line x1="18" x2="18" y1="18" y2="11"></line><polygon points="12 2 20 7 4 7"></polygon>',
    'user': '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle>',
})

def vis_court(m):
    return ('<div style="position: relative; width: 230px; height: 200px">'
            '<div style="position: absolute; left: 6px; top: 10px; width: 200px; padding: 16px; border-radius: 16px; background: #FFFFFF; box-shadow: 0 18px 40px rgba(10,15,13,.14); transform: rotate(-4deg); display: flex; flex-direction: column; gap: 8px">'
            '<span style="font-size: 10px; font-weight: 800; letter-spacing: 1px; color: #8A968F">FINAL APPROVAL ORDER</span>'
            + ''.join(f'<span style="height: 7px; width: {w}%; border-radius: 99px; background: #E3EAE6"></span>' for w in (92, 80, 88, 64)) +
            '<span style="font-size: 11px; font-weight: 700; color: #43504A; margin-top: 4px">U.S. District Court</span></div>'
            f'<div style="position: absolute; right: 0; bottom: 6px; width: 92px; height: 92px; border-radius: 50%; background: {MINT}; color: {DARK}; display: flex; flex-direction: column; align-items: center; justify-content: center; transform: rotate(10deg); box-shadow: 0 14px 30px rgba(10,15,13,.2), inset 0 0 0 5px rgba(255,255,255,.5)">{ic("scale", 30, 2.2)}<span style="font-size: 10px; font-weight: 800; letter-spacing: .8px; margin-top: 2px">APPROVED</span></div></div>')

def vis_pay(m):
    node = lambda icon, label, bg, c: f'<div style="display: flex; flex-direction: column; align-items: center; gap: 8px"><span style="width: 64px; height: 64px; border-radius: 20px; background: {bg}; color: {c}; display: flex; align-items: center; justify-content: center; box-shadow: 0 12px 26px rgba(0,0,0,.18)">{ic(icon, 28, 2.2)}</span><span style="font-size: 12px; font-weight: 800; color: #C9D6CF">{label}</span></div>'
    return ('<div style="display: flex; flex-direction: column; align-items: center; gap: 18px">'
            '<div style="display: flex; align-items: center; gap: 10px">' + node('landmark', 'Settlement', '#FFFFFF', DARK) +
            f'<div style="display: flex; flex-direction: column; align-items: center; gap: 4px; margin-bottom: 22px"><span style="font-size: 15px; font-weight: 800; color: {MINT}">$95</span><span style="width: 70px; height: 3px; border-radius: 99px; background: repeating-linear-gradient(90deg, {MINT} 0 8px, transparent 8px 13px)"></span></div>'
            + node('user', 'You', MINT, DARK) + '</div>'
            f'<span style="padding: 7px 14px; border-radius: 99px; background: rgba(255,255,255,.1); box-shadow: inset 0 0 0 1px rgba(255,255,255,.18); font-size: 13px; font-weight: 800">We take $0 of your payout</span></div>')

def vis_lock(m):
    field = lambda k, v: f'<div style="display: flex; justify-content: space-between; padding: 10px 12px; border-radius: 12px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #E3EAE6; font-size: 13px"><span style="color: #8A968F; font-weight: 700">{k}</span><span style="font-weight: 800; letter-spacing: 2px">{v}</span></div>'
    return ('<div style="position: relative; width: 230px; display: flex; flex-direction: column; gap: 8px; padding: 14px; border-radius: 20px; background: #F3F6F4; box-shadow: 0 18px 40px rgba(10,15,13,.10)">'
            + field('Address', '•••• ••••') + field('Phone', '••• ••• ••••') + field('Date of birth', '••/••/••••') +
            f'<span style="position: absolute; right: -24px; top: -30px; width: 54px; height: 54px; border-radius: 16px; background: {DARK}; color: {MINT}; display: flex; align-items: center; justify-content: center; box-shadow: 0 12px 26px rgba(10,15,13,.25)">{ic("lock", 26, 2.4)}</span></div>')

def vis_cancel(m):
    return ('<div style="width: 240px; display: flex; flex-direction: column; gap: 10px; padding: 16px; border-radius: 20px; background: #FFFFFF; box-shadow: 0 18px 40px rgba(10,15,13,.12)">'
            '<div style="display: flex; justify-content: space-between; align-items: center"><span style="display: flex; flex-direction: column"><b style="font-size: 14px">Membership</b><span style="font-size: 12px; color: #5B6862; font-weight: 600">Renews Dec 15</span></span>'
            '<span style="width: 50px; height: 30px; border-radius: 99px; background: #DDE5E0; position: relative"><span style="position: absolute; left: 3px; top: 3px; width: 24px; height: 24px; border-radius: 50%; background: #FFFFFF; box-shadow: 0 2px 6px rgba(0,0,0,.2)"></span></span></div>'
            '<div style="height: 1px; background: #EEF2F0"></div>'
            f'<span style="display: flex; align-items: center; gap: 6px; font-size: 13px; font-weight: 800; color: {GREEN}">{ic("check", 15, 3)}Cancelled. No fees, no calls.</span></div>')

TILES = [
    ('Every settlement is court-approved', 'We only list settlements a judge has approved, so the money is real and set aside.', vis_court, MINT, DARK, DARK),
    ('Payouts come straight from the settlement', 'The administrator pays you directly by PayPal, Venmo, Zelle or check.', vis_pay, DARK, '#FFFFFF', '#C9D6CF'),
    ('Your details are encrypted', 'Only the claim forms you sign ever see them. We never sell your data.', vis_lock, '#FFFFFF', '#0A0F0D', '#5B6862'),
    ('Cancel anytime in one tap', 'No phone calls, no emails, no fees. It is a switch in your settings.', vis_cancel, '#E9F6EF', DARK, '#43504A'),
]

def tile(i, m):
    t, d, vis, bg, fg, sub = TILES[i]
    edge = 'box-shadow: inset 0 0 0 1px #E3EAE6;' if bg == '#FFFFFF' else ''
    if m:
        return (f'<div style="min-height: 680px; border-radius: 30px; background: {bg}; {edge} color: {fg}; padding: 30px 24px; box-sizing: border-box; display: flex; flex-direction: column; justify-content: space-between">'
                f'<span style="font-size: 13px; font-weight: 800; opacity: .6">0{i + 1}</span><div style="flex: 1; display: flex; align-items: center; justify-content: center; padding: 30px 0">{vis(m)}</div>'
                f'<div style="display: flex; flex-direction: column; gap: 10px"><h3 style="margin: 0; font-size: 32px; line-height: 1.08; letter-spacing: -1px">{t}</h3><p style="margin: 0; font-size: 16px; line-height: 1.5; color: {sub}">{d}</p></div></div>')
    return (f'<div style="flex: 1 1 0; min-width: 0; height: 470px; border-radius: 28px; background: {bg}; {edge} color: {fg}; padding: 26px; box-sizing: border-box; display: flex; flex-direction: column">'
            f'<div style="flex: 1; display: flex; align-items: center; justify-content: center">{vis(m)}</div>'
            f'<div style="display: flex; flex-direction: column; gap: 8px"><h3 style="margin: 0; font-size: 23px; line-height: 1.12; letter-spacing: -.6px">{t}</h3><p style="margin: 0; font-size: 14.5px; line-height: 1.5; color: {sub}">{d}</p></div></div>')

def section(m):
    head = f'<h2 style="margin: 0 0 {22 if m else 32}px; font-size: {30 if m else 44}px; letter-spacing: -1.2px; color: {DARK}">Why people trust Claimclub</h2>'
    body = ''.join(tile(i, m) for i in range(4))
    return (f'<section style="background: #F3F6F4; padding: {40 if m else 80}px {16 if m else 40}px; min-height: 100%; box-sizing: border-box">{head}'
            f'<div style="display: flex; {"flex-direction: column; gap: 14px" if m else "gap: 16px"}">{body}</div></section>')

def build():
    c = json.load(open(os.path.join(OUT, 'canvas.json')))
    y0 = max(b['y'] + b['h'] for k, b in c['boards'].items() if k != 'TrustT.dc.html') + 260
    c['notes']['tTR'] = {'x': 0, 'y': y0, 'text': 'Draft · trust tiles under the reviews (desktop 4 across, mobile one per screen)', 'kind': 'title1', 'maxW': 1926, 'w': 240}
    if 'tTR' not in c['noteOrder']: c['noteOrder'].append('tTR')
    title = 'Trust tiles draft'
    page = (f'<div style="width: 1926px; height: 980px; box-sizing: border-box; padding: 24px; background: #E7ECE9; font-family: \'Manrope\', sans-serif; color: #0A0F0D; display: flex; flex-direction: column; gap: 14px">'
            f'<div style="font-size: 14px; font-weight: 800; letter-spacing: 1.2px; color: #43504A">TRUST TILES · DRAFT (SCROLL INSIDE THE PHONE)</div><div style="display: flex; gap: 48px; align-items: flex-start">'
            f'<div class="scroll" style="width: 1440px; height: 900px; flex: none; overflow-y: auto; border-radius: 18px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{section(False)}</div>'
            f'<div class="scroll" style="width: 390px; height: 844px; flex: none; overflow-y: auto; border-radius: 28px; background: #FFFFFF; box-shadow: 0 30px 70px rgba(10,15,13,.14)">{section(True)}</div></div></div>\n</x-dc>\n')
    open(os.path.join(OUT, 'TrustT.dc.html'), 'w').write(HEAD % title + page + JS)
    c['boards']['TrustT.dc.html'] = {'x': 0, 'y': y0 + 220, 'w': 1926, 'h': 980, 'is_interactive': True, 'title': title}
    if 'TrustT.dc.html' not in c['order']: c['order'].append('TrustT.dc.html')
    json.dump(c, open(os.path.join(OUT, 'canvas.json'), 'w'))
    print('built TrustT y0', y0)

if __name__ == '__main__':
    build()
