import sys,re
logo=open('logo.txt').read().strip()
parts={'%%LOGO_P%%':logo.replace('__C__','#2A1570'),'%%LOGO_W%%':logo.replace('__C__','#FFFFFF'),
 '%%DATA%%':open('data.js').read(),'%%LANDING%%':open('landing.js').read(),'%%FLOW%%':open('flow.js').read()}
for name in sys.argv[1:]:
    s=open(name+'.tpl.html').read()
    for k,v in parts.items(): s=s.replace(k,v)
    open('../project/'+name+'.dc.html','w').write(s)
    js=s.split('data-dc-script')[1].split('>',1)[1].rsplit('</script>',1)[0]
    open('/tmp/'+name+'.js','w').write('class DCLogic{constructor(p){this.props=p||{};this.state={}}setState(u){const v=typeof u==="function"?u(this.state):u;Object.assign(this.state,v)}};'+js+';const c=new Component({});const r=c.renderVals();console.log("'+name+' ok", Object.keys(r).length);')
