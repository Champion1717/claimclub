src=open('green.py').read();ns={}
exec(src.split("for name,v in")[0],ns)
for n in ['FlowG2','FlowG2D']:
    p='../project/'+n+'.dc.html';s=open(p).read()
    s=ns['recolor'](s,ns['V']['G2']).replace('#D6409F','#12805C').replace('rgba(59,31,158,.16)','rgba(18,128,92,.18)')
    open(p,'w').write(s)
print('post ok')
