# Flow B trial page (Nov 16 2026, pricing test). Writes the `trial` step (FlowB1 design) into FlowC2 (mobile)
# and FlowC2D (desktop), right before the plan page. Reuses the choice page's claims summary line. Run before green.py.
G, MINT, INK, MUTE, LINE, DARK = '#12805C', '#3DDC97', '#0A0F0D', '#5B6862', '#DDE5E0', '#0F3B2E'
MARK = 'trial page, flow B'
def ic_check(s, c, w=3):
    return f'<svg width="{s}" height="{s}" viewBox="0 0 24 24" fill="none" stroke="{c}" stroke-width="{w}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex: none"><path d="M20 6 9 17l-5-5"></path></svg>'
LOCK = f'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="{DARK}" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex: none"><rect width="18" height="11" x="3" y="11" rx="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>'
LEGAL = '<div style="display: flex; justify-content: center; gap: 22px; font-size: 12px; font-weight: 600; color: #43504A"><a href="https://claimclub.io/terms" target="_blank" rel="noopener" style="color: inherit">{{ L.termsW }}</a><a href="https://claimclub.io/privacy" target="_blank" rel="noopener" style="color: inherit">{{ L.privacyW }}</a></div>'
def offer(m):
    perks = (f'<sc-for list="{{{{ trPerks }}}}" as="k" hint-placeholder-count="5"><div style="display: flex; align-items: center; gap: 10px; font-size: {14 if m else 15}px; font-weight: 700; color: #FFFFFF; text-align: left">'
             f'<span style="width: 22px; height: 22px; flex: none; border-radius: 99px; background: rgba(61,220,151,.18); display: flex; align-items: center; justify-content: center">{ic_check(13, MINT)}</span>{{{{ k.t }}}}</div></sc-for>')
    return (f'<div style="flex: none; position: relative; border-radius: 24px; padding: {20 if m else 20}px {20 if m else 24}px; background: radial-gradient(120% 90% at 100% 0%, rgba(61,220,151,.25), transparent 55%), linear-gradient(165deg, #1B5A44, #0A2A20); color: #FFFFFF; display: flex; flex-direction: column; gap: {14 if m else 12}px; box-shadow: 0 20px 44px rgba(10,42,32,.28); text-align: left">'
            f'<div style="display: flex; justify-content: space-between; align-items: center; gap: 8px"><span style="font-size: 12px; font-weight: 800; letter-spacing: 1.3px; color: #CFE9DD">{{{{ trKick }}}}</span><span style="padding: 5px 10px; border-radius: 99px; background: {MINT}; color: {DARK}; font-size: 12px; font-weight: 800; letter-spacing: .4px; white-space: nowrap">{{{{ trOff }}}}</span></div>'
            f'<div style="display: flex; align-items: flex-end; gap: 12px"><b style="font-size: {56 if m else 54}px; letter-spacing: -2.5px; line-height: .9">$2</b>'
            f'<span style="display: flex; flex-direction: column; padding-bottom: 4px"><span style="font-size: 16px; font-weight: 700; color: #9FC3B4; text-decoration: line-through">$49</span><span style="font-size: {14 if m else 15}px; font-weight: 800">{{{{ trFirst }}}}</span></span></div>'
            f'<span style="font-size: {13 if m else 14}px; font-weight: 600; color: #CFE9DD; margin-top: -6px">{{{{ trThen }}}}</span>'
            f'<div style="height: 1px; background: rgba(255,255,255,.12)"></div><div style="display: flex; flex-direction: column; gap: {9 if m else 8}px">{perks}</div></div>')
def timeline(m):
    out = ''
    for i, k in enumerate(['1', '2', '3']):
        out += (f'<div style="flex: 1; display: flex; flex-direction: column; gap: 4px; min-width: 0; text-align: left"><span style="display: flex; align-items: center; gap: 8px"><span style="width: 12px; height: 12px; border-radius: 99px; background: {G if i == 0 else "#FFFFFF"}; box-shadow: inset 0 0 0 2.5px {G}; flex: none"></span>'
                f'<span style="flex: 1; height: 2px; background: {LINE if i < 2 else "transparent"}"></span></span><b style="font-size: 13px; color: {INK}">{{{{ trT{k} }}}}</b><span style="font-size: 12px; font-weight: 600; color: {MUTE}; line-height: 1.35">{{{{ trT{k}p }}}}</span></div>')
    return f'<div style="flex: none; display: flex; gap: {8 if m else 12}px; padding: 2px">{out}</div>'
def consent():
    return (f'<button onClick="{{{{ trToggle }}}}" role="checkbox" aria-checked="{{{{ trAgree }}}}" style="flex: none; display: flex; gap: 10px; align-items: flex-start; padding: 12px 14px; border-radius: 14px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}; text-align: left; width: 100%">'
            f'<span style="{{{{ trBoxStyle }}}}"><sc-if value="{{{{ trAgree }}}}" hint-placeholder-val="{{{{ false }}}}">{ic_check(14, "#FFFFFF")}</sc-if></span>'
            f'<span style="font-size: 12.5px; font-weight: 600; color: #43504A; line-height: 1.45">{{{{ trAgreeT }}}}</span></button>'
            f'<sc-if value="{{{{ trNeed }}}}" hint-placeholder-val="{{{{ false }}}}"><span role="alert" style="margin-top: -6px; font-size: 12.5px; font-weight: 700; color: #C8323B; text-align: left">{{{{ trNeedT }}}}</span></sc-if>')
def cta(label, h):
    return (f'<button onClick="{{{{ trGo }}}}" style="height: {h}px; width: 100%; flex: none; border-radius: 999px; background: {MINT}; color: {DARK}; font-size: 17px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 10px 24px rgba(61,220,151,.35)">{LOCK}<span>{{{{ {label} }}}}</span></button>')
def block(m, summary):
    head = f'<h1 style="margin: 0; font-size: {26 if m else 30}px; line-height: 1.12; font-weight: 800; letter-spacing: {-0.8 if m else -1}px; text-align: {"left" if m else "center"}">{{{{ trH }}}}</h1><span style="font-size: {14.5 if m else 16}px; line-height: 1.45; font-weight: 600; color: {MUTE}; text-align: {"left" if m else "center"}; margin-top: -8px">{{{{ trSub }}}}</span>'
    fine = f'<span style="font-size: 12px; line-height: 1.45; color: {MUTE}; font-weight: 600; text-align: center">{{{{ trFine }}}}</span>'
    if m:
        return (f'  <!-- {MARK} -->\n  <sc-if value="{{{{ isTrial }}}}" hint-placeholder-val="{{{{ false }}}}">\n'
                f'    <div class="enter scroll" style="flex-grow: 1; min-height: 0; overflow-y: auto; padding: 8px 18px 16px; display: flex; flex-direction: column; gap: 14px; background: #F3F6F4; text-align: left">\n'
                f'      {head}\n      {summary}\n      {offer(True)}\n      {timeline(True)}\n      {consent()}\n    </div>\n'
                f'    <div style="flex: none; padding: 10px 18px 16px; border-top: 1px solid #E8EEEA; background: #FFFFFF; display: flex; flex-direction: column; gap: 6px; text-align: center">\n'
                f'      {cta("trCtaM", 54)}\n      {fine}\n      {LEGAL}\n    </div>\n  </sc-if>\n\n')
    return (f'  <!-- {MARK} -->\n  <sc-if value="{{{{ isTrial }}}}" hint-placeholder-val="{{{{ false }}}}">\n'
            f'    <div class="enter" style="display: flex; flex-direction: column; gap: 12px; padding: 4px 0">\n'
            f'      <div style="display: flex; flex-direction: column; gap: 14px">{head}</div>\n      {summary}\n      {offer(False)}\n      {timeline(False)}\n      {consent()}\n      {cta("trCta", 56)}\n      {fine}\n      {LEGAL}\n    </div>\n  </sc-if>\n\n')
for f, m in [('FlowC2.tpl.html', True), ('FlowC2D.tpl.html', False)]:
    s = open(f).read()
    if MARK in s: print(f, 'already has the trial page'); continue
    a = s.index('<!-- choice page, draft 2 -->'); k = s.index('{{ chLogos', a)
    summary = s[s.rfind('\n', 0, k) + 1:s.index('\n', k)].strip()
    assert summary.startswith('<div'), summary[:80]
    p = s.index('  <!-- MEMBERSHIP PLANS -->')
    s = s[:p] + block(m, summary) + s[p:]
    open(f, 'w').write(s); print(f, 'trial page written')
