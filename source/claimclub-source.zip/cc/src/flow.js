  constructor(props) {
    super(props);
    this.state = { step: 0, st: null, a: {}, filed: {}, bump: 0, email: '', lang: 'en', ai: 0, signed: {}, skipped: {}, consent: {}, sawAll: false, allQ: '', saOpen: false, saConsent: false, saSigned: false, plan: '1m', pi: 0, paid: '', bankDone: false, buying: '', payState: '', card: '', exp: '', cvc: '', czip: '',
      p: { first: '', middle: '', last: '', street: '', apt: '', city: '', zip: '', phone: '', dob: '' } };
    let fid = props && props.offer;
    try { if (!fid && typeof location !== 'undefined' && location.search) fid = new URLSearchParams(location.search).get('offer'); } catch (e) {}
    const fd = fid && this.data().find(d => d.id === fid && this.daysLeft(d.dl) > 0);
    this.state.focus = fd ? fd.id : null; this.state.focusMore = false;
  }
  dict() {
    return {
      notLaw: ['Not a law firm · Free to check', 'No somos abogados · Revisar es gratis'],
      qWord: ['Question', 'Pregunta'], of: ['of', 'de'],
      estSoFar: ['YOUR ESTIMATE SO FAR', 'TU ESTIMADO HASTA AHORA'], matched: ['matched', 'encontrados'],
      asideEmpty: ['Settlements you match will appear here as you answer.', 'Los acuerdos que coincidan aparecerán aquí mientras respondes.'],
      b1: ['Every settlement is court-approved', 'Cada acuerdo está aprobado por un tribunal'], b2: ['We pre-fill and submit your claims', 'Llenamos y enviamos tus reclamos'],
      b3: ['Payouts come straight from the settlement', 'Los pagos vienen directo del acuerdo'], b4: ['Cancel anytime', 'Cancela cuando quieras'],
      asideNote: ['Amounts are caps or estimates from each settlement notice and are not guaranteed.', 'Los montos son límites o estimados de cada aviso y no están garantizados.'],
      i1a: ["There's money out there with ", 'Hay dinero por ahí con '], i1b: ['your name on it.', 'tu nombre.'],
      i1p: ['Companies settle class action lawsuits all the time. Most people never claim their share.', 'Las empresas resuelven demandas colectivas todo el tiempo. La mayoría de la gente nunca reclama su parte.'],
      exHead: ['REAL SETTLEMENTS, OPEN NOW', 'ACUERDOS REALES, ABIERTOS AHORA'], exNote: ['Examples', 'Ejemplos'],
      exFoot: ['Just examples. Your own matches show up after a few quick questions.', 'Solo son ejemplos. Tus coincidencias aparecen después de unas preguntas rápidas.'],
      next: ['Next', 'Siguiente'], start: ['Get started', 'Comenzar'], cont: ['Continue', 'Continuar'],
      i2a: ['You answer ', 'Tú respondes '], i2b: [' questions. We do the paperwork.', ' preguntas. Nosotros hacemos el papeleo.'],
      match: ['Match', 'Busca'], matchP: ['Tap yes or no on brands. Each one is a real, open settlement.', 'Responde sí o no sobre marcas. Cada una es un acuerdo real y abierto.'],
      file: ['File', 'Reclama'], fileP: ['We pre-fill each claim form. You sign with a tap.', 'Llenamos cada formulario por ti. Tú firmas con un toque.'],
      paid: ['Get paid', 'Cobra'], paidP: ['We track every claim until the settlement pays you.', 'Damos seguimiento a cada reclamo hasta que el acuerdo te pague.'],
      disclaim: ['Claimclub is a claims preparation service, not a law firm or settlement administrator. Payouts are decided by courts and administrators.', 'Claimclub es un servicio de preparación de reclamos, no un bufete de abogados ni un administrador de acuerdos. Los pagos los deciden los tribunales y administradores.'],
      stateH: ['Which state do you live in?', '¿En qué estado vives?'], stateP: ['Some settlements only pay residents of certain states.', 'Algunos acuerdos solo pagan a residentes de ciertos estados.'],
      tapAns: ['Tap an answer to continue', 'Toca una respuesta para continuar'],
      calcH: ['Checking your answers', 'Revisando tus respuestas'], calcA: ['Matching against ', 'Comparando con '], calcB: [' found', ''],
      calc2: ['Checking deadlines and state rules', 'Revisando fechas límite y reglas estatales'], calc3: ['Estimating your payout', 'Calculando tu pago'],
      owed: ['Based on your answers, you could be owed', 'Según tus respuestas, podrías recibir'],
      noMatchH: ['No matches yet, but new settlements open every week.', 'Aún no hay coincidencias, pero cada semana se abren nuevos acuerdos.'],
      noMatchP: ["Add your email and we'll alert you when one fits.", 'Agrega tu correo y te avisaremos cuando haya uno para ti.'],
      checkNote: ["This check is an illustration of your estimate, not a payment. Amounts come from each settlement's notice and are not guaranteed.", 'Este cheque ilustra tu estimado, no es un pago. Los montos vienen del aviso de cada acuerdo y no están garantizados.'],
      claimMoney: ['Claim my money', 'Reclamar mi dinero'],
      saveH: ['Save your matches', 'Guarda tus coincidencias'], saveP: ["We'll use this to pre-fill your claims and send deadline reminders.", 'Lo usaremos para llenar tus reclamos y enviarte recordatorios de fechas límite.'],
      google: ['Continue with Google', 'Continuar con Google'], appleBtn: ['Continue with Apple', 'Continuar con Apple'], orEmail: ['Or enter your email', 'O escribe tu correo'],
      detH: ['Your details', 'Tus datos'], detP: ['These go on every claim form. Use your legal name and current address.', 'Van en cada formulario de reclamo. Usa tu nombre legal y tu dirección actual.'],
      fFirst: ['First name', 'Nombre'], fMiddle: ['Middle (optional)', 'Segundo nombre (opcional)'], fLast: ['Last name', 'Apellido'],
      fStreet: ['Street address', 'Dirección'], fApt: ['Apt, suite (optional)', 'Apto., suite (opcional)'], fCity: ['City', 'Ciudad'], fState: ['State', 'Estado'], fZip: ['ZIP', 'Código postal'],
      fPhone: ['Mobile phone', 'Teléfono celular'], fDob: ['Date of birth (optional)', 'Fecha de nacimiento (opcional)'],
      detSafe: ['Encrypted and used only for your claims. We never sell your data.', 'Cifrado y usado solo para tus reclamos. Nunca vendemos tus datos.'],
      authH: ['Claim authorization form', 'Formulario de autorización de reclamo'], claimWord: ['Claim', 'Reclamo'],
      secClaimant: ['A. CLAIMANT', 'A. RECLAMANTE'], secClaim: ['CLAIM', 'RECLAMO'], secAuth: ['AUTHORIZATION', 'AUTORIZACIÓN'],
      rName: ['Full name', 'Nombre completo'], rAddr: ['Address', 'Dirección'], rEmail: ['Email', 'Correo'], rPhone: ['Phone', 'Teléfono'],
      rSettle: ['Settlement', 'Acuerdo'], rEst: ['Estimated payout', 'Pago estimado'], rDl: ['Claim deadline', 'Fecha límite'], rClass: ['Class definition', 'Definición del grupo'],
      notGiven: ['Not provided', 'No proporcionado'],
      tapSign: ['Tap to sign', 'Toca para firmar'], sigLine: ['Signature', 'Firma'], dateW: ['Date', 'Fecha'], printName: ['Print name', 'Nombre en letra de molde'],
      editForm: ['Edit details', 'Editar datos'], skip: ['Skip for now', 'Omitir por ahora'], submitAuth: ['Submit signed form', 'Enviar formulario firmado'],
      secAnswers: ['B. CLAIM FORM ANSWERS', 'B. RESPUESTAS DEL FORMULARIO'], secCert: ['C. SETTLEMENT CERTIFICATION', 'C. CERTIFICACIÓN DEL ACUERDO'], secFile: ['D. FILING AUTHORIZATION', 'D. AUTORIZACIÓN DE PRESENTACIÓN'],
      payoutQ: ['Payout method', 'Método de pago'], payoutA: ['Paper check to the address above', 'Cheque por correo a la dirección de arriba'],
      certNote: ['As printed on the official claim form', 'Tal como aparece en el formulario oficial'],
      consentTxt: ['I agree to sign electronically and have read the ', 'Acepto firmar electrónicamente y he leído el '], agreeLink: ['Claim Filing Authorization Agreement', 'Acuerdo de Autorización de Presentación de Reclamos'],
      eachNote: ['Each claim needs its own signature.', 'Cada reclamo necesita su propia firma.'],
      authHelp: ['Read the form, check the box at the bottom, then tap the signature line to sign. We submit it after your filing fee is paid.', 'Lee el formulario, marca la casilla de abajo y toca la línea de firma para firmar. Lo enviamos después de pagar tu tarifa.'],
      payUpTo: ['You could be owed up to', 'Podrías recibir hasta'], fromW: ['from ', 'de '],
      member: ['Claimclub membership', 'Membresía Claimclub'], month: ['/ month', '/ mes'],
      unlockA: ['Unlock all ', 'Desbloquea los '], unlockB: [' by name', ' por nombre'],
      track: ['Track every claim until it pays', 'Seguimiento de cada reclamo hasta el pago'], alerts: ['Alerts when new settlements match you', 'Alertas cuando un nuevo acuerdo coincida contigo'],
      startMem: ['Start membership · 75% off', 'Iniciar membresía · 75% de descuento'],
      billed: ['Billed monthly. Cancel anytime. You can also file any claim yourself, free, on its official settlement site.', 'Cobro mensual. Cancela cuando quieras. También puedes presentar cualquier reclamo tú mismo, gratis, en su sitio oficial.'],
      yourClaims: ['Your claims', 'Tus reclamos'], restart: ['Restart demo', 'Reiniciar demo'], filedOf: ['filed of up to ', 'presentado de hasta '],
      payee: ['You', 'Usted'],
      feeH: ['File your claims', 'Presenta tus reclamos'], feeSub: ['One filing fee covers every claim below. We submit them as soon as you pay.', 'Una sola tarifa cubre todos los reclamos de abajo. Los enviamos en cuanto pagues.'],
      feeHead: ['FILING SUMMARY', 'RESUMEN DE PRESENTACIÓN'], included: ['Included', 'Incluido'],
      feeLine: ['Filing fee', 'Tarifa de presentación'], estBack: ['Estimated back to you', 'Estimado que podrías recibir'], dueToday: ['Due today', 'A pagar hoy'],
      payBtn: ['Pay filing fee · $99', 'Pagar tarifa · $99'], applePay: ['Pay with Apple Pay', 'Pagar con Apple Pay'],
      feeTerms: ['One-time filing fee for the claims above. No subscription. Settlement payouts go straight to you; we never take a cut.', 'Tarifa única por los reclamos de arriba. Sin suscripción. Los pagos de los acuerdos van directo a ti; nunca nos quedamos con una parte.'],
      orW: ['or', 'o'], memPromoH: ['Or join and file free', 'O únete y presenta gratis'],
      memPromoP: ['We file every claim you match, now and as new settlements open. Your first billing period is 75% off.', 'Presentamos cada reclamo que coincida contigo, ahora y cuando se abran nuevos acuerdos. Tu primer periodo cuesta 75% menos.'],
      seePlans: ['See membership plans', 'Ver planes de membresía'], memPromoP2: ['75% off your first period · from', '75% menos el primer periodo · desde'], perMo: ['/ month', '/ mes'],
      plansH: ['Choose your plan', 'Elige tu plan'], plansSub: ['Every plan includes unlimited filing, all {N} open settlements and local scans near you. Your first billing period is 75% off.', 'Todos los planes incluyen presentaciones ilimitadas, los {N} acuerdos abiertos y búsquedas locales cerca de ti. Tu primer periodo cuesta 75% menos.'],
      potential: ['Your potential claim value', 'Valor potencial de tus reclamos'], members: ['members', 'miembros'],
      bestValue: ['BEST VALUE', 'MEJOR VALOR'], stopLaw: ['Stop paying lawyers.', 'Deja de pagarle a abogados.'], keep100: ['Keep 100% of your payouts.', 'Quédate con el 100% de tus pagos.'],
      noCommit: ['No commitment. Cancel anytime.', 'Sin compromiso. Cancela cuando quieras.'], startPaid: ['Start getting paid', 'Empieza a cobrar'],
      termsW: ['Terms', 'Términos'], privacyW: ['Privacy', 'Privacidad'],
      bankH1: ['Never miss your', 'Nunca te pierdas tus'], bankH2: ['payout updates', 'avisos de pago'],
      bankP: ['Connect the account your settlement payments go to. We alert you the moment a payout lands. Read-only: we can never move your money.', 'Conecta la cuenta donde recibes los pagos de los acuerdos. Te avisamos en cuanto llegue un pago. Solo lectura: nunca podemos mover tu dinero.'],
      bankSec: ['Bank-level security', 'Seguridad bancaria'], bankEnc: ['256-bit encryption', 'Cifrado de 256 bits'], bankRO: ['Read-only', 'Solo lectura'],
      connectBank: ['Connect bank account', 'Conectar cuenta bancaria'], notNow: ['Not now', 'Ahora no'], connected: ['Bank connected', 'Banco conectado'],
      payoutTitle: ['Payout received', 'Pago recibido'],
      pk1a: ['Your claims,', 'Tus reclamos,'], pk1b: ['all in one dashboard', 'en un solo panel'],
      pk1p: ['See every claim you filed and exactly where it stands, from submitted to paid, plus anything that still needs you.', 'Ve cada reclamo que presentaste y en qué etapa está, de enviado a pagado, y lo que aún necesita de ti.'],
      pk2a: ['Constant updates on', 'Avisos constantes de'], pk2b: ['new claims you qualify for', 'nuevos reclamos para ti'],
      pk2p: ['New settlements open every week. We check each one against your answers and tell you the moment you can file.', 'Cada semana se abren nuevos acuerdos. Revisamos cada uno con tus respuestas y te avisamos en cuanto puedas presentar.'],
      pk3a: ['Every open settlement,', 'Todos los acuerdos abiertos,'], pk3b: ['plus local scans near you', 'y búsquedas locales cerca de ti'],
      pk3p: ['Browse all {N} open settlements, and we scan for state and city settlements near you that most people never hear about.', 'Explora los {N} acuerdos abiertos y buscamos acuerdos estatales y locales cerca de ti que casi nadie conoce.'],
      nearYou: ['NEAR YOU', 'CERCA DE TI'],
      newMatchT: ['New claim match', 'Nuevo reclamo para ti'], youHave: ['YOUR MEMBERSHIP INCLUDES', 'TU MEMBRESÍA INCLUYE'], nextW: ['Next', 'Siguiente'], skipW: ['Skip', 'Omitir'],
      memberActive: ['Membership active', 'Membresía activa'],
      coH: ['Checkout', 'Pago'], coOr: ['or pay with card', 'o paga con tarjeta'], coCard: ['Card number', 'Número de tarjeta'], coExp: ['MM / YY', 'MM / AA'], coCvc: ['CVC', 'CVC'], coZip: ['ZIP', 'C.P.'],
      coSecure: ['Payments are encrypted and processed by our payment partner. We never store your full card number.', 'Los pagos están cifrados y los procesa nuestro socio de pagos. Nunca guardamos el número completo de tu tarjeta.'],
      unlockK: ['MEMBERSHIP UNLOCKED', 'MEMBRESÍA DESBLOQUEADA'], unlockH: ['Welcome to the club', 'Bienvenido al club'], unlockP: ['Every claim you match, filed for you.', 'Cada reclamo que coincida contigo, presentado por ti.'],
      coBusyT: ['Processing payment', 'Procesando el pago'], coDoneT: ['Payment received', 'Pago recibido'], coDoneP: ['Thanks! One more quick step.', '¡Gracias! Un paso más.'], dueToday2: ['Due today', 'A pagar hoy'],
      saBtn: ['Sign all forms at once', 'Firmar todos a la vez'], saH: ['Sign all your claim forms', 'Firma todos tus formularios'],
      saP: ['Your details are already on every form. One signature applies to each form listed below, and each one is filed under your name.', 'Tus datos ya están en cada formulario. Una firma se aplica a cada formulario de la lista, y cada uno se presenta a tu nombre.'],
      saConsent: ['I have reviewed these forms, the statements in each are true, and I agree to sign each one electronically under the ', 'Revisé estos formularios, las declaraciones de cada uno son verdaderas y acepto firmar cada uno electrónicamente según el '],
      cancelW: ['Cancel', 'Cancelar'],
      moreH: ['That is just your top 10', 'Eso es solo de tus 10 principales'],
      moreCheck: ['Check the other offers', 'Revisar las demás ofertas'],
      paidH: ['Payment received', 'Pago recibido'], perksH: ['Your membership also includes', 'Tu membresía también incluye'],
      perksSub: ['Your membership is active. Here is what it does for you every month.', 'Tu membresía está activa. Esto es lo que hace por ti cada mes.'],
      toDash: ['Go to my claims', 'Ir a mis reclamos'],
      p1: ['New settlement alerts', 'Alertas de nuevos acuerdos'], p1d: ['We check new settlements weekly and tell you when one matches.', 'Revisamos acuerdos nuevos cada semana y te avisamos en cuanto uno coincide contigo.'],
      p2: ['One-tap filing for new matches', 'Presentación con un toque'], p2d: ['Future claims come pre-filled and ready to sign.', 'Tus datos quedan guardados, así que los próximos reclamos ya vienen listos para firmar.'],
      p3: ['Claim tracking', 'Seguimiento de reclamos'], p3d: ['See where every claim stands, from submitted to approved to paid.', 'Ve el estado de cada reclamo, de enviado a aprobado a pagado.'],
      p4: ['Deadline and document reminders', 'Recordatorios de fechas y documentos'], p4d: ['If an administrator needs more, we tell you what and when.', 'Si un administrador pide más información, te decimos qué enviar y cuándo.'],
      p5: ['Payout alerts', 'Alertas de pago'], p5d: ['Know when money is sent, so no check goes uncashed.', 'Sabrás cuándo un acuerdo empieza a pagar, para que ningún cheque se quede sin cobrar.'],
      p6: ['Arbitration claim matching', 'Reclamos de arbitraje'], p6d: ['Partner law firms for claims worth more than a settlement.', 'Te conectamos con bufetes asociados para reclamos que pagan más que un acuerdo.']
    };
  }
  quickMode() { return true; }
  quiz() {
    const st = this.state.st, es = this.state.lang === 'es';
    const yn = (id) => [[id, 'Yes', 'Sí'], ['no', 'No', 'No']];
    const TOP = [
      { key: 'apple', brand: 'Apple', cat: 'apps', title: ['Did you buy an iPhone 15 Pro, 15 Pro Max or any iPhone 16?', '¿Compraste un iPhone 15 Pro, 15 Pro Max o cualquier iPhone 16?'], sub: ['Bought in the U.S. in 2024 or 2025.', 'Comprado en EE. UU. en 2024 o 2025.'], opts: yn('apple') },
      { key: 'amazon', brand: 'Amazon', cat: 'products', title: ['Have you ever returned something to Amazon?', '¿Alguna vez devolviste algo a Amazon?'], sub: ['Any return since 2017. Some refunds came late, short or never.', 'Cualquier devolución desde 2017. Algunos reembolsos llegaron tarde, incompletos o nunca.'], opts: yn('amazon') },
      { key: 'visa', brand: 'Visa & Mastercard', cat: 'bank', title: ["Have you paid a fee to use another bank's ATM?", '¿Has pagado una comisión por usar el cajero de otro banco?'], sub: ['Any out-of-network ATM fee in the U.S.', 'Cualquier comisión de cajero fuera de tu red en EE. UU.'], opts: yn('visa') },
      { key: 'googleplay', brand: 'Google Play', cat: 'apps', title: ['Have you bought apps or in-app items on Google Play?', '¿Has comprado apps o artículos dentro de apps en Google Play?'], sub: ['On any Android phone or tablet.', 'En cualquier teléfono o tableta Android.'], opts: yn('googleplay') },
      { key: 'realpage', brand: 'RealPage', cat: 'bank', title: ['Do you rent in a large apartment building?', '¿Rentas en un edificio grande de apartamentos?'], sub: ['Many big landlords set rents with RealPage software.', 'Muchos grandes arrendadores fijan rentas con el software de RealPage.'], opts: yn('realpage') },
      { key: 'tyson', brand: 'Tyson & beef packers', cat: 'products', title: ['Have you bought beef at a grocery store?', '¿Has comprado carne de res en el supermercado?'], sub: ['Ground beef, steaks or roasts from a store.', 'Carne molida, filetes o asados de una tienda.'], opts: yn('tyson') },
      { key: 'cvs', brand: 'CVS', cat: 'privacy', title: ['Have you used the CVS website or app?', '¿Has usado el sitio web o la app de CVS?'], sub: ['To shop, fill prescriptions or book a visit.', 'Para comprar, surtir recetas o agendar una cita.'], opts: yn('cvs') },
      { key: 'goodrx', brand: 'GoodRx', cat: 'health', title: ['Have you used GoodRx?', '¿Has usado GoodRx?'], sub: ['The app or a GoodRx discount card for a prescription.', 'La app o una tarjeta de descuento GoodRx para una receta.'], opts: yn('goodrx') },
      { key: 'netflix', brand: 'Netflix', cat: 'arb', title: ['Do you have a Netflix account?', '¿Tienes cuenta de Netflix?'], sub: ['A privacy claim filed through a partner law firm.', 'Un reclamo de privacidad presentado por un bufete asociado.'], opts: yn('netflix') },
      { key: 'openai', brand: 'ChatGPT', cat: 'arb', title: ['Do you use ChatGPT?', '¿Usas ChatGPT?'], sub: ['A privacy claim filed through a partner law firm.', 'Un reclamo de privacidad presentado por un bufete asociado.'], opts: yn('openai') }
    ];
    const loc = (q) => Object.assign({}, q, { title: q.title[es ? 1 : 0], sub: q.sub[es ? 1 : 0], opts: q.opts.map(o => [o[0], es ? o[2] : o[1]]) });
    const fid = this.state.focus;
    if (this.quickMode() && fid) {
      const d = this.data().find(x => x.id === fid);
      const fq = TOP.find(q => q.key === fid) || { key: fid, brand: d.co, cat: d.cat, title: ['Does the ' + d.co + ' settlement apply to you?', '¿Te aplica el acuerdo de ' + d.co + '?'], sub: ['Eligible: ' + d.who + '.', 'Pueden reclamar: ' + d.who + '.'], opts: yn(fid) };
      this._moreN = TOP.filter(q => q.key !== fid).length;
      return [fq].concat(this.state.focusMore ? TOP.filter(q => q.key !== fid) : []).map(loc);
    }
    if (this.quickMode()) return TOP.map(loc);
    const Q = [
      { key: 'apple', brand: 'Apple', cat: 'apps', title: ['Did you buy an iPhone 15 Pro, 15 Pro Max or any iPhone 16?', '¿Compraste un iPhone 15 Pro, 15 Pro Max o cualquier iPhone 16?'], sub: ['Bought in the U.S. in 2024 or 2025.', 'Comprado en EE. UU. en 2024 o 2025.'], opts: [['apple', 'Yes', 'Sí'], ['no', 'No', 'No']] },
      { key: 'amazon', brand: 'Amazon', cat: 'products', title: ['Has Amazon ever refunded a return late, short, or not at all?', '¿Amazon te reembolsó una devolución tarde, incompleta o nunca?'], sub: ['Any return since September 2017.', 'Cualquier devolución desde septiembre de 2017.'], opts: [['amazon', 'Yes', 'Sí'], ['amazon', 'Not sure', 'No estoy seguro'], ['no', 'No', 'No']] },
      { key: 'bofa', brand: 'Bank of America', cat: 'bank', title: ['Did Bank of America deny your dispute of a debit card or ATM charge?', '¿Bank of America rechazó tu disputa de un cargo de débito o cajero?'], sub: ['An unauthorized charge you reported between May 2023 and July 2026.', 'Un cargo no autorizado que reportaste entre mayo de 2023 y julio de 2026.'], opts: [['bofa', 'Yes', 'Sí'], ['no', 'No', 'No']] },
      { key: 'apps', multi: true, cat: 'apps', cols: 2, title: ['Have you used any of these?', '¿Has usado alguno de estos?'], sub: ['Tap all that apply.', 'Toca todos los que apliquen.'],
        opts: [['cvs', 'CVS website or app', 'Sitio o app de CVS'], ['goodrx', 'GoodRx', 'GoodRx'], ['kroger', 'Kroger pharmacy, with insurance', 'Farmacia Kroger, con seguro'], ['googleplay', 'Bought apps on Google Play', 'Compraste apps en Google Play'],
          ['knotts', "Six Flags Knott's or Great America tickets", "Boletos de Six Flags Knott's o Great America"], ['seatgeek', 'SeatGeek tickets for a Nevada event', 'Boletos de SeatGeek para un evento en Nevada']]
          .concat(st === 'CA' ? [['venetian', 'The Venetian Las Vegas website', 'Sitio web de The Venetian Las Vegas']] : []).concat(st === 'IL' ? [['neutrogena', 'Neutrogena Skin360 skin scan', 'Escaneo de piel Neutrogena Skin360']] : []).concat([['none', 'None of these', 'Ninguno']]) },
      { key: 'accts', multi: true, cat: 'arb', cols: 2, title: ['Do you have an account with any of these?', '¿Tienes cuenta en alguno de estos?'], sub: ['Privacy claims filed through a partner law firm. Tap all that apply.', 'Reclamos de privacidad presentados por un bufete asociado. Toca todos los que apliquen.'],
        opts: [['netflix', 'Netflix', 'Netflix'], ['youtube', 'YouTube', 'YouTube'], ['google', 'Google', 'Google'], ['openai', 'ChatGPT', 'ChatGPT'], ['disney', 'Disney+', 'Disney+'], ['yahoo', 'Yahoo', 'Yahoo'],
          ['ubereats', 'Uber Eats', 'Uber Eats'], ['walgreens', 'Walgreens', 'Walgreens'], ['bestbuy', 'Best Buy', 'Best Buy'], ['myfitnesspal', 'MyFitnessPal', 'MyFitnessPal'], ['flo', 'Flo', 'Flo'], ['ubisoft', 'Ubisoft', 'Ubisoft'],
          ['equinox', 'Equinox', 'Equinox'], ['lemonade', 'Lemonade', 'Lemonade'], ['fanatics', 'Fanatics', 'Fanatics'], ['vesync', 'VeSync or Levoit', 'VeSync o Levoit'], ['ups', 'UPS My Choice', 'UPS My Choice']]
          .concat(['CA', 'PA', 'FL', 'WA', 'MA'].includes(st) || st === 'Other' ? [['bn', 'Barnes & Noble', 'Barnes & Noble']] : []).concat(st === 'CA' ? [['alo', 'Alo Yoga', 'Alo Yoga']] : []).concat([['none', 'None of these', 'Ninguno']]) },
      { key: 'prod', multi: true, cat: 'products', cols: 2, title: ['Have you bought or owned any of these?', '¿Has comprado o tenido alguno de estos?'], sub: ['Tap all that apply. No receipts needed for most.', 'Toca todos los que apliquen. La mayoría no pide recibos.'],
        opts: [['squatch', 'Dr. Squatch soap or deodorant', 'Jabón o desodorante Dr. Squatch'], ['thinkware', 'A Thinkware dash cam', 'Una cámara Thinkware'], ['tyson', 'Beef from a grocery store', 'Carne de res del supermercado'], ['pork', 'Pork from a grocery store', 'Carne de cerdo del supermercado'],
          ['kia', '2016 to 2017 Kia Optima or 2017 Sportage', 'Kia Optima 2016 a 2017 o Sportage 2017'], ['hyundaikia', 'A Hyundai or Kia with an airbag recall', 'Un Hyundai o Kia con retiro de bolsas de aire'], ['toyota', 'A Toyota with an airbag recall', 'Un Toyota con retiro de bolsas de aire'], ['deere', 'John Deere equipment repaired at a dealer', 'Equipo John Deere reparado en un distribuidor'],
          ['smarttv', 'A smart TV', 'Una smart TV'], ['dexcom', 'A Dexcom glucose monitor', 'Un monitor de glucosa Dexcom']]
          .concat(st === 'CA' ? [['vanilla', 'A Vanilla gift card that got drained', 'Una tarjeta Vanilla que vaciaron']] : []).concat([['none', 'None of these', 'Ninguno']]) },
      { key: 'money', multi: true, cat: 'bank', cols: 2, title: ['Any of these happen with your money?', '¿Te pasó algo de esto con tu dinero?'], sub: ['Tap all that apply.', 'Toca todos los que apliquen.'],
        opts: [['visa', 'Paid an out-of-network ATM fee', 'Pagaste una comisión en un cajero de otro banco'], ['realpage', 'Rented in a large apartment building', 'Rentaste en un edificio grande de apartamentos'], ['equifax', 'Disputed an error with Equifax', 'Disputaste un error con Equifax'], ['transunion', 'Have a TransUnion credit report', 'Tienes un reporte de crédito de TransUnion'],
          ['westernunion', 'Sent money to a scammer by Western Union', 'Enviaste dinero a un estafador por Western Union'], ['navy', 'Navy Federal denied a loan fraud claim', 'Navy Federal rechazó un reclamo de fraude'], ['bright', 'Took a loan from Bright Lending', 'Pediste un préstamo a Bright Lending'], ['onemain', 'Took a loan from OneMain', 'Pediste un préstamo a OneMain'], ['none', 'None of these', 'Ninguno']] },
      { key: 'breach', multi: true, cat: 'privacy', cols: 2, title: ['Did you get a data breach notice from any of these?', '¿Recibiste un aviso de filtración de datos de alguno de estos?'], sub: ['An email or letter saying your information was exposed.', 'Un correo o carta diciendo que tus datos quedaron expuestos.'],
        opts: [['columbia', 'Columbia University', 'Columbia University'], ['davita', 'DaVita', 'DaVita'], ['sirva', 'Sirva', 'Sirva'], ['bauer', 'Bauer Built', 'Bauer Built'], ['woodloch', 'Woodloch Pines', 'Woodloch Pines'], ['benkeith', 'Ben E. Keith', 'Ben E. Keith'], ['safefleet', 'Safe Fleet', 'Safe Fleet'], ['tennis', 'Merchant of Tennis', 'Merchant of Tennis'],
          ['jbs', 'JBS', 'JBS'], ['renal', 'Innovative Renal Care', 'Innovative Renal Care'], ['prime', 'Prime Healthcare', 'Prime Healthcare'], ['pp', 'LSC lab testing', 'Laboratorio LSC'], ['ey', 'EY', 'EY'], ['apollomd', 'ApolloMD', 'ApolloMD'], ['none', 'None of these', 'Ninguno']] },
      { key: 'other', multi: true, cat: 'apps', cols: 2, title: ['Did any of these happen to you?', '¿Te pasó alguno de estos?'], sub: ['Tap all that apply.', 'Toca todos los que apliquen.'],
        opts: [['nissan', 'Marketing texts from Al Piemonte Nissan', 'Mensajes de Al Piemonte Nissan'], ['connectamerica', 'Calls or texts from ConnectAmerica', 'Llamadas o mensajes de ConnectAmerica'], ['indegene', 'Marketing texts from Indegene', 'Mensajes de Indegene'], ['suffolk', 'Paid a Suffolk County red-light camera fee', 'Pagaste una multa de semáforo en Suffolk County'],
          ['hirevue', 'Did a HireVue video job interview', 'Hiciste una entrevista en video con HireVue'], ['sandoz', 'Paid for generic prescriptions', 'Pagaste medicamentos genéricos'], ['cone', 'Used the Cone Health patient portal', 'Usaste el portal de Cone Health'], ['duke', 'Used the Duke Health patient portal', 'Usaste el portal de Duke Health'], ['xactus', 'Had a mortgage credit check', 'Te hicieron un chequeo de crédito hipotecario'], ['none', 'None of these', 'Ninguno']] },
      { key: 'invest', multi: true, cat: 'invest', cols: 2, title: ['Any of these apply to you?', '¿Alguno de estos aplica a ti?'], sub: ['Investments and work. Tap all that apply.', 'Inversiones y trabajo. Toca todos los que apliquen.'],
        opts: [['ni', 'Owned National Instruments stock in 2022', 'Acciones de National Instruments en 2022'], ['skin', 'Bought BeautyHealth stock, 2022 to 2023', 'Acciones de BeautyHealth, 2022 a 2023'], ['marqeta', 'Bought Marqeta stock in 2024', 'Acciones de Marqeta en 2024'], ['twitter', 'Sold Twitter stock in 2022', 'Vendiste acciones de Twitter en 2022'], ['upsfair', 'Bought UPS stock', 'Compraste acciones de UPS'],
          ['capone', 'In the Capital One 401(k)', 'En el 401(k) de Capital One'], ['starbucks', 'Got a Starbucks COBRA notice', 'Recibiste un aviso COBRA de Starbucks'], ['stv', 'Applied to an STV job in Washington', 'Solicitaste empleo en STV en Washington'], ['none', 'None of these', 'Ninguno']] }
    ];
    return Q.map(q => Object.assign({}, q, { title: q.title[es ? 1 : 0], sub: q.sub[es ? 1 : 0], opts: q.opts.map(o => [o[0], es ? o[2] : o[1]]) }));
  }
  matched() {
    const a = this.state.a, D = this.data(), ids = new Set();
    Object.values(a).forEach(v => (Array.isArray(v) ? v : [v]).forEach(x => { if (x && x !== 'no' && x !== 'none') ids.add(x); }));
    return D.filter(d => ids.has(d.id) && this.daysLeft(d.dl) > 0);
  }
  answerOf(id) {
    const Q = this.quiz(), a = this.state.a, es = this.state.lang === 'es';
    for (const q of Q) {
      const v = a[q.key];
      if (q.multi ? (v || []).includes(id) : v === id) {
        const o = q.opts.find(x => x[0] === id);
        return q.multi ? { q: q.title, a: o[1] + (es ? ': Sí' : ': Yes') } : { q: q.title, a: o ? o[1] : (es ? 'Sí' : 'Yes') };
      }
    }
    const d = this.data().find(x => x.id === id);
    return d ? { q: d.who, a: es ? 'Sí' : 'Yes' } : { q: '', a: '' };
  }
  authList() { return this.matched().filter(m => m.mode === 'here'); }
  componentDidUpdate() {
    if (this.stepName() === 'calc' && !this._calc) {
      this._calc = setTimeout(() => { this._calc = null; this.go(1); }, 2600);
    }
  }
  componentWillUnmount() { clearTimeout(this._t); clearTimeout(this._calc); clearTimeout(this._bk); clearTimeout(this._pay); }
  steps() {
    if (this.quickMode()) return (this.state.focus ? [] : ['intro1']).concat(this.quiz().map((q, i) => 'q' + i)).concat(['picked', 'all', 'calc', 'reveal', 'email', 'details', 'auth', 'pay', 'plans', 'checkout', 'perks', 'bank', 'dash']);
    return ['intro1', 'intro2', 'state'].concat(this.quiz().map((q, i) => 'q' + i)).concat(['calc', 'reveal', 'email', 'details', 'auth', 'pay', 'perks', 'dash']);
  }
  stepName() { return this.steps()[this.state.step]; }
  go(d) {
    const S = this.steps(), noAuth = this.authList().length === 0;
    this.setState(st => {
      let n = st.step + d;
      if (d < 0 && S[n] === 'calc') n -= 1;
      if (S[n] === 'all' && !st.sawAll) n += d;
      if (S[n] === 'auth' && noAuth) n += d;
      const extra = {};
      if (S[n] === 'auth') extra.ai = d < 0 ? Math.max(0, this.authList().length - 1) : 0;
      return Object.assign({ step: Math.max(0, Math.min(S.length - 1, n)) }, extra);
    });
  }
  back() {
    if (this.stepName() === 'auth' && this.state.ai > 0) { this.setState({ ai: this.state.ai - 1 }); return; }
    this.go(-1);
  }
  planInfo(id, es) {
    return ({ '1m': { first: '$7.50', full: '$29.99', every: es ? 'cada mes' : 'every month' }, '3m': { first: '$18.74', full: '$74.97', every: es ? 'cada 3 meses' : 'every 3 months' }, '6m': { first: '$29.99', full: '$119.94', every: es ? 'cada 6 meses' : 'every 6 months' } })[id] || { first: '$7.50', full: '$29.99', every: es ? 'cada mes' : 'every month' };
  }
  renderVals() {
    const s = this.state, K = this.cats(), S = this.skin(), Q = this.quiz(), name = this.stepName();
    const es = s.lang === 'es', D = this.dict(), L = {};
    Object.keys(D).forEach(k => { L[k] = D[k][es ? 1 : 0]; });
    const openAllN = this.data().filter(d => this.daysLeft(d.dl) > 0).length;
    L.plansSub = L.plansSub.replace('{N}', openAllN); L.pk3p = L.pk3p.replace('{N}', openAllN);
    const ml = this.matched();
    const settle = ml.filter(m => m.cat !== 'arb'), arbs = ml.filter(m => m.cat === 'arb');
    const val = (m) => m.amt > 0 ? m.amt : (m.max > 0 ? m.max : 0);
    const total = settle.reduce((t, m) => t + val(m), 0);
    const varies = settle.filter(m => !val(m)).length, noFigure = total === 0 && settle.length > 0;
    const qIndex = name && name[0] === 'q' ? Number(name.slice(1)) : -1;
    const quick = this.quickMode();
    const qTotal = quick ? Q.length : Q.length + 1;
    const qNum = name === 'state' ? 1 : qIndex >= 0 ? qIndex + (quick ? 1 : 2) : 0;
    const plural = (n, en1, enN, es1, esN) => n + ' ' + (es ? (n === 1 ? es1 : esN) : (n === 1 ? en1 : enN));
    const countLabel = plural(ml.length, 'settlement', 'settlements', 'acuerdo', 'acuerdos');
    const amtOf = (m) => m.cat === 'arb' ? (m.max ? (es ? 'Hasta ' : 'Up to ') + this.money(m.max) : (es ? 'Arbitraje' : 'Arbitration')) : val(m) > 0 ? (es ? 'Hasta ' : 'Up to ') + this.money(val(m)) : (es ? 'Varía' : 'Varies');
    let q = { opts: [], multi: false, single: false };
    let nextDisabled = true;
    if (qIndex >= 0) {
      const raw = Q[qIndex], qc = K[raw.cat], cur = s.a[raw.key];
      q = {
        title: raw.title, sub: raw.sub, multi: !!raw.multi, single: !raw.multi, hasBrand: !!raw.brand, brand: raw.brand || '', catLabel: qc.label,
        brandLogo: raw.brand ? (this.logos()[raw.key] || '') : '', hasBrandLogo: !!(raw.brand && this.logos()[raw.key]),
        brandStyle: S.brand(qc), isQuick: false, notQuick: true, gridStyle: 'display:grid;grid-template-columns:repeat(' + (raw.cols || 1) + ',minmax(0,1fr));gap:10px',
        opts: raw.opts.map(([id, label], oi) => {
          const sel = raw.multi ? (cur || []).includes(id) : (cur === id && s['l_' + raw.key] === oi);
          const d = this.data().find(x => x.id === id);
          const c = d ? K[d.cat] : K.invest;
          return {
            logo: raw.multi ? (this.logos()[id] || '') : '', hasLogo: !!(raw.multi && this.logos()[id]), label, sel, sub: d && raw.multi ? amtOf(d) : '', hasSub: !!(d && raw.multi),
            style: S.opt(sel, c, !!raw.multi), markStyle: S.mark(sel, c, !!raw.multi),
            tile: 'position:relative;display:flex;flex-direction:column;align-items:flex-start;gap:5px;text-align:left;padding:9px 10px;border-radius:14px;background:' + (sel ? '#F3F0FB' : '#FFFFFF') + ';box-shadow:inset 0 0 0 ' + (sel ? '2px #1B0F4F' : '1.5px #E4DEF5') + ';min-height:0',
            check: 'position:absolute;top:8px;right:8px;width:20px;height:20px;border-radius:50%;display:flex;align-items:center;justify-content:center;' + (sel ? 'background:#1B0F4F;color:#FFFFFF' : 'box-shadow:inset 0 0 0 1.5px #D9D2EE;color:transparent'),
            pick: () => this.pick(raw, id, oi, d)
          };
        })
      };
      nextDisabled = !(raw.multi && (cur || []).length > 0);
    }
    const states = ['CA', 'TX', 'FL', 'NY', 'IL', 'PA', 'OH', 'GA', 'WA', 'NJ', 'NC', 'Other'].map(x => ({
      label: x === 'Other' ? (es ? 'Otro' : 'Other') : x, style: S.stateBtn(s.st === x), pick: () => { this.setState({ st: x }); clearTimeout(this._t); this._t = setTimeout(() => this.go(1), 300); }
    }));
    const em = (s.email || '').trim().toLowerCase();
    const disposable = /@(mailinator|guerrillamail|10minutemail|tempmail|temp-mail|yopmail|trashmail|getnada|sharklasers|dispostable|fakeinbox|throwawaymail)\./;
    const emailErr = !em ? '' : !/^[a-z0-9._%+-]+@[a-z0-9-]+(\.[a-z0-9-]+)*\.[a-z]{2,}$/.test(em) ? (es ? 'Escribe un correo válido' : 'Enter a valid email address') : disposable.test(em) ? (es ? 'Usa un correo permanente, no uno temporal' : 'Use a permanent email, not a temporary one') : /^(test|asdf|fake|abc|none|noemail|no)@/.test(em) ? (es ? 'Usa tu correo real' : 'Use your real email address') : '';
    const emailOk = !!em && !emailErr;
    const filedAmt = settle.filter(m => s.filed[m.id]).reduce((t, m) => t + val(m), 0);
    const matches = ml.map(m => {
      const c = K[m.cat], done = !!s.filed[m.id] || m.mode === 'auto', lg = this.logos()[m.id];
      const arb = m.cat === 'arb';
      return {
        logo: lg || '', hasLogo: !!lg, noLogo: !lg, co: m.co, title: m.title, pay: m.pay, catLabel: c.label,
        deadline: m.dl ? (es ? 'Fecha límite ' : 'Deadline ') + this.fmtDate(m.dl) : (es ? 'Sin fecha límite' : 'No deadline'),
        amtLabel: amtOf(m), signed: !!s.signed[m.id], unsigned: !s.signed[m.id],
        tileStyle: S.tile(c), initial: m.co.replace(/[^A-Za-z]/g, '').slice(0, 1),
        done: done || !!s.signed[m.id], notDone: !(done || s.signed[m.id]),
        tag: arb ? (es ? 'Bufete asociado' : 'Partner law firm') : m.mode === 'here' ? (es ? 'Se presenta aquí' : 'Files here') : m.mode === 'auto' ? (es ? 'Pago automático' : 'Paid automatically') : (es ? 'Sitio oficial requerido' : 'Official site required'),
        tagStyle: 'font-size:12px;font-weight:700;padding:4px 8px;border-radius:7px;' + (arb ? 'background:#F3F0FB;color:#4A4266' : m.mode === 'here' ? 'background:#E9F6EF;color:#17603F' : m.mode === 'auto' ? 'background:#ECF0FC;color:#2C4BB8' : 'background:#FFF4D6;color:#6B4600'),
        btn: m.mode === 'here' ? (es ? 'Presentar' : 'File now') : (es ? 'Abrir sitio' : 'Open site'), btnStyle: S.act(m.mode === 'here'),
        doneLabel: m.mode === 'auto' ? (es ? 'Nada que hacer' : 'No action needed') : s.signed[m.id] ? (es ? 'Firmado' : 'Signed') : m.mode === 'here' ? (es ? 'Enviado' : 'Submitted') : (es ? 'Abierto' : 'Opened'),
        act: () => this.setState({ filed: Object.assign({}, s.filed, { [m.id]: true }) })
      };
    });
    const segs = [];
    for (let i = 1; i <= qTotal; i++) segs.push({ style: S.seg(i < qNum, i === qNum) });
    // details form
    const p = s.p;
    const setP = (k) => (e) => this.setState({ p: Object.assign({}, this.state.p, { [k]: e.target.value }) });
    const stCode0 = s.st && s.st !== 'Other' ? s.st : '';
    const DE = this.validate(p, stCode0, es);
    const detOk = Object.keys(DE).length === 0;
    const showDE = s.detTried ? DE : {};
    const inp = 'height:50px;border-radius:12px;border:1.5px solid #E4DEF5;padding:0 14px;font-size:16px;font-family:inherit;color:#140B3A;background:#FFFFFF;width:100%;box-sizing:border-box;min-width:0';
    const fullName = [p.first, p.middle, p.last].map(x => (x || '').trim()).filter(Boolean).join(' ');
    const stCode = stCode0;
    // authorization form
    const AL = this.authList();
    const ai = Math.min(s.ai, Math.max(0, AL.length - 1));
    const cur = AL[ai];
    const today = new Date();
    const dateStr = (today.getMonth() + 1) + '/' + today.getDate() + '/' + today.getFullYear();
    let auth = { has: false, rows: [], claim: [] };
    if (cur) {
      const arb = cur.cat === 'arb', lg = this.logos()[cur.id];
      const signedNow = !!s.signed[cur.id];
      const nm = fullName || 'Your name';
      const attest = arb
        ? (es ? 'Revisé la información de arriba y es verdadera y correcta. Autorizo a Claimclub a enviarla a un bufete asociado para que evalúe un posible reclamo de arbitraje individual contra ' + cur.co + ' en mi nombre. Entiendo que no se presenta nada hasta que firme un acuerdo aparte con el bufete, que indicará cualquier honorario. Claimclub no recibe ninguna parte de lo que se otorgue.'
              : 'I have reviewed the information above and it is true and correct. I authorize Claimclub to send it to a partner law firm so the firm can review a possible individual arbitration claim against ' + cur.co + ' for me. I understand no claim is filed until I sign a separate agreement with the firm, which will disclose any fees. Claimclub takes no part of any award.')
        : (es ? 'Revisé las respuestas de arriba y son verdaderas y correctas. Autorizo a Claimclub a presentar este reclamo al administrador del acuerdo ' + cur.co + ' a mi nombre, usando mi firma electrónica de abajo, y a recibir actualizaciones, según el Acuerdo de Autorización de Presentación de Reclamos. Cualquier pago se me enviará directamente. Claimclub no recibe ninguna parte. Puedo revocar esta autorización antes de que se presente el reclamo.'
              : 'I have reviewed the answers above and they are true and correct. I authorize Claimclub to submit this claim to the ' + cur.co + ' settlement administrator under my name, using my electronic signature below, and to receive updates about it, as described in the Claim Filing Authorization Agreement. Any payment will be sent directly to me. Claimclub takes no part of it. I can revoke this authorization at any time before the claim is submitted.');
      const cert = es ? 'Declaro bajo pena de perjurio, conforme a las leyes de los Estados Unidos, que la información de este formulario es verdadera y correcta según mi leal saber, y que soy miembro del grupo del acuerdo descrito en el aviso.'
                      : 'I declare under penalty of perjury under the laws of the United States that the information in this claim form is true and correct to the best of my knowledge, and that I am a member of the Settlement Class described in the notice.';
      const ans = this.answerOf(cur.id);
      const consentOn = !!s.consent[cur.id];
      const advance = () => { if (ai + 1 < AL.length) this.setState({ ai: ai + 1 }); else this.go(1); };
      auth = {
        has: true, co: cur.title.startsWith(cur.co) ? '' : cur.co, title: cur.title, logo: lg || '', hasLogo: !!lg, noLogo: !lg, initial: cur.co.replace(/[^A-Za-z]/g, '').slice(0, 1), tileStyle: S.tile(K[cur.cat]),
        step: L.claimWord + ' ' + (ai + 1) + ' ' + L.of + ' ' + AL.length,
        bar: 'height:100%;border-radius:99px;background:#12805C;transition:width .3s ease;width:' + Math.round((ai + (signedNow ? 1 : 0)) / AL.length * 100) + '%',
        rows: [[L.rName, fullName || L.notGiven], [L.rAddr, [p.street, p.apt].filter(x => (x || '').trim()).join(', ') + (p.city ? ', ' + p.city : '') + (stCode ? ', ' + stCode : '') + (p.zip ? ' ' + p.zip : '') || L.notGiven], [L.rEmail, s.email || L.notGiven], [L.rPhone, p.phone || L.notGiven]].map(([k, v]) => ({ k, v })),
        nameLine: [fullName || L.notGiven, p.phone].filter(Boolean).join(' · '),
        addrLine: [p.street, p.apt].filter(x => (x || '').trim()).join(', ') + (p.city ? ', ' + p.city : '') + (stCode ? ', ' + stCode : '') + (p.zip ? ' ' + p.zip : ''),
        emailLine: s.email || L.notGiven, who: cur.who,
        metaLine: L.rEst + ': ' + amtOf(cur) + ' · ' + L.rDl + ': ' + (cur.dl ? this.fmtDate(cur.dl) : (es ? 'Sin fecha límite' : 'No deadline')),
        claim: [[L.rSettle, cur.co + ' ' + cur.title], [L.rEst, amtOf(cur)], [L.rDl, cur.dl ? this.fmtDate(cur.dl) : (es ? 'Sin fecha límite' : 'No deadline')], [L.rClass, cur.who]].map(([k, v]) => ({ k, v })),
        attest, cert, hasCert: !arb, consentOn, consentOff: !consentOn,
        answers: [[ans.q, ans.a]].concat(arb ? [] : [[L.payoutQ, L.payoutA]]).filter(r => r[0]).map(([k, v]) => ({ k, v })),
        toggleConsent: () => this.setState({ consent: Object.assign({}, this.state.consent, { [cur.id]: !this.state.consent[cur.id] }) }),
        consentBox: 'width:22px;height:22px;flex:none;border-radius:6px;display:flex;align-items:center;justify-content:center;' + (consentOn ? 'background:#1B0F4F;color:#FFFFFF' : 'background:#FFFFFF;box-shadow:inset 0 0 0 1.5px #A99FCC'),
        cantSubmit: !(signedNow && consentOn),
        signed: signedNow, unsigned: !signedNow, sigName: fullName || 'Alex Rivera', sigDate: signedNow ? dateStr : '', printName: fullName,
        sign: () => this.setState({ signed: Object.assign({}, this.state.signed, { [cur.id]: true }) }),
        submit: () => { if (this.state.signed[cur.id] && this.state.consent[cur.id]) advance(); },
        submitStyle: S.btn(signedNow && consentOn),
        skip: () => { this.setState({ skipped: Object.assign({}, this.state.skipped, { [cur.id]: true }) }); advance(); },
        edit: () => this.setState({ step: this.steps().indexOf('details') }),
        arbNote: arb, kind: arb ? (es ? 'ARBITRAJE · BUFETE ASOCIADO' : 'ARBITRATION · PARTNER LAW FIRM') : (es ? 'ACUERDO DE DEMANDA COLECTIVA' : 'CLASS ACTION SETTLEMENT')
      };
    }
    const signedCount = AL.filter(m => s.signed[m.id]).length;
    const topIds = quick ? Q.map(q => q.key) : [];
    const more = s.a.more || [];
    const ql = (s.allQ || '').trim().toLowerCase();
    const allPool = this.data().filter(d => !topIds.includes(d.id) && this.daysLeft(d.dl) > 0 && !d.dir && !d.st);
    const tile = (sel) => 'display:flex;align-items:center;gap:10px;width:100%;text-align:left;padding:9px 10px;border-radius:12px;background:' + (sel ? '#F3F0FB' : '#FFFFFF') + ';box-shadow:inset 0 0 0 ' + (sel ? '2px #1B0F4F' : '1px #E4DEF5');
    const chk = (sel) => 'width:20px;height:20px;flex:none;border-radius:50%;display:flex;align-items:center;justify-content:center;' + (sel ? 'background:#1B0F4F;color:#FFFFFF' : 'box-shadow:inset 0 0 0 1.5px #D9D2EE;color:transparent');
    const allGroups = Object.keys(K).map(ck => ({ label: K[ck].label, items: allPool.filter(d => d.cat === ck && (!ql || (d.co + ' ' + d.title + ' ' + d.who).toLowerCase().includes(ql))).map(d => {
      const sel = more.includes(d.id), lg = this.logos()[d.id];
      return { co: d.co, title: d.title.startsWith(d.co) ? d.title : d.co + ' ' + d.title, who: d.who, amt: amtOf(d), logo: lg || '', hasLogo: !!lg, noLogo: !lg, initial: d.co.replace(/[^A-Za-z]/g, '').slice(0, 1), tileStyle: S.tile(K[d.cat]), sel, rowStyle: tile(sel), check: chk(sel),
        pick: () => { const m = (this.state.a.more || []).slice(); const i = m.indexOf(d.id); if (i >= 0) m.splice(i, 1); else m.push(d.id); this.setState({ a: Object.assign({}, this.state.a, { more: m }), bump: this.state.bump + 1 }); } };
    }) })).filter(g => g.items.length);
    const pickedN = ml.length;
    const toCalc = () => this.setState({ step: this.steps().indexOf('calc') });
    const others = allPool.filter(d => !more.includes(d.id));
    const moreN = others.length;
    const checkedN = Q.length + more.length;
    L.moreH = es ? 'Eso es solo ' + (checkedN === 1 ? '1 oferta' : checkedN + ' ofertas') : 'That is just ' + (checkedN === 1 ? '1 offer' : checkedN + ' offers');
    const allOpen = this.data().filter(d => this.daysLeft(d.dl) > 0 && !d.dir && !d.st);
    const allValue = this.money(Math.round(allOpen.reduce((t, d) => t + (d.max || d.amt || 0), 0)));
    const moreLabel = this.money(Math.round(others.filter(d => d.cat !== 'arb').reduce((t, d) => t + (d.max || d.amt || 0), 0)));
    const showBack = qNum > 0 || ['details', 'auth', 'all', 'picked', 'pay', 'plans'].includes(name) || (name === 'checkout' && !s.payState);
    return {
      L, isEn: !es, isEs: es,
      enStyle: this.langStyle(!es), esStyle: this.langStyle(es),
      setEn: () => this.setState({ lang: 'en' }), setEs: () => this.setState({ lang: 'es' }),
      isIntro1: name === 'intro1', isIntro2: name === 'intro2', isState: name === 'state', isQ: qIndex >= 0,
      isCalc: name === 'calc', isReveal: name === 'reveal', isEmail: name === 'email', isDetails: name === 'details', isAuth: name === 'auth', isAll: name === 'all', isPicked: name === 'picked', notAuth: name !== 'auth',
      mainStyle: name === 'perks' || name === 'bank' ? 'width:100%;max-width:1680px;box-sizing:border-box;display:flex;flex-direction:column;justify-content:center;min-height:0;padding:32px 48px' : name === 'auth' ? 'width:100%;display:flex;flex-direction:column;min-height:0;padding:14px 0 0' : 'width:100%;max-width:600px;display:flex;flex-direction:column;justify-content:center;min-height:0;padding:24px 0', isPay: name === 'pay', isPerks: name === 'perks', isPlans: name === 'plans', isCheckout: name === 'checkout', isBank: name === 'bank', isDash: name === 'dash',
      inQuiz: qNum > 0, notQuiz: qNum === 0, showBack, showSegs: qNum > 0 && qTotal > 1,
      quickNote: quick && qIndex >= 0, quickNoteText: es ? 'Cuando te unas revisamos más de 70 reclamos más para ti.' : "After you join, we check 70+ more claims for you.",
      setStCode: (e) => this.setState({ st: (e.target.value || '').toUpperCase().slice(0, 2) }),
      asideMatches: qNum > 0 || ['picked', 'all', 'calc', 'reveal', 'email', 'details', 'auth'].includes(name), asideInfo: !(qNum > 0 || ['picked', 'all', 'calc', 'reveal', 'email', 'details', 'auth'].includes(name)),
      qLabel: qNum + ' ' + L.of + ' ' + qTotal, qFull: L.qWord + ' ' + qNum + ' ' + L.of + ' ' + qTotal, segs, q, states,
      segGrid: 'flex-grow:1;display:grid;grid-template-columns:repeat(' + qTotal + ',minmax(0,1fr));gap:4px',
      i2h: L.i2a + qTotal + L.i2b,
      totalLabel: noFigure ? (es ? 'Varía' : 'Varies') : this.money(total), totalNum: noFigure ? (es ? 'Varía' : 'Varies') : total.toFixed(2), hasFigure: !noFigure, countLabel, countMatched: countLabel + ' ' + L.matched,
      calc1: L.calcA + countLabel + L.calcB, fromCount: L.fromW + countLabel, unlockAll: L.unlockA + countLabel + L.unlockB, filedOfLabel: noFigure ? '' : L.filedOf + this.money(total),
      variesLabel: [varies ? (es ? '+ ' + varies + ' con pagos variables' : '+ ' + varies + ' with variable payouts') : '', arbs.length ? (es ? '+ ' + arbs.length + ' reclamos de arbitraje' : '+ ' + plural(arbs.length, 'arbitration claim', 'arbitration claims', '', '')) : ''].filter(Boolean).join(' · '),
      hasVaries: varies > 0 || arbs.length > 0,
      hasMatches: ml.length > 0, noMatches: ml.length === 0,
      bumpClass: s.bump % 2 ? 'bumpA' : 'bumpB', matches,
      checkLogos: matches.slice(0, 6).map((m, i) => Object.assign({}, m, { popStyle: 'animation-delay:' + (2.1 + i * 0.12).toFixed(2) + 's' })),
      checkMore: ml.length > 6 ? '+' + (ml.length - 6) + (es ? ' más' : ' more') : '', hasCheckMore: ml.length > 6,
      amountWords: noFigure ? (es ? 'Monto fijado por el administrador' : 'Amount set by the settlement administrator') : this.words(total), checkDate: this.fmtDate(new Date().toISOString().slice(0, 10)),
      teaser: ['apple', 'amazon', 'goodrx'].map(id => this.data().find(d => d.id === id)).map(d => ({
        logo: this.logos()[d.id] || '', hasLogo: !!this.logos()[d.id], noLogo: !this.logos()[d.id], co: d.co, tileStyle: S.tile(K[d.cat]), initial: d.co.slice(0, 1),
        line: es ? ('acordó pagar ' + d.fund + '. ' + ((d.max || d.amt) ? 'Quienes califiquen reciben hasta ' + this.money(d.max || d.amt) + '.' : 'Quienes califiquen reciben una parte.'))
                 : ('settled for ' + d.fund + '. ' + ((d.max || d.amt) ? 'People who qualify get up to ' + this.money(d.max || d.amt) + '.' : 'People who qualify get a share.'))
      })),
      next: () => this.go(1), back: () => this.back(),
      nextDisabled, nextStyle: S.btn(!nextDisabled), primary: S.btn(true),
      email: s.email, onEmail: (e) => this.setState({ email: e.target.value }),
      emailErr: s.emailTried ? emailErr : '', hasEmailErr: !!(s.emailTried && emailErr), emailDisabled: !em, emailStyle: S.btn(!!em), emailNext: () => { if (emailOk) this.go(1); else this.setState({ emailTried: true }); }, quickSignIn: () => { if (!emailOk) this.setState({ email: 'alex.rivera@gmail.com' }); this.go(1); },
      p, inp, stCode: stCode || '', setFirst: setP('first'), setMiddle: setP('middle'), setLast: setP('last'), setStreet: setP('street'), setApt: setP('apt'), setCity: setP('city'), setZip: setP('zip'), setPhone: setP('phone'), setDob: (e) => this.setState({ p: Object.assign({}, this.state.p, { dob: this.slashFmt(e.target.value, this.state.p.dob, [2, 2, 4]) }) }),
      detDisabled: false, detStyle: S.btn(true), detNext: () => { if (detOk) this.go(1); else this.setState({ detTried: true }); },
      fe: showDE, detErrN: Object.keys(showDE).length, hasDetErr: Object.keys(showDE).length > 0,
      detErrMsg: es ? 'Revisa los campos marcados para que tus reclamos no sean rechazados.' : 'Fix the highlighted fields so your claims are not rejected.',
      fs: ['first', 'middle', 'last', 'street', 'apt', 'city', 'st', 'zip', 'phone', 'dob'].reduce((o, k) => { o[k] = inp + (showDE[k] ? ';border-color:#C8323B;background:#FFF7F7' : ''); return o; }, {}),
      stOpts: [['', es ? 'Elige' : 'Select']].concat(['AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'DC', 'FL', 'GA', 'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD', 'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ', 'NM', 'NY', 'NC', 'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC', 'SD', 'TN', 'TX', 'UT', 'VT', 'VA', 'WA', 'WV', 'WI', 'WY'].map(x => [x, x])).map(([v, l]) => ({ v, l, sel: v === stCode0 })),
      pickSt: (e) => this.setState({ st: e.target.value || null }),
      auth, signedCount, hasSigned: signedCount > 0,
      pickedH: s.focus && !s.focusMore ? (pickedN ? (es ? '¡Coincides con ' + (ml[0] ? ml[0].co : '') + '!' : 'You qualify for ' + (ml[0] ? ml[0].co : 'this settlement') + '!') : (es ? 'Este no parece aplicarte' : 'This one does not look like a match')) : pickedN ? (es ? 'Coincides con ' + plural(pickedN, '', '', 'reclamo', 'reclamos') : 'You matched ' + plural(pickedN, 'claim', 'claims', '', '')) : (es ? 'Ninguno de los 10 principales aplicó' : 'None of the top 10 applied'),
      pickedSub: s.focus && !s.focusMore ? (es ? '¿Quieres ver si te deben dinero de otros acuerdos? Responde ' + (this._moreN || 9) + ' preguntas rápidas o revisa las ' + (allPool.length + topIds.length) + ' ofertas abiertas.' : 'Want to see if other settlements owe you money too? Answer ' + (this._moreN || 9) + ' quick questions, or browse all ' + (allPool.length + topIds.length) + ' open offers.') : pickedN ? (es ? 'Continúa para ver tu estimado, o revisa las demás ofertas abiertas para sumar más.' : 'Continue to see your estimate, or check the other open offers to add more.') : (es ? 'Hay ' + (allPool.length) + ' ofertas abiertas más. Revisa la lista para encontrar las tuyas.' : 'There are ' + allPool.length + ' more open offers. Browse the list to find yours.'),
      hasPicked: pickedN > 0, noPicked: pickedN === 0, pickedTotal: noFigure ? (es ? 'Varía' : 'Varies') : this.money(total),
      browseStyle: pickedN ? 'display:block;width:100%;min-height:52px;margin-top:8px;border-radius:999px;background:#FFFFFF;color:#1B0F4F;box-shadow:inset 0 0 0 1.5px #1B0F4F;font-size:16px;font-weight:800' : S.btn(true),
      allGroups, allPoolN: allPool.length + topIds.length, allQ: s.allQ, setAllQ: (e) => this.setState({ allQ: e.target.value }),
      allH: es ? 'Todas las ofertas abiertas' : 'All open offers', allSub: es ? 'Toca las que apliquen a ti. Lo que ya elegiste está guardado.' : 'Tap any that apply to you. Your picks so far are already saved.',
      searchPh: es ? 'Buscar empresa o producto' : 'Search a company or product',
      browseAll: () => this.setState({ sawAll: true, step: this.steps().indexOf('all') }),
      showMoreQuiz: !!(s.focus && !s.focusMore), moreQuiz: () => this.setState({ focusMore: true, step: 1 }),
      moreQuizLabel: es ? 'Revisar ' + (this._moreN || 9) + ' acuerdos más comunes' : 'Check ' + (this._moreN || 9) + ' more common settlements',
      moreQuizStyle: 'display:block;width:100%;min-height:52px;margin-top:8px;border-radius:999px;background:#FFFFFF;color:#1B0F4F;box-shadow:inset 0 0 0 1.5px #1B0F4F;font-size:16px;font-weight:800',
      browseLabel: es ? 'Ver las ' + (allPool.length + topIds.length) + ' ofertas abiertas' : 'Browse all ' + (allPool.length + topIds.length) + ' open offers',
      quickCont: toCalc, quickContDisabled: pickedN === 0, quickContStyle: S.btn(pickedN > 0),
      quickContLabel: pickedN ? (es ? 'Continuar con ' + plural(pickedN, '', '', 'reclamo', 'reclamos') : 'Continue with ' + plural(pickedN, 'claim', 'claims', '', '')) : (es ? 'Elige al menos uno' : 'Pick at least one'),
      qTileGrid: 'display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:8px',
      billItems: (signedCount ? AL.filter(m => s.signed[m.id]) : AL).map(m => { const lg = this.logos()[m.id]; return { logo: lg || '', hasLogo: !!lg, noLogo: !lg, initial: m.co.replace(/[^A-Za-z]/g, '').slice(0, 1), tileStyle: S.tile(K[m.cat]), co: m.co, title: m.title.startsWith(m.co) ? m.title : m.co + ' ' + m.title, amt: amtOf(m) }; }),
      billCount: plural(signedCount || AL.length, 'claim', 'claims', 'reclamo', 'reclamos'),
      estBackLabel: (es ? 'Hasta ' : 'Up to ') + this.money((signedCount ? AL.filter(m => s.signed[m.id]) : AL).filter(m => m.cat !== 'arb').reduce((t, m) => t + val(m), 0)),
      isPerk1: s.pi === 0, isPerk2: s.pi === 1, isPerk3: s.pi === 2,
      perkNext: () => { if (this.state.pi < 2) this.setState({ pi: this.state.pi + 1 }); else this.setState({ step: this.steps().indexOf('bank') }); },
      perkSkip: () => this.setState({ step: this.steps().indexOf('bank') }),
      dot1: this.dotStyle(s.pi === 0 && name === 'perks'), dot2: this.dotStyle(s.pi === 1 && name === 'perks'), dot3: this.dotStyle(s.pi === 2 && name === 'perks'), dot4: this.dotStyle(name === 'bank'),
      perkSt: (s.p && s.p.st) || s.st && s.st !== 'Other' && s.st || 'CA',
      perkLocal: (() => { const code = (s.p && s.p.st) || (s.st && s.st !== 'Other' ? s.st : 'CA'); let L2 = this.data().filter(d => d.st && d.st.split(',').includes(code) && this.daysLeft(d.dl) > 0); if (L2.length < 3) L2 = L2.concat(this.data().filter(d => d.st && !L2.includes(d) && this.daysLeft(d.dl) > 0)); return L2.slice(0, 4).map(d => ({ co: d.co, initial: d.co.replace(/[^A-Za-z]/g, '').slice(0, 1), tileStyle: S.tile(K[d.cat]), area: d.area || d.st, amt: (d.max || d.amt) > 0 ? (es ? 'Hasta ' : 'Up to ') + this.money(d.max || d.amt) : (es ? 'Varía' : 'Varies') })); })(),
      showDots: s.paid === 'member', perkMatches: ml.slice(0, 4).map(m => { const lg = this.logos()[m.id]; return { co: m.co, logo: lg || '', hasLogo: !!lg, noLogo: !lg, initial: m.co.slice(0, 1), tileStyle: S.tile(K[m.cat]), st: s.signed[m.id] ? (es ? 'Presentado' : 'Filed') : m.mode === 'site' ? (es ? 'Sitio oficial' : 'Official site') : (es ? 'Listo' : 'Ready'), amt: amtOf(m) }; }),
      newMatch: (() => { const d = allPool.find(x => !more.includes(x.id) && x.cat !== 'arb' && (x.max || x.amt) >= 50); return d ? { co: d.co, line: es ? 'Podrías calificar para ' + (d.title.startsWith(d.co) ? d.title : d.co + ' ' + d.title) + '. Toca para presentar.' : 'You may qualify for the ' + (d.title.startsWith(d.co) ? d.title : d.co + ' ' + d.title) + '. Tap to file.' } : { co: '', line: '' }; })(),
      perks: [['p1', 'M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9 M10.3 21a1.94 1.94 0 0 0 3.4 0'], ['p2', 'M12 20h9 M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z'], ['p3', 'M3 3v18h18 M7 14l4-4 4 4 5-5'], ['p4', 'M8 2v4 M16 2v4 M3 10h18 M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z'], ['p5', 'M12 2v20 M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6'], ['p6', 'M12 3v18 M5 7h14 M5 7l-3 7a4 4 0 0 0 6 0Z M19 7l-3 7a4 4 0 0 0 6 0Z']].map(([k, d]) => ({ title: L[k], body: L[k + 'd'], d })),
      signedLabel: es ? signedCount + ' autorizaciones firmadas, listas para enviar al activar tu membresía' : signedCount + (signedCount === 1 ? ' authorization signed' : ' authorizations signed') + ', ready to submit when your membership starts',
      unlock: () => this.setState({ buying: 'fee', payState: '', step: this.steps().indexOf('checkout') }),
      toPlans: () => this.setState({ step: this.steps().indexOf('plans') }),
      plans: [['1m', es ? '1 MES' : '1 MONTH', '$7.50', es ? 'primer mes' : 'first month', es ? 'Luego $29.99 cada mes' : 'Then $29.99 every month', 'Reg. $29.99', ''], ['3m', es ? '3 MESES' : '3 MONTHS', '$18.74', es ? 'primeros 3 meses' : 'first 3 months', es ? 'Luego $74.97 cada 3 meses ($24.99/mes)' : 'Then $74.97 every 3 months ($24.99/mo)', 'Reg. $74.97', es ? 'Ahorra 17%' : 'Save 17%'], ['6m', es ? '6 MESES' : '6 MONTHS', '$29.99', es ? 'primeros 6 meses' : 'first 6 months', es ? 'Luego $119.94 cada 6 meses ($19.99/mes)' : 'Then $119.94 every 6 months ($19.99/mo)', 'Reg. $119.94', es ? 'Ahorra 33%' : 'Save 33%']].map(([id, name, per, unit, billed, total, save]) => ({
        id, name, per, unit: ' ' + unit, billed, total, save, hasSave: !!save, best: id === '6m', notBest: id !== '6m', sel: s.plan === id,
        style: 'position:relative;display:flex;flex-direction:column;width:100%;text-align:left;padding:0;border-radius:16px;overflow:hidden;background:#FFFFFF;' + (s.plan === id ? 'box-shadow:inset 0 0 0 2px #1B0F4F,0 10px 24px rgba(20,11,58,.08)' : 'box-shadow:inset 0 0 0 1px #E4DEF5'),
        pick: () => this.setState({ plan: id }) })),
      planRenew: (() => { const p = this.planInfo(s.plan, es); return es ? 'Pagas ' + p.first + ' hoy (75% de descuento). Luego se renueva a ' + p.full + ' ' + p.every + ' hasta que canceles.' : 'You pay ' + p.first + ' today (75% off). Then it auto-renews at ' + p.full + ' ' + p.every + ' until you cancel.'; })(),
      subscribe: () => this.setState({ buying: 'member', payState: '', step: this.steps().indexOf('checkout') }),
      coItem: s.buying === 'member' ? (es ? 'Membresía Claimclub · ' : 'Claimclub membership · ') + ({ '1m': es ? '1 mes' : '1 month', '3m': es ? '3 meses' : '3 months', '6m': es ? '6 meses' : '6 months' }[s.plan]) : (es ? 'Tarifa de presentación · ' : 'Filing fee · ') + plural(signedCount || AL.length, 'claim', 'claims', 'reclamo', 'reclamos'),
      coSub: s.buying === 'member' ? (() => { const p = this.planInfo(s.plan, es); return es ? '75% de descuento en tu primer periodo. Se renueva a ' + p.full + ' ' + p.every + ' hasta que canceles.' : '75% off your first billing period. Renews at ' + p.full + ' ' + p.every + ' until you cancel.'; })() : (es ? 'Pago único. Sin suscripción.' : 'One-time payment. No subscription.'),
      coPrice: s.buying === 'member' ? this.planInfo(s.plan, es).first : '$99',
      coPayLabel: (es ? 'Pagar ' : 'Pay ') + (s.buying === 'member' ? this.planInfo(s.plan, es).first : '$99'),
      coIdle: !s.payState, coBusy: s.payState === 'busy', coDone: s.payState === 'done',
      unlockOn: !!s.unlock, unlockCls: 'unl' + (s.unlock === 'out' ? ' out' : ''), confetti: s.unlock ? this.confetti() : [],
      card: s.card, exp: s.exp, cvc: s.cvc, czip: s.czip,
      setCard: (e) => this.setState({ card: e.target.value }), setExp: (e) => this.setState({ exp: this.slashFmt(e.target.value, this.state.exp, [2, 2]) }), setCvc: (e) => this.setState({ cvc: e.target.value }), setCzip: (e) => this.setState({ czip: e.target.value }),
      payCardStyle: S.btn(!!(s.card || '').trim()), payCardDisabled: !(s.card || '').trim(),
      ce: s.cardTried ? this.cardCheck(s.card, s.exp, s.cvc, s.czip, es) : {}, hasCardErr: s.cardTried && Object.keys(this.cardCheck(s.card, s.exp, s.cvc, s.czip, es)).length > 0,
      cardErrText: s.cardTried ? Object.values(this.cardCheck(s.card, s.exp, s.cvc, s.czip, es)).join(' · ') : '',
      payCard: () => { const E = this.cardCheck(this.state.card, this.state.exp, this.state.cvc, this.state.czip, es); if (Object.keys(E).length) this.setState({ cardTried: true }); else this.payNow(); },
      payNow: () => this.payNow(),
      connectBankAct: () => { this.setState({ bankDone: true }); clearTimeout(this._bk); this._bk = setTimeout(() => this.afterBank(), 1400); },
      skipBank: () => this.afterBank(), bankDone: s.bankDone, bankTodo: !s.bankDone,
      payoutLine: (() => { const m = settle.find(x => x.amt > 0) || ml[0]; return m ? (es ? 'Recibiste ' + this.money(m.amt || 50) + ' de tu reclamo de ' + m.co + '.' : 'You received ' + this.money(m.amt || 50) + ' from your ' + m.co + ' claim.') : ''; })(),
      memberCount: '148,000+',
      allValue, allOpenN: allOpen.length, potentialSub: es ? 'En las ' + allOpen.length + ' ofertas abiertas. Tus coincidencias: ' + this.money(total) + '.' : 'Across all ' + allOpen.length + ' open offers. Your matches so far: ' + this.money(total) + '.',
      moreTotal: moreLabel, moreSmall: es ? '+ hasta ' + moreLabel + ' en otras ofertas abiertas' : '+ up to ' + moreLabel + ' in other open offers', moreCount: moreN, hasMore: moreN > 0, pickedMore: moreN > 0 && !(s.focus && !s.focusMore),
      moreLine: es ? 'Hay hasta ' + moreLabel + ' más en ' + moreN + ' ofertas abiertas que aún no has revisado. Las revisamos todas por ti cuando te unes.' : 'There is up to ' + moreLabel + ' more in ' + moreN + ' other open offers you have not checked yet. We check them all for you when you join.',
      saOpen: s.saOpen, saList: AL.map(m => { const lg = this.logos()[m.id]; return { co: m.co, title: m.title.startsWith(m.co) ? m.title : m.co + ' ' + m.title, logo: lg || '', hasLogo: !!lg, noLogo: !lg, initial: m.co.replace(/[^A-Za-z]/g, '').slice(0, 1), tileStyle: S.tile(K[m.cat]), amt: amtOf(m) }; }),
      saCount: AL.length, hasSa: AL.length > 1, saBtnLabel: (es ? 'Firmar los ' : 'Sign all ') + AL.length + (es ? ' formularios a la vez' : ' forms at once'),
      openSa: () => this.setState({ saOpen: true }), closeSa: () => this.setState({ saOpen: false }),
      saConsentOn: s.saConsent, saBox: 'width:20px;height:20px;flex:none;border-radius:5px;display:flex;align-items:center;justify-content:center;' + (s.saConsent ? 'background:#1B0F4F;color:#FFFFFF' : 'background:#FFFFFF;box-shadow:inset 0 0 0 1.5px #A99FCC'),
      toggleSaConsent: () => this.setState({ saConsent: !this.state.saConsent }),
      saSigned: s.saSigned, saUnsigned: !s.saSigned, saSign: () => this.setState({ saSigned: true }),
      saDisabled: !(s.saConsent && s.saSigned), saStyle: S.btn(s.saConsent && s.saSigned),
      saGo: () => { if (!(this.state.saConsent && this.state.saSigned)) return; const sg = {}, cs = {}; AL.forEach(m => { sg[m.id] = true; cs[m.id] = true; }); this.setState({ signed: sg, consent: cs, saOpen: false, step: this.steps().indexOf('pay') }); },
      saGoLabel: (es ? 'Firmar los ' : 'Sign all ') + AL.length + (es ? ' formularios' : ' forms'),
      filedLabel: this.money(filedAmt),
      filedBar: 'height:100%;border-radius:99px;transition:width .4s ease;background:#218358;width:' + (total ? Math.round(filedAmt / total * 100) : 0) + '%',
      restart: () => this.setState({ step: 0, st: null, a: {}, filed: {}, email: '', ai: 0, signed: {}, skipped: {}, consent: {}, p: { first: '', middle: '', last: '', street: '', apt: '', city: '', zip: '', phone: '', dob: '' } })
    };
  }
  payNow() {
    if (this.state.payState) return;
    this.setState({ payState: 'busy' });
    clearTimeout(this._pay);
    this._pay = setTimeout(() => { this.setState({ payState: 'done', paid: this.state.buying }); this.saveForApp(); this.finishPay(this.state.buying); }, 1400);
  }
  finishPay(kind) {
    clearTimeout(this._fin); clearTimeout(this._fin2); clearTimeout(this._fin3);
    if (kind !== 'member') { this._fin = setTimeout(() => this.setState({ pi: 0, step: this.steps().indexOf('bank') }), 1300); return; }
    const reduce = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    this._fin = setTimeout(() => this.setState({ unlock: 'in' }), 450);
    this._fin2 = setTimeout(() => this.setState({ pi: 0, step: this.steps().indexOf('perks'), unlock: 'out' }), reduce ? 1600 : 3000);
    this._fin3 = setTimeout(() => this.setState({ unlock: '' }), reduce ? 1900 : 3550);
  }
  confetti() {
    if (this._conf) return this._conf;
    const cols = ['#FFB224', '#FFFFFF', '#CBBEF5', '#9FE8C4', '#FFD978'];
    const out = [];
    for (let i = 0; i < 34; i++) {
      const a = (i / 34) * Math.PI * 2 + (i % 3) * 0.21, d = 170 + ((i * 37) % 9) * 26;
      const x = Math.round(Math.cos(a) * d), y = Math.round(Math.sin(a) * d * 0.8 + 40 + (i % 4) * 22);
      out.push({ st: '--x:' + x + 'px;--y:' + y + 'px;--r:' + ((i * 83) % 720 - 360) + 'deg;background:' + cols[i % cols.length] + ';width:' + (6 + (i % 3) * 3) + 'px;height:' + (10 + (i % 4) * 3) + 'px;border-radius:' + (i % 5 === 0 ? '50%' : '2px') + ';animation-delay:' + (0.62 + (i % 6) * 0.03).toFixed(2) + 's' });
    }
    return (this._conf = out);
  }
  afterBank() { this.saveForApp(); this.setState({ step: this.steps().indexOf('dash') }); }
  saveForApp() {
    try {
      const ml = this.matched(), p = this.state.p;
      const data = { ids: ml.map(m => m.id), signed: Object.keys(this.state.signed).filter(k => this.state.signed[k]), bank: !!this.state.bankDone, plan: this.state.paid === 'member' ? this.state.plan : '', paid: this.state.paid,
        p: { name: [p.first, p.middle, p.last].filter(Boolean).join(' '), email: this.state.email, phone: p.phone, street: [p.street, p.apt].filter(Boolean).join(', '), city: p.city, st: this.state.st && this.state.st !== 'Other' ? this.state.st : '', zip: p.zip, dob: p.dob } };
      localStorage.setItem('claimclub_session', JSON.stringify(data));
    } catch (e) {}
  }
  validate(p, st, es) {
    const E = {}, t = (v) => (v || '').trim();
    const junk = /^(test|testing|asdf\w*|qwer\w*|fake|none|na|n\/a|xxx+|abc|aaa+|john doe|jane doe|null|undefined|sdf\w*)$/i;
    const hasVowel = (v) => /[aeiouyáéíóúü]/i.test(v);
    const nameBad = (v) => !/^[A-Za-zÀ-ÿ' .-]{2,40}$/.test(v) || junk.test(v) || /(.)\1\1/i.test(v) || (v.length > 3 && !hasVowel(v));
    const msg = (en, sp) => es ? sp : en;
    if (!t(p.first)) E.first = msg('Enter your first name', 'Escribe tu nombre'); else if (nameBad(t(p.first))) E.first = msg('Enter your real first name, letters only', 'Escribe tu nombre real, solo letras');
    if (t(p.middle) && !/^[A-Za-zÀ-ÿ' .-]{1,40}$/.test(t(p.middle))) E.middle = msg('Letters only', 'Solo letras');
    if (!t(p.last)) E.last = msg('Enter your last name', 'Escribe tu apellido'); else if (nameBad(t(p.last))) E.last = msg('Enter your real last name, letters only', 'Escribe tu apellido real, solo letras');
    const street = t(p.street);
    if (!street) E.street = msg('Enter your street address', 'Escribe tu dirección');
    else if (!(/^\d+[A-Za-z]?\s+[A-Za-zÀ-ÿ0-9.'#-]{2,}(\s+\S+)*$/.test(street) || /^p\.?\s*o\.?\s*box\s+\d+/i.test(street)) || junk.test(street)) E.street = msg('Use a street number and name, like 1452 Maple Ave', 'Usa número y calle, por ejemplo 1452 Maple Ave');
    const city = t(p.city);
    if (!city) E.city = msg('Enter your city', 'Escribe tu ciudad'); else if (!/^[A-Za-zÀ-ÿ' .-]{2,40}$/.test(city) || !hasVowel(city) || junk.test(city)) E.city = msg('Enter a real city name', 'Escribe una ciudad real');
    if (!st) E.st = msg('Choose your state', 'Elige tu estado');
    const zip = t(p.zip);
    if (!/^\d{5}(-\d{4})?$/.test(zip)) E.zip = msg('Use a 5-digit ZIP', 'Usa un código postal de 5 dígitos');
    else if (st && !this.zipFits(zip, st)) E.zip = msg('This ZIP is not in ' + st, 'Este código postal no es de ' + st);
    const ph = (p.phone || '').replace(/\D/g, '').replace(/^1(?=\d{10}$)/, '');
    if (!ph) E.phone = msg('Enter your mobile number', 'Escribe tu número celular');
    else if (ph.length !== 10 || /^[01]/.test(ph) || /^\d{3}[01]/.test(ph) || /^(\d)\1+$/.test(ph) || ph.slice(3, 6) === '555' || ph === '1234567890') E.phone = msg('Enter a real 10-digit US mobile number', 'Escribe un celular real de 10 dígitos');
    if (t(p.dob)) {
      const m = t(p.dob).match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
      const d = m ? new Date(+m[3], +m[1] - 1, +m[2]) : null;
      const age = d ? (Date.now() - d.getTime()) / 31557600000 : -1;
      if (!m || !d || d.getMonth() !== +m[1] - 1) E.dob = msg('Use MM/DD/YYYY', 'Usa MM/DD/AAAA'); else if (age < 18) E.dob = msg('You must be 18 or older', 'Debes tener 18 años o más'); else if (age > 110) E.dob = msg('Check the year', 'Revisa el año');
    }
    return E;
  }
  zipFits(zip, st) {
    const z = parseInt(zip.slice(0, 3), 10);
    const R = { AL: [[350, 369]], AK: [[995, 999]], AZ: [[850, 865]], AR: [[716, 729]], CA: [[900, 961]], CO: [[800, 816]], CT: [[60, 69]], DE: [[197, 199]], DC: [[200, 205], [569, 569]], FL: [[320, 349]], GA: [[300, 319], [398, 399]], HI: [[967, 968]], ID: [[832, 838]], IL: [[600, 629]], IN: [[460, 479]], IA: [[500, 528]], KS: [[660, 679]], KY: [[400, 427]], LA: [[700, 714]], ME: [[39, 49]], MD: [[206, 219]], MA: [[10, 27], [55, 55]], MI: [[480, 499]], MN: [[550, 567]], MS: [[386, 397]], MO: [[630, 658]], MT: [[590, 599]], NE: [[680, 693]], NV: [[889, 898]], NH: [[30, 38]], NJ: [[70, 89]], NM: [[870, 884]], NY: [[100, 149], [5, 5], [63, 63]], NC: [[270, 289]], ND: [[580, 588]], OH: [[430, 459]], OK: [[730, 749]], OR: [[970, 979]], PA: [[150, 196]], RI: [[28, 29]], SC: [[290, 299]], SD: [[570, 577]], TN: [[370, 385]], TX: [[750, 799], [733, 733], [885, 885]], UT: [[840, 847]], VT: [[50, 59]], VA: [[201, 201], [220, 246]], WA: [[980, 994]], WV: [[247, 268]], WI: [[530, 549]], WY: [[820, 831]] };
    return !R[st] || R[st].some(([a, b]) => z >= a && z <= b);
  }
  // Inserts the slashes for date fields as the person types (MM/DD/YYYY, MM/YY). Backspacing over a slash still works.
  slashFmt(v, prev, parts) {
    const max = parts.reduce((a, b) => a + b, 0), d = String(v || '').replace(/\D/g, '').slice(0, max), grow = String(v || '').length > String(prev || '').length;
    let out = '', i = 0;
    parts.forEach((n, k) => { const seg = d.slice(i, i + n); i += n; out += seg; if (k < parts.length - 1 && (d.length > i || (grow && d.length === i && seg.length === n))) out += '/'; });
    return out;
  }
  cardCheck(card, exp, cvc, zip, es) {
    const E = {}, n = (card || '').replace(/\D/g, '');
    let sum = 0, alt = false;
    for (let i = n.length - 1; i >= 0; i--) { let d = +n[i]; if (alt) { d *= 2; if (d > 9) d -= 9; } sum += d; alt = !alt; }
    if (n.length < 13 || n.length > 19 || sum % 10 !== 0) E.card = es ? 'Número de tarjeta no válido' : 'That card number is not valid';
    const m = (exp || '').replace(/\s/g, '').match(/^(\d{2})\/?(\d{2})$/);
    const now = new Date(), y = now.getFullYear() % 100, mo = now.getMonth() + 1;
    if (!m || +m[1] < 1 || +m[1] > 12 || +m[2] < y || (+m[2] === y && +m[1] < mo) || +m[2] > y + 20) E.exp = es ? 'Fecha de vencimiento no válida' : 'Check the expiry date';
    if (!/^\d{3,4}$/.test((cvc || '').trim())) E.cvc = es ? 'CVC no válido' : 'Check the CVC';
    if (!/^\d{5}$/.test((zip || '').trim())) E.czip = es ? 'Código postal no válido' : 'Use a 5-digit ZIP';
    return E;
  }
  dotStyle(on) { return 'height:4px;border-radius:99px;transition:width .3s,background .3s;' + (on ? 'width:30px;background:#140B3A' : 'width:16px;background:#E4DEF5'); }
  langStyle(on) { return 'min-width:40px;height:32px;padding:0 10px;border-radius:99px;font-family:inherit;font-size:12px;font-weight:800;letter-spacing:.4px;' + (on ? 'background:#1B0F4F;color:#FFFFFF' : 'background:transparent;color:#6B6188'); }
  words(n) {
    const ones = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
    const tens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
    const under1k = (x) => { let out = []; if (x >= 100) { out.push(ones[Math.floor(x / 100)] + ' hundred'); x %= 100; } if (x >= 20) { out.push(tens[Math.floor(x / 10)] + (x % 10 ? '-' + ones[x % 10] : '')); } else if (x > 0) out.push(ones[x]); return out.join(' '); };
    const whole = Math.floor(n), cents = Math.round((n - whole) * 100);
    let w = whole === 0 ? 'zero' : (whole >= 1000 ? under1k(Math.floor(whole / 1000)) + ' thousand ' : '') + under1k(whole % 1000);
    w = w.trim(); w = w.charAt(0).toUpperCase() + w.slice(1);
    return w + ' and ' + String(cents).padStart(2, '0') + '/100';
  }
  pick(raw, id, oi, d) {
    const a = this.state.a;
    if (raw.multi) {
      let arr = (a[raw.key] || []).slice(); let adding = false;
      if (id === 'none') arr = ['none'];
      else {
        arr = arr.filter(x => x !== 'none');
        if (arr.includes(id)) arr = arr.filter(x => x !== id); else { arr.push(id); adding = true; }
      }
      this.setState({ a: Object.assign({}, a, { [raw.key]: arr }), bump: this.state.bump + (adding && d && d.amt > 0 ? 1 : 0) });
    } else {
      this.setState({ a: Object.assign({}, a, { [raw.key]: id }), ['l_' + raw.key]: oi, bump: this.state.bump + (d && d.amt > 0 ? 1 : 0) });
      clearTimeout(this._t);
      this._t = setTimeout(() => this.go(1), 380);
    }
  }
