import re,subprocess
base={'#140B3A':'#0A0F0D','#0E0729':'#000000','#F7F5FC':'#F3F6F4','#F3F0FB':'#EAF2EE','#E4DEF5':'#DDE5E0','#EEEAF7':'#E8EEEA',
'#6B6188':'#5B6862','#4A4266':'#43504A','#3B1F9E':'#12805C','#CBBEF5':'#B9CCC2','#2A1570':'#0F3B2E','#D9D2EE':'#CFDAD3','#A99FCC':'#9AA8A0',
'#7A7096':'#6E7A73','#FBFAFE':'#F8FAF9','#F1EEF8':'#EEF2EF','#CFC6E6':'#C3CEC8','rgba(42,21,112,':'rgba(10,15,13,','rgba(20,11,58,':'rgba(10,15,13,'}
V={
 'G1':{'dark':'#0A0F0D','accent':'#3DDC97','font':('Manrope','Manrope:wght@400;500;600;700;800'),'hero':None,'light':'#C9D6CF','lighter':'#D7E3DC',
   'cats':"""      privacy: { bg: '#3E63DD', fg: '#FFFFFF', tint: '#ECF0FC', ink: '#2C4BB8', label: 'Data & privacy' },
      products: { bg: '#E5590A', fg: '#FFFFFF', tint: '#FDEEE5', ink: '#B54608', label: 'Products' },
      auto: { bg: '#12805C', fg: '#FFFFFF', tint: '#E6F4EC', ink: '#0E6649', label: 'Auto' },
      bank: { bg: '#FFB224', fg: '#0A0F0D', tint: '#FFF6E0', ink: '#7A5200', label: 'Banking & fees' },
      apps: { bg: '#D6409F', fg: '#FFFFFF', tint: '#FBEAF4', ink: '#A82F7C', label: 'Apps & services' },
      health: { bg: '#E5484D', fg: '#FFFFFF', tint: '#FDECEC', ink: '#B8333A', label: 'Health' },
      invest: { bg: '#0A0F0D', fg: '#FFFFFF', tint: '#EEF2EF', ink: '#0A0F0D', label: 'Investor & employee' }""",'tile':None},
 'G2':{'dark':'#0F3B2E','accent':'#3DDC97','font':('Manrope','Manrope:wght@400;500;600;700;800&family=Instrument+Serif:ital@0;1'),'hero':None,'light':'#C9D6CF','lighter':'#D7E3DC',
   'cats':"""      privacy: { bg: '#0F3B2E', fg: '#FFFFFF', tint: '#E3ECE8', ink: '#0F3B2E', label: 'Data & privacy' },
      products: { bg: '#12805C', fg: '#FFFFFF', tint: '#E6F4EC', ink: '#0E6649', label: 'Products' },
      auto: { bg: '#2F5D4E', fg: '#FFFFFF', tint: '#E5EDEA', ink: '#2F5D4E', label: 'Auto' },
      bank: { bg: '#3DDC97', fg: '#0A0F0D', tint: '#E3FAEF', ink: '#0E6649', label: 'Banking & fees' },
      apps: { bg: '#0A0F0D', fg: '#FFFFFF', tint: '#EEF2EF', ink: '#0A0F0D', label: 'Apps & services' },
      health: { bg: '#B7EFD3', fg: '#0A0F0D', tint: '#EAF9F1', ink: '#0E6649', label: 'Health' },
      invest: { bg: '#DDE5E0', fg: '#0A0F0D', tint: '#F3F6F4', ink: '#43504A', label: 'Investor & employee' },
      arb: { bg: '#43504A', fg: '#FFFFFF', tint: '#EEF2EF', ink: '#43504A', label: 'Arbitration' }""",'tile':None},
 'G3':{'dark':'#0A0F0D','accent':'#3DDC97','font':('Plus Jakarta Sans','Plus+Jakarta+Sans:wght@400;500;600;700;800'),'hero':'#12805C','light':'#F0FAF4','lighter':'#F0FAF4',
   'cats':"""      privacy: { bg: '#3E63DD', fg: '#FFFFFF', tint: '#ECF0FC', ink: '#2C4BB8', label: 'Data & privacy' },
      products: { bg: '#F76B15', fg: '#FFFFFF', tint: '#FDEEE5', ink: '#B54608', label: 'Products' },
      auto: { bg: '#3DDC97', fg: '#0A0F0D', tint: '#E6F4EC', ink: '#0E6649', label: 'Auto' },
      bank: { bg: '#FFB224', fg: '#0A0F0D', tint: '#FFF6E0', ink: '#7A5200', label: 'Banking & fees' },
      apps: { bg: '#E54BAA', fg: '#FFFFFF', tint: '#FBEAF4', ink: '#A82F7C', label: 'Apps & services' },
      health: { bg: '#E5484D', fg: '#FFFFFF', tint: '#FDECEC', ink: '#B8333A', label: 'Health' },
      invest: { bg: '#FFFFFF', fg: '#0A0F0D', tint: '#EEF2EF', ink: '#0A0F0D', label: 'Investor & employee' }""",
   'tile':"      tile: (c) => 'background:#0A0F0D;color:#FFFFFF;box-shadow:inset 0 8px 0 ' + c.bg,"}
}
def recolor(s,v):
    s=s.replace('#1B0F4F',v['dark']).replace('#FFB224',v['accent'])
    s=s.replace('#CFC6EE',v['light']).replace('#DCD3FA',v['lighter'])
    for k,val in base.items(): s=s.replace(k,val)
    return s
for name,v in [(k,V[k]) for k in V if k in __import__('sys').argv[1:]]:
    for kind in (['Landing','Flow','FlowD'] if name=='G2' else ['Landing','Flow']):
        s=open({'Landing':'LandingC','Flow':'FlowC','FlowD':'FlowC2D'}[kind].replace('C','C2') if name=='G2' and kind!='FlowD' else {'Landing':'LandingC','Flow':'FlowC','FlowD':'FlowC2D'}[kind]+'.tpl.html' if True else '').read() if False else open(({'Landing':'LandingC2','Flow':'FlowC2','FlowD':'FlowC2D'}[kind] if name=='G2' else kind+'C')+'.tpl.html').read()
        if kind=='Landing':
            s=s.replace("family=Manrope:wght@400;500;600;700;800","family="+v['font'][1])
            s=s.replace('Variation 3 homepage','Green '+name[1]+' homepage')
            if v['hero']:
                s=s.replace('<section id="top" style="background: #1B0F4F;','<section id="top" style="background: '+v['hero']+';')
            if name=='G2':
                s=s.replace('<span style="color: #FFB224">in one app.</span>','<span style="font-family: \'Instrument Serif\', serif; font-style: italic; font-weight: 400; letter-spacing: -0.02em; color: #3DDC97">in one app.</span>')
                s=s.replace('<section id="top" style="background: #1B0F4F; color: #FFFFFF; padding: 72px 4vw 0; overflow: hidden">','<section id="top" style="padding: 16px 2vw 0"><div style="background: #1B0F4F; color: #FFFFFF; padding: 72px 4vw 0; overflow: hidden; border-radius: 36px">')
                s=s.replace('  </section>\n\n  <!-- SHELVES -->','  </div></section>\n\n  <!-- SHELVES -->')
                s=s.replace('<header style="position: sticky; top: 0; z-index: 20; background: #1B0F4F">','<header style="position: sticky; top: 0; z-index: 20; background: #0A0F0D">')
        else:
            s=s.replace('Variation 3 claim flow','Green '+name[1]+' claim flow')
            s=s.replace("family=Manrope:wght@500;600;700;800","family="+v['font'][1])
        s=s.replace("font-family: Manrope, sans-serif;","font-family: '"+v['font'][0]+"', sans-serif;")
        s=s.replace('FlowC.dc.html','Flow'+name+'.dc.html').replace('id="emailC"','id="email'+name+'"').replace('for="emailC"','for="email'+name+'"')
        catsm="  cats() {\n    return {\n"+v['cats']+"\n    };\n  }\n  skin() {"
        s=s.replace('  skin() {',catsm,1)
        if v['tile']: s=re.sub(r"      tile: \(c\) => [^\n]*\n",v['tile']+"\n",s,count=1)
        s=recolor(s,v)
        open((kind.replace('FlowD','Flow')+name+('D' if kind=='FlowD' else ''))+'.tpl.html','w').write(s)
print('ok')
