# Writes the chosen reviews design (RevR2 from ../concepts/revR.py: dark cards, payout amount first, photo) into LandingC2.tpl.html.
# The people, photos and amounts are examples, so the section carries a visible "Example reviews" label. Run before green.py.
import sys, os, re
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'concepts'))
import revR
BLOB = {'logos/apple.svg': '7fd6ec4499df609a19ab46e16342f49d', 'logos/columbia.png': '0c6525be1fec809009a40a8f755ba9e8', 'logos/goodrx.png': '53105612f75094b555dcad8ddabc83e7',
        'logos/bofa.svg': '121d9429923e05b984526c8965383d6a'}
import json
bm = json.load(open('/tmp/blobmap.json')); inv = {v: k for k, v in bm.items()}
revR.logo = lambda p: '/_blob/' + (BLOB.get(p) or inv[p])
T = 'LandingC2.tpl.html'
s = open(T).read()
cards = ''.join(f'<div class="rv" style="flex: 0 0 316px; display: flex">{revR.r2card(r, False).replace("class=\"meshDark\"", "class=\"hmesh\"")}</div>' for r in revR.R)
label = ('<span style="display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 99px; background: #F7F5FC; color: #4A4266; font-size: 13px; font-weight: 700">'
         '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>'
         'Example reviews. Real member reviews coming soon.</span>')
sec = ('<section class="revSec" style="padding: 100px 4vw">\n    <div style="max-width: 1240px; margin: 0 auto; display: flex; flex-direction: column; gap: 32px">\n'
       f'      <div class="rv" style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: flex-end; gap: 14px"><h2 style="margin: 0; font-size: clamp(32px, 3.4vw, 46px); font-weight: 800; letter-spacing: -1.4px; color: #1B0F4F">What a payout looks like</h2>{label}</div>\n'
       f'      <div class="revGrid revR2" style="display: flex; gap: 16px; overflow-x: auto; padding-bottom: 8px; scrollbar-width: thin">{cards}</div>\n    </div>\n  </section>')
a = s.index('<section class="revSec"'); b = s.index('</section>', a) + len('</section>')
s = s[:a] + sec + s[b:]
CSS = '/* rev-r2 */@media (max-width:900px){.revR2>*{flex:0 0 84% !important;padding:0 !important}.revR2 .hmesh{min-height:340px !important}}\n'
s = re.sub(r'/\* rev-r2 \*/[^\n]*\n', '', s)
s = s.replace('</style>', CSS + '</style>', 1)
open(T, 'w').write(s)
print('reviews written')
