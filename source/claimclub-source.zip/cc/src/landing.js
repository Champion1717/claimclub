  constructor(props) {
    super(props);
    this.state = { filter: 'all', q: '', showAll: false, faq: -1 };
  }
  componentDidMount() { this.wireShelf(); this.countUp(); }
  countUp() {
    try {
      if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      const roots = [document];
      document.querySelectorAll('*').forEach((el) => { if (el.shadowRoot) roots.push(el.shadowRoot); });
      roots.forEach((root) => root.querySelectorAll('[data-countup]').forEach((el) => {
        if (el._cc) return; el._cc = true;
        const txt = el.textContent.trim(), target = Number(txt.replace(/[^0-9]/g, '')), pre = txt.startsWith('$') ? '$' : '';
        if (!target) return;
        const t0 = performance.now() + 250, dur = 1600;
        const fmt = (n) => pre + Math.round(n).toLocaleString('en-US');
        el.textContent = fmt(0);
        const tick = (now) => { const k = Math.min(1, Math.max(0, (now - t0) / dur)), e = 1 - Math.pow(1 - k, 3); el.textContent = fmt(target * e); if (k < 1) requestAnimationFrame(tick); else el.textContent = txt; };
        requestAnimationFrame(tick);
      }));
    } catch (e) {}
  }
  componentDidUpdate() { this.wireShelf(); }
  wireShelf() {
    try {
      const roots = [document];
      document.querySelectorAll('*').forEach((el) => { if (el.shadowRoot) roots.push(el.shadowRoot); });
      roots.forEach((root) => {
        const sh = root.querySelector('[data-shelf]'), tr = root.querySelector('[data-strack]'), th = root.querySelector('[data-sthumb]');
        const pv = root.querySelector('[data-sprev]'), nx = root.querySelector('[data-snext]');
        if (!sh || !tr || !th) return;
        const sync = () => {
          const max = sh.scrollWidth - sh.clientWidth, ratio = sh.scrollWidth ? sh.clientWidth / sh.scrollWidth : 1;
          const w = Math.max(0.12, Math.min(1, ratio)), pos = max > 0 ? sh.scrollLeft / max : 0;
          th.style.width = (w * 100) + '%'; th.style.left = (pos * (1 - w) * 100) + '%';
          tr.parentNode.style.visibility = max > 4 ? 'visible' : 'hidden';
          if (pv) pv.disabled = sh.scrollLeft <= 2; if (nx) nx.disabled = sh.scrollLeft >= max - 2;
        };
        if (sh._ccWired) { sync(); return; }
        sh._ccWired = true;
        sh.addEventListener('scroll', sync, { passive: true });
        window.addEventListener('resize', sync);
        const step = () => Math.max(240, sh.clientWidth * 0.8);
        if (pv) pv.addEventListener('click', () => sh.scrollBy({ left: -step(), behavior: 'smooth' }));
        if (nx) nx.addEventListener('click', () => sh.scrollBy({ left: step(), behavior: 'smooth' }));
        const toPos = (x) => {
          const r = tr.getBoundingClientRect(), tw = th.getBoundingClientRect().width;
          const f = Math.max(0, Math.min(1, (x - r.left - tw / 2) / Math.max(1, r.width - tw)));
          sh.scrollLeft = f * (sh.scrollWidth - sh.clientWidth);
        };
        let drag = null;
        th.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); drag = { x: e.clientX, s: sh.scrollLeft }; th.classList.add('drag'); sh.style.scrollBehavior = 'auto'; sh.style.scrollSnapType = 'none'; th.setPointerCapture(e.pointerId); });
        th.addEventListener('pointermove', (e) => { if (!drag) return; const r = tr.getBoundingClientRect(), tw = th.getBoundingClientRect().width; sh.scrollLeft = drag.s + (e.clientX - drag.x) * (sh.scrollWidth - sh.clientWidth) / Math.max(1, r.width - tw); });
        const end = () => { if (!drag) return; drag = null; th.classList.remove('drag'); sh.style.scrollBehavior = ''; sh.style.scrollSnapType = ''; };
        th.addEventListener('pointerup', end); th.addEventListener('pointercancel', end);
        tr.addEventListener('pointerdown', (e) => { if (e.target === th) return; sh.style.scrollBehavior = 'smooth'; toPos(e.clientX); });
        sync(); setTimeout(sync, 300);
      });
    } catch (e) {}
  }
  renderVals() {
    const s = this.state, K = this.cats(), S = this.skin();
    const allOpenAll = this.data().map(d => Object.assign({}, d, { days: this.daysLeft(d.dl) })).filter(d => d.days > 0);
    const all = allOpenAll.filter(d => !d.st);
    const localCount = allOpenAll.length - all.length;
    const filters = [
      { id: 'all', label: 'All' }, { id: 'noproof', label: 'No proof needed' }, { id: 'soon', label: 'Closing soon' },
      { id: 'privacy', label: 'Data & privacy' }, { id: 'products', label: 'Products' }, { id: 'apps', label: 'Apps & services' },
      { id: 'bank', label: 'Banking & fees' }, { id: 'health', label: 'Health' }, { id: 'auto', label: 'Auto' }, { id: 'invest', label: 'Investor & employee' }, { id: 'arb', label: 'Arbitration' }
    ];
    const q = s.q.trim().toLowerCase();
    let list = all.filter(d => {
      if (q && !(d.co + ' ' + d.title + ' ' + d.who).toLowerCase().includes(q)) return false;
      if (s.filter === 'noproof') return d.proof === 'No proof';
      if (s.filter === 'soon') return d.days <= 21;
      if (s.filter !== 'all') return d.cat === s.filter;
      return true;
    });
    list.sort((a, b) => (b.pop ? 1 : 0) - (a.pop ? 1 : 0) || a.days - b.days);
    const card = (d) => {
      const c = K[d.cat]; const lg = this.logos()[d.id];
      return {
        id: d.id, logo: lg || '', hasLogo: !!lg, noLogo: !lg, co: d.co, title: d.title, pay: d.pay, who: d.who, fund: d.fund, hasFund: !!d.fund, catLabel: c.label,
        headline: (d.max || d.amt) > 0 ? 'Up to ' + this.money(d.max || d.amt) : (d.proof === 'Automatic' ? 'Automatic' : 'Cash share'),
        withProof: !!(d.max && d.max > d.amt), proofNote: d.cat === 'arb' ? 'Not guaranteed' : d.max && d.max > d.amt ? (d.amt > 0 ? this.money(d.amt) + ' without proof' : 'With documentation') : '',
        deadline: this.fmtDate(d.dl), daysLabel: !d.dl ? 'No deadline' : d.days + (d.days === 1 ? ' day left' : ' days left'),
        urgent: d.days <= 14, calm: d.days > 14, pop: !!d.pop, noProof: d.proof === 'No proof', proof: d.proof,
        modeLabel: d.cat === 'arb' ? 'Filed with a partner law firm' : d.mode === 'here' ? 'File on Claimclub' : d.mode === 'auto' ? 'Paid automatically' : 'Official site required',
        tileStyle: S.tile(c), dotStyle: 'width:10px;height:10px;border-radius:3px;flex:none;background:' + c.bg,
        initial: d.co.replace(/[^A-Za-z]/g, '').slice(0, 1)
      };
    };
    const figured = list.filter(d => (d.max || d.amt) > 0);
    const shown = (s.showAll || this.rowMode) ? figured : figured.slice(0, 12);
    const soon = all.filter(d => (d.max || d.amt) > 0).slice().sort((a, b) => a.days - b.days).slice(0, 5).map(card);
    const phone = all.filter(d => d.pop && (d.max || d.amt) > 0).slice(0, 4).map(card);
    const byDays = (arr) => arr.slice().sort((a, b) => a.days - b.days);
    const shelves = [
      { title: 'Popular right now', items: all.filter(d => d.pop) },
      { title: 'No proof needed', items: byDays(all.filter(d => d.proof === 'No proof')) },
      { title: 'Data breaches', items: byDays(all.filter(d => d.cat === 'privacy' || d.cat === 'health')) },
      { title: 'Products, apps & fees', items: byDays(all.filter(d => ['products', 'apps', 'bank', 'auto'].includes(d.cat))) },
      { title: 'Investors & employees', items: byDays(all.filter(d => d.cat === 'invest')) },
      { title: 'Arbitration claims', items: all.filter(d => d.cat === 'arb') }
    ].map(sh => ({ title: sh.title, count: sh.items.length + ' open', items: sh.items.map(card) }));
    const header = (this.props.header ?? this.defaultHeader ?? 'slim');
    const vis = this.props.heroVisual ?? this.defaultVisual ?? 'tracker';
    const orbitSrc = all.filter(d => this.logos && this.logos()[d.id]).sort((a, b) => (b.pop ? 1 : 0) - (a.pop ? 1 : 0)).slice(0, 10);
    const orbit = orbitSrc.map((d, i) => { const ring = i < 6 ? 180 : 100, n = i < 6 ? 6 : orbitSrc.length - 6, k = i < 6 ? i : i - 6, ang = (k / n) * Math.PI * 2 + (i < 6 ? 0 : 0.5), sz = i < 6 ? 64 : 50;
      return { logo: this.logos()[d.id], co: d.co, style: 'position:absolute;left:' + Math.round(220 + ring * Math.cos(ang) - sz / 2) + 'px;top:' + Math.round(220 + ring * Math.sin(ang) - sz / 2) + 'px;width:' + sz + 'px;height:' + sz + 'px;border-radius:50%;object-fit:contain;background:#FFFFFF;padding:' + Math.round(sz * 0.18) + 'px;box-sizing:border-box;box-shadow:0 12px 30px rgba(0,0,0,.25)' }; });
    return {
      visStats: vis === 'stats', statsN: allOpenAll.length, localCount, allCount: allOpenAll.length, statsTotal: this.money(Math.round(all.reduce((t, d) => t + (d.max || d.amt || 0), 0))),
      statsTop: [['apple', 'iPhone 15 Pro or iPhone 16 buyers. $250M fund, no proof needed.'], ['googleplay', 'Anyone who bought apps or in-app items on Google Play, 2016 to 2023.'], ['visa', 'Anyone who paid an out-of-network ATM fee in the U.S.']].map(([id, note]) => { const d = all.find(x => x.id === id); if (!d) return null; const c = card(d); return { logo: c.logo, co: d.co, note, amt: (d.max || d.amt) > 0 ? 'Up to ' + this.money(d.max || d.amt) : 'Refund owed', days: c.daysLabel }; }).filter(Boolean),
      visStack: vis === 'stack', visTracker: vis === 'tracker', visOrbit: vis === 'orbit', visPhone: vis === 'phone', visCheck: vis === 'check', visNotifs: vis === 'notifs', visQuiz: vis === 'quiz', visGrid: vis === 'grid', visGauge: vis === 'gauge', orbit,
      slim: header === 'slim', full: header === 'full',
      filters: filters.map(f => ({ label: f.label, style: S.chip(s.filter === f.id), pick: () => this.setState({ filter: f.id, showAll: false }) })),
      logoStrip: (() => { const ls = all.filter(d => d.cat !== 'arb' && this.logos && this.logos()[d.id] && (d.max || d.amt) >= 50).sort((a, b) => (b.max || b.amt) - (a.max || a.amt)).slice(0, 16).map(card); return ls.concat(ls); })(),
      mobileCards: (s.showAll ? figured : figured.slice(0, 8)).map(card), hasMoreMobile: figured.length > 8,
      cards: shown.map(card), soon, phone, shelves,
      resultCount: list.length + (list.length === 1 ? ' settlement' : ' settlements'),
      openCount: all.length, settleCount: all.filter(d => d.cat !== 'arb').length, arbCount: all.filter(d => d.cat === 'arb').length, noProofCount: all.filter(d => d.proof === 'No proof').length,
      moreLabel: s.showAll ? 'Show fewer' : 'Show all ' + figured.length + ' settlements',
      hasMore: figured.length > 12, empty: figured.length === 0,
      toggleAll: () => this.setState({ showAll: !s.showAll }),
      q: s.q, onSearch: (e) => this.setState({ q: e.target.value, showAll: false })
    };
  }
