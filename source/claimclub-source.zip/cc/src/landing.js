  constructor(props) {
    super(props);
    this.state = { filter: 'all', q: '', showAll: false, faq: -1 };
  }
  componentDidMount() { this.wireShelf(); this.countUp(); }
  countUp() {
    try {
      if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      const roots = [document];
      document.querySelectorAll('*').forEach((el) => { if (el.shadowRoot) roots.push(el.shadowRoot); });
      roots.forEach((root) => root.querySelectorAll('[data-countup]').forEach((el) => {
        if (el._cc) return; el._cc = true;
        const txt = el.textContent.trim(), target = Number(txt.replace(/[^0-9]/g, '')), pre = txt.startsWith('$') ? '$' : '';
        if (!target) return;
        const t0 = performance.now() + 250, dur = 1600;
        const fmt = (n) => pre + Math.round(n).toLocaleString('en-US');
        el.textContent = fmt(0);
        const tick = (now) => { const k = Math.min(1, Math.max(0, (now - t0) / dur)), e = 1 - Math.pow(1 - k, 3); el.textContent = fmt(target * e); if (k < 1) requestAnimationFrame(tick); else el.textContent = txt; };
        requestAnimationFrame(tick);
      }));
    } catch (e) {}
  }
  componentDidUpdate() { this.wireShelf(); }
  wireShelf() {
    try {
      const roots = [document];
      document.querySelectorAll('*').forEach((el) => { if (el.shadowRoot) roots.push(el.shadowRoot); });
      roots.forEach((root) => {
        const sh = root.querySelector('[data-shelf]'), tr = root.querySelector('[data-strack]'), th = root.querySelector('[data-sthumb]');
        const pv = root.querySelector('[data-sprev]'), nx = root.querySelector('[data-snext]');
        if (!sh || !tr || !th) return;
        const sync = () => {
          const max = sh.scrollWidth - sh.clientWidth, ratio = sh.scrollWidth ? sh.clientWidth / sh.scrollWidth : 1;
          const w = Math.max(0.12, Math.min(1, ratio)), pos = max > 0 ? sh.scrollLeft / max : 0;
          th.style.width = (w * 100) + '%'; th.style.left = (pos * (1 - w) * 100) + '%';
          tr.parentNode.style.visibility = max > 4 ? 'visible' : 'hidden';
          if (pv) pv.disabled = sh.scrollLeft <= 2; if (nx) nx.disabled = sh.scrollLeft >= max - 2;
        };
        if (sh._ccWired) { sync(); return; }
        sh._ccWired = true;
        sh.addEventListener('scroll', sync, { passive: true });
        window.addEventListener('resize', sync);
        const step = () => Math.max(240, sh.clientWidth * 0.8);
        if (pv) pv.addEventListener('click', () => sh.scrollBy({ left: -step(), behavior: 'smooth' }));
        if (nx) nx.addEventListener('click', () => sh.scrollBy({ left: step(), behavior: 'smooth' }));
        const toPos = (x) => {
          const r = tr.getBoundingClientRect(), tw = th.getBoundingClientRect().width;
          const f = Math.max(0, Math.min(1, (x - r.left - tw / 2) / Math.max(1, r.width - tw)));
          sh.scrollLeft = f * (sh.scrollWidth - sh.clientWidth);
        };
        let drag = null;
        th.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); drag = { x: e.clientX, s: sh.scrollLeft }; th.classList.add('drag'); sh.style.scrollBehavior = 'auto'; sh.style.scrollSnapType = 'none'; th.setPointerCapture(e.pointerId); });
        th.addEventListener('pointermove', (e) => { if (!drag) return; const r = tr.getBoundingClientRect(), tw = th.getBoundingClientRect().width; sh.scrollLeft = drag.s + (e.clientX - drag.x) * (sh.scrollWidth - sh.clientWidth) / Math.max(1, r.width - tw); });
        const end = () => { if (!drag) return; drag = null; th.classList.remove('drag'); sh.style.scrollBehavior = ''; sh.style.scrollSnapType = ''; };
        th.addEventListener('pointerup', end); th.addEventListener('pointercancel', end);
        tr.addEventListener('pointerdown', (e) => { if (e.target === th) return; sh.style.scrollBehavior = 'smooth'; toPos(e.clientX); });
        sync(); setTimeout(sync, 300);
      });
    } catch (e) {}
  }
  renderVals() {
    const s = this.state, K = this.cats(), S = this.skin();
    const allOpenAll = this.data().map(d => Object.assign({}, d, { days: this.daysLeft(d.dl) })).filter(d => d.days > 0);
    const all = allOpenAll.filter(d => !d.st);
    const localCount = allOpenAll.length - all.length;
    const filters = [
      { id: 'all', label: 'All' }, { id: 'noproof', label: 'No proof needed' }, { id: 'soon', label: 'Closing soon' },
      { id: 'privacy', label: 'Data & privacy' }, { id: 'products', label: 'Products' }, { id: 'apps', label: 'Apps & services' },
      { id: 'bank', label: 'Banking & fees' }, { id: 'health', label: 'Health' }, { id: 'auto', label: 'Auto' }, { id: 'invest', label: 'Investor & employee' }, { id: 'arb', label: 'Arbitration' }
    ];
    const q = s.q.trim().toLowerCase();
    let list = all.filter(d => {
      if (q && !(d.co + ' ' + d.title + ' ' + d.who).toLowerCase().includes(q)) return false;
      if (s.filter === 'noproof') return d.proof === 'No proof';
      if (s.filter === 'soon') return d.days <= 21;
      if (s.filter !== 'all') return d.cat === s.filter;
      return true;
    });
    // Most common first: settlements nearly everyone qualifies for, then broad consumer claims, then narrower ones.
    const TOP = ['googleplay', 'visa', 'tyson', 'amazon', 'apple', 'realpage', 'equifax', 'equifax_inq', 'cvs', 'genericdrugs', 'kroger', 'goodrx', 'fleatick', 'tenet', 'hyundaikia', 'hk_theft', 'toyota', 'westernunion', 'mdlive', 'warnermusic', 'bofa', 'navy', 'google', 'youtube', 'openai', 'netflix', 'yahoo', 'disney', 'ubereats', 'smarttv', 'transunion', 'walgreens', 'bestbuy', 'ups', 'pork', 'sandoz', 'seatgeek', 'deere', 'knotts', 'squatch', 'whirlpool_frost', 'whirlpool_fz', 'geico_clue', 'natera', 'kia', 'keurig', 'bestway', 'thinkware', 'ragingwaters', 'compounce', 'high5', 'simplilearn', 'localmed', 'teleflora', 'starbucks'];
    const W = { products: 0, apps: 1, bank: 1, auto: 2, arb: 3, health: 4, privacy: 4, invest: 5 };
    const fundN = (d) => { const m = /\$([\d.]+)\s*([MBK])?/.exec(d.fund || ''); return m ? parseFloat(m[1]) * ({ B: 1e9, M: 1e6, K: 1e3 }[m[2]] || 1) : 0; };
    const rank = (d) => { const i = TOP.indexOf(d.id); return i >= 0 ? i : 1000 + (W[d.cat] ?? 6) * 100 - Math.min(99, Math.log10(fundN(d) + 1) * 10); };
    list.sort((a, b) => rank(a) - rank(b) || a.days - b.days);
    const card = (d) => {
      const c = K[d.cat]; const lg = this.logos()[d.id];
      return {
        id: d.id, logo: lg || '', hasLogo: !!lg, noLogo: !lg, co: d.co, title: d.title, pay: d.pay, who: d.who, fund: d.fund, hasFund: !!d.fund, catLabel: c.label,
        headline: (d.max || d.amt) > 0 ? 'Up to ' + this.money(d.max || d.amt) : (d.proof === 'Automatic' ? 'Automatic' : 'Cash share'),
        withProof: !!(d.max && d.max > d.amt), proofNote: d.cat === 'arb' ? 'Not guaranteed' : d.max && d.max > d.amt ? (d.amt > 0 ? this.money(d.amt) + ' without proof' : 'With documentation') : '',
        deadline: this.fmtDate(d.dl), daysLabel: !d.dl ? 'No deadline' : d.days + (d.days === 1 ? ' day left' : ' days left'),
        urgent: d.days <= 14, calm: d.days > 14, pop: !!d.pop, noProof: d.proof === 'No proof', proof: d.proof,
        modeLabel: d.cat === 'arb' ? 'Filed with a partner law firm' : d.mode === 'here' ? 'File on Claimclub' : d.mode === 'auto' ? 'Paid automatically' : 'Official site required',
        tileStyle: S.tile(c), dotStyle: 'width:10px;height:10px;border-radius:3px;flex:none;background:' + c.bg,
        initial: d.co.replace(/[^A-Za-z]/g, '').slice(0, 1),
        img: this.photo(d.id, 464, 264), imgSet: this.photo(d.id, 240, 136) + ' 240w, ' + this.photo(d.id, 464, 264) + ' 464w, ' + this.photo(d.id, 700, 400) + ' 700w', hasImg: !!this.photos()[d.id]
      };
    };
    const figured = list.filter(d => (d.max || d.amt) > 0);
    const shown = (s.showAll || this.rowMode) ? figured : figured.slice(0, 12);
    const soon = all.filter(d => (d.max || d.amt) > 0).slice().sort((a, b) => a.days - b.days).slice(0, 5).map(card);
    const phone = all.filter(d => d.pop && (d.max || d.amt) > 0).slice(0, 4).map(card);
    const byDays = (arr) => arr.slice().sort((a, b) => a.days - b.days);
    const shelves = [
      { title: 'Popular right now', items: all.filter(d => d.pop) },
      { title: 'No proof needed', items: byDays(all.filter(d => d.proof === 'No proof')) },
      { title: 'Data breaches', items: byDays(all.filter(d => d.cat === 'privacy' || d.cat === 'health')) },
      { title: 'Products, apps & fees', items: byDays(all.filter(d => ['products', 'apps', 'bank', 'auto'].includes(d.cat))) },
      { title: 'Investors & employees', items: byDays(all.filter(d => d.cat === 'invest')) },
      { title: 'Arbitration claims', items: all.filter(d => d.cat === 'arb') }
    ].map(sh => ({ title: sh.title, count: sh.items.length + ' open', items: sh.items.map(card) }));
    const header = (this.props.header ?? this.defaultHeader ?? 'slim');
    const vis = this.props.heroVisual ?? this.defaultVisual ?? 'tracker';
    const orbitSrc = all.filter(d => this.logos && this.logos()[d.id]).sort((a, b) => (b.pop ? 1 : 0) - (a.pop ? 1 : 0)).slice(0, 10);
    const orbit = orbitSrc.map((d, i) => { const ring = i < 6 ? 180 : 100, n = i < 6 ? 6 : orbitSrc.length - 6, k = i < 6 ? i : i - 6, ang = (k / n) * Math.PI * 2 + (i < 6 ? 0 : 0.5), sz = i < 6 ? 64 : 50;
      return { logo: this.logos()[d.id], co: d.co, style: 'position:absolute;left:' + Math.round(220 + ring * Math.cos(ang) - sz / 2) + 'px;top:' + Math.round(220 + ring * Math.sin(ang) - sz / 2) + 'px;width:' + sz + 'px;height:' + sz + 'px;border-radius:50%;object-fit:contain;background:#FFFFFF;padding:' + Math.round(sz * 0.18) + 'px;box-sizing:border-box;box-shadow:0 12px 30px rgba(0,0,0,.25)' }; });
    return {
      visStats: vis === 'stats', statsN: allOpenAll.length, localCount, allCount: allOpenAll.length, statsTotal: this.money(Math.round(all.reduce((t, d) => t + (d.max || d.amt || 0), 0))),
      statsTop: [['apple', 'iPhone 15 Pro or iPhone 16 buyers. $250M fund, no proof needed.'], ['googleplay', 'Anyone who bought apps or in-app items on Google Play, 2016 to 2023.'], ['visa', 'Anyone who paid an out-of-network ATM fee in the U.S.']].map(([id, note]) => { const d = all.find(x => x.id === id); if (!d) return null; const c = card(d); return { logo: c.logo, co: d.co, note, amt: (d.max || d.amt) > 0 ? 'Up to ' + this.money(d.max || d.amt) : 'Refund owed', days: c.daysLabel }; }).filter(Boolean),
      visStack: vis === 'stack', visTracker: vis === 'tracker', visOrbit: vis === 'orbit', visPhone: vis === 'phone', visCheck: vis === 'check', visNotifs: vis === 'notifs', visQuiz: vis === 'quiz', visGrid: vis === 'grid', visGauge: vis === 'gauge', orbit,
      slim: header === 'slim', full: header === 'full',
      filters: filters.map(f => ({ label: f.label, style: S.chip(s.filter === f.id), pick: () => this.setState({ filter: f.id, showAll: false }) })),
      logoStrip: (() => {
        // Broad settlements most people qualify for (everyday purchases, phones, renting, banking), in this order.
        const COMMON = ['googleplay', 'tyson', 'visa', 'apple', 'amazon', 'realpage', 'cvs', 'equifax', 'genericdrugs', 'fleatick', 'kroger', 'goodrx', 'tenet', 'mdlive', 'westernunion', 'warnermusic'];
        const L = this.logos ? this.logos() : {};
        let ls = COMMON.map(id => all.find(d => d.id === id)).filter(d => d && L[d.id]);
        if (ls.length < 8) ls = ls.concat(all.filter(d => d.cat !== 'arb' && L[d.id] && !ls.includes(d) && /^(People|U\.S\.|Customers|Renters) who (bought|paid|used|rent)/.test(d.who)).slice(0, 8 - ls.length));
        ls = ls.slice(0, 14).map(card); return ls.concat(ls); })(),
      mobileCards: (s.showAll ? figured : figured.slice(0, 8)).map(card), hasMoreMobile: figured.length > 8,
      cards: shown.map(card), soon, phone, shelves,
      resultCount: list.length + (list.length === 1 ? ' settlement' : ' settlements'),
      openCount: all.length, settleCount: all.filter(d => d.cat !== 'arb').length, arbCount: all.filter(d => d.cat === 'arb').length, noProofCount: all.filter(d => d.proof === 'No proof').length,
      moreLabel: s.showAll ? 'Show fewer' : 'Show all ' + figured.length + ' settlements',
      hasMore: figured.length > 12, empty: figured.length === 0,
      toggleAll: () => this.setState({ showAll: !s.showAll }),
      q: s.q, onSearch: (e) => this.setState({ q: e.target.value, showAll: false })
    };
  }
  // Photos for each settlement, served from the Unsplash CDN (free Unsplash license), sized and compressed per request.
  photo(id, w, h) { const p = this.photos()[id]; return p ? 'https://images.unsplash.com/photo-' + p + '?auto=format&fit=crop&w=' + w + '&h=' + h + '&q=60' : ''; }
  photos() { return {"apple":"1573148195900-7845dcb9b127","amazon":"1633174524827-db00a6b7bc74","goodrx":"1631549916768-4119b2e5f926","cvs":"1789108978116-2763682414a4","bofa":"1613243555988-441166d4d6fd","squatch":"1636846528145-46195929433c","thinkware":"1468510634867-6747418867dc","knotts":"1627035983655-0ceec61bb733","kia":"1695269912852-0615abff3b3c","vanilla":"1501167786227-4cba60f6d58f","venetian":"1640158615573-cd28feb1bf4e","neutrogena":"1519494026892-80bbd2d6fd0d","kroger":"1604719312566-8912e9227c6a","navy":"1563013544-824ae1b704d3","bright":"1634757439914-23b8acb9d411","columbia":"1648300373008-77fbee93e0ef","pp":"1606206591513-adbfbdd7a177","sirva":"1730154838368-c37b1fdebcf6","bauer":"1578844251758-2f71da64c96f","woodloch":"1771623181314-0b9df0fb57f9","benkeith":"1592838064575-70ed626d3a0e","safefleet":"1613688263142-67f1e0c25ef1","tennis":"1554068865-24cecd4e34b8","jbs":"1602470521006-aaea8b2fcc36","renal":"1563233269-7e86880558a7","prime":"1512678080530-7760d81faba6","nissan":"1574023240744-64c47c8c0676","connectamerica":"1758691030826-86a149b6278b","indegene":"1488509082528-cefbba5ad692","suffolk":"1681561110802-453bfc6db5a3","ni":"1611974789855-9c2a0a7236a3","skin":"1581182800629-7d90925ad072","marqeta":"1768242079046-c9c633187db1","starbucks":"1577215451400-f207c63e30be","stv":"1653038417332-6db0ff9d4bfb","visa":"1710149459994-480e2b5c3b16","googleplay":"1555774698-0b77e0d5fac6","equifax":"1740818576423-34be7fe85176","capone":"1633158829556-6ea20ad39b4f","twitter":"1683721003111-070bcc053d8b","hyundaikia":"1674110997072-41f11b7d4ae7","toyota":"1581862142388-23e1c52ca091","tyson":"1723893905879-0e309c2a8e06","westernunion":"1553729459-efe14ef6055d","seatgeek":"1601056645460-05fd9ad8f4e0","realpage":"1515263487990-61b07816b324","deere":"1614977645540-7abd88ba8e56","upsfair":"1689732888407-310424e3a372","davita":"1559757175-053139280de2","harvard":"1559135197-8a45ea74d367","netflix":"1574375927938-d5a98e8ffe85","google":"1529612700005-e35377bf1415","youtube":"1521302200778-33500795e128","openai":"1761223976372-f2324a8e2812","ups":"1751218682008-f68d3eff2d7c","walgreens":"1568092886042-00eaf9f4adc0","disney":"1522869635100-9f4c5e86aa37","transunion":"1654263937079-f63a3ea4d48b","bestbuy":"1777073233428-ff338440ccad","yahoo":"1596526131083-e8c633c948d2","dexcom":"1683727186226-910f31a9da45","ubereats":"1617347454431-f49d7ff5c3b1","smarttv":"1560169897-fc0cdbdfa4d5","myfitnesspal":"1596236100223-f3c656de3038","flo":"1653762379954-8943c787e78b","bn":"1774070231417-4bf4d2025878","ubisoft":"1612287230202-1ff1d85d1bdf","sandoz":"1628771065518-0d82f1938462","equinox":"1571902943202-507ec2618e8f","onemain":"1559067341-04a52c7d06d2","pork":"1611059263765-f57653f3bba3","fanatics":"1655089131279-8029e8a21ac6","lemonade":"1637763723578-79a4ca9225f7","cone":"1719934398679-d764c1410770","duke":"1764885415480-558e5631d371","ey":"1621831337128-35676ca30868","hirevue":"1497015289639-54688650d173","alo":"1593115057322-e94b77572f20","apollomd":"1764885449345-d0d6629bf7bf","xactus":"1560518883-ce09059eeffa","vesync":"1436473849883-bb3464c23e93","teleflora":"1531120364508-a6b656c3e78d","sizzling":"1773266110858-acb9b6c43b15","twist":"1637929476734-bd7f5f78e40a","mymichigan":"1634474588707-de99f09285c0","mha":"1758273241078-8eec353836be","mig":"1781229771042-2a859f8f8022","cartercu":"1705313382153-ed294af4b0a7","bestway":"1762811054950-b74e0a055c80","holley":"1725289339928-06ee31684df5","datadog":"1522071820081-009f0129c71c","speedway":"1761839257046-84e95464cc52","concord":"1486406146926-c627a92ad1ab","progressive_fl":"1762792049412-7bf096c0f016","hearthside":"1645226880663-81561dcab0ae","sela":"1579621970795-87facc2f976d","lavista":"1664455340023-214c33a9d0bd","lily":"1651341050677-24dba59ce0fd","mullinax":"1723065775998-af1c09fd6060","mi_surplus":"1601597111158-2fceff292cdc","lajolla":"1767167752097-fb36347efde1","vasindas":"1762955911431-4c44c7c3f408","emeraldcity":"1707761918029-1295034aa31e","wiz":"1590283603385-17ffb3a7f29f","ragingwaters":"1642717841683-c0323214617c","compounce":"1502136969935-8d8eef54d77b","fastbucks":"1460925895917-afdab827c52f","overland":"1607944024060-0450380ddd33","everbridge":"1611974789855-9c2a0a7236a3","wellnow":"1768242079046-c9c633187db1","fujifilm":"1766297247924-6638d54e7c89","cpap":"1712232420820-50733a53b961","nyc_strip":"1501167786227-4cba60f6d58f","finastra":"1548092372-0d1bd40894a3","seeeyewear":"1517948430535-1e2469d314fe","equifax_inq":"1542744173-05336fcc7ad4","pulsz":"1592890288564-76628a30a657","texasretina":"1483519173755-be893fab1f46","iod_pa":"1758691461990-03b49d969495","jacks":"1775750219087-2c4023d007a9","hirevelocity":"1686771416282-3888ddaf249b","pars":"1614064641938-3bbee52942c7","holt":"1517089596392-fb9a9033e05b","okanogan":"1551847677-dc82d764e1eb","steelwarehouse":"1697698532634-ea59b636ccea","geotek":"1541888946425-d81bb19240f5","mdlive":"1576091160550-2173dba999ef","edwards":"1773266110858-acb9b6c43b15","aspi":"1560221328-12fe60f83ab8","ihrs":"1550751827-4bd374c3f58b","nordstrom":"1645226880663-81561dcab0ae","inotiv":"1602052577122-f73b9710adba","seattleschools":"1542903660-eedba2cda473","ohiobmv":"1765211003784-a82564cb8d3d","lbcc":"1651341050677-24dba59ce0fd","fci":"1457342813143-a1ae27448a82","sequoia":"1486406146926-c627a92ad1ab","abington":"1789758490018-be1efacd7218","jacksoncounty":"1762792049412-7bf096c0f016","aramark":"1423784346385-c1d4dac9893a","its_bipa":"1707761918029-1295034aa31e","assaabloy":"1590283603385-17ffb3a7f29f","belcan":"1611974789855-9c2a0a7236a3","hut8":"1623227413711-25ee4388dae3","waynememorial":"1532938911079-1b06ac7ceec7","uscarcadia":"1769488718464-882e6c1adfd9","pillsbury":"1775144657626-29ff0a46ca90","koppers":"1483985988355-763728e1935b","frontier401k":"1633158829875-e5316a358c6f","brockton":"1764885518098-781b23d50e7f","adapthealth":"1516574187841-cb9cc2ca948b","baptistdrew":"1519494026892-80bbd2d6fd0d","kornit":"1503694978374-8a2fa686963a","mclean":"1759428679273-11d914866394","stanfordfcu":"1684679674829-fc7b436ec8e8","brighthouse":"1517960413843-0aee8e2b3285","groundlight":"1768242079046-c9c633187db1","bd":"1666446224369-2783384adf02","millcreek":"1579621970795-87facc2f976d","webtoon":"1612036782180-6f0b6cd846fe","ufcw7":"1768839721176-2fa91fdce725","quadrant":"1773266110858-acb9b6c43b15","camden":"1601597111158-2fceff292cdc","camc":"1512678080530-7760d81faba6","providence":"1645226880663-81561dcab0ae","statefarm_wa":"1603584173870-7f23fdae1b7a","pandora":"1651341050677-24dba59ce0fd","fordham":"1772418028359-823f2eb333d4","kimco":"1641122669951-3e2aff778d3b","simplilearn":"1501504905252-473c47e087f8","florencebank":"1601597111158-2fceff292cdc","brandt":"1580587771525-78b9dba3b914","servicespot":"1512428559087-560fa5ceab42","ardent":"1758575514475-2a84975db58e","fairmontfcu":"1616803140354-03891a719ae0","shadestore":"1707761918029-1295034aa31e","containerstore":"1481437156560-3205f6a55735","asure":"1590283603385-17ffb3a7f29f","telmate":"1758876204260-bdb299fa4374","etairos":"1624727828489-a1e03b79bba8","auxilio":"1758691461990-03b49d969495","ecsi":"1785052335692-ee4d5aff9903","benworth":"1444653614773-995cb1ef9efa","efi":"1612815154858-60aa4c59eaa6","trcstaffing":"1504384308090-c894fdcc538d","jbsmha":"1576091160550-2173dba999ef","antigo":"1587582423116-ec07293f0395","cbiz":"1556740714-a8395b3bf30f","coastdental":"1777331903190-341a3dd0441b","napco":"1496368077930-c1e31b4e5b44","missouridelta":"1532938911079-1b06ac7ceec7","grayback":"1677934245112-192a9bbea770","parkdental":"1769488718464-882e6c1adfd9","spal":"1775144657610-9a6f171e522f","chimienti":"1589829545856-d10d557cf95f","nyctlc":"1492144534655-ae79c964c9d7","sonataphev":"1726038021851-9dc24938b376","kellybenefits":"1676287567550-e875cf4af133","azlaborforce":"1523961131990-5ea7c61b2107","camobile":"1516574187841-cb9cc2ca948b","covenant":"1519494026892-80bbd2d6fd0d","roseland":"1512678080530-7760d81faba6","healthport_uw":"1758691461990-03b49d969495","whirlpool_fz":"1721613877687-c9099b698faa","tci_al":"1611974789855-9c2a0a7236a3","avondale":"1460925895917-afdab827c52f","high5":"1596838132731-3301c3fd4317","amca":"1615461066159-fea0960485d5","archer":"1777221673309-217738aba82c","riverside":"1517232115160-ff93364542dd","offerpad":"1570129477492-45c003edd2be","trane":"1768242079046-c9c633187db1","codx":"1780461159717-04ebb5eb3293","paysafe":"1758612215034-02c23a576afc","bofa_vac":"1773266110858-acb9b6c43b15","aurora":"1505751172876-fa1923c5c528","redcoats":"1531973576160-7125cd663d86","nyc_booking":"1607944024060-0450380ddd33","arcare":"1576091160550-2173dba999ef","hertz":"1765446647632-cf6ee5c9ad7a","planetlabs":"1446776811953-b23d57bd21aa","washgastro":"1532938911079-1b06ac7ceec7","costa":"1555529669-e69e7aa0ba9a","hampton":"1769488718464-882e6c1adfd9","nysid":"1781919293919-693ee10fb06c","lowe":"1485083269755-a7b559a4fe5e","blueridge":"1757466762489-52fea38071ad","swinerton":"1768926968986-a88590ce5025","fordtransit":"1515876305430-f06edab8282a","casefoods":"1759836675448-1acadfa25b6a","vidaysalud":"1758691462878-6edc3d3da1be","kisco":"1542622475-904e18612fa1","progressive_tx":"1503376780353-7e6692767b70","warriormet":"1759411354013-a4313f3ce7d3","marbrisa":"1787734081268-01a06df25f4a","warnermusic":"1669801158950-f663cf15298c","brookdale":"1516574187841-cb9cc2ca948b","localmed":"1606811971618-4486d14f3f99","doctorsimaging":"1519494026892-80bbd2d6fd0d","eyecare":"1516220362602-dba5272034e7","mavis":"1542362567-b07e54358753","pohns":"1512678080530-7760d81faba6","academymortgage":"1633158829585-23ba8f7c8caf","lakeside":"1758691461990-03b49d969495","allstate_az":"1501167786227-4cba60f6d58f","genesys":"1633265486064-086b219458ec","dothouse":"1576091160550-2173dba999ef","lionelectric":"1570125909232-eb263c188f7e","releasecard":"1764385827792-0d3682a416de","jci":"1542361345-89e58247f2d5","yuma":"1532938911079-1b06ac7ceec7","bigfork":"1769488718464-882e6c1adfd9","mhoa":"1516574187841-cb9cc2ca948b","progressive_co":"1568605117036-5fe5e7bab0b7","wyatt":"1640158615573-cd28feb1bf4e","nrx":"1645226880663-81561dcab0ae","lagunahonda":"1519494026892-80bbd2d6fd0d","bigelow":"1573855619003-97b4799dcd8b","ncaatennis":"1545809074-59472b3f5ecc","sportsedtv":"1761839256547-0a1cd11b6dfb","carpenters_wa":"1651341050677-24dba59ce0fd","adamstoyota":"1494976388531-d1058494cdd8","buyalerts":"1526045612212-70caf35c14df","merrill":"1563986768711-b3bde3dc821e","oregon_surplus":"1486406146926-c627a92ad1ab","fleatick":"1561037404-61cd46aa615b","lacounty_jail":"1762792049412-7bf096c0f016","genericdrugs":"1607874963930-2edecc67a25a","tenet":"1512678080530-7760d81faba6","revance":"1713085085470-fba013d67e65","meatwage":"1611038333075-2efd28705f42","beckcruise":"1554254648-2d58a1bc3fd5","natera":"1493894473891-10fc1e5dbd22","ciox_md":"1758691461990-03b49d969495","keurig":"1707241358597-bafcc8a8e73d","whirlpool_frost":"1606859191214-25806e8e2423","sanyo":"1509391366360-2e959784a276","fashionnova":"1766503206581-6824e98f49de","geico_clue":"1787571354001-b2c975845e09","cashapp_mla":"1569242840510-9fe6f0112cee","firstcash":"1633144427937-e108eeb92421","hk_theft":"1751152110851-ec8c5b94132f","zonolite":"1776604336398-decfacdc7c07","raleigh":"1579621970795-87facc2f976d","gardencity":"1460925895917-afdab827c52f","longcounty":"1607944024060-0450380ddd33","brookside":"1765211003784-a82564cb8d3d","otay":"1501167786227-4cba60f6d58f","aion":"1486406146926-c627a92ad1ab","hughesfcu":"1603584173870-7f23fdae1b7a","guadalupecu":"1762792049412-7bf096c0f016","huntermd":"1579621970795-87facc2f976d","kaiser_mh":"1576091160550-2173dba999ef","bailbond":"1601597111158-2fceff292cdc"}; }
