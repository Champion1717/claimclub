  constructor(props) {
    super(props);
    this.state = { filter: 'all', q: '', showAll: false, faq: -1 };
  }
  componentDidMount() { this.wireShelf(); this.countUp(); this.howAnim(); }
  countUp() {
    try {
      if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      const roots = [document];
      document.querySelectorAll('*').forEach((el) => { if (el.shadowRoot) roots.push(el.shadowRoot); });
      roots.forEach((root) => root.querySelectorAll('[data-countup]').forEach((el) => {
        if (el._cc) return; el._cc = true;
        const txt = el.textContent.trim(), target = Number(txt.replace(/[^0-9]/g, '')), pre = txt.startsWith('$') ? '$' : '';
        if (!target) return;
        const t0 = performance.now() + 250, dur = 1600;
        const fmt = (n) => pre + Math.round(n).toLocaleString('en-US');
        el.textContent = fmt(0);
        const tick = (now) => { const k = Math.min(1, Math.max(0, (now - t0) / dur)), e = 1 - Math.pow(1 - k, 3); el.textContent = fmt(target * e); if (k < 1) requestAnimationFrame(tick); else el.textContent = txt; };
        requestAnimationFrame(tick);
      }));
    } catch (e) {}
  }
  componentDidUpdate() { this.wireShelf(); this.howAnim(); }
  wireShelf() {
    try {
      const roots = [document];
      document.querySelectorAll('*').forEach((el) => { if (el.shadowRoot) roots.push(el.shadowRoot); });
      roots.forEach((root) => {
        const sh = root.querySelector('[data-shelf]'), tr = root.querySelector('[data-strack]'), th = root.querySelector('[data-sthumb]');
        const pv = root.querySelector('[data-sprev]'), nx = root.querySelector('[data-snext]');
        if (!sh || !tr || !th) return;
        const sync = () => {
          const max = sh.scrollWidth - sh.clientWidth, ratio = sh.scrollWidth ? sh.clientWidth / sh.scrollWidth : 1;
          const w = Math.max(0.12, Math.min(1, ratio)), pos = max > 0 ? sh.scrollLeft / max : 0;
          th.style.width = (w * 100) + '%'; th.style.left = (pos * (1 - w) * 100) + '%';
          tr.parentNode.style.visibility = max > 4 ? 'visible' : 'hidden';
          if (pv) pv.disabled = sh.scrollLeft <= 2; if (nx) nx.disabled = sh.scrollLeft >= max - 2;
        };
        if (sh._ccWired) { sync(); return; }
        sh._ccWired = true;
        sh.addEventListener('scroll', sync, { passive: true });
        window.addEventListener('resize', sync);
        const step = () => Math.max(240, sh.clientWidth * 0.8);
        if (pv) pv.addEventListener('click', () => sh.scrollBy({ left: -step(), behavior: 'smooth' }));
        if (nx) nx.addEventListener('click', () => sh.scrollBy({ left: step(), behavior: 'smooth' }));
        const toPos = (x) => {
          const r = tr.getBoundingClientRect(), tw = th.getBoundingClientRect().width;
          const f = Math.max(0, Math.min(1, (x - r.left - tw / 2) / Math.max(1, r.width - tw)));
          sh.scrollLeft = f * (sh.scrollWidth - sh.clientWidth);
        };
        let drag = null;
        th.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); drag = { x: e.clientX, s: sh.scrollLeft }; th.classList.add('drag'); sh.style.scrollBehavior = 'auto'; sh.style.scrollSnapType = 'none'; th.setPointerCapture(e.pointerId); });
        th.addEventListener('pointermove', (e) => { if (!drag) return; const r = tr.getBoundingClientRect(), tw = th.getBoundingClientRect().width; sh.scrollLeft = drag.s + (e.clientX - drag.x) * (sh.scrollWidth - sh.clientWidth) / Math.max(1, r.width - tw); });
        const end = () => { if (!drag) return; drag = null; th.classList.remove('drag'); sh.style.scrollBehavior = ''; sh.style.scrollSnapType = ''; };
        th.addEventListener('pointerup', end); th.addEventListener('pointercancel', end);
        tr.addEventListener('pointerdown', (e) => { if (e.target === th) return; sh.style.scrollBehavior = 'smooth'; toPos(e.clientX); });
        sync(); setTimeout(sync, 300);
      });
    } catch (e) {}
  }
  renderVals() {
    const s = this.state, K = this.cats(), S = this.skin();
    const allOpenAll = this.data().map(d => Object.assign({}, d, { days: this.daysLeft(d.dl) })).filter(d => d.days > 0);
    const all = allOpenAll.filter(d => !d.st);
    const localCount = allOpenAll.length - all.length;
    const filters = [
      { id: 'all', label: 'All' }, { id: 'noproof', label: 'No proof needed' }, { id: 'soon', label: 'Closing soon' },
      { id: 'privacy', label: 'Data & privacy' }, { id: 'products', label: 'Products' }, { id: 'apps', label: 'Apps & services' },
      { id: 'bank', label: 'Banking & fees' }, { id: 'health', label: 'Health' }, { id: 'auto', label: 'Auto' }, { id: 'invest', label: 'Investor & employee' }, { id: 'arb', label: 'Arbitration' }
    ];
    const q = s.q.trim().toLowerCase();
    let list = all.filter(d => {
      if (q && !(d.co + ' ' + d.title + ' ' + d.who).toLowerCase().includes(q)) return false;
      if (s.filter === 'noproof') return d.proof === 'No proof';
      if (s.filter === 'soon') return d.days <= 21;
      if (s.filter !== 'all') return d.cat === s.filter;
      return true;
    });
    // Best-known companies first (brand recognition), then broad consumer claims, then narrower ones.
    const TOP = ['apple', 'google', 'youtube', 'netflix', 'openai', 'amazon', 'disney', 'googleplay', 'ubereats', 'yahoo', 'cvs', 'walgreens', 'bestbuy', 'starbucks', 'ups', 'visa', 'toyota', 'hyundaikia', 'kia', 'bofa', 'equifax', 'equifax_inq', 'transunion', 'kroger', 'twitter', 'hertz', 'geico_clue', 'cashapp_mla', 'fordtransit', 'warnermusic', 'myfitnesspal', 'fanatics', 'bn', 'ubisoft', 'smarttv', 'fleatick', 'keurig', 'whirlpool_frost', 'whirlpool_fz', 'goodrx', 'tyson', 'realpage', 'genericdrugs', 'tenet', 'hk_theft', 'westernunion', 'mdlive', 'navy', 'seatgeek', 'deere', 'knotts', 'squatch', 'natera', 'bestway', 'thinkware', 'ragingwaters', 'compounce', 'high5', 'simplilearn', 'localmed', 'teleflora', 'pork', 'sandoz'];
    const W = { products: 0, apps: 1, bank: 1, auto: 2, arb: 3, health: 4, privacy: 4, invest: 5 };
    const fundN = (d) => { const m = /\$([\d.]+)\s*([MBK])?/.exec(d.fund || ''); return m ? parseFloat(m[1]) * ({ B: 1e9, M: 1e6, K: 1e3 }[m[2]] || 1) : 0; };
    const rank = (d) => { const i = TOP.indexOf(d.id); return i >= 0 ? i : 1000 + (W[d.cat] ?? 6) * 100 - Math.min(99, Math.log10(fundN(d) + 1) * 10); };
    list.sort((a, b) => rank(a) - rank(b) || a.days - b.days);
    const card = (d) => {
      const c = K[d.cat]; const lg = this.logos()[d.id] || this.catIcon(d.cat);
      return {
        id: d.id, logo: lg || '', hasLogo: !!lg, noLogo: !lg, co: d.co, title: d.title, pay: d.pay, who: d.who, fund: d.fund, hasFund: !!d.fund, catLabel: c.label,
        headline: (d.max || d.amt) > 0 ? 'Up to ' + this.money(d.max || d.amt) : (d.proof === 'Automatic' ? 'Automatic' : 'Cash share'),
        withProof: !!(d.max && d.max > d.amt), proofNote: d.cat === 'arb' ? 'Not guaranteed' : d.max && d.max > d.amt ? (d.amt > 0 ? this.money(d.amt) + ' without proof' : 'With documentation') : '',
        deadline: this.fmtDate(d.dl), daysLabel: !d.dl ? 'No deadline' : d.days + (d.days === 1 ? ' day left' : ' days left'),
        urgent: d.days <= 14, calm: d.days > 14, pop: !!d.pop, noProof: d.proof === 'No proof', proof: d.proof,
        modeLabel: d.cat === 'arb' ? 'Filed with a partner law firm' : d.mode === 'here' ? 'File on Claimclub' : d.mode === 'auto' ? 'Paid automatically' : 'Official site required',
        tileStyle: S.tile(c), dotStyle: 'width:10px;height:10px;border-radius:3px;flex:none;background:' + c.bg,
        initial: d.co.replace(/[^A-Za-z]/g, '').slice(0, 1),
        ...(() => { const m = this.logoMeta()[d.id]; const real = !!this.logos()[d.id]; const mode = !real ? 'i' : (m ? m.m : 't');
          return { topBg: 'background:' + (!real ? '#E9F6EF' : (m ? m.bg : '#F3F6F4')), logoSolid: mode === 's', logoTrans: mode === 't', logoIcon: mode === 'i' }; })()
      };
    };
    const figured = list.filter(d => (d.max || d.amt) > 0);
    const shown = (s.showAll || this.rowMode) ? figured : figured.slice(0, 12);
    const soon = all.filter(d => (d.max || d.amt) > 0).slice().sort((a, b) => a.days - b.days).slice(0, 5).map(card);
    const phone = all.filter(d => d.pop && (d.max || d.amt) > 0).slice(0, 4).map(card);
    const byDays = (arr) => arr.slice().sort((a, b) => a.days - b.days);
    const shelves = [
      { title: 'Popular right now', items: all.filter(d => d.pop) },
      { title: 'No proof needed', items: byDays(all.filter(d => d.proof === 'No proof')) },
      { title: 'Data breaches', items: byDays(all.filter(d => d.cat === 'privacy' || d.cat === 'health')) },
      { title: 'Products, apps & fees', items: byDays(all.filter(d => ['products', 'apps', 'bank', 'auto'].includes(d.cat))) },
      { title: 'Investors & employees', items: byDays(all.filter(d => d.cat === 'invest')) },
      { title: 'Arbitration claims', items: all.filter(d => d.cat === 'arb') }
    ].map(sh => ({ title: sh.title, count: sh.items.length + ' open', items: sh.items.map(card) }));
    const header = (this.props.header ?? this.defaultHeader ?? 'slim');
    const vis = this.props.heroVisual ?? this.defaultVisual ?? 'tracker';
    const orbitSrc = all.filter(d => this.logos && this.logos()[d.id]).sort((a, b) => (b.pop ? 1 : 0) - (a.pop ? 1 : 0)).slice(0, 10);
    const orbit = orbitSrc.map((d, i) => { const ring = i < 6 ? 180 : 100, n = i < 6 ? 6 : orbitSrc.length - 6, k = i < 6 ? i : i - 6, ang = (k / n) * Math.PI * 2 + (i < 6 ? 0 : 0.5), sz = i < 6 ? 64 : 50;
      return { logo: this.logos()[d.id], co: d.co, style: 'position:absolute;left:' + Math.round(220 + ring * Math.cos(ang) - sz / 2) + 'px;top:' + Math.round(220 + ring * Math.sin(ang) - sz / 2) + 'px;width:' + sz + 'px;height:' + sz + 'px;border-radius:50%;object-fit:contain;background:#FFFFFF;padding:' + Math.round(sz * 0.18) + 'px;box-sizing:border-box;box-shadow:0 12px 30px rgba(0,0,0,.25)' }; });
    return {
      visStats: vis === 'stats', statsN: allOpenAll.length, localCount, allCount: allOpenAll.length, statsTotal: (() => { const v = all.map(d => d.max || d.amt || 0).filter(x => x > 0); return this.money(Math.round(v.reduce((t, x) => t + x, 0) / Math.max(1, v.length))); })(), statsAvgN: all.filter(d => (d.max || d.amt) > 0).length,
      statsTop: [['apple', 'iPhone 15 Pro or iPhone 16 buyers. $250M fund, no proof needed.'], ['googleplay', 'Anyone who bought apps or in-app items on Google Play, 2016 to 2023.'], ['visa', 'Anyone who paid an out-of-network ATM fee in the U.S.']].map(([id, note]) => { const d = all.find(x => x.id === id); if (!d) return null; const c = card(d); return { logo: c.logo, co: d.co, note, amt: (d.max || d.amt) > 0 ? 'Up to ' + this.money(d.max || d.amt) : 'Refund owed', days: c.daysLabel }; }).filter(Boolean),
      visStack: vis === 'stack', visTracker: vis === 'tracker', visOrbit: vis === 'orbit', visPhone: vis === 'phone', visCheck: vis === 'check', visNotifs: vis === 'notifs', visQuiz: vis === 'quiz', visGrid: vis === 'grid', visGauge: vis === 'gauge', orbit,
      slim: header === 'slim', full: header === 'full',
      filters: filters.map(f => ({ label: f.label, style: S.chip(s.filter === f.id), pick: () => this.setState({ filter: f.id, showAll: false }) })),
      logoStrip: (() => {
        // Broad settlements most people qualify for (everyday purchases, phones, renting, banking), in this order.
        const COMMON = ['googleplay', 'tyson', 'visa', 'apple', 'amazon', 'realpage', 'cvs', 'equifax', 'genericdrugs', 'fleatick', 'kroger', 'goodrx', 'tenet', 'mdlive', 'westernunion', 'warnermusic'];
        const L = this.logos ? this.logos() : {};
        let ls = COMMON.map(id => all.find(d => d.id === id)).filter(d => d && L[d.id]);
        if (ls.length < 8) ls = ls.concat(all.filter(d => d.cat !== 'arb' && L[d.id] && !ls.includes(d) && /^(People|U\.S\.|Customers|Renters) who (bought|paid|used|rent)/.test(d.who)).slice(0, 8 - ls.length));
        ls = ls.slice(0, 14).map(card); return ls.concat(ls); })(),
      mobileCards: (s.showAll ? figured : figured.slice(0, 8)).map(card), hasMoreMobile: figured.length > 8,
      cards: shown.map(card), soon, phone, shelves,
      resultCount: list.length + (list.length === 1 ? ' settlement' : ' settlements'),
      openCount: all.length, settleCount: all.filter(d => d.cat !== 'arb').length, arbCount: all.filter(d => d.cat === 'arb').length, noProofCount: all.filter(d => d.proof === 'No proof').length,
      moreLabel: s.showAll ? 'Show fewer' : 'Show all ' + figured.length + ' settlements',
      hasMore: figured.length > 12, empty: figured.length === 0,
      toggleAll: () => this.setState({ showAll: !s.showAll }),
      q: s.q, onSearch: (e) => this.setState({ q: e.target.value, showAll: false })
    };
  }
  // Fallback when a settlement has no logo: a Lucide icon (ISC license) for its category.
  catIcon(cat) {
    const P = {
      privacy: '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="M12 8v4"/><path d="M12 16h.01"/>',
      health: '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/><path d="M3.22 12H9.5l.5-1 2 4.5 2-7 1.5 3.5h5.27"/>',
      products: '<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/>',
      apps: '<rect width="14" height="20" x="5" y="2" rx="2" ry="2"/><path d="M12 18h.01"/>',
      bank: '<line x1="3" x2="21" y1="22" y2="22"/><line x1="6" x2="6" y1="18" y2="11"/><line x1="10" x2="10" y1="18" y2="11"/><line x1="14" x2="14" y1="18" y2="11"/><line x1="18" x2="18" y1="18" y2="11"/><polygon points="12 2 20 7 4 7"/>',
      auto: '<path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/>',
      invest: '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
      arb: '<path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="M7 21h10"/><path d="M12 3v18"/><path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2"/>'
    };
    const svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-6 -6 36 36"><rect x="-6" y="-6" width="36" height="36" rx="9" fill="#E9F6EF"/><g fill="none" stroke="#12805C" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + (P[cat] || P.products) + '</g></svg>';
    return 'data:image/svg+xml,' + encodeURIComponent(svg);
  }
  // How it works phones: play each phone's animation once, when it scrolls into view.
  howAnim() {
    const phones = Array.from(document.querySelectorAll('.howv2 .howrow .iph')); this.howMob();
    if (!phones.length) return;
    this._howPlayed = this._howPlayed || new Set();
    const play = (el) => {
      const i = phones.indexOf(el); if (i < 0 || this._howPlayed.has(i)) return;
      this._howPlayed.add(i);
      el.querySelectorAll('.hin').forEach((n, k) => { n.style.animationDelay = (0.25 + k * 0.18) + 's'; });
      el.classList.add('play');
    };
    phones.forEach((el, i) => { if (this._howPlayed.has(i) && !el.classList.contains('play')) el.classList.add('done'); });
    if (!('IntersectionObserver' in window)) { phones.forEach(play); return; }
    if (this._howObs) this._howObs.disconnect();
    this._howObs = new IntersectionObserver((es) => es.forEach(e => { if (e.isIntersecting) play(e.target); }), { threshold: 0.45 });
    phones.forEach(el => { if (!el.classList.contains('play') && !el.classList.contains('done')) this._howObs.observe(el); });
  }
  // Card top colour per logo: 's' = logo has its own solid brand background (shown full height), 't' = transparent logo on a light tint of its main colour.
  logoMeta() { return {"archer":{"m":"t","bg":"#F3F6F4"},"aspi":{"m":"t","bg":"#FFFFFF"},"aurora":{"m":"t","bg":"#ECECF6"},"bd":{"m":"t","bg":"#FDE9DB"},"bestway":{"m":"t","bg":"#E9F6F6"},"brighthouse":{"m":"t","bg":"#E5F6E9"},"cashapp_mla":{"m":"s","bg":"#00CF31"},"cbiz":{"m":"t","bg":"#DBEFE5"},"compounce":{"m":"t","bg":"#DBF3F3"},"covenant":{"m":"s","bg":"#1C428B"},"datadog":{"m":"t","bg":"#FFFFFF"},"edwards":{"m":"t","bg":"#F3F6F4"},"efi":{"m":"t","bg":"#DBE5EF"},"etairos":{"m":"t","bg":"#DFE5EF"},"everbridge":{"m":"s","bg":"#3760F3"},"eyecare":{"m":"t","bg":"#DBF6F6"},"fci":{"m":"t","bg":"#E9E9F3"},"finastra":{"m":"t","bg":"#EFE2F3"},"fleatick":{"m":"t","bg":"#DBDFE5"},"fordham":{"m":"t","bg":"#ECDBDF"},"fordtransit":{"m":"t","bg":"#DBDBE5"},"frontier401k":{"m":"t","bg":"#FDDBE2"},"geico_clue":{"m":"t","bg":"#DBE2EF"},"geotek":{"m":"t","bg":"#DBE5E2"},"grayback":{"m":"t","bg":"#F3F6F4"},"hertz":{"m":"t","bg":"#FDF6DB"},"high5":{"m":"t","bg":"#FAF3E2"},"hut8":{"m":"t","bg":"#FFFFFF"},"inotiv":{"m":"t","bg":"#FFFFFF"},"jacks":{"m":"t","bg":"#FADFDF"},"jci":{"m":"t","bg":"#F3F6F4"},"kellybenefits":{"m":"t","bg":"#DBE5E2"},"keurig":{"m":"t","bg":"#F6DBE5"},"kisco":{"m":"t","bg":"#DBE9EF"},"kornit":{"m":"t","bg":"#E2ECFD"},"lionelectric":{"m":"t","bg":"#F3F6F4"},"localmed":{"m":"t","bg":"#DBDFE5"},"lowe":{"m":"t","bg":"#FAE9E2"},"mdlive":{"m":"s","bg":"#F1881E"},"merrill":{"m":"t","bg":"#DBDFE9"},"navy":{"m":"s","bg":"#044380"},"ncaatennis":{"m":"t","bg":"#DBEFFA"},"nrx":{"m":"t","bg":"#DFE2E9"},"paysafe":{"m":"t","bg":"#F3F6F4"},"planetlabs":{"m":"t","bg":"#DBEFF3"},"ragingwaters":{"m":"t","bg":"#DFF3FA"},"sanyo":{"m":"t","bg":"#F6DBE2"},"seeeyewear":{"m":"s","bg":"#000000"},"simplilearn":{"m":"t","bg":"#DBE2F6"},"sportsedtv":{"m":"t","bg":"#FDECE2"},"stanfordfcu":{"m":"t","bg":"#FFFFFF"},"steelwarehouse":{"m":"t","bg":"#FADFDF"},"swinerton":{"m":"t","bg":"#DBE2E9"},"teleflora":{"m":"s","bg":"#E60895"},"telmate":{"m":"t","bg":"#DFF6E5"},"texasretina":{"m":"t","bg":"#DBE2EF"},"trcstaffing":{"m":"t","bg":"#F3F3E2"},"twist":{"m":"t","bg":"#E2EFEC"},"warnermusic":{"m":"t","bg":"#DBE2EF"},"warriormet":{"m":"t","bg":"#FFFFFF"},"waynememorial":{"m":"t","bg":"#FFFFFF"},"webtoon":{"m":"t","bg":"#DBF6E9"},"whirlpool_fz":{"m":"t","bg":"#FAF3DB"},"woodloch":{"m":"t","bg":"#F3F6F4"},"equifax_inq":{"m":"t","bg":"#FFFFFF"},"sonataphev":{"m":"t","bg":"#FFFFFF"},"hk_theft":{"m":"t","bg":"#FFFFFF"},"whirlpool_frost":{"m":"t","bg":"#FAF3DB"},"amazon":{"m":"t","bg":"#FFF1DB"},"apple":{"m":"t","bg":"#F3F6F4"},"bofa":{"m":"t","bg":"#DBE0EA"},"kia":{"m":"t","bg":"#F3F6F4"},"nissan":{"m":"t","bg":"#F7DBE2"},"starbucks":{"m":"t","bg":"#DBE9E4"},"bauer":{"m":"t","bg":"#FFFFFF"},"benkeith":{"m":"t","bg":"#FFFFFF"},"bright":{"m":"t","bg":"#FFFFFF"},"columbia":{"m":"t","bg":"#FFFFFF"},"connectamerica":{"m":"t","bg":"#FFFFFF"},"cvs":{"m":"t","bg":"#FFFFFF"},"goodrx":{"m":"t","bg":"#FFFFFF"},"indegene":{"m":"t","bg":"#FFFFFF"},"jbs":{"m":"t","bg":"#FFFFFF"},"knotts":{"m":"t","bg":"#FFFFFF"},"kroger":{"m":"s","bg":"#113E81"},"marqeta":{"m":"s","bg":"#240A33"},"neutrogena":{"m":"s","bg":"#030104"},"ni":{"m":"t","bg":"#FFFFFF"},"pp":{"m":"s","bg":"#0B225F"},"prime":{"m":"t","bg":"#FFFFFF"},"renal":{"m":"t","bg":"#FFFFFF"},"safefleet":{"m":"t","bg":"#FFFFFF"},"skin":{"m":"t","bg":"#E2E5EC"},"squatch":{"m":"t","bg":"#FFFFFF"},"stv":{"m":"t","bg":"#FFFFFF"},"tennis":{"m":"t","bg":"#FFFFFF"},"thinkware":{"m":"t","bg":"#FADFDF"},"vanilla":{"m":"t","bg":"#FFFFFF"},"venetian":{"m":"t","bg":"#FFFFFF"},"alo":{"m":"s","bg":"#020203"},"apollomd":{"m":"t","bg":"#FFFFFF"},"bestbuy":{"m":"t","bg":"#FFFFFF"},"bn":{"m":"s","bg":"#525154"},"capone":{"m":"t","bg":"#FFFFFF"},"cone":{"m":"t","bg":"#FFFFFF"},"davita":{"m":"t","bg":"#DBE5EF"},"deere":{"m":"t","bg":"#E3EDE1"},"dexcom":{"m":"t","bg":"#FFFFFF"},"disney":{"m":"t","bg":"#DFE5E9"},"duke":{"m":"s","bg":"#0E4E8A"},"equifax":{"m":"t","bg":"#FFFFFF"},"equinox":{"m":"t","bg":"#FFFFFF"},"ey":{"m":"t","bg":"#FDFADB"},"fanatics":{"m":"s","bg":"#000000"},"flo":{"m":"s","bg":"#E75E80"},"google":{"m":"t","bg":"#FFFFFF"},"googleplay":{"m":"t","bg":"#F3F6F4"},"harvard":{"m":"t","bg":"#FFFFFF"},"hirevue":{"m":"t","bg":"#FFFFFF"},"hyundaikia":{"m":"t","bg":"#FFFFFF"},"lemonade":{"m":"t","bg":"#FFFFFF"},"myfitnesspal":{"m":"t","bg":"#DBE9FA"},"netflix":{"m":"t","bg":"#FBDDDE"},"onemain":{"m":"t","bg":"#DFE5FA"},"openai":{"m":"t","bg":"#FFFFFF"},"pork":{"m":"t","bg":"#FFFFFF"},"realpage":{"m":"t","bg":"#DFE5EC"},"sandoz":{"m":"t","bg":"#FFFFFF"},"seatgeek":{"m":"t","bg":"#FDE9E5"},"toyota":{"m":"t","bg":"#FCDDE0"},"transunion":{"m":"t","bg":"#FFFFFF"},"twitter":{"m":"s","bg":"#000001"},"tyson":{"m":"t","bg":"#FFFFFF"},"ubereats":{"m":"t","bg":"#FFFFFF"},"ubisoft":{"m":"t","bg":"#F3F6F4"},"ups":{"m":"t","bg":"#F3F6F4"},"vesync":{"m":"t","bg":"#FFFFFF"},"visa":{"m":"t","bg":"#DFE0EB"},"walgreens":{"m":"t","bg":"#FFFFFF"},"westernunion":{"m":"s","bg":"#010002"},"xactus":{"m":"t","bg":"#FFFFFF"},"yahoo":{"m":"t","bg":"#FFFFFF"},"youtube":{"m":"t","bg":"#FFFFFF"},"upsfair":{"m":"t","bg":"#F3F6F4"}}; }
  // Mobile How it works: the section stays pinned (sticky) while you scroll through it; scroll position picks the step (3 steps), each step's tap animation loops by itself.
  howMob() {
    const w = document.querySelector('.howStory'); if (!w || w._hm) return; w._hm = true;
    const bars = Array.from(w.querySelectorAll('.hsb')); let raf = 0, vis = false, cur = -1;
    const tick = () => {
      raf = 0; if (!vis) return;
      const r = w.getBoundingClientRect(), vh = window.innerHeight || document.documentElement.clientHeight;
      const total = Math.max(1, r.height - vh), p = Math.min(1, Math.max(0, -r.top / total));
      const step = Math.min(2, Math.floor(p * 3)), within = Math.min(1, p * 3 - step);
      if (step !== cur) { cur = step; w.setAttribute('data-s', step); }
      bars.forEach((b, n) => { b.style.width = (n < step ? 100 : n > step ? 0 : within * 100) + '%'; });
      raf = requestAnimationFrame(tick);
    };
    if (!('IntersectionObserver' in window)) { vis = true; tick(); return; }
    new IntersectionObserver((es) => { vis = es[0].isIntersecting; if (vis && !raf) raf = requestAnimationFrame(tick); }).observe(w);
  }

