src=open('green.py').read();ns={}
exec(src.split("for name,v in")[0],ns)
p='../project/LandingG2.dc.html';s=open(p).read();s=s.replace('  renderVals() {',"  get defaultVisual() { return 'stats'; }\n  renderVals() {",1);s=ns['recolor'](s,ns['V']['G2']).replace('#D6409F','#12805C')
s=s.replace('"$preview":{"width":1440,"height":5600}','"$preview":{"width":1440,"height":900}')
m=s.replace('<title>Claimclub · Green 2 homepage</title>','<title>Claimclub · Homepage (mobile)</title>').replace('"$preview":{"width":1440,"height":900}','"$preview":{"width":390,"height":844}')
open('../project/LandingG2M.dc.html','w').write(m)
open(p,'w').write(s.replace('FlowG2.dc.html','FlowG2D.dc.html').replace('<title>Claimclub · Green 2 homepage</title>','<title>Claimclub · Homepage</title>'))
