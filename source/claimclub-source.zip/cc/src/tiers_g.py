"""Offer G plan page (T3 final, Nov 21 2026): writes a <sc-if isTiers> block into FlowC2 (phones) and FlowC2D (desktop).
Run before green.py. Skips files that already have the marker."""
import re, os
H = os.path.dirname(os.path.abspath(__file__))
LU = os.path.join(H, '..', 'concepts', 'lucide')
def inner(n):
    s = open(os.path.join(LU, n + '.svg')).read()
    return re.search(r'>\s*(<(?:path|rect|circle|line|polyline)[\s\S]*?)</svg>', s).group(1).strip()
def svg(n, sz, col='{{ t.icC }}', sw=2.2):
    return f'<svg width="{sz}" height="{sz}" viewBox="0 0 24 24" fill="none" stroke="{col}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">{inner(n)}</svg>'
CHECK = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="{{ f.c }}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex: none"><path d="M20 6 9 17l-5-5"></path></svg>'
TICK = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>'
MARK = '<!-- offer G tiers page -->'
def icons(sz):
    return (f'<sc-if value="{{{{ t.isStd }}}}" hint-placeholder-val="{{{{ false }}}}">{svg("calendar-days", sz)}</sc-if>'
            f'<sc-if value="{{{{ t.isFast }}}}" hint-placeholder-val="{{{{ true }}}}">{svg("gauge", sz)}</sc-if>'
            f'<sc-if value="{{{{ t.isPri }}}}" hint-placeholder-val="{{{{ false }}}}">{svg("rocket", sz)}</sc-if>')
def card(desk):
    return ('<sc-for list="{{ tiers }}" as="t" hint-placeholder-count="3">'
      '<div role="radio" tabindex="0" aria-checked="{{ t.on }}" onClick="{{ t.pick }}" style="{{ t.card }}">'
      f'<div style="{{{{ t.blk }}}}">{icons(20)}<b style="font-size: 22px; line-height: 1; letter-spacing: -.6px; margin-top: 3px">{{{{ t.num }}}}</b><span style="font-size: 9.5px; font-weight: 800; letter-spacing: .8px">{{{{ t.unit }}}}</span></div>'
      '<div style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 7px">'
      '<div style="display: flex; align-items: center; gap: 8px"><b style="font-size: 17px; letter-spacing: -.3px">{{ t.name }}</b>'
      '<sc-if value="{{ t.hasTag }}" hint-placeholder-val="{{ false }}"><span style="{{ t.tagSt }}">{{ t.tag }}</span></sc-if>'
      '<span style="flex: 1"></span><span style="display: flex; align-items: baseline; gap: 1px; white-space: nowrap"><b style="font-size: 19px; letter-spacing: -.6px">{{ t.price }}</b><span style="{{ t.perSt }}">{{ t.per }}</span></span>'
      f'<span style="{{{{ t.radio }}}}"><sc-if value="{{{{ t.on }}}}" hint-placeholder-val="{{{{ false }}}}">{TICK}</sc-if></span></div>'
      f'<sc-for list="{{{{ t.fl }}}}" as="f" hint-placeholder-count="3"><div style="{{{{ f.st }}}}">{CHECK}<span>{{{{ f.t }}}}</span></div></sc-for>'
      '</div></div></sc-for>')
def agree(src):
    i = src.index('<div role="checkbox" tabindex="0" aria-checked="{{ agreeAll }}"')
    j = src.index('</sc-if>', src.index('{{ agreeErrT }}')) + len('</sc-if>')
    return src[i:j]
LEGAL = '<div style="display: flex; justify-content: center; gap: 22px; font-size: 12px; font-weight: 600; color: #43504A"><a href="https://claimclub.io/terms" target="_blank" rel="noopener" style="color: inherit">{{ L.termsW }}</a><a href="https://claimclub.io/privacy" target="_blank" rel="noopener" style="color: inherit">{{ L.privacyW }}</a></div>'
def btn(h): return f'<button onClick="{{{{ tgGo }}}}" style="height: {h}px; width: 100%; flex: none; border-radius: 999px; background: #3DDC97; color: #0F3B2E; font-size: 17px; font-weight: 800; display: flex; align-items: center; justify-content: center; box-shadow: 0 10px 24px rgba(61,220,151,.35)"><span>{{{{ tgCta }}}}</span></button>'
FINE = '<span style="font-size: 12px; line-height: 1.45; color: #5B6862; font-weight: 600; text-align: center">{{ tgFine }}</span>'
def mobile(src): return f'''  {MARK}
  <sc-if value="{{{{ isTiers }}}}" hint-placeholder-val="{{{{ false }}}}">
    <div class="enter scroll" style="flex-grow: 1; min-height: 0; overflow-y: auto; padding: 8px 16px 16px; display: flex; flex-direction: column; gap: 10px; background: #F3F6F4; text-align: left">
      <h1 style="margin: 0; font-size: 26px; line-height: 1.12; font-weight: 800; letter-spacing: -0.8px">{{{{ tgH }}}}</h1><span style="font-size: 14px; line-height: 1.45; font-weight: 600; color: #5B6862; margin-top: -4px">{{{{ tgSub }}}}</span>
      {card(False)}
    </div>
    <div style="flex: none; padding: 10px 18px 16px; border-top: 1px solid #E8EEEA; background: #FFFFFF; display: flex; flex-direction: column; gap: 6px; text-align: center">
      {agree(src)}
      {btn(54)}
      {FINE}
      {LEGAL}
    </div>
  </sc-if>

'''
def desk(src): return f'''  {MARK}
  <sc-if value="{{{{ isTiers }}}}" hint-placeholder-val="{{{{ false }}}}">
    <div class="enter" style="display: flex; flex-direction: column; gap: 12px; padding: 4px 0; max-width: 560px; width: 100%; margin: 0 auto">
      <div style="display: flex; flex-direction: column; gap: 10px"><h1 style="margin: 0; font-size: 30px; line-height: 1.12; font-weight: 800; letter-spacing: -1px; text-align: center">{{{{ tgH }}}}</h1><span style="font-size: 16px; line-height: 1.45; font-weight: 600; color: #5B6862; text-align: center">{{{{ tgSub }}}}</span></div>
      {card(True)}
      {agree(src)}
      {btn(56)}
      {FINE}
      {LEGAL}
    </div>
  </sc-if>

'''
for fn, mk in (('FlowC2.tpl.html', mobile), ('FlowC2D.tpl.html', desk)):
    p = os.path.join(H, fn); s = open(p).read()
    if MARK in s: print('skip', fn); continue
    a = '  <!-- MEMBERSHIP PLANS -->'
    assert a in s
    s = s.replace(a, mk(s) + a, 1); open(p, 'w').write(s); print('wrote', fn)
