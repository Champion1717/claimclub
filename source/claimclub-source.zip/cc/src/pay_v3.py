# Payment sheet direction (Nov 15 2026, chosen as PayF1/PayF2 on the canvas): writes the fee page and the plan page
# into FlowC2 (mobile) and FlowC2D (desktop), plus the receipt in the desktop side panel. The payment itself
# (Apple Pay, Google Pay, card) opens in a sheet drawn by site/live.js. Run before green.py.
G, MINT, INK, MUTE, LINE = '#12805C', '#3DDC97', '#0A0F0D', '#5B6862', '#DDE5E0'
CHECK = '<svg width="{s}" height="{s}" viewBox="0 0 24 24" fill="none" stroke="{c}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex: none"><path d="M20 6 9 17l-5-5"></path></svg>'
DASH = '<div style="border-top: 2px dashed #DDE5E0; margin: 12px 0"></div>'
def zig():
    return '<div aria-hidden="true" style="height: 12px; flex: none; background: linear-gradient(135deg, #FFFFFF 33.3%, transparent 33.3%) 0 0 / 16px 16px, linear-gradient(225deg, #FFFFFF 33.3%, transparent 33.3%) 0 0 / 16px 16px"></div>'
def receipt_m():
    rows = (f'<sc-for list="{{{{ rcItems }}}}" as="r" hint-placeholder-count="4"><div style="display: flex; justify-content: space-between; gap: 12px; padding: 8px 0; font-size: 15px"><span style="font-weight: 700; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">{{{{ r.t }}}}</span><span style="flex: none; font-weight: 800; color: {G}">{{{{ r.v }}}}</span></div></sc-for>'
            f'<sc-if value="{{{{ hasRcMore }}}}" hint-placeholder-val="{{{{ false }}}}"><div style="padding: 6px 0 0; font-size: 13px; font-weight: 700; color: {MUTE}">{{{{ rcMore }}}}</div></sc-if>')
    return (f'<div style="flex: none; display: flex; flex-direction: column; filter: drop-shadow(0 12px 22px rgba(10,15,13,.08)); text-align: left">'
            f'<div style="background: #FFFFFF; border-radius: 20px 20px 0 0; padding: 20px 20px 16px; display: flex; flex-direction: column; color: {INK}">'
            f'<span style="font-size: 12px; font-weight: 800; letter-spacing: 1.2px; color: #8A968F">{{{{ rcHead }}}}</span>'
            f'<span style="font-size: 14px; font-weight: 700; color: {MUTE}; margin-top: 10px">{{{{ rcEarn }}}}</span>'
            f'<b style="font-size: 38px; letter-spacing: -1.4px; line-height: 1.1; color: {G}">{{{{ rcTotal }}}}</b>'
            + DASH + rows + DASH +
            f'<div style="display: flex; justify-content: space-between; align-items: center; gap: 12px"><span style="display: flex; flex-direction: column; gap: 3px"><b style="font-size: 15px">{{{{ rcFeeLabel }}}}</b><span style="font-size: 13px; color: {MUTE}; font-weight: 600">{{{{ rcFeeSub }}}}</span></span><b style="font-size: 26px; letter-spacing: -0.8px">{{{{ rcFee }}}}</b></div>'
            f'<div style="display: flex; align-items: center; gap: 10px; margin-top: 14px; padding: 12px 14px; border-radius: 14px; background: #E9F6EF; color: #17603F">{CHECK.format(s=18, c=G)}<span style="display: flex; flex-direction: column; gap: 2px"><b style="font-size: 14px">{{{{ keepH }}}}</b><span style="font-size: 12.5px; font-weight: 600">{{{{ keepP }}}}</span></span></div>'
            f'</div>{zig()}</div>')
def receipt_d():
    rows = (f'<sc-for list="{{{{ rcItems }}}}" as="r" hint-placeholder-count="4"><div style="display: flex; justify-content: space-between; gap: 10px; padding: 5px 0; font-size: 14px"><span style="display: flex; align-items: center; gap: 8px; font-weight: 700; min-width: 0">{CHECK.format(s=15, c=G)}<span style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap">{{{{ r.t }}}}</span></span><span style="flex: none; font-weight: 800; color: {G}">{{{{ r.v }}}}</span></div></sc-for>'
            f'<sc-if value="{{{{ hasRcMore }}}}" hint-placeholder-val="{{{{ false }}}}"><div style="padding: 4px 0 0 23px; font-size: 12.5px; font-weight: 700; color: {MUTE}">{{{{ rcMore }}}}</div></sc-if>')
    return (f'<sc-if value="{{{{ asideReceipt }}}}" hint-placeholder-val="{{{{ false }}}}"><div class="scroll" style="flex-grow: 1; min-height: 0; overflow-y: auto; margin: 0 -8px; padding: 0 8px 8px"><div style="display: flex; flex-direction: column; filter: drop-shadow(0 18px 30px rgba(0,0,0,.35))">'
            f'<div style="background: #FFFFFF; border-radius: 18px 18px 0 0; padding: 20px 20px 12px; display: flex; flex-direction: column; color: {INK}">'
            f'<span style="font-size: 11.5px; font-weight: 800; letter-spacing: 1.2px; color: #8A968F">{{{{ rcHeadD }}}}</span>'
            f'<span style="font-size: 13px; font-weight: 700; color: {MUTE}; margin-top: 8px">{{{{ rcEarn }}}}</span><b style="font-size: 38px; letter-spacing: -1.4px; line-height: 1.08; color: {G}">{{{{ rcTotal }}}}</b><span style="font-size: 12.5px; color: {MUTE}; font-weight: 600">{{{{ rcFrom }}}}</span>'
            + DASH.replace('12px 0', '10px 0') + rows + DASH.replace('12px 0', '10px 0') +
            f'<div style="display: flex; justify-content: space-between; align-items: center; gap: 10px"><span style="display: flex; flex-direction: column; gap: 2px"><b style="font-size: 15px">{{{{ rcFeeLabel }}}}</b><span style="font-size: 12px; color: {MUTE}; font-weight: 600">{{{{ rcFeeSub }}}}</span></span><b style="font-size: 28px; letter-spacing: -1px">{{{{ rcFee }}}}</b></div>'
            f'<div style="display: flex; justify-content: space-between; font-size: 13.5px; font-weight: 800; margin-top: 8px"><span>{{{{ rcShare }}}}</span><span style="color: {G}">100%</span></div>'
            f'<div style="margin-top: 12px; padding: 10px 12px; border-radius: 12px; background: #F3F6F4; font-size: 12px; color: #43504A; line-height: 1.45; font-weight: 600">{{{{ keepP2 }}}}</div>'
            f'</div>{zig()}</div></div></sc-if>\n      ')
LEGAL = '<div style="display: flex; justify-content: center; gap: 22px; font-size: 12px; font-weight: 600; color: #43504A"><a href="https://claimclub.io/terms" target="_blank" rel="noopener" style="color: inherit">{{ L.termsW }}</a><a href="https://claimclub.io/privacy" target="_blank" rel="noopener" style="color: inherit">{{ L.privacyW }}</a></div>'
def upsell():
    return (f'<button onClick="{{{{ toPlans }}}}" style="flex: none; display: flex; align-items: center; gap: 12px; width: 100%; padding: 12px 14px; border-radius: 16px; background: #E9F6EF; color: {INK}; text-align: left">'
            f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><b style="font-size: 14px">{{{{ joinUp }}}}</b><span style="font-size: 12.5px; color: {MUTE}; font-weight: 600; line-height: 1.4">{{{{ joinSub }}}}</span></span>'
            f'<span style="flex: none; font-size: 13.5px; font-weight: 800; color: {G}; display: flex; align-items: center; gap: 4px">{{{{ switchW }}}}<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="{G}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg></span></button>')
LOCK = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0F3B2E" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex: none"><path d="M5 11h14a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2z M7 11V7a5 5 0 0 1 10 0v4"></path></svg>'
def cta(onclick, label, h):
    return f'<button onClick="{{{{ {onclick} }}}}" style="height: {h}px; width: 100%; flex: none; border-radius: 999px; background: {MINT}; color: #0F3B2E; font-size: 17px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 10px 24px rgba(61,220,151,.35)">{LOCK}{{{{ {label} }}}}</button>'
def fee_block(m):
    if m:
        body = (f'    <div class="enter scroll plcol" style="flex-grow: 1; min-height: 0; overflow-y: auto; padding: 10px 18px 14px; display: flex; flex-direction: column; gap: 14px; background: #F3F6F4">\n'
                f'      {receipt_m()}\n      {upsell()}\n    </div>\n')
        foot = (f'    <div style="flex: none; padding: 10px 18px 16px; border-top: 1px solid #E8EEEA; background: #FFFFFF; display: flex; flex-direction: column; gap: 6px; text-align: center">\n'
                f'      {cta("unlock", "feeCta", 54)}\n      <span style="font-size: 11.5px; line-height: 1.45; color: {MUTE}">{{{{ feeOnce }}}}</span>\n      {LEGAL}\n    </div>\n')
        return '  <!-- FILING FEE -->\n  <sc-if value="{{ isPay }}" hint-placeholder-val="{{ false }}">\n' + body + foot + '  </sc-if>\n\n  '
    body = (f'    <div class="enter scroll plcol" style="flex-grow: 1; min-height: 0; overflow-y: auto; padding: 24px 0 16px; display: flex; flex-direction: column; gap: 16px; justify-content: safe center; text-align: left">\n'
            f'      <h1 style="margin: 0; font-size: 30px; line-height: 1.12; font-weight: 800; letter-spacing: -0.9px">{{{{ feeH2 }}}}</h1>\n'
            f'      <div style="margin-top: -6px; font-size: 15px; line-height: 1.5; font-weight: 600; color: {MUTE}">{{{{ feeSub2 }}}}</div>\n'
            f'      {cta("unlock", "feeCta", 56)}\n      <span style="margin-top: -6px; font-size: 12px; text-align: center; color: {MUTE}">{{{{ feeOnce }}}}</span>\n      {upsell()}\n      {LEGAL}\n    </div>\n')
    return '  <!-- FILING FEE -->\n  <sc-if value="{{ isPay }}" hint-placeholder-val="{{ false }}">\n' + body + '  </sc-if>\n\n  '
def plans_block(m, old):
    if not m:
        # Desktop keeps Plan page V2, minus the matches card (the receipt in the side panel covers it).
        a = old.index('<div style="display: flex; align-items: center; justify-content: center; gap: 18px; padding: 14px 18px; border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #DDE5E0">')
        b = old.index('<h1', a)
        old = old[:a] + old[b:]
        return old.replace('{{ plCta }}</button>', '{{ plCta }}</button>', 1)
    seg = old[old.index('<div role="radiogroup"'):]; seg = seg[:seg.index('</sc-for></div>') + len('</sc-for></div>')]
    foot = old[old.index('    <div style="flex: none; padding: 10px 18px 16px; border-top'):old.rindex('  </sc-if>')]
    body = (f'    <div class="enter scroll plcol" style="flex-grow: 1; min-height: 0; overflow-y: auto; padding: 10px 18px 14px; display: flex; flex-direction: column; gap: 12px; background: #F3F6F4; text-align: left">\n'
            f'      {receipt_m()}\n      <h1 style="margin: 6px 0 0; font-size: 22px; line-height: 1.1; font-weight: 800; letter-spacing: -0.6px">{{{{ pickPlanH }}}}</h1>\n      {seg}\n    </div>\n')
    return '  <!-- MEMBERSHIP PLANS -->\n  <sc-if value="{{ isPlans }}" hint-placeholder-val="{{ false }}">\n' + body + foot + '  </sc-if>\n\n  '
for f, m in [('FlowC2.tpl.html', True), ('FlowC2D.tpl.html', False)]:
    s = open(f).read()
    if 'pay_v3' in s: print(f, 'already done'); continue
    # The fee page was put back to its original design on Henry's request (Nov 15); fee_block() is kept but not used.
    a = s.rfind('\n', 0, s.index('<!-- MEMBERSHIP PLANS -->')) + 1; b = s.index('<!-- CHECKOUT -->')
    s = s[:a] + plans_block(m, s[a:b]) + s[b:]
    if not m:
        k = '<div style="font-size: 12px; line-height: 1.6; color: #CFC6EE">{{ L.asideNote }}</div>'
        assert k in s
        s = s.replace('      ' + k, '      ' + receipt_d() + k, 1)
        # the estimate header in the side panel repeats the receipt on the pay steps
        h0 = '<div style="display: flex; flex-direction: column; gap: 4px"><div style="font-size: 12px; font-weight: 700; letter-spacing: 1.4px; color: #CFC6EE">{{ L.estSoFar }}</div>'
        i = s.index(h0); j = s.index('{{ countMatched }}</div></div>', i) + len('{{ countMatched }}</div></div>')
        s = s[:i] + '<sc-if value="{{ notReceipt }}" hint-placeholder-val="{{ true }}">' + s[i:j] + '</sc-if>' + s[j:]
    s = s.replace('</head>', '<!-- pay_v3 -->\n</head>', 1) if '</head>' in s else '<!-- pay_v3 -->\n' + s
    open(f, 'w').write(s); print(f, 'ok')

# ---- Nov 15 (later): new steps. The fee receipt page (choice > receipt > payment sheet) reuses fee_block(),
# and the email code step sits between details and signing.
def feepay_block(m):
    b = fee_block(m).replace('<!-- FILING FEE -->', '<!-- FEE RECEIPT (pay filing fee, opens the payment sheet) -->').replace('{{ isPay }}', '{{ isFeePay }}').replace('{{ unlock }}', '{{ payFee }}')
    return b
def verify_block():
    return ('  <!-- EMAIL CODE (confirms the email and signs them in) -->\n'
            '  <sc-if value="{{ isVerify }}" hint-placeholder-val="{{ false }}">\n'
            '    <div class="enter scroll" style="flex-grow: 1; overflow-y: auto; padding: 20px 22px 26px; display: flex; flex-direction: column; gap: 14px">\n'
            f'      <span style="width: 52px; height: 52px; border-radius: 16px; background: #E9F6EF; display: flex; align-items: center; justify-content: center"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="{G}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect width="20" height="16" x="2" y="4" rx="2"></rect><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path></svg></span>\n'
            '      <h1 style="margin: 0; font-size: 26px; line-height: 1.15; font-weight: 800; letter-spacing: -0.8px">{{ codeH }}</h1>\n'
            '      <div style="margin-top: -6px; font-size: 15px; line-height: 1.5; color: #6B6188; overflow-wrap: anywhere">{{ codeP }}</div>\n'
            '      <input aria-label="6-digit code" type="text" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="000000" value="{{ code }}" onChange="{{ onCode }}" style="height: 64px; border-radius: 16px; border: 1.5px solid #E4DEF5; padding: 0 16px; font-size: 30px; font-weight: 800; letter-spacing: 12px; text-align: center; font-family: inherit; color: #140B3A">\n'
            '      <sc-if value="{{ hasCodeErr }}" hint-placeholder-val="{{ false }}"><div role="alert" style="padding: 10px 12px; border-radius: 12px; background: #FFF0F0; color: #A1262E; font-size: 13px; font-weight: 700">{{ codeErr }}</div></sc-if>\n'
            '      <button onClick="{{ codeGo }}" disabled="{{ codeDisabled }}" style="{{ codeStyle }}">{{ codeBtn }}</button>\n'
            f'      <div style="display: flex; justify-content: space-between; align-items: center; gap: 12px; font-size: 13px; font-weight: 600; color: #6B6188"><span>{{{{ wrongEmailW }}}}</span><button onClick="{{{{ resendCode }}}}" style="background: transparent; color: {G}; font-size: 13.5px; font-weight: 800; padding: 6px 0; white-space: nowrap">{{{{ resendW }}}}</button></div>\n'
            '      <div style="display: flex; gap: 10px; align-items: center; font-size: 12px; font-weight: 600; color: #6B6188"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex: none"><rect width="18" height="11" x="3" y="11" rx="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>{{ codeHint }}</div>\n'
            '    </div>\n  </sc-if>\n\n')
for f, m in [('FlowC2.tpl.html', True), ('FlowC2D.tpl.html', False)]:
    s = open(f).read()
    if 'isFeePay' not in s:
        i = s.rfind('\n', 0, s.index('<!-- CHECKOUT -->')) + 1
        s = s[:i] + feepay_block(m) + s[i:]
    if 'isVerify' not in s:
        i = s.rfind('\n', 0, s.index('<!-- CLAIM AUTHORIZATION -->')) + 1
        s = s[:i] + verify_block() + s[i:]
    open(f, 'w').write(s); print(f, 'steps added')

# ---- Nov 15 (latest): the choice page (`pay` step) is draft 2 from the canvas (choiceD.py v2 + m2a):
# membership first with every perk, the one-time filing fee second, a one-line claims summary.
# Desktop: centered, two columns side by side. Phones: stacked membership card, small fee card, sticky Join button.
CK = '<span style="width: {s}px; height: {s}px; flex: none; margin-top: 1px; border-radius: 99px; background: ' + G + '; display: flex; align-items: center; justify-content: center"><svg width="{i}" height="{i}" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg></span>'
XK = '<span style="width: 18px; height: 18px; flex: none; margin-top: 1px; border-radius: 99px; background: #EEF1EF; display: flex; align-items: center; justify-content: center"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#A0AAA5" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18 M6 6l12 12"></path></svg></span>'
def ch_logos(lst, sz):
    one = (f'<span style="margin-left: -6px; padding: 3px; border-radius: 10px; background: #FFFFFF; box-shadow: 0 0 0 1.5px #DDE5E0, 0 0 0 3.5px #FFFFFF; display: flex">'
           f'<sc-if value="{{{{ g.hasLogo }}}}" hint-placeholder-val="{{{{ true }}}}"><img src="{{{{ g.logo }}}}" alt="" style="width: {sz - 6}px; height: {sz - 6}px; border-radius: 6px; object-fit: contain; background: #FFFFFF"></sc-if>'
           f'<sc-if value="{{{{ g.noLogo }}}}" hint-placeholder-val="{{{{ false }}}}"><span style="{{{{ g.tileStyle }}}}; width: {sz - 6}px; height: {sz - 6}px; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 800">{{{{ g.initial }}}}</span></sc-if></span>')
    return f'<span style="display: flex; padding-left: 7px; flex: none"><sc-for list="{{{{ {lst} }}}}" as="g" hint-placeholder-count="3">{one}</sc-for></span>'
def ch_strip(m):
    return (f'<div style="flex: none; display: flex; align-items: center; gap: 12px; padding: 12px 14px; border-radius: 16px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}; text-align: left">'
            + ch_logos('chLogosM' if m else 'chLogos', 24 if m else 26) +
            f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column"><b style="font-size: {14 if m else 15}px; color: {INK}">{{{{ chReady }}}}</b><span style="font-size: 12.5px; font-weight: 600; color: {MUTE}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{{{ {"chNamesM" if m else "chNames"} }}}}</span></span>'
            f'<span style="flex: none; display: flex; flex-direction: column; align-items: flex-end"><span style="font-size: 11px; font-weight: 700; color: {MUTE}">{{{{ chUpTo }}}}</span><b style="font-size: 20px; letter-spacing: -0.5px; color: {G}">{{{{ chTotal }}}}</b></span></div>')
def ch_member(m):
    rows = f'<sc-for list="{{{{ chPerksM }}}}" as="k" hint-placeholder-count="6"><div style="display: flex; align-items: flex-start; gap: 9px; font-size: {13.5 if m else 14}px; font-weight: 700; line-height: 1.35; color: {INK}">{CK.format(s=18, i=11)}<span>{{{{ k.t }}}}</span></div></sc-for>'
    btn = '' if m else f'<span style="flex: 1"></span><button onClick="{{{{ joinGo }}}}" style="height: 52px; width: 100%; flex: none; border-radius: 99px; background: {MINT}; color: #0F3B2E; font-size: 16px; font-weight: 800; box-shadow: 0 10px 24px rgba(61,220,151,.3)">{{{{ chJoin }}}}</button>'
    return (f'<div style="{"" if m else "flex: 1.25; "}position: relative; border-radius: 22px; padding: 20px; margin-top: 12px; background: #FFFFFF; box-shadow: 0 0 0 2.5px {G}, 0 16px 36px rgba(18,128,92,.16); display: flex; flex-direction: column; gap: 13px; text-align: left">'
            f'<span style="position: absolute; top: -12px; left: 20px; padding: 4px 10px; border-radius: 99px; background: {G}; color: #FFFFFF; font-size: 11.5px; font-weight: 800; letter-spacing: .4px">{{{{ chBest }}}}</span>'
            f'<span style="display: flex; justify-content: space-between; align-items: baseline; gap: 10px"><b style="font-size: 20px; color: {INK}">{{{{ chMem }}}}</b><span style="white-space: nowrap"><b style="font-size: 28px; letter-spacing: -0.8px; color: {INK}">{{{{ chMemPrice }}}}</b><span style="font-size: 12px; font-weight: 700; color: {MUTE}"> {{{{ chFirst }}}}</span></span></span>'
            f'<span style="font-size: 12.5px; font-weight: 700; color: {MUTE}; margin-top: -9px">{{{{ chThen }}}}</span>{rows}{btn}</div>')
def ch_fee_col():
    rows = (f'<sc-for list="{{{{ chPerksF }}}}" as="k" hint-placeholder-count="6"><div style="display: flex; align-items: flex-start; gap: 9px; font-size: 14px; font-weight: 700; line-height: 1.35">'
            f'<sc-if value="{{{{ k.on }}}}" hint-placeholder-val="{{{{ true }}}}">{CK.format(s=18, i=11)}<span style="color: {INK}">{{{{ k.t }}}}</span></sc-if>'
            f'<sc-if value="{{{{ k.off }}}}" hint-placeholder-val="{{{{ false }}}}">{XK}<span style="color: #A0AAA5; text-decoration: line-through">{{{{ k.t }}}}</span></sc-if></div></sc-for>')
    return (f'<div style="flex: 1; border-radius: 22px; padding: 20px; margin-top: 30px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; flex-direction: column; gap: 13px; text-align: left">'
            f'<span style="display: flex; justify-content: space-between; align-items: baseline"><b style="font-size: 18px; color: {INK}">{{{{ chFee }}}}</b><b style="font-size: 24px; letter-spacing: -0.6px; color: {INK}">$49.99</b></span>'
            f'<span style="font-size: 12.5px; font-weight: 700; color: {MUTE}; margin-top: -9px">{{{{ chFeeSub }}}}</span>{rows}<span style="flex: 1"></span>'
            f'<button onClick="{{{{ payFee }}}}" style="height: 52px; width: 100%; flex: none; border-radius: 99px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {INK}; color: {INK}; font-size: 15px; font-weight: 800">{{{{ chFeeBtn }}}}</button></div>')
def ch_fee_m():
    return (f'<button onClick="{{{{ payFee }}}}" style="flex: none; width: 100%; border-radius: 18px; padding: 14px 16px; background: #FFFFFF; box-shadow: inset 0 0 0 1.5px {LINE}; display: flex; flex-direction: column; gap: 6px; text-align: left">'
            f'<span style="display: flex; justify-content: space-between; align-items: center; width: 100%"><b style="font-size: 15px; color: {INK}">{{{{ chFee }}}}</b><span style="padding: 6px 12px; border-radius: 99px; box-shadow: inset 0 0 0 1.5px {INK}; font-size: 13.5px; font-weight: 800; color: {INK}">{{{{ chFeeOnce }}}}</span></span>'
            f'<span style="font-size: 12.5px; font-weight: 600; color: {MUTE}; line-height: 1.45">{{{{ chFeeLeft }}}}</span></button>')
KEEP = f'<div style="display: flex; align-items: center; justify-content: center; gap: 6px; font-size: 12.5px; font-weight: 700; color: {MUTE}"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="{G}" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>{{{{ chKeep }}}}</div>'
def choice_block(m):
    if m:
        body = (f'    <div class="enter scroll" style="flex-grow: 1; min-height: 0; overflow-y: auto; padding: 8px 18px 16px; display: flex; flex-direction: column; gap: 12px; background: #F3F6F4; text-align: left">\n'
                f'      <h1 style="margin: 0; font-size: 26px; line-height: 1.12; font-weight: 800; letter-spacing: -0.8px">{{{{ chH }}}}</h1>\n'
                f'      {ch_strip(True)}\n      {ch_member(True)}\n      {ch_fee_m()}\n    </div>\n'
                f'    <div style="flex: none; padding: 10px 18px 16px; border-top: 1px solid #E8EEEA; background: #FFFFFF; display: flex; flex-direction: column; gap: 6px; text-align: center">\n'
                f'      <button onClick="{{{{ joinGo }}}}" style="height: 54px; width: 100%; flex: none; border-radius: 999px; background: {MINT}; color: #0F3B2E; font-size: 17px; font-weight: 800; box-shadow: 0 10px 24px rgba(61,220,151,.35)">{{{{ chJoinM }}}}</button>\n'
                f'      <span style="font-size: 12px; line-height: 1.45; color: {MUTE}; font-weight: 600">{{{{ chThen }}}}</span>\n      {LEGAL}\n    </div>\n')
    else:
        body = (f'    <div class="enter" style="display: flex; flex-direction: column; gap: 16px; padding: 4px 0">\n'
                f'      <div style="display: flex; flex-direction: column; align-items: center; gap: 6px; text-align: center"><h1 style="margin: 0; font-size: 34px; line-height: 1.12; font-weight: 800; letter-spacing: -1px">{{{{ chH }}}}</h1>'
                f'<span style="font-size: 16px; line-height: 1.5; font-weight: 600; color: {MUTE}">{{{{ chSub }}}}</span></div>\n'
                f'      {ch_strip(False)}\n      <div style="display: flex; gap: 16px; align-items: stretch">{ch_member(False)}{ch_fee_col()}</div>\n      {KEEP}\n      {LEGAL}\n    </div>\n')
    return '  <!-- FILING FEE -->\n  <!-- choice page, draft 2 -->\n  <sc-if value="{{ isPay }}" hint-placeholder-val="{{ false }}">\n' + body + '  </sc-if>\n\n  '
for f, m in [('FlowC2.tpl.html', True), ('FlowC2D.tpl.html', False)]:
    s = open(f).read()
    if 'choice page, draft 2' in s: continue
    a = s.rfind('\n', 0, s.index('<!-- FILING FEE -->')) + 1; b = s.index('<!-- MEMBERSHIP PLANS -->')
    s = s[:a] + choice_block(m) + s[b:]
    if not m:
        s = s.replace('<sc-if value="{{ notAuth }}" hint-placeholder-val="{{ true }}"><aside class="mesh"', '<sc-if value="{{ showAside }}" hint-placeholder-val="{{ true }}"><aside class="mesh"', 1)
    open(f, 'w').write(s); print(f, 'choice page written')

# ---- Nov 15 (latest): plan page = draft 1 from planD.py (all three plans visible, 1 month picked by default).
# Desktop: centered heading, three cards side by side, the receipt in the side panel prints in (`.rcPrint`).
# Phones: heading and three stacked rows, sticky button.
RADIO = '<span style="{{ p.radio }}"><sc-if value="{{ p.on }}" hint-placeholder-val="{{ false }}"><span style="width: 12px; height: 12px; border-radius: 99px; background: ' + G + '"></span></sc-if></span>'
TAGP = '<span style="padding: 4px 9px; border-radius: 99px; background: ' + G + '; color: #FFFFFF; font-size: 11px; font-weight: 800; letter-spacing: .4px; white-space: nowrap">{{ p.tag }}</span>'
SAVEP = '<span style="padding: 3px 8px; border-radius: 99px; background: #FFF4DB; color: #8A5A00; font-size: 12px; font-weight: 800; white-space: nowrap">{{ p.save }}</span>'
LOCKI = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0F3B2E" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 11h14a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2z M7 11V7a5 5 0 0 1 10 0v4"></path></svg>'
def plan_cta(h):
    return f'<button onClick="{{{{ subscribe }}}}" style="height: {h}px; width: 100%; flex: none; border-radius: 999px; background: {MINT}; color: #0F3B2E; font-size: 17px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 10px 24px rgba(61,220,151,.35)">{LOCKI}{{{{ plCta }}}}</button>'
def plans_d1(m):
    if m:
        row = (f'<sc-for list="{{{{ pd }}}}" as="p" hint-placeholder-count="3"><button onClick="{{{{ p.pick }}}}" aria-pressed="{{{{ p.on }}}}" style="{{{{ p.rowStyle }}}}">'
               f'<sc-if value="{{{{ p.hasTag }}}}" hint-placeholder-val="{{{{ false }}}}"><span style="position: absolute; top: -10px; right: 14px">{TAGP}</span></sc-if>{RADIO}'
               f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 3px"><span style="display: flex; justify-content: space-between; align-items: baseline; gap: 8px"><b style="font-size: 16px; color: {INK}">{{{{ p.name }}}}</b><span style="white-space: nowrap"><b style="font-size: 20px; letter-spacing: -0.5px; color: {INK}">{{{{ p.today }}}}</b><span style="font-size: 12px; font-weight: 700; color: {MUTE}">{{{{ p.todayW }}}}</span></span></span>'
               f'<span style="font-size: 12.5px; font-weight: 600; color: {MUTE}">{{{{ p.per }}}}{{{{ p.nowW }}}} · {{{{ p.thenS }}}}</span>'
               f'<sc-if value="{{{{ p.hasSave }}}}" hint-placeholder-val="{{{{ false }}}}"><span style="margin-top: 2px">{SAVEP}</span></sc-if></span></button></sc-for>')
        return ('  <!-- MEMBERSHIP PLANS -->\n  <!-- plan page, draft 1 -->\n  <sc-if value="{{ isPlans }}" hint-placeholder-val="{{ false }}">\n'
                f'    <div class="enter scroll" style="flex-grow: 1; min-height: 0; overflow-y: auto; padding: 8px 18px 16px; display: flex; flex-direction: column; gap: 12px; background: #F3F6F4; text-align: left">\n'
                f'      <h1 style="margin: 0; font-size: 26px; line-height: 1.12; font-weight: 800; letter-spacing: -0.8px">{{{{ pdH }}}}</h1>\n'
                f'      <div style="margin-top: -6px; font-size: 14.5px; line-height: 1.45; font-weight: 600; color: {MUTE}">{{{{ pdSub }}}}</div>\n'
                f'      <div style="display: flex; flex-direction: column; gap: 14px; margin-top: 8px">{row}</div>\n    </div>\n'
                f'    <div style="flex: none; padding: 10px 18px 16px; border-top: 1px solid #E8EEEA; background: #FFFFFF; display: flex; flex-direction: column; gap: 6px; text-align: center">\n'
                f'      {plan_cta(54)}\n      <span style="font-size: 12px; line-height: 1.45; color: {MUTE}; font-weight: 600">{{{{ pdFine }}}}</span>\n      {LEGAL}\n    </div>\n  </sc-if>\n\n  ')
    card = (f'<sc-for list="{{{{ pd }}}}" as="p" hint-placeholder-count="3"><button onClick="{{{{ p.pick }}}}" aria-pressed="{{{{ p.on }}}}" style="{{{{ p.cardStyle }}}}">'
            f'<sc-if value="{{{{ p.hasTag }}}}" hint-placeholder-val="{{{{ false }}}}"><span style="position: absolute; top: -11px; left: 18px">{TAGP}</span></sc-if>'
            f'<span style="display: flex; justify-content: space-between; align-items: center; width: 100%"><b style="font-size: 18px; color: {INK}">{{{{ p.name }}}}</b>{RADIO}</span>'
            f'<span style="display: flex; align-items: baseline; gap: 4px"><b style="font-size: 36px; letter-spacing: -1.2px; line-height: 1; color: {INK}">{{{{ p.per }}}}</b><span style="font-size: 13px; font-weight: 700; color: {MUTE}">{{{{ p.mo }}}}</span></span>'
            f'<span style="font-size: 13px; font-weight: 600; color: {MUTE}; margin-top: -4px">{{{{ p.today }}}}{{{{ p.todayW }}}}, {{{{ p.perlab }}}}</span>'
            f'<span style="height: 1px; width: 100%; background: #EEF1EF; margin: 2px 0"></span>'
            f'<span style="font-size: 13px; font-weight: 700; color: {INK}">{{{{ p.then }}}}</span>'
            f'<span style="display: flex; align-items: center; gap: 6px; flex-wrap: wrap; font-size: 12.5px; font-weight: 600; color: {MUTE}">{{{{ p.thenmo }}}}<sc-if value="{{{{ p.hasSave }}}}" hint-placeholder-val="{{{{ false }}}}">{SAVEP}</sc-if></span></button></sc-for>')
    return ('  <!-- MEMBERSHIP PLANS -->\n  <!-- plan page, draft 1 -->\n  <sc-if value="{{ isPlans }}" hint-placeholder-val="{{ false }}">\n'
            f'    <div class="enter" style="display: flex; flex-direction: column; gap: 16px; padding: 4px 0">\n'
            f'      <div style="display: flex; flex-direction: column; align-items: center; gap: 6px; text-align: center"><h1 style="margin: 0; font-size: 34px; line-height: 1.12; font-weight: 800; letter-spacing: -1px">{{{{ pdH }}}}</h1>'
            f'<span style="font-size: 16px; line-height: 1.5; font-weight: 600; color: {MUTE}">{{{{ pdSub }}}}</span></div>\n'
            f'      <div style="display: flex; gap: 14px; margin-top: 14px">{card}</div>\n'
            f'      {plan_cta(56)}\n      <span style="text-align: center; font-size: 12.5px; color: {MUTE}; font-weight: 600; margin-top: -4px">{{{{ pdFine }}}}</span>\n      {LEGAL}\n    </div>\n  </sc-if>\n\n  ')
PRINT_CSS = ('\n/* receipt prints into the side panel on the plan page (Nov 15) */\n'
             '.rcPrint{animation:rcPrint .95s cubic-bezier(.2,.8,.2,1) both}\n'
             '@keyframes rcPrint{0%{opacity:0;transform:translateY(-18px);clip-path:inset(0 0 100% 0)}25%{opacity:1}100%{opacity:1;transform:none;clip-path:inset(0 0 -40px 0)}}\n'
             '.rcFade{animation:rcFade .5s ease both}@keyframes rcFade{from{opacity:0}to{opacity:1}}\n'
             '@media (prefers-reduced-motion:reduce){.rcPrint,.rcFade{animation:none}}\n')
for f, m in [('FlowC2.tpl.html', True), ('FlowC2D.tpl.html', False)]:
    s = open(f).read()
    if 'plan page, draft 1' not in s:
        a = s.rfind('\n', 0, s.index('<!-- MEMBERSHIP PLANS -->')) + 1
        b = s.index('<!-- ', s.index('<!-- MEMBERSHIP PLANS -->') + 10); b = s.rfind('\n', 0, b) + 1
        s = s[:a] + plans_d1(m) + s[b:]
    if not m and 'rcPrint' not in s:
        s = s.replace('</style>', PRINT_CSS + '</style>', 1)
        k = '<sc-if value="{{ asideReceipt }}" hint-placeholder-val="{{ false }}"><div class="scroll"'
        assert k in s
        s = s.replace(k, '<sc-if value="{{ asideReceipt }}" hint-placeholder-val="{{ false }}"><div class="scroll rcPrint"', 1)
    open(f, 'w').write(s); print(f, 'plan page written')
