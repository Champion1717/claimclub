# Payment sheet direction (Nov 15 2026, chosen as PayF1/PayF2 on the canvas): writes the fee page and the plan page
# into FlowC2 (mobile) and FlowC2D (desktop), plus the receipt in the desktop side panel. The payment itself
# (Apple Pay, Google Pay, card) opens in a sheet drawn by site/live.js. Run before green.py.
G, MINT, INK, MUTE, LINE = '#12805C', '#3DDC97', '#0A0F0D', '#5B6862', '#DDE5E0'
CHECK = '<svg width="{s}" height="{s}" viewBox="0 0 24 24" fill="none" stroke="{c}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex: none"><path d="M20 6 9 17l-5-5"></path></svg>'
DASH = '<div style="border-top: 2px dashed #DDE5E0; margin: 12px 0"></div>'
def zig():
    return '<div aria-hidden="true" style="height: 12px; flex: none; background: linear-gradient(135deg, #FFFFFF 33.3%, transparent 33.3%) 0 0 / 16px 16px, linear-gradient(225deg, #FFFFFF 33.3%, transparent 33.3%) 0 0 / 16px 16px"></div>'
def receipt_m():
    rows = (f'<sc-for list="{{{{ rcItems }}}}" as="r" hint-placeholder-count="4"><div style="display: flex; justify-content: space-between; gap: 12px; padding: 8px 0; font-size: 15px"><span style="font-weight: 700; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap">{{{{ r.t }}}}</span><span style="flex: none; font-weight: 800; color: {G}">{{{{ r.v }}}}</span></div></sc-for>'
            f'<sc-if value="{{{{ hasRcMore }}}}" hint-placeholder-val="{{{{ false }}}}"><div style="padding: 6px 0 0; font-size: 13px; font-weight: 700; color: {MUTE}">{{{{ rcMore }}}}</div></sc-if>')
    return (f'<div style="flex: none; display: flex; flex-direction: column; filter: drop-shadow(0 12px 22px rgba(10,15,13,.08)); text-align: left">'
            f'<div style="background: #FFFFFF; border-radius: 20px 20px 0 0; padding: 20px 20px 16px; display: flex; flex-direction: column; color: {INK}">'
            f'<span style="font-size: 12px; font-weight: 800; letter-spacing: 1.2px; color: #8A968F">{{{{ rcHead }}}}</span>'
            f'<span style="font-size: 14px; font-weight: 700; color: {MUTE}; margin-top: 10px">{{{{ rcEarn }}}}</span>'
            f'<b style="font-size: 38px; letter-spacing: -1.4px; line-height: 1.1; color: {G}">{{{{ rcTotal }}}}</b>'
            + DASH + rows + DASH +
            f'<div style="display: flex; justify-content: space-between; align-items: center; gap: 12px"><span style="display: flex; flex-direction: column; gap: 3px"><b style="font-size: 15px">{{{{ rcFeeLabel }}}}</b><span style="font-size: 13px; color: {MUTE}; font-weight: 600">{{{{ rcFeeSub }}}}</span></span><b style="font-size: 26px; letter-spacing: -0.8px">{{{{ rcFee }}}}</b></div>'
            f'<div style="display: flex; align-items: center; gap: 10px; margin-top: 14px; padding: 12px 14px; border-radius: 14px; background: #E9F6EF; color: #17603F">{CHECK.format(s=18, c=G)}<span style="display: flex; flex-direction: column; gap: 2px"><b style="font-size: 14px">{{{{ keepH }}}}</b><span style="font-size: 12.5px; font-weight: 600">{{{{ keepP }}}}</span></span></div>'
            f'</div>{zig()}</div>')
def receipt_d():
    rows = (f'<sc-for list="{{{{ rcItems }}}}" as="r" hint-placeholder-count="4"><div style="display: flex; justify-content: space-between; gap: 10px; padding: 5px 0; font-size: 14px"><span style="display: flex; align-items: center; gap: 8px; font-weight: 700; min-width: 0">{CHECK.format(s=15, c=G)}<span style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap">{{{{ r.t }}}}</span></span><span style="flex: none; font-weight: 800; color: {G}">{{{{ r.v }}}}</span></div></sc-for>'
            f'<sc-if value="{{{{ hasRcMore }}}}" hint-placeholder-val="{{{{ false }}}}"><div style="padding: 4px 0 0 23px; font-size: 12.5px; font-weight: 700; color: {MUTE}">{{{{ rcMore }}}}</div></sc-if>')
    return (f'<sc-if value="{{{{ asideReceipt }}}}" hint-placeholder-val="{{{{ false }}}}"><div class="scroll" style="flex-grow: 1; min-height: 0; overflow-y: auto; margin: 0 -8px; padding: 0 8px 8px"><div style="display: flex; flex-direction: column; filter: drop-shadow(0 18px 30px rgba(0,0,0,.35))">'
            f'<div style="background: #FFFFFF; border-radius: 18px 18px 0 0; padding: 20px 20px 12px; display: flex; flex-direction: column; color: {INK}">'
            f'<span style="font-size: 11.5px; font-weight: 800; letter-spacing: 1.2px; color: #8A968F">{{{{ rcHeadD }}}}</span>'
            f'<span style="font-size: 13px; font-weight: 700; color: {MUTE}; margin-top: 8px">{{{{ rcEarn }}}}</span><b style="font-size: 38px; letter-spacing: -1.4px; line-height: 1.08; color: {G}">{{{{ rcTotal }}}}</b><span style="font-size: 12.5px; color: {MUTE}; font-weight: 600">{{{{ rcFrom }}}}</span>'
            + DASH.replace('12px 0', '10px 0') + rows + DASH.replace('12px 0', '10px 0') +
            f'<div style="display: flex; justify-content: space-between; align-items: center; gap: 10px"><span style="display: flex; flex-direction: column; gap: 2px"><b style="font-size: 15px">{{{{ rcFeeLabel }}}}</b><span style="font-size: 12px; color: {MUTE}; font-weight: 600">{{{{ rcFeeSub }}}}</span></span><b style="font-size: 28px; letter-spacing: -1px">{{{{ rcFee }}}}</b></div>'
            f'<div style="display: flex; justify-content: space-between; font-size: 13.5px; font-weight: 800; margin-top: 8px"><span>{{{{ rcShare }}}}</span><span style="color: {G}">100%</span></div>'
            f'<div style="margin-top: 12px; padding: 10px 12px; border-radius: 12px; background: #F3F6F4; font-size: 12px; color: #43504A; line-height: 1.45; font-weight: 600">{{{{ keepP2 }}}}</div>'
            f'</div>{zig()}</div></div></sc-if>\n      ')
LEGAL = '<div style="display: flex; justify-content: center; gap: 22px; font-size: 12px; font-weight: 600; color: #43504A"><a href="https://claimclub.io/terms" target="_blank" rel="noopener" style="color: inherit">{{ L.termsW }}</a><a href="https://claimclub.io/privacy" target="_blank" rel="noopener" style="color: inherit">{{ L.privacyW }}</a></div>'
def upsell():
    return (f'<button onClick="{{{{ toPlans }}}}" style="flex: none; display: flex; align-items: center; gap: 12px; width: 100%; padding: 12px 14px; border-radius: 16px; background: #E9F6EF; color: {INK}; text-align: left">'
            f'<span style="flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px"><b style="font-size: 14px">{{{{ joinUp }}}}</b><span style="font-size: 12.5px; color: {MUTE}; font-weight: 600; line-height: 1.4">{{{{ joinSub }}}}</span></span>'
            f'<span style="flex: none; font-size: 13.5px; font-weight: 800; color: {G}; display: flex; align-items: center; gap: 4px">{{{{ switchW }}}}<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="{G}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"></path></svg></span></button>')
LOCK = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0F3B2E" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex: none"><path d="M5 11h14a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2z M7 11V7a5 5 0 0 1 10 0v4"></path></svg>'
def cta(onclick, label, h):
    return f'<button onClick="{{{{ {onclick} }}}}" style="height: {h}px; width: 100%; flex: none; border-radius: 999px; background: {MINT}; color: #0F3B2E; font-size: 17px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 10px 24px rgba(61,220,151,.35)">{LOCK}{{{{ {label} }}}}</button>'
def fee_block(m):
    if m:
        body = (f'    <div class="enter scroll plcol" style="flex-grow: 1; min-height: 0; overflow-y: auto; padding: 10px 18px 14px; display: flex; flex-direction: column; gap: 14px; background: #F3F6F4">\n'
                f'      {receipt_m()}\n      {upsell()}\n    </div>\n')
        foot = (f'    <div style="flex: none; padding: 10px 18px 16px; border-top: 1px solid #E8EEEA; background: #FFFFFF; display: flex; flex-direction: column; gap: 6px; text-align: center">\n'
                f'      {cta("unlock", "feeCta", 54)}\n      <span style="font-size: 11.5px; line-height: 1.45; color: {MUTE}">{{{{ feeOnce }}}}</span>\n      {LEGAL}\n    </div>\n')
        return '  <!-- FILING FEE -->\n  <sc-if value="{{ isPay }}" hint-placeholder-val="{{ false }}">\n' + body + foot + '  </sc-if>\n\n  '
    body = (f'    <div class="enter scroll plcol" style="flex-grow: 1; min-height: 0; overflow-y: auto; padding: 24px 0 16px; display: flex; flex-direction: column; gap: 16px; justify-content: safe center; text-align: left">\n'
            f'      <h1 style="margin: 0; font-size: 30px; line-height: 1.12; font-weight: 800; letter-spacing: -0.9px">{{{{ feeH2 }}}}</h1>\n'
            f'      <div style="margin-top: -6px; font-size: 15px; line-height: 1.5; font-weight: 600; color: {MUTE}">{{{{ feeSub2 }}}}</div>\n'
            f'      {cta("unlock", "feeCta", 56)}\n      <span style="margin-top: -6px; font-size: 12px; text-align: center; color: {MUTE}">{{{{ feeOnce }}}}</span>\n      {upsell()}\n      {LEGAL}\n    </div>\n')
    return '  <!-- FILING FEE -->\n  <sc-if value="{{ isPay }}" hint-placeholder-val="{{ false }}">\n' + body + '  </sc-if>\n\n  '
def plans_block(m, old):
    if not m:
        # Desktop keeps Plan page V2, minus the matches card (the receipt in the side panel covers it).
        a = old.index('<div style="display: flex; align-items: center; justify-content: center; gap: 18px; padding: 14px 18px; border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #DDE5E0">')
        b = old.index('<h1', a)
        old = old[:a] + old[b:]
        return old.replace('{{ plCta }}</button>', '{{ plCta }}</button>', 1)
    seg = old[old.index('<div role="radiogroup"'):]; seg = seg[:seg.index('</sc-for></div>') + len('</sc-for></div>')]
    foot = old[old.index('    <div style="flex: none; padding: 10px 18px 16px; border-top'):old.rindex('  </sc-if>')]
    body = (f'    <div class="enter scroll plcol" style="flex-grow: 1; min-height: 0; overflow-y: auto; padding: 10px 18px 14px; display: flex; flex-direction: column; gap: 12px; background: #F3F6F4; text-align: left">\n'
            f'      {receipt_m()}\n      <h1 style="margin: 6px 0 0; font-size: 22px; line-height: 1.1; font-weight: 800; letter-spacing: -0.6px">{{{{ pickPlanH }}}}</h1>\n      {seg}\n    </div>\n')
    return '  <!-- MEMBERSHIP PLANS -->\n  <sc-if value="{{ isPlans }}" hint-placeholder-val="{{ false }}">\n' + body + foot + '  </sc-if>\n\n  '
for f, m in [('FlowC2.tpl.html', True), ('FlowC2D.tpl.html', False)]:
    s = open(f).read()
    if 'pay_v3' in s: print(f, 'already done'); continue
    a = s.rfind('\n', 0, s.index('<!-- FILING FEE -->')) + 1; b = s.index('<!-- MEMBERSHIP PLANS -->')
    s = s[:a] + fee_block(m) + s[b:]
    a = s.rfind('\n', 0, s.index('<!-- MEMBERSHIP PLANS -->')) + 1; b = s.index('<!-- CHECKOUT -->')
    s = s[:a] + plans_block(m, s[a:b]) + s[b:]
    if not m:
        k = '<div style="font-size: 12px; line-height: 1.6; color: #CFC6EE">{{ L.asideNote }}</div>'
        assert k in s
        s = s.replace('      ' + k, '      ' + receipt_d() + k, 1)
        # the estimate header in the side panel repeats the receipt on the pay steps
        h0 = '<div style="display: flex; flex-direction: column; gap: 4px"><div style="font-size: 12px; font-weight: 700; letter-spacing: 1.4px; color: #CFC6EE">{{ L.estSoFar }}</div>'
        i = s.index(h0); j = s.index('{{ countMatched }}</div></div>', i) + len('{{ countMatched }}</div></div>')
        s = s[:i] + '<sc-if value="{{ notReceipt }}" hint-placeholder-val="{{ true }}">' + s[i:j] + '</sc-if>' + s[j:]
    s = s.replace('</head>', '<!-- pay_v3 -->\n</head>', 1) if '</head>' in s else '<!-- pay_v3 -->\n' + s
    open(f, 'w').write(s); print(f, 'ok')
