# Puts the chosen hero visual (HeroP2: top half of a realistic iPhone showing "You could be owed", with a "Claim filed" alert) into LandingC2.tpl.html.
# Markup comes from ../concepts/heroP.py p2(). Run before green.py.
import sys, os, re
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'concepts'))
import heroP
T = 'LandingC2.tpl.html'
s = open(T).read()
col = ('<div class="phonecol heroPhone" aria-hidden="true" style="flex: 0 0 auto; align-self: flex-end; margin: 0 auto -48px; display: flex; justify-content: center">'
       + heroP.p2().replace('height: 540px;', 'height: 480px;').replace('<div style="position: absolute; left: 10px; width: max-content; top: 300px; transform: rotate(3deg);', '<div class="noteAnim" style="position: absolute; left: 10px; width: max-content; top: 300px; transform: rotate(3deg);') + '</div>')
a = s.index('      <div class="phonecol')
depth = 0
for m in re.finditer(r'<div\b|</div>', s[a:]):
    depth += -1 if m.group() == '</div>' else 1
    if depth == 0:
        end = a + m.end(); break
s = s[:a] + '      ' + col + s[end:]
CSS = '.heroPhone{user-select:none;pointer-events:none}\n@keyframes noteIn{0%{opacity:0;transform:translate(36px,10px) rotate(6deg) scale(.94)}7%{opacity:1;transform:translate(0,0) rotate(3deg) scale(1.02)}10%,40%{opacity:1;transform:translate(0,0) rotate(3deg) scale(1)}55%{transform:translate(0,-6px) rotate(2.5deg)}70%{transform:translate(0,0) rotate(3deg)}86%{opacity:1;transform:translate(0,0) rotate(3deg)}94%,100%{opacity:0;transform:translate(0,-14px) rotate(3deg) scale(.97)}}.noteAnim{animation:noteIn 6.5s cubic-bezier(.2,.8,.2,1) .6s infinite both}@media (prefers-reduced-motion: reduce){.noteAnim{animation:none}}\n@media (min-width:901px){.herogrid{align-items:stretch !important}.herotext{align-self:flex-start;padding-top:10px}.phonecol.heroPhone{align-self:stretch !important}.heroPhone>div{height:auto !important;min-height:480px}.heroPhone>div>div:first-child{height:auto !important;bottom:0}}\n@media (max-width:900px){.phonecol.heroPhone{display:flex !important;zoom:.74;margin:6px auto -44px !important}}\n@media (min-width:901px) and (max-width:1023px){.phonecol.heroPhone{margin-top:8px !important}}\n'
if '.heroPhone{' in s:
    s = re.sub(r'\.heroPhone\{user-select.*?\n@media \(min-width:901px\) and \(max-width:1023px\)\{\.(?:phonecol\.)?heroPhone[^\n]*\n', lambda m: CSS, s, count=1, flags=re.S)
else:
    s = s.replace('.lift{transition:transform .18s ease}', CSS + '.lift{transition:transform .18s ease}', 1)
open(T, 'w').write(s)
print('hero V2 written')
