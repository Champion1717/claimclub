# Puts the chosen hero visual (HeroP2: top half of a realistic iPhone showing "You could be owed", with a "Claim filed" alert) into LandingC2.tpl.html.
# Markup comes from ../concepts/heroP.py p2(). Run before green.py.
import sys, os, re
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'concepts'))
import heroP
T = 'LandingC2.tpl.html'
s = open(T).read()
col = ('<div class="phonecol heroPhone" aria-hidden="true" style="flex: 0 0 auto; align-self: flex-end; margin: 0 auto -48px; display: flex; justify-content: center">'
       + heroP.p2().replace('height: 540px;', 'height: 480px;') + '</div>')
a = s.index('      <div class="phonecol')
depth = 0
for m in re.finditer(r'<div\b|</div>', s[a:]):
    depth += -1 if m.group() == '</div>' else 1
    if depth == 0:
        end = a + m.end(); break
s = s[:a] + '      ' + col + s[end:]
CSS = '.heroPhone{user-select:none;pointer-events:none}\n@media (min-width:901px){.herogrid{align-items:stretch !important}.herotext{align-self:flex-start;padding-top:10px}.phonecol.heroPhone{align-self:stretch !important}.heroPhone>div{height:auto !important;min-height:480px}.heroPhone>div>div:first-child{height:auto !important;bottom:0}}\n@media (max-width:900px){.phonecol.heroPhone{display:flex !important;zoom:.74;margin:6px auto -44px !important}}\n@media (min-width:901px) and (max-width:1023px){.phonecol.heroPhone{margin-top:8px !important}}\n'
if '.heroPhone{' in s:
    s = re.sub(r'\.heroPhone\{user-select.*?\n@media \(min-width:901px\) and \(max-width:1023px\)\{\.(?:phonecol\.)?heroPhone[^\n]*\n', lambda m: CSS, s, count=1, flags=re.S)
else:
    s = s.replace('.lift{transition:transform .18s ease}', CSS + '.lift{transition:transform .18s ease}', 1)
open(T, 'w').write(s)
print('hero V2 written')
