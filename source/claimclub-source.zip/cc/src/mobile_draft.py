# Mobile homepage draft (Nov 14): CSS-only changes for phones, shown on the design canvas as LandingMDraft before going live.
# To ship: run `python3 mobile_draft.py ship` (adds the CSS to LandingC2.tpl.html), then rebuild.
import sys, re
CSS = ('/* mobile-draft */@media (max-width:900px){'
       # hero fits one phone screen: no subtext, phone fills what is left
       '.herotext .u2{display:none !important}'
       '}@media (max-width:600px){.mesh{height:100svh;min-height:600px !important;box-sizing:border-box}.herogrid{flex:1 1 auto;min-height:0;flex-direction:column !important;flex-wrap:nowrap !important;justify-content:flex-start !important;padding:18px 16px 0 !important;gap:18px !important}.herotext{flex:none !important;gap:16px !important}.phonecol.heroPhone{flex:1 1 0 !important;min-height:0 !important;overflow:hidden;margin:4px auto 0 !important;align-self:center !important}'
       '}@media (max-width:900px){'
       # settlements: one swipeable row instead of a tall 2-column grid
       '.mGrid{display:flex !important;overflow-x:auto;scroll-snap-type:x mandatory;gap:10px !important;margin:0 -16px;padding:2px 16px 10px;scroll-padding-inline:16px;scrollbar-width:none}.mGrid::-webkit-scrollbar{display:none}'
       '.mGrid>a{flex:0 0 44%;scroll-snap-align:start}#settlements{padding-bottom:36px !important}'
       # how it works: tighter section, smaller phones
       '.howv2{padding:44px 0 36px !important}.howhead{margin-bottom:22px !important}.howhead h2{font-size:30px !important}.howhead p{font-size:15px !important}'
       # how it works: step chip over each full phone, stacked, no sideways swipe
       '.howrow{flex-direction:column !important;align-items:center !important;overflow:visible !important;scroll-snap-type:none !important;gap:36px !important;padding:0 !important}'
       '.howrow>div{flex:none !important;width:100% !important;gap:16px !important}.howrow>div>.iph{zoom:.92}.howhead h2{font-size:32px !important}'
       # reviews: swipeable row
       '.revSec{padding:48px 16px !important}.revSec h2{font-size:30px !important}'
       '.revGrid{display:flex !important;overflow-x:auto;scroll-snap-type:x mandatory;gap:12px !important;margin:0 -16px;padding:2px 16px 10px;scroll-padding-inline:16px;scrollbar-width:none}.revGrid::-webkit-scrollbar{display:none}'
       '.revGrid>*{flex:0 0 80%;scroll-snap-align:start;padding:18px !important}'
       # pricing: full-width card, shorter feature list, roomier plan rows
       '#pricing{padding:0 12px 56px !important}.priceBox{padding:30px 18px 18px !important;border-radius:26px !important;gap:24px !important}.priceBox h2{font-size:32px !important}'
       '.priceFeat{gap:10px !important}.priceFeat>div>div>span:last-child{display:none}.priceFeat>div>div>span:first-child{font-size:15px !important}'
       '.priceCard{flex-basis:100% !important;padding:14px !important;border-radius:20px !important}.priceCard>div{padding-left:14px !important;padding-right:14px !important}'
       '}')
if __name__ == '__main__' and sys.argv[1:] == ['ship']:
    T = 'LandingC2.tpl.html'; s = open(T).read()
    s = re.sub(r'/\* mobile-draft \*/[^\n]*\n', '', s)
    s = s.replace('</style>', CSS + '\n</style>', 1); open(T, 'w').write(s); print('shipped mobile draft CSS')
