# Writes the chosen Plan page V2 markup into the claim flow source templates (FlowC2 / FlowC2D; green.py derives G2 from them).
def block(m):
    if m:
        card = ('<div style="display: flex; flex-direction: column; align-items: center; gap: 6px; padding: 14px 18px; border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #DDE5E0">'
                '<span style="display: flex; flex-direction: column; align-items: center"><span style="font-size: 13px; font-weight: 700; color: #5B6862">{{ L.matchesSo }}</span><span style="font-size: 12px; font-weight: 600; color: #9AA8A0">{{ countMatched }}</span></span>'
                '<span style="font-size: 48px; line-height: 1; font-weight: 800; letter-spacing: -2px; color: #12805C">{{ matchValue }}</span>'
                '<span style="font-size: 12px; font-weight: 600; color: #5B6862">{{ plPotLead }}<b style="color: #0A0F0D">{{ plPot }}</b></span></div>')
    else:
        card = ('<div style="display: flex; align-items: center; justify-content: center; gap: 18px; padding: 14px 18px; border-radius: 18px; background: #FFFFFF; box-shadow: inset 0 0 0 1px #DDE5E0">'
                '<span style="display: flex; flex-direction: column; align-items: flex-end; text-align: right"><span style="font-size: 13px; font-weight: 700; color: #5B6862">{{ L.matchesSo }}</span><span style="font-size: 12px; font-weight: 600; color: #9AA8A0">{{ countMatched }}</span></span>'
                '<span style="font-size: 52px; line-height: 1; font-weight: 800; letter-spacing: -2px; color: #12805C">{{ matchValue }}</span>'
                '<span style="max-width: 190px; font-size: 12px; font-weight: 600; color: #5B6862; text-align: left">{{ plPotLead }}<b style="color: #0A0F0D">{{ plPot }}</b></span></div>')
    h = 24 if m else 28
    seg = ('<div role="radiogroup" aria-label="{{ L.plansH }}" style="display: grid; grid-template-columns: repeat(3,1fr); gap: 4px; padding: 4px; border-radius: 16px; background: #EEF2EF">'
           '<sc-for list="{{ plSeg }}" as="g" hint-placeholder-count="3"><button onClick="{{ g.pick }}" role="radio" aria-checked="{{ g.on }}" style="{{ g.style }}"><span style="font-size: 14px; font-weight: 800">{{ g.name }}</span><span style="{{ g.subStyle }}">{{ g.sub }}</span></button></sc-for></div>')
    pc = ('<div style="display: flex; flex-direction: column; gap: 12px; padding: 18px; border-radius: 20px; background: #FFFFFF; box-shadow: inset 0 0 0 2px #0F3B2E, 0 14px 30px rgba(15,59,46,.08); text-align: left">'
          '<div style="display: flex; align-items: flex-end; justify-content: space-between; gap: 10px"><span style="display: flex; flex-direction: column; gap: 2px"><span style="font-size: 12px; font-weight: 800; letter-spacing: 1.2px; color: #12805C">{{ L.introP }}</span>'
          f'<span style="display: flex; align-items: baseline; gap: 8px"><span style="font-size: {36 if m else 40}px; line-height: 1; font-weight: 800; letter-spacing: -1.4px">{{{{ pl.first }}}}</span><span style="font-size: 16px; font-weight: 700; color: #9AA8A0; text-decoration: line-through">{{{{ pl.full }}}}</span></span>'
          '<span style="font-size: 13px; font-weight: 700; color: #5B6862">{{ pl.line }}</span></span>'
          '<span style="flex: none; display: flex; flex-direction: column; align-items: center; padding: 8px 12px; border-radius: 14px; background: #E9F6EF; color: #0F3B2E"><span style="font-size: 18px; font-weight: 800">{{ pl.per }}</span><span style="font-size: 10.5px; font-weight: 800">{{ L.perMoCap }}</span></span></div>'
          '<div style="height: 1px; background: #E8EEEA"></div>'
          '<sc-for list="{{ plFeats }}" as="ft" hint-placeholder-count="4"><span style="display: flex; align-items: center; gap: 10px; font-size: 14px; font-weight: 700; color: #0A0F0D"><span style="width: 24px; height: 24px; border-radius: 8px; background: #E9F6EF; display: flex; align-items: center; justify-content: center; flex: none"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#12805C" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="{{ ft.d }}"></path></svg></span>{{ ft.t }}</span></sc-for></div>')
    pad = '10px 18px 14px' if m else '24px 0 16px'
    jc = '' if m else ' justify-content: safe center;'
    body = (f'    <div class="enter scroll plcol" style="flex-grow: 1; min-height: 0; overflow-y: auto; padding: {pad}; display: flex; flex-direction: column; gap: {12 if m else 14}px;{jc} align-items: stretch; text-align: center">\n'
            f'      {card}\n      <h1 style="margin: 4px 0 0; font-size: {h}px; line-height: 1.1; font-weight: 800; letter-spacing: -0.8px">{{{{ L.plansH }}}}</h1>\n      {seg}\n      {pc}\n    </div>\n')
    fpad = '10px 18px 16px' if m else '12px 0 16px'
    foot = (f'    <div style="flex: none; padding: {fpad}; border-top: 1px solid #E8EEEA; background: #FFFFFF; display: flex; flex-direction: column; gap: 6px; text-align: center">\n'
            f'      <button onClick="{{{{ subscribe }}}}" style="height: {54 if m else 56}px; width: 100%; border-radius: 999px; background: #3DDC97; color: #0F3B2E; font-size: 17px; font-weight: 800; box-shadow: 0 10px 24px rgba(61,220,151,.35)">{{{{ plCta }}}}</button>\n'
            '      <span style="font-size: 11.5px; line-height: 1.45; color: #5B6862">{{ planRenew }}</span>\n'
            '      <div style="display: flex; justify-content: center; gap: 22px; font-size: 12px; font-weight: 600; color: #43504A"><a href="https://claimclub.io/legal/terms.html" target="_blank" rel="noopener" style="color: inherit">{{ L.termsW }}</a><a href="https://claimclub.io/legal/privacy.html" target="_blank" rel="noopener" style="color: inherit">{{ L.privacyW }}</a></div>\n    </div>\n')
    return '  <!-- MEMBERSHIP PLANS -->\n  <sc-if value="{{ isPlans }}" hint-placeholder-val="{{ false }}">\n' + body + foot + '  </sc-if>\n\n  '
for f, m in [('FlowC2.tpl.html', True), ('FlowC2D.tpl.html', False)]:
    s = open(f).read(); a = s.index('<!-- MEMBERSHIP PLANS -->'); b = s.index('<!-- CHECKOUT -->')
    a = s.rfind('\n', 0, a) + 1
    s = s[:a] + block(m) + s[b:]
    if '.plcol>*{flex-shrink:0}' not in s: s = s.replace('body{margin:0}', 'body{margin:0}\n.plcol>*{flex-shrink:0}', 1)
    open(f, 'w').write(s); print(f, 'ok')
