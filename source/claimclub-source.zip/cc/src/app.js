  constructor(props) {
    super(props);
    this.state = {
      view: 'dash', tour: 0, filter: 'all', toast: '', push: true, emails: true, subOpen: true, bank: false, bankBanner: true, spot: null,
      status: { goodrx: 'submitted', cvs: 'review', squatch: 'submitted' },
      p: { name: 'Alex Rivera', email: 'alex.rivera@email.com', phone: '(555) 201-4477', street: '1452 Maple Ave, Apt 3', city: 'Sacramento', st: 'CA', zip: '95814', prev: '', dob: '', payout: 'PayPal', payHandle: 'alex.rivera@email.com', sig: '' },
      ids: { kroger: '', venetian: '', apple: '' }, dashTab: 'all', plan: '1m'
    };
    try {
      const raw = typeof localStorage !== 'undefined' && localStorage.getItem('claimclub_session');
      const ss = raw ? JSON.parse(raw) : null;
      if (ss && ss.ids && ss.ids.length) {
        this._sess = ss;
        const st = {}; (ss.signed || []).forEach(id => { st[id] = 'submitted'; });
        this.state.status = st;
        this.state.bank = !!ss.bank; this.state.plan = ss.plan || '';
        const p = Object.assign({}, this.state.p); Object.keys(ss.p || {}).forEach(k => { if (ss.p[k]) p[k] = ss.p[k]; });
        if (ss.p && ss.p.name) { p.sig = ss.p.name; }
        this.state.p = p;
        this.state.tour = 0;
      }
    } catch (e) {}
  }
  tiers() {
    return {
      t1: { label: 'Fully auto-filled', short: 'Filed by Claimclub', style: 'background:#12805C;color:#FFFFFF' },
      t2: { label: 'Auto-filled + 1 detail', short: 'Needs one detail from you', style: 'background:#3DDC97;color:#0A0F0D' },
      t3: { label: 'You file on the official site', short: 'Official site required', style: 'background:#FFF4D6;color:#6B4600' },
      t4: { label: 'Paid automatically', short: 'No claim needed', style: 'background:#ECF0FC;color:#2C4BB8' },
      t5: { label: 'Arbitration via partner firm', short: 'Partner law firm files', style: 'background:#EEF2EF;color:#43504A;box-shadow:inset 0 0 0 1px #C3CEC8' }
    };
  }
  fill() {
    return {
      apple: ['t2', 'Needs your iPhone serial number or Apple Account email.'], amazon: ['t4', 'Eligible customers are refunded automatically.'],
      goodrx: ['t1', 'Sworn statement only. No proof.'], cvs: ['t1', 'Sworn statement only for the $5 option.'], bofa: ['t1', 'Statement that your dispute was denied.'],
      squatch: ['t1', 'Up to 5 products without receipts.'], thinkware: ['t2', 'Needs your dash cam model and serial number.'], knotts: ['t1', 'Statement that you bought tickets online.'],
      kia: ['t3', 'Repair receipts and VIN are uploaded on the official site.'], vanilla: ['t2', 'Needs the drained card number.'], venetian: ['t2', 'Needs the notice ID from your email or letter.'],
      neutrogena: ['t1', 'Statement that you used Skin360 in Illinois.'], kroger: ['t2', 'Needs the notice ID and confirmation code.'], navy: ['t2', 'Needs the notice ID and PIN from your letter.'],
      bright: ['t2', 'Needs the notice ID from your letter.'], columbia: ['t1', 'Alternative cash option. Larger loss claims need receipts on the official site.'],
      pp: ['t1', 'No-proof cash option.'], sirva: ['t1', 'No-proof $50 option.'], bauer: ['t1', 'No-proof $45 option.'], woodloch: ['t1', 'No-proof $60 option.'],
      benkeith: ['t1', 'No-proof $35 option.'], safefleet: ['t2', 'Needs the login ID and PIN from your notice.'], tennis: ['t1', 'No-proof cash option.'],
      jbs: ['t3', 'Claims are for documented losses, uploaded on the official site.'], renal: ['t2', 'Needs your class member ID.'], prime: ['t1', 'Statement that you used the patient portal.'],
      nissan: ['t1', 'Needs only the phone number that got the texts.'], connectamerica: ['t1', 'Needs only the phone number that got the calls.'], indegene: ['t1', 'Needs only the phone number that got the texts.'],
      suffolk: ['t3', 'Violation numbers are entered on the county portal.'], ni: ['t3', 'Brokerage statements are uploaded on the official site.'], skin: ['t3', 'Brokerage statements are uploaded on the official site.'],
      marqeta: ['t3', 'Brokerage statements are uploaded on the official site.'], starbucks: ['t1', 'Statement that you got a COBRA notice.'], stv: ['t1', 'Statement that you applied in Washington.'],
      visa: ['t1', 'Statement that you paid out-of-network ATM fees.'], googleplay: ['t1', 'Needs only the email on your Google account.'], equifax: ['t2', 'Needs your Equifax dispute confirmation number.'],
      capone: ['t1', 'Statement that you were in the 401(k) plan.'], twitter: ['t3', 'Brokerage statements are uploaded on the official site.'], hyundaikia: ['t3', 'VIN and repair records go on the official site.'],
      toyota: ['t3', 'VIN and repair records go on the official site.'], tyson: ['t1', 'Statement of where and when you bought beef.'], westernunion: ['t3', 'Transfer records are filed with the remission administrator.'],
      seatgeek: ['t1', 'Needs only the email on your SeatGeek account.'], realpage: ['t2', 'Needs your building address and lease dates.'], deere: ['t2', 'Needs the dealer name and repair dates.'],
      upsfair: ['t3', 'Brokerage statements are uploaded on the official site.'], davita: ['t2', 'Needs the notice ID from your letter.'], harvard: ['t3', 'Family claims are handled on the official site.'],
      netflix: ['t5', 'You authorize a partner law firm to file for you.'], google: ['t5', 'You authorize a partner law firm to file for you.'], youtube: ['t5', 'You authorize a partner law firm to file for you.'],
      openai: ['t5', 'You authorize a partner law firm to file for you.'], ups: ['t5', 'You authorize a partner law firm to file for you.'], walgreens: ['t5', 'You authorize a partner law firm to file for you.'],
      disney: ['t5', 'You authorize a partner law firm to file for you.'], transunion: ['t5', 'You authorize a partner law firm to file for you.'], bestbuy: ['t5', 'You authorize a partner law firm to file for you.'],
      yahoo: ['t5', 'You authorize a partner law firm to file for you.'], dexcom: ['t5', 'You authorize a partner law firm to file for you.'], ubereats: ['t5', 'You authorize a partner law firm to file for you.'],
      smarttv: ['t5', 'You authorize a partner law firm to file for you.'], myfitnesspal: ['t5', 'You authorize a partner law firm to file for you.'], flo: ['t5', 'You authorize a partner law firm to file for you.'],
      bn: ['t5', 'You authorize a partner law firm to file for you.'], ubisoft: ['t5', 'You authorize a partner law firm to file for you.'], sandoz: ['t5', 'You authorize a partner law firm to file for you.'],
      equinox: ['t5', 'You authorize a partner law firm to file for you.'], onemain: ['t5', 'You authorize a partner law firm to file for you.'], pork: ['t5', 'You authorize a partner law firm to file for you.'],
      fanatics: ['t5', 'You authorize a partner law firm to file for you.'], lemonade: ['t5', 'You authorize a partner law firm to file for you.'], cone: ['t5', 'You authorize a partner law firm to file for you.'],
      duke: ['t5', 'You authorize a partner law firm to file for you.'], ey: ['t5', 'You authorize a partner law firm to file for you.'], hirevue: ['t5', 'You authorize a partner law firm to file for you.'],
      alo: ['t5', 'You authorize a partner law firm to file for you.'], apollomd: ['t5', 'You authorize a partner law firm to file for you.'], xactus: ['t5', 'You authorize a partner law firm to file for you.'],
      vesync: ['t5', 'You authorize a partner law firm to file for you.']
    };
  }
  mine() { if (this._sess) return this._sess.ids.filter(id => this.fill()[id]); return ['apple', 'goodrx', 'cvs', 'bofa', 'squatch', 'knotts', 'kroger', 'sirva', 'columbia', 'amazon', 'kia', 'venetian', 'ni', 'connectamerica', 'starbucks', 'visa', 'netflix', 'openai']; }
  renderVals() {
    const s = this.state, K = this.cats(), T = this.tiers(), F = this.fill(), L = this.logos();
    const all = this.data().filter(d => this.daysLeft(d.dl) > 0);
    const mineIds = this.mine();
    const sigOk = s.p.sig.trim().length > 1;
    const claimStatus = (d) => {
      const tier = F[d.id][0];
      if (tier === 't4') return 'auto';
      if (s.status[d.id]) return s.status[d.id];
      if (tier === 't3') return 'site';
      if (tier === 't2' && !(s.ids[d.id] || '').trim()) return 'needs';
      return 'ready';
    };
    const ST = {
      ready: ['Ready to sign', 'background:#E6F4EC;color:#0E6649'], needs: ['Needs info', 'background:#FFF4D6;color:#6B4600'],
      submitted: ['Submitted', 'background:#ECF0FC;color:#2C4BB8'], review: ['In review', 'background:#F3F0FB;color:#3B1F9E'],
      site: ['File on official site', 'background:#F3F6F4;color:#43504A;box-shadow:inset 0 0 0 1px #DDE5E0'], opened: ['Opened on site', 'background:#F3F6F4;color:#43504A'],
      auto: ['Paid automatically', 'background:#E9F6EF;color:#17603F']
    };
    const row = (d) => {
      const st = claimStatus(d), tier = F[d.id][0], c = K[d.cat], days = this.daysLeft(d.dl);
      return {
        id: d.id, co: d.co, title: d.title, logo: L[d.id] || '', hasLogo: !!L[d.id], noLogo: !L[d.id], initial: d.co.slice(0, 1), tileStyle: 'background:' + c.bg + ';color:' + c.fg,
        amt: d.cat === 'arb' ? 'Not guaranteed' : d.amt > 0 ? this.money(d.amt) : 'Varies', max: (d.max || d.amt) > 0 ? 'Up to ' + this.money(d.max || d.amt) : d.pay,
        deadline: this.fmtDate(d.dl), days: d.dl ? days + 'd left' : 'Ongoing', urgent: days <= 14, calm: days > 14, proof: d.proof,
        stLabel: ST[st][0], stStyle: 'font-size:12px;font-weight:800;padding:5px 10px;border-radius:99px;white-space:nowrap;' + ST[st][1],
        tierLabel: T[tier].label, tierStyle: 'font-size:12px;font-weight:800;padding:5px 10px;border-radius:99px;white-space:nowrap;' + T[tier].style, why: F[d.id][1],
        matched: mineIds.includes(d.id),
        needsYou: ['ready', 'needs', 'site', 'opened'].includes(st),
        stage: { ready: 0, needs: 0, site: 0, opened: 0, submitted: 1, review: 2, auto: 2 }[st],
        waiting: ({ ready: 'Waiting on you: review and sign the form', needs: 'Waiting on you: ' + F[d.id][1].replace(/^Needs /, 'add ').replace(/\.$/, ''), site: 'Waiting on you: finish on the official site. Your details are ready to copy.', opened: 'Waiting on you: finish on the official site', submitted: 'Waiting on the administrator to review your claim', review: 'Under review by the settlement administrator', auto: 'Nothing to do. You will be paid automatically.' })[st],
        waitWho: ['ready', 'needs', 'site', 'opened'].includes(st) ? 'you' : 'them',
        payWhen: d.cat === 'arb' ? 'Partner law firm reviewing' : 'Payouts start after final court approval',
        segs: ['Filed', 'In review', 'Approved', 'Paid'].map((lab, i) => ({ lab, style: 'flex:1;height:5px;border-radius:99px;background:' + (i < ({ ready: 0, needs: 0, site: 0, opened: 0, submitted: 1, review: 2, auto: 2 }[st]) ? '#12805C' : '#DDE5E0') })),
        stageLabel: ['Not filed yet', 'Filed', 'In review', 'Approved', 'Paid'][{ ready: 0, needs: 0, site: 0, opened: 0, submitted: 1, review: 2, auto: 3 }[st]],
        canSign: st === 'ready', canAdd: st === 'needs', canSite: st === 'site', done: ['submitted', 'review', 'auto', 'opened'].includes(st),
        doneLabel: st === 'auto' ? 'Nothing to do' : st === 'opened' ? 'Track it here' : 'We are tracking it',
        sign: () => sigOk ? this.setState({ status: Object.assign({}, s.status, { [d.id]: 'submitted' }), toast: d.co + ' claim submitted' }) : this.setState({ view: 'profile', toast: 'Add your signature first' }),
        add: () => this.setState({ view: 'profile', toast: 'Add the ' + d.co + ' detail below' }),
        site: () => this.setState({ status: Object.assign({}, s.status, { [d.id]: 'opened' }), toast: 'Your details were copied for the ' + d.co + ' site' })
      };
    };
    const mine = all.filter(d => mineIds.includes(d.id)).sort((a, b) => this.daysLeft(a.dl) - this.daysLeft(b.dl)).map(row);
    const est = all.filter(d => mineIds.includes(d.id)).reduce((t, d) => t + d.amt, 0);
    const counts = { ready: 0, needs: 0, filed: 0, site: 0 };
    all.filter(d => mineIds.includes(d.id)).forEach(d => { const st = claimStatus(d); if (st === 'ready') counts.ready++; else if (st === 'needs') counts.needs++; else if (st === 'site') counts.site++; else if (st === 'submitted' || st === 'review') counts.filed++; });
    const actions = [];
    if (counts.ready) actions.push({ text: 'Sign ' + counts.ready + ' claims that are ready to file', go: () => this.signAll(), cta: sigOk ? 'Sign all' : 'Add signature', tone: 'background:#0F3B2E;color:#FFFFFF' });
    mine.filter(r => r.canAdd).forEach(r => actions.push({ text: 'Add your ' + r.co + ' detail: ' + r.why.replace('Needs ', '').replace(/\.$/, ''), go: r.add, cta: 'Add info', tone: 'background:#FFFFFF;color:#0F3B2E;box-shadow:inset 0 0 0 1.5px #0F3B2E' }));
    mine.filter(r => r.urgent && !r.done).slice(0, 2).forEach(r => actions.push({ text: r.co + ' deadline in ' + r.days.replace('d left', ' days'), go: r.canSign ? r.sign : r.canAdd ? r.add : r.site, cta: 'Handle it', tone: 'background:#FDECEC;color:#B8333A' }));
    const fields = ['name', 'email', 'phone', 'street', 'city', 'st', 'zip', 'dob', 'payHandle', 'sig'];
    const filled = fields.filter(f => (s.p[f] || '').trim()).length;
    const pct = Math.round(filled / fields.length * 100);
    const filters = [['all', 'All'], ['t1', 'Fully auto-filled'], ['t2', 'Auto-filled + 1 detail'], ['t3', 'Official site'], ['t4', 'Automatic'], ['t5', 'Arbitration']];
    const list = all.filter(d => s.filter === 'all' || F[d.id][0] === s.filter).sort((a, b) => (mineIds.includes(b.id) ? 1 : 0) - (mineIds.includes(a.id) ? 1 : 0) || this.daysLeft(a.dl) - this.daysLeft(b.dl)).map(row);
    const tierCount = (t) => all.filter(d => F[d.id][0] === t).length;
    const STEPS = this.tourSteps();
    const STEPS_UNUSED = [
      { k: 'est', title: 'Your estimated total', body: 'This adds up the no-proof payouts from every settlement you matched. Courts set the final amounts, so treat it as a solid estimate.' },
      { k: 'act', title: 'Things only you can do', body: 'Sign a claim, add a notice ID, or beat a deadline. Clear this list and we handle everything else.' },
      { k: 'list', title: 'Every claim, one list', body: 'Each settlement you matched lives here. The colored pill on the right shows where that claim stands right now.' },
      { k: 'legend', title: 'How each claim gets filed', body: 'Most claims we pre-fill and submit after you e-sign. A few settlements only accept claims on their own site, and we walk you through those.' },
      { k: 'nav', title: 'Your info fills every claim', body: 'Name, address, payout method and signature. The more complete it is, the more claims we can file in one tap.' }
    ];
    const ti = s.tour;
    const on = (k) => ti >= 1 && ti <= STEPS.length && STEPS[ti - 1].k === k;
    const hl = (k) => 'position:relative';
    const cur = ti >= 1 && ti <= STEPS.length ? STEPS[ti - 1] : { title: '', body: '' };
    const set = (k, v) => this.setState({ p: Object.assign({}, s.p, { [k]: v }) });
    return {
      isDash: s.view === 'dash', isList: s.view === 'list', isProfile: s.view === 'profile',
      navDash: this.navStyle(s.view === 'dash'), navList: this.navStyle(s.view === 'list'), navProfile: this.navStyle(s.view === 'profile'),
      goDash: () => this.setState({ view: 'dash' }), goList: () => this.setState({ view: 'list' }), goProfile: () => this.setState({ view: 'profile' }),
      estLabel: this.money(est), maxLabel: 'Up to ' + this.money(all.filter(d => mineIds.includes(d.id)).reduce((t, d) => t + (d.max || d.amt), 0)) + ' with documentation',
      matchCount: mine.length, readyCount: counts.ready, needsCount: counts.needs, filedCount: counts.filed, siteCount: counts.site,
      mine: mine.filter(r => s.dashTab === 'all' || (s.dashTab === 'you' ? r.needsYou : !r.needsYou)),
      mineAll: mine, youN: mine.filter(r => r.needsYou).length, themN: mine.filter(r => !r.needsYou).length,
      tabAll: this.seg(s.dashTab === 'all'), tabYou: this.seg(s.dashTab === 'you'), tabThem: this.seg(s.dashTab === 'them'),
      setTabAll: () => this.setState({ dashTab: 'all' }), setTabYou: () => this.setState({ dashTab: 'you' }), setTabThem: () => this.setState({ dashTab: 'them' }),
      planLabel: ({ '1m': 'Monthly · $9.99/month', '3m': '3 months · $26.97', '6m': '6 months · $47.94' })[s.plan] || 'Filing fee · one-time', isMember: !!s.plan, notMember: !s.plan,
      actions, hasActions: actions.length > 0, noActions: actions.length === 0,
      signAll: () => this.signAll(),
      pct: pct + '%', pctBar: 'height:100%;border-radius:99px;background:#12805C;width:' + pct + '%', pctNote: pct === 100 ? 'Complete. Every claim can be pre-filled.' : (fields.length - filled) + ' fields left to pre-fill every claim',
      list, listCount: list.length + ' settlements', filters: filters.map(([id, label]) => ({ label, style: this.chip(s.filter === id), pick: () => this.setState({ filter: id }) })),
      c1: tierCount('t1'), c2: tierCount('t2'), c3: tierCount('t3'), c4: tierCount('t4'),
      tourOn: ti >= 1 && ti <= STEPS.length, tourOff: !(ti >= 1 && ti <= STEPS.length), tourIntro: ti === 0,
      tourTitle: cur.title, tourBody: cur.body, tourStep: 'Step ' + ti + ' of ' + STEPS.length, tourLast: ti === STEPS.length, tourMid: ti < STEPS.length,
      onEst: false, onAct: false, onList: false, onLegend: false, onNav: false,
      spotOn: !!(s.spot && ti >= 1 && ti <= STEPS.length), spotStyle: this.spotStyle(), bubbleStyle: this.bubbleStyle(),
      hlEst: hl('est'), hlAct: hl('act'), hlList: hl('list'), hlLegend: hl('legend'), hlNav: 'position:relative',
      dots: STEPS.map((x, i) => ({ style: 'width:' + (i + 1 === ti ? 18 : 7) + 'px;height:7px;border-radius:99px;background:' + (i + 1 === ti ? '#0F3B2E' : '#DDE5E0') })),
      startTour: () => this.setState({ tour: 1, view: 'dash' }), skipTour: () => this.setState({ tour: 99 }),
      nextTour: () => this.setState({ tour: ti + 1 > STEPS.length ? 99 : ti + 1 }), backTour: () => this.setState({ tour: Math.max(1, ti - 1) }),
      replay: () => this.setState({ tour: 1, view: 'dash' }),
      p: s.p, ids: s.ids, sigOk, sigMissing: !sigOk,
      setName: (e) => set('name', e.target.value), setEmail: (e) => set('email', e.target.value), setPhone: (e) => set('phone', e.target.value),
      setStreet: (e) => set('street', e.target.value), setCity: (e) => set('city', e.target.value), setSt: (e) => set('st', e.target.value), setZip: (e) => set('zip', e.target.value),
      setPrev: (e) => set('prev', e.target.value), setDob: (e) => set('dob', e.target.value), setPayHandle: (e) => set('payHandle', e.target.value), setSig: (e) => set('sig', e.target.value),
      payouts: ['PayPal', 'Venmo', 'Direct deposit', 'Paper check'].map(m => ({ label: m, style: this.chip(s.p.payout === m), pick: () => set('payout', m) })),
      vault: [['apple', 'Apple', 'iPhone serial number or Apple Account email'], ['kroger', 'Kroger', 'Notice ID and confirmation code'], ['venetian', 'The Venetian', 'Notice ID from your email']].map(([id, co, hint]) => ({
        id: 'v_' + id, co, hint, logo: L[id], value: s.ids[id], ok: !!(s.ids[id] || '').trim(), missing: !(s.ids[id] || '').trim(),
        onIn: (e) => this.setState({ ids: Object.assign({}, s.ids, { [id]: e.target.value }) })
      })),
      bankLinked: s.bank, bankNot: !s.bank, showBankBanner: !s.bank && s.bankBanner,
      connectBank: () => this.setState({ bank: true, toast: 'Bank connected. We will alert you when payouts land.' }),
      disconnectBank: () => this.setState({ bank: false, toast: 'Bank disconnected' }),
      dismissBank: () => this.setState({ bankBanner: false }),
      isSettings: s.view === 'settings', navSettings: this.navStyle(s.view === 'settings'), goSettings: () => this.setState({ view: 'settings' }),
      tabClaims: this.tabStyle(s.view === 'dash'), tabList: this.tabStyle(s.view === 'list'), tabSettings: this.tabStyle(s.view === 'settings' || s.view === 'profile'),
      subOpen: s.subOpen, subClosed: !s.subOpen, toggleSub: () => this.setState({ subOpen: !this.state.subOpen }),
      settingRows: this.settingRows(),
      logout: () => this.setState({ toast: 'Logged out (demo)' }),
      manageSub: () => this.setState({ toast: 'Opens billing portal: update card, view receipts, cancel' }),
      cancelSub: () => this.setState({ toast: 'Opens the cancel flow. No calls or emails needed.' }),
      toast: s.toast, hasToast: !!s.toast, clearToast: () => this.setState({ toast: '' })
    };
  }
  signAll() {
    const s = this.state, F = this.fill();
    if (s.p.sig.trim().length < 2) { this.setState({ view: 'profile', toast: 'Add your signature to sign claims' }); return; }
    const st = Object.assign({}, s.status); let n = 0;
    this.mine().forEach(id => { const tier = F[id][0]; if (st[id]) return; if (tier === 't1' || tier === 't5' || (tier === 't2' && (s.ids[id] || '').trim())) { st[id] = 'submitted'; n++; } });
    this.setState({ status: st, toast: n ? n + ' claims signed and submitted' : 'Nothing ready to sign' });
  }
  navStyle(on) { return 'display:flex;align-items:center;gap:12px;width:100%;min-height:46px;padding:0 14px;border-radius:12px;font-size:15px;font-weight:700;text-align:left;' + (on ? 'background:#EAF2EE;color:#0F3B2E' : 'background:transparent;color:#43504A'); }
  tourSteps() {
    return [
      { k: 'est', title: 'Your estimated total', body: 'This adds up the no-proof payouts from every settlement you matched. Courts set the final amounts, so treat it as a solid estimate.' },
      { k: 'act', title: 'Things only you can do', body: 'Sign a claim, add a notice ID, or beat a deadline. Clear this list and we handle everything else.' },
      { k: 'list', title: 'Every claim, one list', body: 'Each settlement you matched lives here. The colored pill on the right shows where that claim stands right now.' },
      { k: 'legend', title: 'How each claim gets filed', body: 'Most claims we pre-fill and submit after you e-sign. A few settlements only accept claims on their own site, and we walk you through those.' },
      { k: 'nav', title: 'Your info fills every claim', body: 'Name, address, payout method and signature. The more complete it is, the more claims we can file in one tap.' }
    ];
  }
  componentDidMount() { this._tm = setInterval(() => this.measureTour(), 120); }
  measureTour() {
    const ti = this.state.tour, S = this.tourSteps();
    if (!(ti >= 1 && ti <= S.length)) { if (this.state.spot) this.setState({ spot: null }); this._lastK = null; return; }
    if (typeof document === 'undefined') return;
    const k = S[ti - 1].k, root = document.querySelector('[data-tour-root]'), el = document.querySelector('[data-tour="' + k + '"]');
    if (!root || !el) return;
    if (this._lastK !== k) { this._lastK = k; try { el.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (e) {} }
    const r = root.getBoundingClientRect(), e = el.getBoundingClientRect();
    const sp = { x: Math.round(e.left - r.left), y: Math.round(e.top - r.top), w: Math.round(e.width), h: Math.round(e.height), W: Math.round(r.width), H: Math.round(r.height) };
    const o = this.state.spot;
    if (!o || ['x', 'y', 'w', 'h', 'W', 'H'].some(q => o[q] !== sp[q])) this.setState({ spot: sp });
  }
  spotStyle() {
    const p = this.state.spot, pad = 8, ease = 'cubic-bezier(.22,1,.36,1)';
    if (!p) return 'display:none';
    return 'position:absolute;z-index:60;pointer-events:none;border-radius:20px;left:' + (p.x - pad) + 'px;top:' + (p.y - pad) + 'px;width:' + (p.w + pad * 2) + 'px;height:' + (p.h + pad * 2) + 'px;box-shadow:0 0 0 4px #3DDC97,0 0 0 9999px rgba(10,15,13,.58);transition:left .55s ' + ease + ',top .55s ' + ease + ',width .55s ' + ease + ',height .55s ' + ease;
  }
  bubbleStyle() {
    const p = this.state.spot, pad = 8, BW = 320, BH = 250, ease = 'cubic-bezier(.22,1,.36,1)';
    if (!p) return 'display:none';
    const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
    let left, top;
    if (p.x + p.w + pad + 18 + BW <= p.W - 16) { left = p.x + p.w + pad + 18; top = clamp(p.y, 16, p.H - BH - 16); }
    else if (p.x - pad - 18 - BW >= 16) { left = p.x - pad - 18 - BW; top = clamp(p.y, 16, p.H - BH - 16); }
    else { left = clamp(p.x, 16, p.W - BW - 16); top = p.y + p.h + pad + 16 + BH <= p.H ? p.y + p.h + pad + 16 : clamp(p.y - pad - 16 - BH, 16, p.H - BH - 16); }
    return 'position:absolute;z-index:70;width:' + BW + 'px;max-width:calc(100% - 32px);left:' + left + 'px;top:' + top + 'px;background:#FFFFFF;color:#0A0F0D;border-radius:18px;padding:18px;box-sizing:border-box;box-shadow:0 24px 60px rgba(0,0,0,.35);display:flex;flex-direction:column;gap:10px;text-align:left;transition:left .55s ' + ease + ',top .55s ' + ease;
  }
  settingRows() {
    const s = this.state;
    const I = {
      bell: 'M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9 M10.3 21a1.94 1.94 0 0 0 3.4 0',
      mail: 'M22 7l-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7 M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z',
      clip: 'M9 2h6a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H9a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1z M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2 M12 11h4 M12 16h4 M8 11h.01 M8 16h.01',
      pen: 'M12 20h9 M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z',
      shield: 'M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z M12 8v4 M12 16h.01',
      file: 'M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z M14 2v4a2 2 0 0 0 2 2h4 M10 9H8 M16 13H8 M16 17H8',
      building: 'M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2 M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2 M10 6h4 M10 10h4 M10 14h4 M10 18h4'
    };
    const tog = (k, label, icon) => ({ label, icon: I[icon], isToggle: true, isNav: false, isExt: false, on: !!s[k], act: () => this.setState({ [k]: !this.state[k] }),
      track: 'width:50px;height:30px;flex:none;border-radius:99px;padding:2px;box-sizing:border-box;display:flex;transition:background .2s;' + (s[k] ? 'background:#12805C;justify-content:flex-end' : 'background:#C3CEC8;justify-content:flex-start'),
      knob: 'width:26px;height:26px;border-radius:50%;background:#FFFFFF;box-shadow:0 1px 3px rgba(0,0,0,.25)' });
    const nav = (label, icon, act) => ({ label, icon: I[icon], isToggle: false, isNav: true, isExt: false, act });
    const ext = (label, icon) => ({ label, icon: I[icon], isToggle: false, isNav: false, isExt: true, act: () => this.setState({ toast: label + ' opens in a new tab' }) });
    return [tog('push', 'Push notifications', 'bell'), tog('emails', 'Deadline emails', 'mail'), nav('Saved information', 'clip', () => this.setState({ view: 'profile' })),
      ext('Claim Filing Authorization Agreement', 'pen'), ext('Privacy Policy', 'shield'), ext('Terms & Conditions', 'file'), ext('About Claimclub', 'building')];
  }
  tabStyle(on) { return 'flex:1;display:flex;flex-direction:column;align-items:center;gap:3px;background:transparent;padding:8px 0 6px;font-size:11.5px;font-weight:700;' + (on ? 'color:#0F3B2E' : 'color:#8A968F'); }
  seg(on) { return 'min-height:34px;padding:0 12px;border-radius:99px;font-size:13px;font-weight:800;white-space:nowrap;' + (on ? 'background:#0F3B2E;color:#FFFFFF' : 'background:#F3F6F4;color:#43504A'); }
  chip(on) { return 'min-height:38px;padding:0 14px;border-radius:999px;font-size:13px;font-weight:700;white-space:nowrap;' + (on ? 'background:#0F3B2E;color:#FFFFFF' : 'background:#FFFFFF;color:#0F3B2E;box-shadow:inset 0 0 0 1px #DDE5E0'); }
  componentDidUpdate() {
    if (this.state.toast && !this._tt) { this._tt = setTimeout(() => { this._tt = null; this.setState({ toast: '' }); }, 2600); }
  }
  componentWillUnmount() { clearTimeout(this._tt); clearInterval(this._tm); }
