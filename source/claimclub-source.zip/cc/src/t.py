import re,sys
pre=[('rgba(18,128,92,.55)','rgba(236,72,153,.42)'),('rgba(18,128,92,0)','rgba(236,72,153,0)')]
M={'#0F3B2E':'#2B1A6B','#3DDC97':'#FFC93C','#5B6862':'#5B5378','#DDE5E0':'#E4DEF5','#0A0F0D':'#1D1438','#43504A':'#4B4467','#12805C':'#4A2FA8','#F3F6F4':'#F4F1FB','#E8EEEA':'#EEEAF7','#C9D6CF':'#CFC4F5','#D7E3DC':'#E4DCFF','#0E6649':'#4A2FA8','#EAF2EE':'#EFEAFB','#C3CEC8':'#CFC6E6','#2F5D4E':'#4A2FA8','rgba(18,128,92,':'rgba(74,47,168,','#B7EFD3':'#FFE7A3','#EEF2EF':'#F1EEF8','#EAF9F1':'#F1EEF8','#E6F4EC':'#F1EEF8','#E5EDEA':'#F1EEF8','#E3FAEF':'#FFF8E1','#E3ECE8':'#F1EEF8','#C9D9CF':'#D6CDF0','rgba(5,33,26,0)':'rgba(24,13,69,0)','rgba(31,122,87,0)':'rgba(107,63,216,0)','#1F7A57':'#6B3FD8','#134A39':'#3A2590','#0A2C22':'#22145C','#05211A':'#180D45','rgba(61,220,151,':'rgba(255,201,60,','rgba(10,15,13,':'rgba(29,20,56,','#EEF6F1':'#F1EEFB','#CFDAD3':'#D9D2EE','#B9D3C5':'#C8BEEA','#B9CCC2':'#CFC4F5','#6E7A73':'#7A7096','#33433B':'#3A3354','#F8FAF9':'#FBFAFE'}
cats="""  cats() {
    return {
      privacy: { bg: '#1E88E5', fg: '#FFFFFF', tint: '#EAF4FD', ink: '#1262A8', label: 'Data & privacy' },
      products: { bg: '#FF8A1F', fg: '#2B1A6B', tint: '#FFF1E3', ink: '#B85A00', label: 'Products' },
      auto: { bg: '#2DB34A', fg: '#0C3315', tint: '#E8F7EC', ink: '#1E7D33', label: 'Auto' },
      bank: { bg: '#FFC93C', fg: '#2B1A6B', tint: '#FFF8E1', ink: '#8A6200', label: 'Banking & fees' },
      apps: { bg: '#EC4899', fg: '#FFFFFF', tint: '#FDE9F3', ink: '#A8256A', label: 'Apps & services' },
      health: { bg: '#EF3B3B', fg: '#FFFFFF', tint: '#FDECEC', ink: '#A82424', label: 'Health' },
      invest: { bg: '#4A2FA8', fg: '#FFFFFF', tint: '#F1EEF8', ink: '#4A2FA8', label: 'Investor & employee' },
      arb: { bg: '#5B5378', fg: '#FFFFFF', tint: '#F1EEF8', ink: '#4B4467', label: 'Arbitration' }
    };
  }
  skin() {"""
def conv(s):
    s=re.sub(r"  cats\(\) \{\n    return \{\n      privacy: \{ bg: '#0F3B2E'.*?\n  skin\(\) \{",lambda m:'@@CATS@@',s,count=1,flags=re.S)
    for a,b in pre: s=s.replace(a,b)
    for a,b in M.items(): s=s.replace(a,b)
    return s.replace('@@CATS@@',cats)
files={'LandingG2':'LandingT','LandingG2M':'LandingTM','FlowG2D':'FlowTD','FlowG2':'FlowT','Main':'MainT'}
for a in sys.argv[1:]:
    b=files[a]
    s=conv(open('../project/'+a+'.dc.html').read())
    s=s.replace('FlowG2D.dc.html','FlowTD.dc.html').replace('FlowG2.dc.html','FlowT.dc.html')
    s=re.sub(r'<title>(.*?)</title>',lambda m:'<title>'+m.group(1)+' (Trivia Crack colors)</title>',s,count=1)
    open('../project/'+b+'.dc.html','w').write(s)
    print(b)
