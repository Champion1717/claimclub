#!/usr/bin/env python3
"""Settlement catalog tool (Nov 23 2026). Used by the daily settlement check and by hand.

The catalog lives in several places; this keeps them in step:
  cc/src/data.js            homepage, claim flow quiz and totals (one entry per line in data())
  cc/concepts/sets.json     public /settlements pages, admin names, member app (embedded as sets0() in make.py)
  cc/data/filing_specs.json how each claim is filed (shipped as api/_specs.json)
Supabase `catalog_extra` (hidden / is_new) and `settlement_filing` override these at runtime; the daily
check updates them with SQL as well (this tool prints the SQL).

Commands (run from anywhere):
  python3 catalog.py status                 JSON summary: every entry with id, co, title, dl, cat, mode, st, closed,
                                            in_data, form_url, admin, plus lists expired / open / closed
  python3 catalog.py close ID [ID...]       take settlements off the site: removed from data.js, marked
                                            "closed": true in sets.json, spec type "closed" (prints the SQL for Supabase)
  python3 catalog.py add FILE.json          add new settlements: FILE is a list of {"entry": {...}, "spec": {...}}
                                            entry needs id, co, title, cat, pay, amt, max, proof, mode, dl, who
                                            (fund, st, area optional); spec is a filing spec (optional)
  python3 catalog.py update ID key=value... change fields on a live entry (dl, pay, amt, max, who, proof, fund...)
                                            in data.js and sets.json (numbers are parsed, null clears)
After any change: run `python3 make.py` in cc/concepts (+ the sed from CLAUDE.md), then the normal rebuild.
"""
import json, os, re, sys, datetime

CC = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
DATA = os.path.join(CC, 'src', 'data.js')
SETS = os.path.join(CC, 'concepts', 'sets.json')
SPECS = os.path.join(CC, 'data', 'filing_specs.json')
MAKE = os.path.join(CC, 'concepts', 'make.py')
FIELDS = ['id', 'co', 'title', 'cat', 'pay', 'amt', 'max', 'proof', 'mode', 'dl', 'who', 'fund', 'st', 'area']
CATS = ['products', 'privacy', 'apps', 'bank', 'health', 'auto', 'invest', 'arb']

def today():
    os.environ.setdefault('TZ', 'America/Los_Angeles')
    try:
        import zoneinfo
        return datetime.datetime.now(zoneinfo.ZoneInfo('America/Los_Angeles')).date().isoformat()
    except Exception:
        return datetime.date.today().isoformat()

def load_data_lines():
    s = open(DATA).read()
    i = s.index('  data() {')
    j = s.index('    return [', i) + len('    return [')
    k = s.index('\n    ];', j)
    return s, j, k

def data_ids():
    s, j, k = load_data_lines()
    return re.findall(r"^\s*\{ id: '([^']+)'", s[j:k], re.M)

def jsv(v):
    if v is None: return 'null'
    if isinstance(v, bool): return 'true' if v else 'false'
    if isinstance(v, (int, float)): return json.dumps(v)
    return "'" + str(v).replace('\\', '\\\\').replace("'", "\\'") + "'"

def js_line(e):
    # One line, same shape as the existing entries (JSON is valid JS).
    d = {k: e.get(k, '' if k in ('fund', 'st', 'area') else None) for k in FIELDS}
    body = ', '.join(k + ': ' + jsv(d[k]) for k in FIELDS if not (k in ('fund', 'st', 'area') and not d[k]))
    return '      { ' + body + ' },'

def load(p): return json.load(open(p))
def save_sets(sets):
    open(SETS, 'w').write(json.dumps(sets, separators=(',', ':'), ensure_ascii=False))
    s = open(MAKE).read()
    i = s.index('  sets0() { return '); j = s.index('\n', i)
    s = s[:i] + '  sets0() { return ' + open(SETS).read().strip().replace('\\"', '\\\\"') + '; }' + s[j:]
    open(MAKE, 'w').write(s)
def save_specs(specs):
    open(SPECS, 'w').write(json.dumps(specs, indent=1, ensure_ascii=False))

def sql_hide(ids):
    vals = ','.join("('%s', '{}'::jsonb, false, true, now(), 'daily check')" % i.replace("'", "''") for i in ids)
    return ("insert into catalog_extra (id, data, is_new, hidden, updated_at, updated_by) values " + vals +
            " on conflict (id) do update set hidden = true, updated_at = now(), updated_by = 'daily check';")

def status():
    sets, specs, ids = load(SETS), {x['id']: x for x in load(SPECS)}, set(data_ids())
    t = today(); out = []
    for e in sets:
        sp = specs.get(e['id'], {})
        out.append({'id': e['id'], 'co': e['co'], 'title': e['title'], 'dl': e.get('dl'), 'cat': e.get('cat'), 'mode': e.get('mode'), 'st': e.get('st', ''),
                    'closed': bool(e.get('closed')), 'in_data': e['id'] in ids, 'form_url': sp.get('form_url'), 'admin': sp.get('admin'), 'type': sp.get('type')})
    live = [x for x in out if not x['closed'] and x['in_data']]
    print(json.dumps({'today': t, 'count': len(out), 'live': len(live),
                      'expired': [x['id'] for x in live if x['dl'] and x['dl'] < t],
                      'no_deadline': [x['id'] for x in live if not x['dl']],
                      'closed': [x['id'] for x in out if x['closed']], 'entries': out}, indent=1))

def close(ids):
    sets, specs = load(SETS), load(SPECS)
    known = {e['id'] for e in sets}
    bad = [i for i in ids if i not in known]
    if bad: sys.exit('Unknown ids: ' + ', '.join(bad))
    s, j, k = load_data_lines()
    lines = s[j:k].split('\n')
    keep = [l for l in lines if not any(re.match(r"^\s*\{ id: '" + re.escape(i) + "'", l) for i in ids)]
    s = s[:j] + '\n'.join(keep) + s[k:]
    open(DATA, 'w').write(s)
    for e in sets:
        if e['id'] in ids: e['closed'] = True
    for sp in specs:
        if sp['id'] in ids: sp['type'] = 'closed'; sp['filer'] = 'none'
    save_sets(sets); save_specs(specs)
    print('Closed: ' + ', '.join(ids))
    print('SQL for Supabase:\n' + sql_hide(ids))
    print("update settlement_filing set type = 'closed', filer = 'none', updated_at = now(), updated_by = 'daily check' where id in (" + ','.join("'%s'" % i for i in ids) + ");")

def add(path):
    items = load(path)
    sets, specs = load(SETS), load(SPECS)
    known, ids = {e['id'] for e in sets}, data_ids()
    s, j, k = load_data_lines()
    new_lines = []
    for it in items:
        e = it['entry']
        e['id'] = re.sub(r'[^a-z0-9_]+', '_', e['id'].lower()).strip('_')
        miss = [f for f in ('id', 'co', 'title', 'cat', 'pay', 'proof', 'mode', 'who') if not e.get(f)]
        if miss: sys.exit(e.get('id', '?') + ' is missing ' + ', '.join(miss))
        if e['cat'] not in CATS: sys.exit(e['id'] + ': cat must be one of ' + ', '.join(CATS))
        if e['mode'] not in ('here', 'site', 'auto'): sys.exit(e['id'] + ': mode must be here, site or auto')
        if e['id'] in known or e['id'] in ids: sys.exit(e['id'] + ' already exists')
        e.setdefault('amt', 0); e.setdefault('max', 0); e.setdefault('dl', None)
        for f in ('fund', 'st', 'area'): e.setdefault(f, '')
        new_lines.append(js_line(e))
        sets.append({f: e.get(f) for f in FIELDS})
        if it.get('spec'):
            sp = dict(it['spec']); sp['id'] = e['id']; specs = [x for x in specs if x['id'] != e['id']] + [sp]
        known.add(e['id'])
    head = s[:k].rstrip()
    if not head.endswith(',') and not head.endswith('['): head += ','
    s = head + '\n' + '\n'.join(new_lines) + s[k:]
    open(DATA, 'w').write(s)
    save_sets(sets); save_specs(specs)
    print('Added: ' + ', '.join(json.loads('[' + ','.join(json.dumps(i['entry']['id']) for i in items) + ']')))

def update(i, pairs):
    sets = load(SETS)
    e = next((x for x in sets if x['id'] == i), None)
    if not e: sys.exit('Unknown id ' + i)
    ch = {}
    for p in pairs:
        key, _, v = p.partition('=')
        if key not in FIELDS or key == 'id': sys.exit('Bad field ' + key)
        if v == 'null': val = None
        elif key in ('amt', 'max'): val = float(v) if '.' in v else int(v)
        else: val = v
        ch[key] = val
    e.update(ch)
    s, j, k = load_data_lines()
    lines = s[j:k].split('\n')
    for n, l in enumerate(lines):
        if re.match(r"^\s*\{ id: '" + re.escape(i) + "'", l):
            for key, val in ch.items():
                pat = re.compile(r"(\b" + key + r": )('(?:[^'\\]|\\.)*'|\"(?:[^\"\\]|\\.)*\"|null|[-\d.]+)")
                if pat.search(l): l = pat.sub(lambda m: m.group(1) + jsv(val), l, count=1)
                else: l = re.sub(r' \},?$', lambda m: ', ' + key + ': ' + jsv(val) + m.group(0), l, count=1)
            lines[n] = l
    s = s[:j] + '\n'.join(lines) + s[k:]
    open(DATA, 'w').write(s)
    save_sets(sets)
    print('Updated ' + i + ': ' + json.dumps(ch))

if __name__ == '__main__':
    a = sys.argv[1:]
    if not a or a[0] == 'status': status()
    elif a[0] == 'close': close(a[1:])
    elif a[0] == 'add': add(a[1])
    elif a[0] == 'update': update(a[1], a[2:])
    else: print(__doc__)
