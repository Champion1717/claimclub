from playwright.sync_api import sync_playwright
import json
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  for W,H,pre in [(1440,900,'d'),(390,844,'m')]:
    ctx=b.new_context(viewport={'width':W,'height':H});pg=ctx.new_page();e=[];pg.on('pageerror',lambda x:e.append(str(x)))
    # full flow end: start page, fake session via flow then go to app
    pg.goto(f'http://localhost:8790/{pre}/start.html');pg.wait_for_timeout(700)
    pg.evaluate('''localStorage.clear();localStorage.setItem('claimclub_session',JSON.stringify({ids:['apple','visa','googleplay','cvs','amazon'],signed:['apple','cvs'],bank:false,plan:'3m',paid:'member',p:{name:'Maria Lopez',email:'maria.lopez@example.com',phone:'',street:'88 Pine St',city:'Seattle',st:'WA',zip:'98101',dob:''}}))''')
    print(pre,'session',pg.evaluate("localStorage.getItem('claimclub_session')")[:160])
    pg.goto(f'http://localhost:8790/{pre}/app.html');pg.wait_for_timeout(900)
    t=pg.inner_text('body');print(pre,'greet', [l for l in t.split('\n') if 'Hi ' in l][:1], '|', [l for l in t.split('\n') if 'Step' in l or 'Finish' in l][:2])
    pg.screenshot(path=f'/tmp/live_{pre}_dash.png')
    pg.locator('section[aria-label="Ready to file"] button:has-text("File")').first.click();pg.wait_for_timeout(1300)
    pg.reload();pg.wait_for_timeout(800);print(pre,'after reload tracking',pg.locator('section[aria-label="Tracking"]').inner_text()[:120].replace('\n',' | '))
    pg.locator('button:has-text("Settings")').first.click();pg.locator('button:has-text("Dark")').click();pg.wait_for_timeout(200)
    pg.locator('button:has-text("Manage membership")').click();pg.wait_for_timeout(300);pg.screenshot(path=f'/tmp/live_{pre}_mm.png')
    pg.locator('[role=dialog] button:has-text("6 months")').click();pg.locator('[role=dialog] button:has-text("Switch to")').click();pg.wait_for_timeout(300)
    pg.locator('button:has-text("Manage membership")').click();pg.locator('[role=dialog] button:has-text("Cancel membership")').click();pg.wait_for_timeout(200);pg.screenshot(path=f'/tmp/live_{pre}_cancel.png')
    pg.locator('[role=dialog] button:has-text("Cancel membership")').last.click();pg.wait_for_timeout(200);print(pre,'done',pg.locator('[role=dialog]').inner_text()[:60])
    pg.locator('[role=dialog] button:has-text("Done")').click();pg.reload();pg.wait_for_timeout(700);print(pre,'theme kept',pg.evaluate("document.querySelector('.dk')!==null"),'plan line',[l for l in pg.inner_text('body').split('\n') if 'Ends' in l or 'month' in l.lower()][:2])
    pg.locator('button:has-text("All settlements"), button:has-text("Settlements")').first.click();pg.locator('button:has-text("Near you")').click();pg.wait_for_timeout(200);print(pre,'near',pg.locator('text=/Near you/').first.inner_text())
    print(pre,'errs',e);ctx.close()
  b.close()
