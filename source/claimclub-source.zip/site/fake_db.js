// In-memory stand-in for the Supabase client calls our API functions use.
const T = {};
const NUM = ['bot_runs', 'claims', 'claim_events', 'email_log']; let SEQ = 100;
const STORE = { url: 'http://localhost:8798/store/' };
function q(table) {
  const st = { table, f: [], op: 'select', rows: null, opts: {}, single: false, order: null, lim: null, head: false };
  const api = {
    select(c, o) { if (st.op === 'select') st.op = 'select'; st.sel = true; if (o && o.head) st.head = true; return api; },
    eq(k, v) { st.f.push((r) => r[k] === v); return api; }, neq(k, v) { st.f.push((r) => r[k] !== v); return api; },
    gte(k, v) { st.f.push((r) => String(r[k]) >= String(v)); return api; }, lt(k, v) { st.f.push((r) => String(r[k]) < String(v)); return api; }, in(k, v) { st.f.push((r) => v.includes(r[k])); return api; },
    order(k, o) { st.order = [k, o && o.ascending === false ? -1 : 1]; return api; }, limit(n) { st.lim = n; return api; }, range(a, b) { st.rng = [a, b]; return api; }, not(k, op, v) { st.f.push((r) => !(op === 'is' ? r[k] == v : r[k] === v)); return api; },
    or(expr) { const parts = String(expr).split(/,(?![^(]*\))/); st.f.push((r) => parts.some((p) => { const m = p.match(/^([a-z_]+)\.(eq|ilike|in)\.(.*)$/); if (!m) return false; const v = String(r[m[1]] == null ? '' : r[m[1]]).toLowerCase(); if (m[2] === 'eq') return v === m[3].toLowerCase(); if (m[2] === 'in') return m[3].replace(/[()"]/g, '').toLowerCase().split(',').includes(v); return v.includes(m[3].replace(/%/g, '').toLowerCase()); })); return api; },
    insert(rows) { st.op = 'insert'; st.rows = [].concat(rows); return api; },
    upsert(rows, o) { st.op = 'upsert'; st.rows = [].concat(rows); st.key = (o && o.onConflict) || 'id'; return api; },
    update(v) { st.op = 'update'; st.val = v; return api; }, delete() { st.op = 'delete'; return api; },
    maybeSingle() { st.single = true; return api; }, single() { st.single = true; return api; },
    then(res, rej) { try { res(run(st)); } catch (e) { rej(e); } }
  };
  return api;
}
function run(st) {
  const t = (T[st.table] = T[st.table] || []);
  const match = (r) => st.f.every((f) => f(r));
  if (st.op === 'insert') { const out = st.rows.map((r) => Object.assign({ id: NUM.includes(st.table) ? ++SEQ : Math.random().toString(36).slice(2), created_at: new Date().toISOString(), status: r.status || 'requested' }, r)); t.push(...out); return { data: st.single ? out[0] : out, error: null }; }
  if (st.op === 'upsert') { st.rows.forEach((r) => { const i = t.findIndex((x) => x[st.key] === r[st.key]); if (i >= 0) Object.assign(t[i], r); else t.push(Object.assign({}, r)); }); return { data: null, error: null }; }
  if (st.op === 'update') { const hit = t.filter(match); hit.forEach((r) => Object.assign(r, st.val)); return { data: st.sel ? (st.single ? (hit[0] ? Object.assign({}, hit[0]) : null) : hit.map((r) => Object.assign({}, r))) : null, error: null }; }
  if (st.op === 'delete') { const keep = t.filter((r) => !match(r)); const n = t.length - keep.length; T[st.table] = keep;
    if (st.table === 'plaid_items') ['plaid_accounts', 'bank_transactions', 'bank_recurring'].forEach((c) => { T[c] = (T[c] || []).filter((r) => keep.some((k) => k.item_id === r.item_id)); });
    return { data: null, error: null, count: n }; }
  let out = t.filter(match);
  if (st.order) out = out.slice().sort((a, b) => (a[st.order[0]] > b[st.order[0]] ? 1 : -1) * st.order[1]);
  if (st.lim) out = out.slice(0, st.lim);
  const cnt = out.length; if (st.rng) out = out.slice(st.rng[0], st.rng[1] + 1);
  if (st.head) return { data: null, count: out.length, error: null };
  return { data: st.single ? (out[0] ? Object.assign({}, out[0]) : null) : out.map((r) => Object.assign({}, r)), error: null, count: cnt };
}
const storage = { from: (bucket) => ({
  createSignedUploadUrl: async (path) => ({ data: { signedUrl: STORE.url + bucket + '/' + path, token: 't' }, error: null }),
  createSignedUrls: async (paths) => ({ data: paths.map((p) => ({ path: p, signedUrl: STORE.url + bucket + '/' + p })), error: null }),
  createSignedUrl: async (p) => ({ data: { signedUrl: STORE.url + bucket + '/' + p }, error: null }) }) };
module.exports = { T, STORE, db: () => ({ from: q, storage, rpc: async (n, a) => ({ data: n === 'admin_daily' ? Array.from({ length: a.p_days }, (_, i) => ({ day: new Date(Date.now() - (a.p_days - 1 - i) * 864e5).toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' }), visitors: 10 + i })) : [], error: null }) }) };
