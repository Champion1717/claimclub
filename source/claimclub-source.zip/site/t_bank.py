from playwright.sync_api import sync_playwright
import json
FAKE=open('/tmp/fake_supabase.js').read()
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  for on in [False,True]:
    ctx=b.new_context(viewport={'width':390,'height':844});pg=ctx.new_page();e=[];pg.on('pageerror',lambda x:e.append(str(x)))
    cfg=json.dumps({'supabaseUrl':'https://x.supabase.co','supabaseAnonKey':'anon','testMode':True,'bankConnect':on})
    ctx.route('**/api/config',lambda r:r.fulfill(status=200,content_type='application/json',body=cfg))
    ctx.route('**/supabase-js@2/**',lambda r:r.fulfill(status=200,content_type='application/javascript',body=FAKE))
    ctx.route('**/api/membership',lambda r:r.fulfill(status=200,content_type='application/json',body='{"membership":null}'))
    ctx.route('**/api/track',lambda r:r.fulfill(status=200,body='{}'))
    pg.goto('http://localhost:8790/m/start.html');pg.wait_for_timeout(900)
    pg.evaluate("__dc.setState({a:{q0:['apple']},email:'member@example.com',paid:'member',plan:'1m',pi:2,step:__dc.steps().indexOf('perks')})");pg.wait_for_timeout(400)
    dots=pg.evaluate("[...document.querySelectorAll('span')].filter(x=>x.getAttribute('style')&&x.getAttribute('style').includes('border-radius:99px')&&x.offsetParent&&x.offsetWidth<40&&x.offsetHeight<8).length")
    print('bank',on,'steps has bank',pg.evaluate("__dc.steps().includes('bank')"),'visible dots',dots)
    pg.get_by_role('button',name='Next',exact=True).click();pg.wait_for_timeout(900);print('  after last perk ->',pg.url.split('/')[-1], pg.evaluate("typeof __dc!=='undefined' && __dc.stepName ? __dc.stepName() : ''"))
    # dashboard
    pg.goto('http://localhost:8790/m/index.html');pg.evaluate('''localStorage.clear();localStorage.setItem('claimclub_session',JSON.stringify({ids:['apple','cvs'],signed:['apple'],bank:false,plan:'1m',paid:'member',p:{name:'Maria Lopez',email:'member@example.com',phone:'',street:'88 Pine St',city:'Seattle',st:'WA',zip:'98101',dob:''}}))''')
    pg.goto('http://localhost:8790/m/app.html');pg.wait_for_timeout(1000);pg.click('text=Email me a code');pg.wait_for_timeout(300)
    pg.locator('input[autocomplete="one-time-code"]').type('123456',delay=20);pg.wait_for_timeout(1500)
    setup=pg.evaluate("__dc.setup().map(x=>x.id).join(',')")
    pg.evaluate("__dc.setState({view:'info'})");pg.wait_for_timeout(300)
    t=pg.inner_text('body')
    print('  setup',setup,'| direct deposit shown','Direct deposit' in t,'| bank row','No bank connected' in t, e)
    pg.screenshot(path=f'/tmp/bank_{on}.png');ctx.close()
  b.close()
