from playwright.sync_api import sync_playwright
import json
FAKE=open('/tmp/fake_supabase.js').read()
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  for w,h in [(1440,900),(390,844)]:
    ctx=b.new_context(viewport={'width':w,'height':h});pg=ctx.new_page();e=[];pg.on('pageerror',lambda x:e.append(str(x)))
    ctx.route('**/supabase-js@2/**',lambda r:r.fulfill(status=200,content_type='application/javascript',body=FAKE))
    ctx.route('**/api/config',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'supabaseUrl':'https://x.supabase.co','supabaseAnonKey':'anon','testMode':True})))
    pg.goto('http://localhost:8790/login?login=member%40example.com');pg.wait_for_timeout(1500)
    print(w,'title',pg.locator('h1').first.inner_text(),'| email',pg.locator('input[type=email]').input_value())
    pg.screenshot(path=f'/tmp/lg2_{w}_login.png')
    i=pg.locator('input[type=email]');i.fill('nobody@example.com');i.dispatch_event('change')
    pg.locator('button:has-text("Email me a code")').click();pg.wait_for_timeout(600)
    print(w,'unknown ->',pg.locator('[role=alert]').inner_text(),'| otp sent to',pg.evaluate('window.__otpTo||null'))
    pg.screenshot(path=f'/tmp/lg2_{w}_unknown.png')
    i.fill('member@example.com');i.dispatch_event('change');pg.locator('button:has-text("Email me a code")').click();pg.wait_for_timeout(600)
    print(w,'member ->',pg.locator('h1').first.inner_text(),'| otp sent to',pg.evaluate('window.__otpTo||null'))
    print(w,'errors',e); ctx.close()
  b.close()
