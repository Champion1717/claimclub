from playwright.sync_api import sync_playwright
import json
def sess(plan,st):
  return json.dumps({"ids":["apple","goodrx"],"signed":["apple"],"bank":False,"plan":plan,"paid":"member" if plan else "fee","p":{"name":"Ana Ruiz","email":"ana@gmail.com","phone":"9165550142","street":"1452 Maple Ave","city":"Sacramento","st":st,"zip":"95814","dob":""}})
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  for plan,st,tag in [('1m','CA','member'),('','CA','fee'),('6m','WA','memberWA')]:
    pg=b.new_page(viewport={'width':1440,'height':900});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://localhost:8790/d/index.html');pg.evaluate(f"localStorage.setItem('claimclub_session',{json.dumps(sess(plan,st))})")
    pg.goto('http://localhost:8790/d/app.html');pg.wait_for_timeout(900)
    pg.evaluate("__dc.setState({tour:99})");pg.wait_for_timeout(300)
    banner=pg.evaluate("(document.body.innerText.match(/Local scan:[^\\n]*/)||[null])[0]")
    pg.evaluate("__dc.setState({view:'list'})");pg.wait_for_timeout(500)
    rows=pg.evaluate("__dc.renderVals().list.length");lab=pg.evaluate("[__dc.renderVals().scopeAllLabel,__dc.renderVals().scopeNearLabel,__dc.renderVals().locked,__dc.renderVals().lockedN]")
    if tag=='member': pg.screenshot(path='/tmp/site/app_all.png')
    if tag=='fee': pg.evaluate("document.querySelector('main, .scroll, body').scrollTo(0,99999)");pg.screenshot(path='/tmp/site/app_fee.png',full_page=False)
    pg.evaluate("__dc.setState({scope:'near'})");pg.wait_for_timeout(400)
    near=pg.evaluate("__dc.renderVals().list.map(r=>r.co+' ('+r.area+')').slice(0,6)")
    if tag=='member': pg.screenshot(path='/tmp/site/app_near.png')
    pg.evaluate("__dc.setState({scope:'all',q:'tesla'})");q0=pg.evaluate("__dc.renderVals().list.length")
    pg.evaluate("__dc.setState({q:'seattle'})");q1=pg.evaluate("__dc.renderVals().list.map(r=>r.co)")
    print(tag,'banner:',banner,'| rows',rows,lab,'| near',near,'| q tesla',q0,'q seattle',q1,errs)
  m=b.new_page(viewport={'width':390,'height':844});m.goto('http://localhost:8790/m/index.html');m.evaluate(f"localStorage.setItem('claimclub_session',{json.dumps(sess('1m','CA'))})")
  m.goto('http://localhost:8790/m/app.html');m.wait_for_timeout(900);m.evaluate("__dc.setState({tour:99})");m.wait_for_timeout(300);m.screenshot(path='/tmp/site/appm_dash.png')
  m.evaluate("__dc.setState({view:'list',scope:'near'})");m.wait_for_timeout(400);m.screenshot(path='/tmp/site/appm_near.png')
  # flow perk3
  f=b.new_page(viewport={'width':1280,'height':800});f.goto('http://localhost:8790/d/start.html');f.wait_for_timeout(600)
  f.evaluate("__dc.setState({paid:'member',p:Object.assign({},__dc.state.p,{st:'CA'}),step:__dc.steps().indexOf('perks'),pi:2})");f.wait_for_timeout(500);f.screenshot(path='/tmp/site/perk3.png')
  f.evaluate("__dc.setState({step:__dc.steps().indexOf('plans')})");f.wait_for_timeout(400);print('plansSub',f.evaluate("(document.body.innerText.match(/Every plan includes[^\\n]*/)||[null])[0]"))
  f.evaluate("__dc.setState({step:__dc.steps().indexOf('reveal'),a:{apple:'apple'}})");print('reveal more',f.evaluate("(document.body.innerText.match(/There is up to[^\\n]*/)||[null])[0]"))
  l=b.new_page(viewport={'width':1440,'height':900});l.goto('http://localhost:8790/d/index.html');l.wait_for_timeout(2600)
  print('home',l.evaluate("[...document.querySelectorAll('[data-countup]')].map(e=>e.textContent)"),l.evaluate("(document.body.innerText.match(/\\d+ settlements nationwide[^\\n]*/)||[null])[0]"),l.evaluate("(document.body.innerText.match(/Every settlement, plus local scans\\n[^\\n]*/)||[null])[0]"))
  b.close()
