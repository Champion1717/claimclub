# Member app card connections, with /api/plaid and Plaid Link faked in the browser.
from playwright.sync_api import sync_playwright
import json, datetime, sys
FAKE=open('/tmp/fake_supabase.js').read()
W=int(sys.argv[1]) if len(sys.argv)>1 else 1440
d=lambda n:(datetime.date.today()-datetime.timedelta(days=n)).isoformat()
TX=[dict(transaction_id='t1',date=d(5),amount=32.18,name='AMZN Mktp US*2K41J8',merchant_name='Amazon',descriptor='AMZN Mktp US*2K41J8',verdict='fight',reasons=['Charged 2 times for $32.18 within 2 days.','If you only bought this once, the extra charge should come back.'],back=32.18,card='Plaid Checking 0000'),
    dict(transaction_id='t2',date=d(5),amount=32.18,name='AMZN Mktp US*2K41J9',merchant_name='Amazon',descriptor='AMZN Mktp US*2K41J9',verdict='fight',reasons=['Charged 2 times for $32.18 within 2 days.'],back=32.18,card='Plaid Checking 0000'),
    dict(transaction_id='t3',date=d(8),amount=35,name='OVERDRAFT FEE',merchant_name=None,descriptor='OVERDRAFT FEE',verdict='fight',reasons=['This looks like an overdraft fee.','Banks often refund fees when you ask, especially the first one.'],back=35,card='Plaid Checking 0000'),
    dict(transaction_id='t5',date=d(3),amount=18.99,name='NETFLIX.COM',merchant_name='Netflix',descriptor='NETFLIX.COM',verdict='look',reasons=['Usually $15.49, this time $18.99.','Price went up. Did you agree to the new price?'],back=None,card='Plaid Checking 0000'),
    dict(transaction_id='t4',date=d(2),amount=6.75,name='SQ *BLUE BOTTLE COF',merchant_name='Blue Bottle Coffee',descriptor='SQ *BLUE BOTTLE COF',verdict='ok',reasons=['Looks like a normal purchase.'],back=None,card='Plaid Checking 0000')]
SUBS=[dict(stream_id='s1',merchant='Netflix',frequency='MONTHLY',last_date=d(3),next_date=d(-27),last_amount=18.99,average_amount=15.49,per_month=18.99),
      dict(stream_id='s2',merchant='Spotify',frequency='MONTHLY',last_date=d(25),next_date=d(-5),last_amount=11.99,average_amount=11.99,per_month=11.99),
      dict(stream_id='s3',merchant='Adobe',frequency='ANNUALLY',last_date=d(340),next_date=d(-25),last_amount=239.88,average_amount=239.88,per_month=19.99)]
ST={'items':[]}
def full(): return dict(enabled=True,env='sandbox',member=True,items=ST['items'],tx=TX if ST['items'] else [],subs=SUBS if ST['items'] else [])
calls=[]
def plaid(r):
  b=json.loads(r.request.post_data); a=b['action']; calls.append(a); out={}
  if a=='status' or a=='sync': out=full()
  elif a=='link_token': out={'link_token':'link-sandbox-123'}
  elif a=='exchange':
    ST['items']=[dict(item_id='item1',institution_name=b['institution']['name'],status='ok',synced_at=datetime.datetime.utcnow().isoformat()+'Z',accounts=[dict(name='Plaid Checking',mask='0000')])]; out=full()
  elif a=='choose':
    for t in TX:
      if t['transaction_id']==b['transaction_id']: t['user_choice']=b['choice']
    out={'ok':True,'request':None if b['choice']=='fine' else dict(id='rq-'+b['transaction_id'],company='Overdraft fee',amount=35,what='This looks like an overdraft fee.',status='requested',kind='refund',created_at=datetime.datetime.utcnow().isoformat())}
  elif a=='sub_choice': out={'ok':True,'request':dict(id='rq-'+b['stream_id'],company='Spotify',amount=11.99,what='Cancel my subscription',status='requested',kind='cancel',created_at=datetime.datetime.utcnow().isoformat()) if b['choice']=='cancel' else None}
  elif a=='remove': ST['items']=[]; out=full()
  r.fulfill(status=200,content_type='application/json',body=json.dumps(out))
STUB="window.Plaid={create:function(o){window.__plaidToken=o.token;return{open:function(){setTimeout(function(){o.onSuccess('public-sandbox-1',{institution:{name:'First Platypus Bank',institution_id:'ins_109508'}})},50)}}}};"
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  ctx=b.new_context(viewport={'width':W,'height':900});pg=ctx.new_page();e=[];pg.on('pageerror',lambda x:e.append(str(x)))
  ctx.route('**/supabase-js@2/**',lambda r:r.fulfill(status=200,content_type='application/javascript',body=FAKE))
  ctx.route('**/api/config',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'supabaseUrl':'https://x.supabase.co','supabaseAnonKey':'anon','testMode':True,'cardConnect':True})))
  ctx.route('**/api/membership',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'membership':None})))
  ctx.route('**/api/plaid',plaid)
  ctx.route('https://cdn.plaid.com/**',lambda r:r.fulfill(status=200,content_type='application/javascript',body=STUB))
  pg.goto('http://localhost:8790/d/index.html');pg.evaluate('''localStorage.clear();localStorage.setItem('claimclub_session',JSON.stringify({ids:['apple','visa'],signed:[],plan:'1m',paid:'member',p:{name:'Maria Lopez',email:'maria.lopez@example.com',st:'WA'}}))''')
  pg.goto('http://localhost:8790/d/app.html');pg.wait_for_timeout(900)
  pg.click('text=Email me a code');pg.wait_for_timeout(300)
  c=pg.locator('input[autocomplete="one-time-code"]');c.click();c.type('123456',delay=20);pg.wait_for_timeout(1500)
  pg.evaluate("(()=>{const db=JSON.parse(localStorage.getItem('__fakedb'));const s=JSON.parse(localStorage.getItem('__fakesess'));db.memberships.push({user_id:s.user.id,kind:'member',plan:'1m',status:'test',started_at:new Date().toISOString()});localStorage.setItem('__fakedb',JSON.stringify(db))})()")
  pg.goto('http://localhost:8790/dashboard/refunds');pg.wait_for_timeout(1800)
  pg.screenshot(path='/tmp/pl_0.png',full_page=True)
  print('soon text gone', 'open soon' not in pg.inner_text('main'))
  pg.get_by_role('button',name='Connect a card',exact=True).first.click();pg.wait_for_timeout(1500);print('DBG',calls,pg.evaluate('typeof window.Plaid'),e)
  pg.screenshot(path='/tmp/pl_1.png',full_page=True)
  body=pg.inner_text('main');print('connected','First Platypus Bank' in body,'fight rows','OVERDRAFT FEE' in body,'test tag','Test bank' in body)
  pg.locator('button:has-text("OVERDRAFT FEE") >> visible=true').first.click();pg.wait_for_timeout(300);pg.screenshot(path='/tmp/pl_2.png',full_page=True)
  pg.get_by_role('button',name='Fight it').first.click();pg.wait_for_timeout(800);pg.screenshot(path='/tmp/pl_3.png',full_page=True)
  print('in progress has request','Overdraft fee' in pg.inner_text('main'))
  pg.goto('http://localhost:8790/dashboard/subscriptions');pg.wait_for_timeout(2200)
  pg.screenshot(path='/tmp/pl_4.png',full_page=True); m=pg.inner_text('main'); print('subs','Spotify' in m,'Adobe' in m,'$50.97' in m)
  pg.locator('text=Cancel for me >> visible=true').nth(1).click();pg.wait_for_timeout(600);print('canceling','Canceling for you' in pg.inner_text('main'))
  pg.screenshot(path='/tmp/pl_5.png',full_page=True)
  pg.goto('http://localhost:8790/dashboard');pg.wait_for_timeout(1800);pg.screenshot(path='/tmp/pl_6.png',full_page=True)
  print('todo','flagged charge' in pg.inner_text('main'))
  print('calls',calls,'errors',e[:3])
