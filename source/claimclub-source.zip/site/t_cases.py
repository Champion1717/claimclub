# Nov 18 2026: VA filing view (form map from the filing spec) and New cases.
from playwright.sync_api import sync_playwright
import json
FAKE=open('/tmp/fake_supabase.js').read()
prof={'id':'u1','email':'maria@example.com','name':'Maria Lopez','phone':'(206) 555-0199','dob':'04/17/1990','address':'88 Pine St, Seattle, WA 98101','state':'WA','pay_default':'PayPal','payout_handles':{'PayPal':'maria@example.com'},'created_at':'2026-11-14T20:00:00Z','past_addresses':[],'bank_connected':False,'email_receipts':True}
auth={'id':7,'settlement_id':'apple','settlement_title':'Apple Intelligence Siri Settlement','signer_name':'Maria Lopez','signature_text':'Maria Lopez','method':'single','email':'maria@example.com','details':{'phone':'(206) 555-0199','dob':'04/17/1990','street':'88 Pine St','city':'Seattle','state':'WA','zip':'98101'},'answers':[{'q':'Did you buy an iPhone 15 Pro or iPhone 16 between 2024 and 2025?','a':'Yes'}],'statements':{'attestation':'I have reviewed the answers above and they are true and correct. I authorize Claimclub to submit this claim...','perjury':'I declare under penalty of perjury...','consent':'I agree to sign electronically and have read the Claim Filing Authorization Agreement','agreement_url':'https://claimclub.io/legal/authorization.html'},'agreement_version':'2026-11-13','ip':'73.42.11.9','user_agent':'Mozilla/5.0 (iPhone)','page':'/m/start.html','lang':'en','record_hash':'9f2c...','created_at':'2026-11-14T20:02:11Z','client_signed_at':'2026-11-14T20:02:10Z'}
claim={'id':11,'user_id':'u1','settlement_id':'apple','status':'requested','requested_at':'2026-11-14T20:10:00Z','created_at':'2026-11-14T20:05:00Z','claim_ref':None,'admin_note':None,'profile':prof,'authorization':{'id':7}}
daily=[{'day':'2026-10-%02d'%(d+16) if d<16 else '2026-11-%02d'%(d-15),'visitors':(d*7)%40+5,'signups':d%3,'orders':1 if d%5==0 else 0,'revenue_cents':4999} for d in range(30)]
R={'me':{'admin':True,'email':'owner@claimclub.io','settings':{'bank_connect':False}},'settings':{'settings':{'bank_connect':False,'bank_connect_meta':{'by':'launch default','at':'2026-11-14T22:58:00Z'}}},'setSetting':{'settings':{'bank_connect':True}},
 'overview':{'members':42,'members7':9,'orders':17,'revenue':'$612.83','ordersByKind':{'fee':6,'member':11},'activeMembers':10,'activeByPlan':{'1m':4,'3m':2,'6m':4},'claimsByStatus':{'requested':5,'filed':12,'approved':3,'paid':2,'ready':40},'queue':5,'authorizations':61,'emailsFailed':0,'visitors30':830,'daily':daily},
 'queue':{'claims':[claim,dict(claim,id=12,settlement_id='cvs',status='needs_info',authorization=None)]},
 'users':{'total':1,'offset':0,'users':[dict(prof,claims=4,requested=1,signed=2,membership={'kind':'member','plan':'3m','status':'active'})]},
 'user':{'profile':prof,'claims':[claim],'membership':{'kind':'member','plan':'3m','status':'active','renews_at':'2027-02-14T00:00:00Z'},'purchases':[{'created_at':'2026-11-14T20:01:00Z','kind':'member','plan':'3m','amount_cents':1899}],'authorizations':[auth],'events':[{'created_at':'2026-11-14T20:10:00Z','settlement_id':'apple','status':'requested','actor':'member'}],'emails':[]},
 'authorization':{'authorization':auth},
 'funnel':{'days':30,'steps':[{'step':'intro1','step_index':0,'visitors':830},{'step':'q0','step_index':1,'visitors':700},{'step':'q1','step_index':2,'visitors':610},{'step':'reveal','step_index':12,'visitors':420},{'step':'email','step_index':13,'visitors':300},{'step':'details','step_index':14,'visitors':190},{'step':'auth','step_index':15,'visitors':150},{'step':'pay','step_index':16,'visitors':120},{'step':'checkout','step_index':18,'visitors':40}]},
 'setStatus':{'claim':dict(claim,status='filed',claim_ref='SIRI-88812'),'email':{'skipped':True,'reason':'RESEND_API_KEY not set'}}}

SP={x['id']:x for x in json.load(open('/tmp/site/out/api/_specs.json'))}
claim2=dict(claim,answers={'n_iphone_count':'2','n_iphone_serials':'F4GZK2XQ1N, G7HQL3ZR2P'},payout_method='PayPal',spec=SP['apple'])
claim3=dict(claim,id=13,settlement_id='dexcom',status='requested',spec=SP['dexcom'],progress={'sent':'2026-11-18T19:00:00Z','conf':'MIL-55821','step':13},member_note='Filed it myself. Confirmation: MIL-55821')
R['queue']={'claims':[claim2,claim3]}
R['files']={'files':[]}
R['cases']={'cases':[{'id':1,'kind':'new','title':'Acme Corp Data Breach Settlement','company':'Acme Corp','url':'https://example.com/acme','source':'Top Class Actions','payout':'up to $5,000','deadline':'2027-02-01','summary':'People notified of the Acme Corp breach can file a claim.','suggested_type':'we','status':'new','found_at':'2026-11-18T14:17:00Z'},{'id':2,'kind':'change','settlement_id':'equifax','title':'Equifax Credit Dispute: deadline moved','source':'Nov 18 research','deadline':'2026-11-29','summary':'The official site lists Nov 29, 2026, not Nov 28.','details':{'what':'The official site lists Nov 29, 2026, not Nov 28.','patch':{'data':{'dl':'2026-11-29'}}},'status':'new','found_at':'2026-11-18T20:00:00Z'}],'last':{'at':'2026-11-18T14:17:00Z','added':1,'sources':[{'source':'Top Class Actions','found':40,'added':1},{'source':'ClaimDepot','found':0,'error':'HTTP 403'}]},'counts':{'new':1,'change':1}}
R['caseAction']={'ok':True}
calls=[]
def adm(r):
  d=json.loads(r.request.post_data); calls.append(d)
  r.fulfill(status=200,content_type='application/json',body=json.dumps(R.get(d['action'],{})))
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  ctx=b.new_context(viewport={'width':1440,'height':900});pg=ctx.new_page();e=[];pg.on('pageerror',lambda x:e.append(str(x)))
  ctx.route('**/supabase-js@2/**',lambda r:r.fulfill(status=200,content_type='application/javascript',body=FAKE))
  ctx.route('**/api/config',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'supabaseUrl':'https://x.supabase.co','supabaseAnonKey':'anon'})))
  ctx.route('**/api/admin',adm)
  pg.goto('http://localhost:8790/admin/index.html');pg.wait_for_timeout(800)
  pg.fill('#em','owner@claimclub.io');pg.click('#send');pg.wait_for_timeout(400)
  pg.locator('#code').type('123456',delay=30);pg.wait_for_timeout(1200)
  pg.click('.nav[data-v=queue]');pg.wait_for_timeout(600);pg.screenshot(path='/tmp/ad_q.png')
  pg.locator('tr.click').first.click();pg.wait_for_timeout(700);pg.screenshot(path='/tmp/ad_va.png',full_page=False)
  t=pg.inner_text('#dr'); print('va view', 'Open claim form' in t, 'Claim form, in order' in t, 'G7HQL3ZR2P' in t)
  pg.locator('.fm input[type=checkbox]').first.check(); print('count', pg.inner_text('#fmN'))
  pg.click('#editSpec');pg.wait_for_timeout(300);print('spec modal', pg.locator('#sp_needs').count()); pg.click('#spx')
  pg.click('.nav[data-v=queue]');pg.wait_for_timeout(500); pg.locator('tr.click').nth(1).click();pg.wait_for_timeout(600)
  t=pg.inner_text('#dr'); print('self view', 'MIL-55821' in t, 'Confirm and mark filed' in t); pg.screenshot(path='/tmp/ad_self.png')
  pg.click('#x')
  pg.click('.nav[data-v=cases]');pg.wait_for_timeout(600);pg.screenshot(path='/tmp/ad_cases.png')
  pg.locator('tr.click').first.click();pg.wait_for_timeout(400);pg.screenshot(path='/tmp/ad_case.png')
  pg.click('#capp');pg.wait_for_timeout(500)
  print('approve call', [c for c in calls if c['action']=='caseAction'])
  print('errors', e)
  b.close()
