# Nov 21 2026: trial flows collect details before the offer and use one blanket authorization (no per-form signing).
# Nov 22: details moved after payment. t_blanket.py [width] [offer]: questions > estimate > email > trial (tick I agree) > payment > details > email code > dashboard.
import sys, json
from playwright.sync_api import sync_playwright
W = int(sys.argv[1]) if len(sys.argv) > 1 else 390
F = sys.argv[2] if len(sys.argv) > 2 else 'f'
path = ('/m/start.html?v=1' if W < 820 else '/d/start.html?v=1') + '&flow=' + F
FAKE = open('/tmp/site/fake_stripejs.js').read()
STUB = "window.ccAuth={sent:[],send:function(e){this.sent.push(e);return Promise.resolve({})},verify:function(e,c){return Promise.resolve({ok:c==='123456'})}}"
signs = []
with sync_playwright() as p:
  b = p.chromium.launch(executable_path='/usr/bin/google-chrome')
  pg = b.new_page(viewport={'width': W, 'height': 844 if W < 820 else 900}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
  pg.route('https://js.stripe.com/**', lambda r: r.fulfill(status=200, content_type='text/javascript', body=FAKE))
  def sign(r):
    signs.append(json.loads(r.request.post_data)); r.fulfill(status=200, content_type='application/json', body='{"ok":true}')
  pg.route('**/api/sign', sign)
  pg.goto('http://localhost:8790' + path); pg.wait_for_function('window.__dc'); pg.wait_for_timeout(300); pg.evaluate(STUB)
  S = lambda: pg.evaluate("window.__dc&&__dc.stepName?__dc.stepName():'(left)'")
  seen = []
  def note():
    n = S()
    if not seen or seen[-1] != n: seen.append(n)
  for i in range(12):
    note()
    if not S().startswith('q'): break
    pg.locator('button:visible', has_text='Yes').first.click(); pg.wait_for_timeout(200)
  while S() != 'email': pg.evaluate('__dc.go(1)'); pg.wait_for_timeout(150); note()
  pg.evaluate("__dc.setState({email:'ana@gmail.com'})"); pg.evaluate('__dc.go(1)'); pg.wait_for_timeout(300); note()
  pg.locator('button:visible', has_text='Start my').last.click(); pg.wait_for_timeout(300)
  print('without tick: step', S(), '| error shown', pg.locator('[role=alert]:visible').count(), '| sheet open', pg.locator('.ccp').count())
  pg.screenshot(path=f'/tmp/bl_{W}_trial_err.png')
  pg.locator('[role=checkbox]:visible').first.click(); pg.wait_for_timeout(200)
  pg.screenshot(path=f'/tmp/bl_{W}_trial.png')
  pg.locator('button:visible', has_text='Start my').last.click()
  pg.wait_for_selector('.ccp .ccp-body:not(.loading)'); pg.wait_for_timeout(300); pg.click('.ccp-pay'); pg.wait_for_timeout(5200); note()
  print('after pay step', S(), '| signs before details', len(signs))
  pg.evaluate("__dc.setState({p:Object.assign({},__dc.state.p,{first:'Ana',last:'Reyes',street:'12 Oak St',city:'Austin',zip:'78701',phone:'5127436190',dob:'04/02/1990'}),st:'TX'})"); pg.wait_for_timeout(200)
  pg.screenshot(path=f'/tmp/bl_{W}_details.png')
  pg.locator('button:visible', has_text='Continue').last.click(); pg.wait_for_timeout(600); note()
  print('after details step', S(), '| code sent to', pg.evaluate('window.ccAuth.sent'))
  pg.fill('input[autocomplete="one-time-code"]', '123456'); pg.wait_for_timeout(1500); note()
  print(' > '.join(seen), '| url', pg.url.replace('http://localhost:8790', ''), '| errs', errs)
  for s in signs:
    r = s['records']
    print('sign:', s['method'], len(r), 'records', [x['settlement_id'] for x in r], '| version', r[0]['agreement_version'], '| name', r[0]['signer_name'])
    print('consent:', r[0]['statements']['consent'][:160])
  print('session signed:', pg.evaluate("JSON.parse(localStorage.claimclub_session||'{}').signed"))
  b.close()
