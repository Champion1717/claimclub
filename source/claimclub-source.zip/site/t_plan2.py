from playwright.sync_api import sync_playwright
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  for w,h,pre in [(1440,900,'d'),(390,844,'m')]:
    pg=b.new_page(viewport={'width':w,'height':h});e=[];pg.on('pageerror',lambda x:e.append(str(x)))
    pg.goto(f'http://localhost:8790/{pre}/start.html');pg.wait_for_timeout(800)
    pg.evaluate("__dc.setState({a:{q0:['apple','googleplay','equifax','tyson']},email:'t@example.com',plan:'6m',step:__dc.steps().indexOf('plans')})");pg.wait_for_timeout(400)
    pg.screenshot(path=f'/tmp/p2_{pre}.png')
    pg.locator('[role=radio]').nth(1).click();pg.wait_for_timeout(200)
    print(pre,e,pg.locator('button:has-text("Start getting paid")').inner_text(), pg.locator('text=/auto-renews/').inner_text())
    pg.locator('button:has-text("Start getting paid")').click();pg.wait_for_timeout(300);print(pg.locator('text=/Pay \\$/').first.inner_text())
  b.close()
