from playwright.sync_api import sync_playwright
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  for w,h,pre in [(1440,900,'d'),(390,844,'m')]:
    pg=b.new_page(viewport={'width':w,'height':h});e=[];pg.on('pageerror',lambda x:e.append(str(x)))
    pg.goto(f'http://localhost:8790/{pre}/start.html');pg.wait_for_timeout(700)
    pg.evaluate("__dc.setState({a:{q0:['apple','googleplay']},step:__dc.steps().indexOf('pay')})");pg.wait_for_timeout(400)
    pg.screenshot(path=f'/tmp/pill_{pre}.png'); t=pg.inner_text('body')
    print(pre,[l for l in t.split('\n') if '$' in l or 'intro' in l.lower() or 'first month' in l], e)
  b.close()
