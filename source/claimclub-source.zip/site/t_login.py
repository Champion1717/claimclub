from playwright.sync_api import sync_playwright
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  for w,h,pre in [(1440,900,'d'),(390,844,'m')]:
    pg=b.new_page(viewport={'width':w,'height':h});e=[];pg.on('pageerror',lambda x:e.append(str(x)))
    # homepage log in link
    pg.goto(f'http://localhost:8790/{pre}/index.html');pg.wait_for_timeout(700)
    a=pg.locator('header a:has-text("Log in")');print(pre,'home login visible',a.is_visible(),a.get_attribute('href'));pg.screenshot(path=f'/tmp/lg_{pre}_home.png',clip={'x':0,'y':0,'width':w,'height':90})
    # signup flow: existing email
    pg.goto(f'http://localhost:8790/{pre}/start.html');pg.wait_for_timeout(700)
    pg.evaluate("__dc.setState({a:{q0:['apple']},step:__dc.steps().indexOf('email')})");pg.wait_for_timeout(300)
    i=pg.locator('input[type=email]');i.fill('member@example.com');i.dispatch_event('change');pg.wait_for_timeout(100)
    pg.get_by_role('button', name='Continue', exact=True).click();pg.wait_for_timeout(700)
    print(pre,'exists box',pg.locator('text=This email already has an account with us').count(), 'step',pg.evaluate("__dc.stepName()"))
    pg.screenshot(path=f'/tmp/lg_{pre}_exists.png')
    href=pg.locator('a:has-text("Log in")').last.get_attribute('href');print(pre,'login href',href)
    pg.locator('button:has-text("Use a different email")').click();pg.wait_for_timeout(200)
    i.fill('new.person@example.com');i.dispatch_event('change');pg.get_by_role('button', name='Continue', exact=True).click();pg.wait_for_timeout(700)
    print(pre,'new email step',pg.evaluate("__dc.stepName()"))
    # login page via /login with param
    pg.goto(f'http://localhost:8790/login?login=member%40example.com');pg.wait_for_timeout(1500)
    print(pre,'login url',pg.url, 'title', pg.locator('h1').first.inner_text() if pg.locator('h1').count() else '-', 'email', pg.locator('input[type=email]').input_value() if pg.locator('input[type=email]').count() else '-')
    pg.screenshot(path=f'/tmp/lg_{pre}_login.png')
    print(pre,'errors',e)
  b.close()
