# Per-claim filing flows (Nov 18 2026): auto pay (googleplay), we file it with needs (apple), you file it step by step (dexcom).
from playwright.sync_api import sync_playwright
import json, sys
FAKE=open('/tmp/fake_supabase.js').read()
SPECS={s['id']:s for s in json.load(open('/tmp/site/out/api/_specs.json'))}
W=int(sys.argv[1]) if len(sys.argv)>1 else 1440
calls=[]; signed={}
def claim(r):
  b=json.loads(r.request.post_data); a=b['action']; calls.append((a,{k:v for k,v in b.items() if k!='action'}))
  sid=b.get('settlement_id')
  if a=='state': out={'signed':signed,'files':[]}
  elif a=='file':
    signed[sid]='2026-11-18T18:00:00Z'; out={'claim':{'settlement_id':sid,'status':'requested','answers':b.get('answers',{})}}
  elif a=='start': out={'claim':{'settlement_id':sid,'status':{'auto':'auto','self':'self'}[SPECS[sid]['type']],'progress':{}}}
  elif a=='progress': out={'claim':{'progress':b['progress']}}
  elif a=='selfDone': out={'claim':{'status':'requested'}}
  elif a=='gotPaid': out={'claim':{'status':'paid'}}
  else: out={}
  r.fulfill(status=200,content_type='application/json',body=json.dumps(out))
def filing(r):
  from urllib.parse import urlparse,parse_qs
  q=parse_qs(urlparse(r.request.url).query)
  if 'catalog' in q: out={'extra':[{'id':'tyson','data':{},'is_new':False,'hidden':True}]}
  elif 'ids' in q: out={'specs':{i:SPECS[i] for i in q['ids'][0].split(',') if i in SPECS}}
  else: out={'spec':SPECS.get(q['id'][0])}
  r.fulfill(status=200,content_type='application/json',body=json.dumps(out))
with sync_playwright() as p:
  br=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  ctx=br.new_context(viewport={'width':W,'height':900});pg=ctx.new_page();e=[];pg.on('pageerror',lambda x:e.append(str(x)))
  ctx.route('**/supabase-js@2/**',lambda r:r.fulfill(status=200,content_type='application/javascript',body=FAKE))
  ctx.route('**/api/config',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'supabaseUrl':'https://x.supabase.co','supabaseAnonKey':'anon','testMode':True})))
  ctx.route('**/api/membership',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'membership':None if json.loads(r.request.post_data)['action']=='link' else {'kind':'member','plan':'1y','status':'test'}})))
  ctx.route('**/api/plaid',lambda r:r.fulfill(status=200,content_type='application/json',body='{"enabled":false}'))
  ctx.route('**/api/claim',claim); ctx.route('**/api/filing*',filing)
  pg.goto('http://localhost:8790/d/index.html');pg.evaluate('''localStorage.clear();localStorage.setItem('claimclub_session',JSON.stringify({ids:['googleplay','apple','dexcom'],signed:[],plan:'1y',paid:'member',p:{name:'Maria Lopez',email:'maria@example.com',st:'WA'}}))''')
  pg.goto('http://localhost:8790/d/app.html');pg.wait_for_timeout(1000)
  pg.click('text=Email me a code');pg.wait_for_timeout(300);c=pg.locator('input[autocomplete="one-time-code"]');c.click();c.type('123456',delay=20);pg.wait_for_timeout(2200)
  pg.goto('http://localhost:8790/dashboard/claims');pg.wait_for_timeout(2000)
  body=pg.inner_text('body')
  print('kind notes:', 'Paid automatically. Nothing to file' in body, 'step-by-step guide' in body, 'We file it. Needs' in body)
  pg.screenshot(path='/tmp/fw_0.png')
  def fileBtn(co):
    b=pg.locator(f'button[aria-label^="File the {co}"] >> visible=true')
    return b.first
  # AUTO
  fileBtn('Google Play').click(); pg.wait_for_timeout(900)
  t=pg.inner_text('[role=dialog]'); print('auto sheet:', 'AUTO PAY' in t, 'Link PayPal or Venmo' in t)
  pg.locator('[role=dialog] button:has-text("Link PayPal or Venmo")').first.click(); pg.wait_for_timeout(800)
  pg.screenshot(path='/tmp/fw_auto.png')
  pg.fill('[role=dialog] input[aria-label="Amount you got"]','12.50'); pg.click('[role=dialog] button:has-text("I got paid")'); pg.wait_for_timeout(700)
  print('auto calls', [x[0] for x in calls if x[0] in ('start','progress','gotPaid')])
  pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
  if pg.locator('[role=dialog] button[aria-label="Close"]').count(): pg.locator('[role=dialog] button[aria-label="Close"]').first.click()
  pg.wait_for_timeout(4500)
  # WE (apple needs)
  fileBtn('Apple').click(); pg.wait_for_timeout(700)
  t=pg.inner_text('[role=dialog]'); print('we sheet needs:', 'Serial number' in t or 'serial' in t.lower(), t[:200].replace('\n',' | '))
  pg.screenshot(path='/tmp/fw_we1.png')
  ins=pg.locator('[role=dialog] input[type=text] >> visible=true')
  for i in range(ins.count()): ins.nth(i).fill('1' if i==2 else 'F4GZK2XQ1N')
  pg.click('[role=dialog] button:has-text("Continue")'); pg.wait_for_timeout(300)
  pg.fill('input[aria-label="Type your full legal name to sign"] >> visible=true','Maria Lopez')
  pg.click('button:has-text("I agree to sign electronically") >> visible=true'); pg.wait_for_timeout(200)
  pg.click('button:has-text("Sign and submit") >> visible=true'); pg.wait_for_timeout(900)
  print('we file answers', [x[1].get('answers') for x in calls if x[0]=='file'])
  pg.wait_for_timeout(4500)
  # SELF (dexcom)
  b=fileBtn('Dexcom')
  if not b.count(): b=pg.locator('button:has-text("File") >> visible=true').first
  b.click(); pg.wait_for_timeout(900)
  t=pg.inner_text('[role=dialog]'); print('self sheet:', 'YOU FILE THIS ONE' in t, 'Before you start' in t)
  pg.screenshot(path='/tmp/fw_self0.png')
  pg.click('[role=dialog] button:has-text("Start step 1")'); pg.wait_for_timeout(400)
  print('step1', pg.inner_text('[role=dialog]').count('Step 1 of'))
  pg.screenshot(path='/tmp/fw_self1.png')
  for i in range(30):
    if pg.locator('[role=dialog] button:has-text("Send confirmation")').count(): break
    pg.click('[role=dialog] button:has-text("Done,")'); pg.wait_for_timeout(120)
  pg.fill('[role=dialog] input[aria-label="Confirmation number"]','MIL-55821'); pg.screenshot(path='/tmp/fw_self2.png')
  pg.click('[role=dialog] button:has-text("Send confirmation")'); pg.wait_for_timeout(700)
  print('self calls', [x for x in calls if x[0]=='selfDone'])
  print('errors', e)
  br.close()
