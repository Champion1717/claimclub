src=open('/tmp/site/build.py').read().split('livevis=')[0]
src=src.replace("shutil.rmtree(OUT,ignore_errors=True); os.makedirs(OUT+'/d'); os.makedirs(OUT+'/m'); os.makedirs(OUT+'/assets')","")
exec(src)
for n in ["PlanV1","PlanV2","PlanV3","PlanV4","PlanV5"]:
    page(n+'.dc.html','d/'+n.lower()+'.html',n)
