from playwright.sync_api import sync_playwright
import json, sys
FAKE=open('/tmp/fake_supabase.js').read()
W=int(sys.argv[1]) if len(sys.argv)>1 else 1440; path=sys.argv[2] if len(sys.argv)>2 else '/dashboard/claims'; out=sys.argv[3] if len(sys.argv)>3 else '/tmp/claims_%d.png'%W
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  ctx=b.new_context(viewport={'width':W,'height':900});pg=ctx.new_page();e=[];pg.on('pageerror',lambda x:e.append(str(x)))
  ctx.route('**/supabase-js@2/**',lambda r:r.fulfill(status=200,content_type='application/javascript',body=FAKE))
  ctx.route('**/api/config',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'supabaseUrl':'https://x.supabase.co','supabaseAnonKey':'anon','testMode':True})))
  ctx.route('**/api/membership',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'membership':None if json.loads(r.request.post_data)['action']=='link' else {'kind':'member','plan':'1m','status':'test'}})))
  ctx.route('**/api/plaid',lambda r:r.fulfill(status=200,content_type='application/json',body='{"enabled":false}'))
  pg.goto('http://localhost:8790/d/index.html');pg.evaluate('''localStorage.clear();localStorage.setItem('claimclub_session',JSON.stringify({ids:['apple','visa','googleplay','cvs'],signed:['apple'],plan:'1m',paid:'member',p:{name:'Maria Lopez',email:'maria@example.com',st:'WA'}}));localStorage.setItem('claimclub_tour','1')''')
  pg.goto('http://localhost:8790'+path);pg.wait_for_timeout(1200)
  if pg.locator('text=Email me a code').count():
    pg.click('text=Email me a code');pg.wait_for_timeout(300);c=pg.locator('input[autocomplete="one-time-code"]');c.click();c.type('123456',delay=20);pg.wait_for_timeout(2200)
  pg.screenshot(path=out); print(pg.url, e)
  if len(sys.argv)>4:
    for i in range(int(sys.argv[4])):
      pg.screenshot(path=out.replace('.png','_t%d.png'%i))
      nb=pg.locator('[data-tour-next]')
      if not nb.count(): print('no tour button at',i); break
      nb.first.click(); pg.wait_for_timeout(900)
    print('tour gone', pg.locator('[data-tour-next]').count()==0, 'errors', e)
