# Nov 21 2026: demo mode. t_demo.py [width] [f|g] [std|fast|pri]: blank email and details, fake payment, any code, no API writes.
import sys, json
from playwright.sync_api import sync_playwright
W = int(sys.argv[1]) if len(sys.argv) > 1 else 390; F = sys.argv[2] if len(sys.argv) > 2 else 'g'; T = sys.argv[3] if len(sys.argv) > 3 else 'fast'
path = ('/m/start.html?v=1' if W < 820 else '/d/start.html?v=1') + '&demo=1&flow=' + F + ('&tier=' + T if F == 'g' else '')
hits = []
with sync_playwright() as p:
  b = p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg = b.new_page(viewport={'width': W, 'height': 844 if W < 820 else 900}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
  pg.on('request', lambda r: hits.append(r.url.split('8790')[-1]) if any(k in r.url for k in ['/api/sign', '/api/track', '/api/checkout', '/api/membership', '/api/account-exists', '/api/session', 'facebook', 'stripe.com']) else None)
  pg.goto('http://localhost:8790' + path); pg.wait_for_function('window.__dc'); pg.wait_for_timeout(400)
  S = lambda: pg.evaluate("window.__dc&&__dc.stepName?__dc.stepName():'(left)'")
  seen = []
  def note():
    n = S()
    if not seen or seen[-1] != n: seen.append(n)
  for i in range(12):
    note()
    if not S().startswith('q'): break
    pg.locator('button:visible', has_text='Yes').first.click(); pg.wait_for_timeout(200)
  while S() != 'email': pg.evaluate('__dc.go(1)'); pg.wait_for_timeout(150); note()
  pg.locator('button:visible', has_text='Continue').last.click(); pg.wait_for_timeout(400); note()
  pg.locator('button:visible', has_text='Continue').last.click(); pg.wait_for_timeout(500); note()
  if F == 'g' and T == 'std': pg.locator('[role=checkbox]:visible').first.click(); pg.wait_for_timeout(150)
  pg.screenshot(path=f'/tmp/demo_{W}_{F}{T}_offer.png')
  pg.locator('button:visible', has_text='Start').last.click(); pg.wait_for_timeout(500)
  if F == 'f' and pg.locator('[role=alert]:visible').count(): pg.locator('[role=checkbox]:visible').first.click(); pg.locator('button:visible', has_text='Start').last.click(); pg.wait_for_timeout(500)
  if not (F == 'g' and T == 'std'):
    pg.wait_for_selector('.ccp-pay')
    if pg.locator('.ccp-ag').count(): pg.click('.ccp-pay'); pg.wait_for_timeout(200)
    print('sheet error without tick:', pg.locator('.ccp-err:visible').inner_text() if pg.locator('.ccp-ag').count() else '(no box)')
    pg.screenshot(path=f'/tmp/demo_{W}_{F}{T}_sheet.png')
    if pg.locator('.ccp-ag').count(): pg.check('.ccp-ag')
    pg.click('.ccp-pay'); pg.wait_for_timeout(4500); note()
  pg.wait_for_timeout(500); note()
  pg.fill('input[autocomplete="one-time-code"]', '000000'); pg.wait_for_timeout(1500); note()
  for i in range(4):
    if S() == '(left)': break
    if S() == 'bank': pg.locator('button:visible', has_text='Skip').last.click() if pg.locator('button:visible', has_text='Skip').count() else pg.evaluate('__dc.afterBank()')
    pg.wait_for_timeout(1200); note()
  pg.wait_for_timeout(2500)
  print(' > '.join(seen)); print('url', pg.url.replace('http://localhost:8790', ''), '| plan', pg.evaluate("window.__dc&&__dc.state.plan"), '| auth', pg.evaluate("window.__dc&&__dc.state.authState"))
  print('demo badge', pg.locator('#ccDemoBadge').count(), '| real session untouched', pg.evaluate("localStorage.getItem('claimclub_session')"), '| api hits', hits, '| errs', errs[:3])
  pg.screenshot(path=f'/tmp/demo_{W}_{F}{T}_dash.png')
  b.close()
