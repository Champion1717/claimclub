from playwright.sync_api import sync_playwright
import time
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome');pg=b.new_page(viewport={'width':1440,'height':900});e=[];pg.on('pageerror',lambda x:e.append(str(x)))
  pg.goto('http://localhost:8790/d/start.html');pg.wait_for_timeout(800)
  pg.evaluate("__dc.setState({a:{apple:'yes'},email:'t@example.com',plan:'1m',buying:'member',step:__dc.steps().indexOf('bank')})");pg.wait_for_timeout(400)
  pg.get_by_role('button',name='Skip for now').first.click() if pg.get_by_role('button',name='Skip for now').count() else pg.evaluate("__dc.afterBank()")
  t0=time.time();j=0;names=[]
  while time.time()-t0<2.2:
    try:
      pg.screenshot(path=f'/tmp/te_{j:02d}.png');names.append(pg.url.split('/')[-1]);j+=1
    except Exception: pass
    pg.wait_for_timeout(70)
  print(j,names,e);b.close()
