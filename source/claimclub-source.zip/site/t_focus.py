import re
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  pg=b.new_page(viewport={'width':1440,'height':900});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
  pg.goto('http://localhost:8790/d/stats.html');pg.wait_for_timeout(1500);pg.screenshot(path='/tmp/site/f_stats.png')
  pg.goto('http://localhost:8790/d/index.html');pg.wait_for_timeout(800)
  pg.evaluate("document.querySelector('#pricing').scrollIntoView()");pg.wait_for_timeout(900);pg.screenshot(path='/tmp/site/f_pricing.png')
  # click a non-top tile
  pg.evaluate("document.querySelector('#settlements').scrollIntoView()");pg.wait_for_timeout(500)
  href=pg.evaluate("[...document.querySelectorAll('[data-shelf] a')].map(a=>a.getAttribute('href')).slice(0,3)");print('hrefs',href)
  pg.click('[data-shelf] a[href*="offer=kia"]') if pg.locator('[data-shelf] a[href*="offer=kia"]').count() else pg.goto('http://localhost:8790/d/start.html?offer=kia')
  pg.wait_for_timeout(900);print('url',pg.url)
  st=lambda:pg.evaluate("[__dc.stepName(), __dc.quiz().length, __dc.quiz()[0].title]");print('start',st())
  pg.screenshot(path='/tmp/site/f_q0.png')
  pg.get_by_role('button',name='Yes').first.click();pg.wait_for_timeout(1000);print('after yes',pg.evaluate("[__dc.stepName(), __dc.matched().map(m=>m.id)]"))
  pg.screenshot(path='/tmp/site/f_picked.png')
  pg.get_by_role('button',name=re.compile('more common settlements')).click();pg.wait_for_timeout(600);print('more',st())
  for i in range(10):
    pg.get_by_role('button',name='No').first.click();pg.wait_for_timeout(700)
  print('after 9',pg.evaluate("[__dc.stepName(), __dc.matched().map(m=>m.id)]"))
  pg.get_by_role('button',name='Continue with 1 claim').click();pg.wait_for_timeout(3400);print('then',pg.evaluate("__dc.stepName()"))
  # apple focus, just this one
  pg.goto('http://localhost:8790/d/start.html?offer=apple');pg.wait_for_timeout(800);print('apple',st())
  pg.get_by_role('button',name='Yes').first.click();pg.wait_for_timeout(900)
  pg.get_by_role('button',name='Continue with 1 claim').click();pg.wait_for_timeout(3400);print('apple then',pg.evaluate("[__dc.stepName(), __dc.matched().map(m=>m.id)]"))
  # normal flow unaffected
  pg.goto('http://localhost:8790/d/start.html');pg.wait_for_timeout(800);print('normal',pg.evaluate("[__dc.stepName(), __dc.quiz().length]"))
  m=b.new_page(viewport={'width':390,'height':844});m.goto('http://localhost:8790/m/start.html?offer=goodrx');m.wait_for_timeout(900);print('mobile',m.evaluate("[__dc.stepName(), __dc.quiz()[0].title]"));m.get_by_role('button',name='Yes').first.click();m.wait_for_timeout(900);m.screenshot(path='/tmp/site/f_mpicked.png')
  print('errs',errs)
  b.close()
