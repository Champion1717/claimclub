from playwright.sync_api import sync_playwright
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  for w,h,pre in [(1440,900,'d'),(1920,1080,'d'),(1280,720,'d'),(390,844,'m')]:
    pg=b.new_page(viewport={'width':w,'height':h});e=[];pg.on('pageerror',lambda x:e.append(str(x)))
    pg.goto(f'http://localhost:8790/{pre}/index.html');pg.wait_for_timeout(1500)
    r=pg.evaluate("(()=>{const s=document.querySelector('#settlements h2');const m=document.querySelector('.mesh');return [Math.round(m.getBoundingClientRect().bottom),Math.round(s.getBoundingClientRect().top),innerHeight]})()")
    strip=pg.evaluate("[...document.querySelectorAll('.marq > div')].slice(0,14).map(x=>x.innerText.split('\\n')[0])")
    print(w,h,'hero bottom/settlements top/viewport',r,e); 
    if w==1440: print('strip',strip)
    pg.screenshot(path=f'/tmp/hero_{w}.png')
  b.close()
