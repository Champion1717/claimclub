// Webhook billing events with a fake Stripe and fake database (node /tmp/site/t_billing.js).
const assert = require('assert'), Module = require('module');
const fake = require(process.env.FAKE_DB || '/tmp/site/fake_db.js');
const API = process.env.API_DIR || '/tmp/site/api/';
let EVENT = null; const sent = [];
const origLoad = Module._load;
Module._load = function (req, parent, isMain) {
  if (req === 'stripe') return () => ({ webhooks: { constructEvent: () => EVENT }, subscriptions: { retrieve: async (id) => ({ id, current_period_end: 1800000000, cancel_at_period_end: false, metadata: { plan: '1m' } }) } });
  return origLoad.apply(this, arguments);
};
require.cache[require.resolve(API + '_db')] = { exports: { db: fake.db, renewsAt: () => null } };
require.cache[require.resolve(API + '_email')] = { exports: { sendNotice: async (x) => { sent.push(x); return { sent: true }; } } };
fake.T.memberships = [{ user_id: 'u1', kind: 'member', plan: '1m', status: 'active', stripe_subscription: 'sub_1' }];
fake.T.profiles = [{ id: 'u1', email: 'maria@example.com' }];
const hook = require(API + 'webhook.js');
const fire = (ev) => new Promise((done) => { EVENT = ev; const req = new (require('events'))(); req.method = 'POST'; req.headers = {}; const res = { end: () => done() };
  hook(req, res); setImmediate(() => { req.emit('data', Buffer.from('{}')); req.emit('end'); }); });
(async () => {
  await fire({ type: 'invoice.payment_failed', data: { object: { parent: { subscription_details: { subscription: 'sub_1' } }, amount_due: 2999 } } });
  assert.equal(fake.T.memberships[0].status, 'past_due'); assert.equal(sent.length, 1); assert.equal(sent[0].to, 'maria@example.com');
  await fire({ type: 'invoice.payment_failed', data: { object: { subscription: 'sub_1', amount_due: 2999 } } });
  assert.equal(sent.length, 1, 'only one email per failure run');
  await fire({ type: 'invoice.paid', data: { object: { subscription: 'sub_1' } } });
  assert.equal(fake.T.memberships[0].status, 'active');
  await fire({ type: 'customer.subscription.updated', data: { object: { id: 'sub_1', status: 'active', cancel_at_period_end: true } } });
  assert.equal(fake.T.memberships[0].status, 'cancelling');
  await fire({ type: 'customer.subscription.deleted', data: { object: { id: 'sub_1' } } });
  assert.equal(fake.T.memberships[0].status, 'ended');
  console.log('billing webhook tests passed:', sent[0].c.subject);
})().catch((e) => { console.error(e); process.exit(1); });
