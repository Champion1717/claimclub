const path = require('path'), assert = require('assert');
const API = process.env.API_DIR || '/tmp/site/api/';
const fake = require(process.env.FAKE_DB || '/tmp/site/fake_db.js');
const USER = { id: 'u1', email: 'henry@example.com' };
require.cache[require.resolve(API + '_db')] = { exports: {
  db: fake.db, userFrom: async () => USER, send: (res, c, o) => { res.code = c; res.body = o; },
  readJson: async (req) => req.body } };
Object.assign(process.env, { PLAID_CLIENT_ID: 'cid', PLAID_SECRET_SANDBOX: 'sec', PLAID_TOKEN_KEY: 'k'.repeat(40), PLAID_ENV: 'sandbox', ADMIN_EMAILS: 'henry@example.com' });
fake.T.memberships = [{ user_id: 'u1', kind: 'member', status: 'test' }];
const d = (n) => new Date(Date.now() - n * 864e5).toISOString().slice(0, 10);
const TX = [
  { transaction_id: 't1', account_id: 'a1', amount: 32.18, date: d(5), name: 'AMZN Mktp US*2K41J8', merchant_name: 'Amazon', personal_finance_category: { primary: 'GENERAL_MERCHANDISE' } },
  { transaction_id: 't2', account_id: 'a1', amount: 32.18, date: d(5), name: 'AMZN Mktp US*2K41J9', merchant_name: 'Amazon', personal_finance_category: { primary: 'GENERAL_MERCHANDISE' } },
  { transaction_id: 't3', account_id: 'a1', amount: 35, date: d(8), name: 'OVERDRAFT FEE', personal_finance_category: { primary: 'BANK_FEES' } },
  { transaction_id: 't4', account_id: 'a1', amount: 6.75, date: d(2), name: 'SQ *BLUE BOTTLE COF', merchant_name: 'Blue Bottle Coffee', personal_finance_category: { primary: 'FOOD_AND_DRINK' } },
  { transaction_id: 't5', account_id: 'a1', amount: 18.99, date: d(3), name: 'NETFLIX.COM', merchant_name: 'Netflix', personal_finance_category: { primary: 'ENTERTAINMENT' } },
  { transaction_id: 't6', account_id: 'a1', amount: 89.5, date: d(9), name: 'POS 4471 XJ HOLDINGS', personal_finance_category: { primary: 'GENERAL_MERCHANDISE' } },
  { transaction_id: 't7', account_id: 'a1', amount: -1200, date: d(1), name: 'PAYROLL', personal_finance_category: { primary: 'INCOME' } }];
const calls = [];
global.fetch = async (url, o) => { const b = JSON.parse(o.body); const p = url.replace(/^https:\/\/sandbox\.plaid\.com/, ''); calls.push(p);
  assert.equal(b.client_id, 'cid');
  const R = { '/link/token/create': { link_token: 'link-sandbox-1' }, '/item/public_token/exchange': { access_token: 'access-sandbox-1', item_id: 'item1' },
    '/accounts/get': { accounts: [{ account_id: 'a1', name: 'Plaid Checking', mask: '0000', type: 'depository', subtype: 'checking' }] },
    '/transactions/sync': { added: TX, modified: [], removed: [], next_cursor: 'c1', has_more: false },
    '/transactions/recurring/get': { outflow_streams: [
      { stream_id: 's1', merchant_name: 'Netflix', description: 'NETFLIX.COM', frequency: 'MONTHLY', first_date: d(200), last_date: d(3), predicted_next_date: d(-27), last_amount: { amount: 18.99 }, average_amount: { amount: 15.49 }, status: 'MATURE', is_active: true, personal_finance_category: { primary: 'ENTERTAINMENT' } },
      { stream_id: 's2', merchant_name: 'Landlord', description: 'RENT', frequency: 'MONTHLY', last_amount: { amount: 2000 }, average_amount: { amount: 2000 }, status: 'MATURE', is_active: true, personal_finance_category: { primary: 'RENT_AND_UTILITIES' } }] },
    '/item/remove': { removed: true } }[p];
  if (b.access_token) assert.equal(b.access_token, 'access-sandbox-1');
  return { ok: true, status: 200, json: async () => R };
};
const h = require(API + 'plaid.js');
const call = async (body) => { const res = {}; await h({ method: 'POST', headers: { host: 'claimclub.io' }, body }, res); return res; };
(async () => {
  let r = await call({ action: 'status' }); assert.equal(r.body.enabled, true); assert.equal(r.body.items.length, 0);
  r = await call({ action: 'link_token' }); assert.equal(r.body.link_token, 'link-sandbox-1');
  r = await call({ action: 'exchange', public_token: 'public-sandbox-1', institution: { name: 'First Platypus Bank', institution_id: 'ins_109508' } });
  assert.equal(r.code, 200, JSON.stringify(r.body));
  const item = fake.T.plaid_items[0]; assert.ok(item.access_token_enc && !item.access_token_enc.includes('access-sandbox'), 'token encrypted');
  const V = Object.fromEntries(r.body.tx.map((t) => [t.transaction_id, t.verdict]));
  console.log('verdicts', V); console.log('subs', r.body.subs.map((s) => [s.merchant, s.per_month]));
  assert.equal(V.t1, 'fight'); assert.equal(V.t2, 'fight'); assert.equal(V.t3, 'fight'); assert.equal(V.t4, 'ok'); assert.equal(V.t5, 'look'); assert.equal(V.t6, 'look');
  assert.ok(!V.t7, 'income hidden'); assert.equal(r.body.subs.length, 1);
  r = await call({ action: 'choose', transaction_id: 't3', choice: 'fight' }); assert.equal(r.body.request.company, 'OVERDRAFT FEE');
  r = await call({ action: 'choose', transaction_id: 't3', choice: 'fight' }); assert.equal(fake.T.refund_requests.length, 1, 'no duplicate request');
  r = await call({ action: 'sub_choice', stream_id: 's1', choice: 'cancel' }); assert.equal(r.body.request.kind, 'cancel');
  r = await call({ action: 'choose', transaction_id: 't4', choice: 'fine' }); assert.equal(r.body.request, null);
  // another user cannot touch this charge
  USER.id = 'u2'; USER.email = 'x@example.com'; r = await call({ action: 'choose', transaction_id: 't3', choice: 'fight' }); assert.equal(r.code, 403);
  fake.T.memberships.push({ user_id: 'u2', kind: 'member', status: 'active' }); fake.T.app_settings = [{ key: 'card_connect', value: true }];
  r = await call({ action: 'choose', transaction_id: 't3', choice: 'fight' }); assert.equal(r.code, 404);
  USER.id = 'u1'; USER.email = 'henry@example.com';
  r = await call({ action: 'remove', item_id: 'item1' }); assert.equal(r.body.items.length, 0); assert.equal((fake.T.bank_transactions || []).length, 0);
  // non-member blocked when switch on
  USER.id = 'u3'; USER.email = 'y@example.com'; r = await call({ action: 'link_token' }); assert.equal(r.code, 403);
  fake.T.memberships.push({ user_id: 'u3', kind: 'fee', status: 'active' }); r = await call({ action: 'link_token' }); assert.equal(r.code, 200, 'fee payer can connect');
  r = await call({ action: 'choose', transaction_id: 't1', choice: 'fight' }); assert.equal(r.code, 403, 'fee payer cannot fight');
  USER.id = 'u4'; USER.email = 'z@example.com'; r = await call({ action: 'status' }); assert.equal(r.body.enabled, false, 'unpaid sees off');
  console.log('server tests passed', calls.join(' '));
})().catch((e) => { console.error(e); process.exit(1); });
