# Nov 18 2026: claim sheet explains the case, checks you qualify, explains the notice, then details. Amazon sample.
from playwright.sync_api import sync_playwright
import json, sys
FAKE=open('/tmp/fake_supabase.js').read()
SPECS={s['id']:s for s in json.load(open('/tmp/site/out/api/_specs.json'))}
_X0=dict(SPECS['amazon'],about='Amazon is accused of keeping money it owed people who returned items. The settlement pays back refunds that were missing, late or too small.',
 who='People who returned an item to Amazon since September 2017 and did not get the full refund on time.',
 qualify=[{'q':'Did you return something to Amazon since September 2017 and get no refund, a late refund or a smaller refund than you expected?','help':'Check Your Orders on Amazon for returns marked refunded late or not at all.'}],
 notice={'mode':'optional','from':'the Amazon Returns Settlement administrator (Angeion Group)','looks':'An email or postcard titled Notice of Class Action Settlement, with a Notice ID and PIN near the top.','fields':[{'k':'notice_id','label':'Notice ID','ph':'ABC1234567'},{'k':'notice_pin','label':'PIN','ph':'A1B2C3'}],'if_none':'No problem. We can file without it using your Amazon order details.'},
 needs=[{'k':'returned_items','kind':'longtext','label':'Which returns were not refunded right?','help':'For each one, the order number and item. Find them in Your Orders on Amazon.','ph':'112-1234567-1234567, wireless earbuds','opts':[],'optional':False,'unsure':"I can't find my orders"}],
 start_note='We fill in the official claim form with your saved info and send you the claim ID.')
W=int(sys.argv[1]) if len(sys.argv)>1 else 1440
calls=[]
def claim(r):
  b=json.loads(r.request.post_data); calls.append(b)
  out={'signed':{},'files':[]} if b['action']=='state' else {'claim':{'settlement_id':b.get('settlement_id'),'status':'requested','answers':b.get('answers',{})}}
  r.fulfill(status=200,content_type='application/json',body=json.dumps(out))
def filing(r):
  from urllib.parse import urlparse,parse_qs
  q=parse_qs(urlparse(r.request.url).query)
  out={'extra':[]} if 'catalog' in q else {'specs':{i:SPECS[i] for i in q['ids'][0].split(',') if i in SPECS}} if 'ids' in q else {'spec':SPECS.get(q['id'][0])}
  r.fulfill(status=200,content_type='application/json',body=json.dumps(out))
with sync_playwright() as p:
  br=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  ctx=br.new_context(viewport={'width':W,'height':900});pg=ctx.new_page();e=[];pg.on('pageerror',lambda x:e.append(str(x)))
  ctx.route('**/supabase-js@2/**',lambda r:r.fulfill(status=200,content_type='application/javascript',body=FAKE))
  ctx.route('**/api/config',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'supabaseUrl':'https://x.supabase.co','supabaseAnonKey':'anon','testMode':True})))
  ctx.route('**/api/membership',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'membership':None if json.loads(r.request.post_data)['action']=='link' else {'kind':'member','plan':'1y','status':'test'}})))
  ctx.route('**/api/plaid',lambda r:r.fulfill(status=200,content_type='application/json',body='{"enabled":false}'))
  ctx.route('**/api/claim',claim); ctx.route('**/api/filing*',filing)
  pg.goto('http://localhost:8790/d/index.html');pg.evaluate("""localStorage.clear();localStorage.setItem('claimclub_session',JSON.stringify({ids:['equifax'],signed:[],plan:'1y',paid:'member',p:{name:'Maria Lopez',email:'maria@example.com',st:'WA'}}))""")
  pg.goto('http://localhost:8790/d/app.html');pg.wait_for_timeout(1000)
  pg.fill('input[type=email]','maria@example.com');pg.click('text=Email me a code');pg.wait_for_timeout(300);c=pg.locator('input[autocomplete="one-time-code"]');c.click();c.type('123456',delay=20);pg.wait_for_timeout(2200)
  pg.goto('http://localhost:8790/dashboard/claims');pg.wait_for_timeout(2000)
  def open_():
    pg.locator('button[aria-label^="File the Equifax"] >> visible=true').first.click(); pg.wait_for_timeout(600)
    d=pg.locator('[role=dialog] >> visible=true').first
    for y in d.locator('button:text-is("Yes")').all(): y.click(); pg.wait_for_timeout(100)
    d.locator('button:has-text("Yes, I qualify")').click(); pg.wait_for_timeout(300); return d
  d=open_()
  d.locator('button:has-text("can")').click(); pg.wait_for_timeout(200)
  pg.screenshot(path='/tmp/eq_no.png'); print('NO text:', d.inner_text()[-520:].replace('\n',' | '))
  d.locator('button:has-text("Save, I")').click(); pg.wait_for_timeout(400)
  print('dialog open after save:', pg.locator('[role=dialog] >> visible=true').count(), '| file calls:', [c['action'] for c in calls])
  d=open_()
  d.locator('button:has-text("Yes, I have it")').click(); pg.wait_for_timeout(200)
  nxt=d.locator('button:has-text("Continue")'); print('continue disabled w/o codes:', 'opacity:.35' in (nxt.get_attribute('style') or '').replace(' ',''))
  ins=d.locator('input[type=text]'); ins.nth(0).fill('EQ12345678'); ins.nth(0).dispatch_event('change'); ins.nth(1).fill('A1B2C3'); ins.nth(1).dispatch_event('change'); pg.wait_for_timeout(200)
  nxt.click(); pg.wait_for_timeout(300)
  d.locator('button:has-text("turned down")').click(); pg.wait_for_timeout(150); d.locator('button:has-text("Continue")').click(); pg.wait_for_timeout(300)
  d.locator('input[placeholder="Type your full legal name"]').fill('Maria Lopez'); d.locator('input[placeholder="Type your full legal name"]').dispatch_event('change')
  d.locator('button:has-text("I agree")').click(); pg.wait_for_timeout(150); d.locator('button:has-text("Sign and submit")').click(); pg.wait_for_timeout(900)
  f=[c for c in calls if c['action']=='file']; print('file answers:', f[-1]['answers'] if f else None); print('errors', e); br.close()
