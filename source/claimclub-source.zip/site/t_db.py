from playwright.sync_api import sync_playwright
import json
FAKE=open('/tmp/fake_supabase.js').read()
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  ctx=b.new_context(viewport={'width':1440,'height':900});pg=ctx.new_page();e=[];pg.on('pageerror',lambda x:e.append(str(x)))
  calls=[]
  ctx.route('**/supabase-js@2/**',lambda r:r.fulfill(status=200,content_type='application/javascript',body=FAKE))
  ctx.route('**/api/config',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'supabaseUrl':'https://x.supabase.co','supabaseAnonKey':'anon','testMode':True})))
  def mem(r):
    calls.append(r.request.post_data);d=json.loads(r.request.post_data)
    body={'membership':None} if d['action']=='link' else {'membership':{'kind':d.get('kind'),'plan':d.get('plan'),'status':'test'}}
    r.fulfill(status=200,content_type='application/json',body=json.dumps(body))
  ctx.route('**/api/membership',mem)
  pg.goto('http://localhost:8790/d/index.html');pg.evaluate('''localStorage.clear();localStorage.setItem('claimclub_session',JSON.stringify({ids:['apple','visa','googleplay','cvs'],signed:['apple'],bank:false,plan:'3m',paid:'member',p:{name:'Maria Lopez',email:'maria.lopez@example.com',phone:'',street:'88 Pine St',city:'Seattle',st:'WA',zip:'98101',dob:''}}))''')
  pg.goto('http://localhost:8790/d/app.html');pg.wait_for_timeout(900);pg.screenshot(path='/tmp/db_signin.png')
  print('signin visible',pg.locator('text=Sign in to your dashboard').count(),'email prefilled',pg.locator('input[type=email]').input_value())
  pg.click('text=Email me a code');pg.wait_for_timeout(300);pg.screenshot(path='/tmp/db_code.png')
  c=pg.locator('input[autocomplete="one-time-code"]');c.click();c.type('111111',delay=30);pg.wait_for_timeout(400);print('bad code err',pg.locator('[role=alert]').inner_text())
  c.fill('');c.type('123456',delay=30);pg.wait_for_timeout(1200)
  print('after login', pg.locator('text=Sign in to your dashboard').count(), [l for l in pg.inner_text('body').split('\n') if 'Hi ' in l][:1])
  db=pg.evaluate("JSON.parse(localStorage.getItem('__fakedb'))");print('claims',[(c['settlement_id'],c['status']) for c in db['claims']],'profile',{k:db['profiles'][0].get(k) for k in ['name','address','state']},'mem',db['memberships'])
  pg.evaluate("(()=>{const db=JSON.parse(localStorage.getItem('__fakedb'));const s=JSON.parse(localStorage.getItem('__fakesess'));db.memberships.push({user_id:s.user.id,kind:'member',plan:'3m',status:'test',started_at:new Date().toISOString(),renews_at:new Date(Date.now()+90*864e5).toISOString()});localStorage.setItem('__fakedb',JSON.stringify(db))})()");pg.reload();pg.wait_for_timeout(1200)
  pg.locator('section[aria-label="Ready to file"] button:has-text("File")').first.click();pg.wait_for_timeout(1300);pg.wait_for_timeout(900)
  db=pg.evaluate("JSON.parse(localStorage.getItem('__fakedb'))");print('after file',[(c['settlement_id'],c['status']) for c in db['claims']])
  pg.locator('button:has-text("Settings")').first.click();pg.locator('button:has-text("Dark")').click();pg.wait_for_timeout(1000)
  db=pg.evaluate("JSON.parse(localStorage.getItem('__fakedb'))");print('theme saved',db['profiles'][0].get('theme'))
  # new device: clear local app data but keep fake db+session
  pg.evaluate("localStorage.removeItem('claimclub_session');localStorage.removeItem('claimclub_app');localStorage.removeItem('claimclub_prefs')")
  pg.reload();pg.wait_for_timeout(1200);print('other device', [l for l in pg.inner_text('body').split('\n') if 'Hi ' in l or 'Settings' in l][:2],'dark',pg.evaluate("!!document.querySelector('.dk')"))
  pg.locator('button:has-text("Dashboard")').first.click();pg.wait_for_timeout(300);print('tracking',pg.locator('section[aria-label="Tracking"]').inner_text()[:80].replace('\n',' | '))
  pg.locator('button:has-text("Settings")').first.click();pg.locator('button:has-text("Manage membership")').click();pg.locator('[role=dialog] button:has-text("Cancel membership")').click();pg.locator('[role=dialog] button:has-text("Cancel membership")').last.click();pg.wait_for_timeout(300)
  print('api calls',calls)
  pg.locator('[role=dialog] button:has-text("Done")').click();pg.locator('button:has-text("Sign out")').click();pg.wait_for_timeout(1200);print('signed out ->',pg.locator('text=Sign in to your dashboard').count())
  print('errs',e);b.close()
