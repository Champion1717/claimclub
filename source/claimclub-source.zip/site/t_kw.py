from playwright.sync_api import sync_playwright
import json,sys
FAKE=open('/tmp/fake_supabase.js').read()
W=int(sys.argv[1]) if len(sys.argv)>1 else 1440
state={'bank_connect':False}
calls=[]
def adm(r):
  d=json.loads(r.request.post_data); calls.append(d); a=d['action']
  if a=='setSetting': state[d['key']]=d['value']
  body={'me':{'admin':True,'email':'owner@claimclub.io','settings':state},'settings':{'settings':state},'setSetting':{'settings':state}}.get(a,{})
  r.fulfill(status=200,content_type='application/json',body=json.dumps(body))
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  ctx=b.new_context(viewport={'width':W,'height':1000},accept_downloads=True);ctx.grant_permissions(['clipboard-read','clipboard-write'],origin='http://localhost:8790')
  pg=ctx.new_page();e=[];pg.on('pageerror',lambda x:e.append(str(x)))
  ctx.route('**/supabase-js@2/**',lambda r:r.fulfill(status=200,content_type='application/javascript',body=FAKE))
  ctx.route('**/api/config',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'supabaseUrl':'https://x.supabase.co','supabaseAnonKey':'anon'})))
  ctx.route('**/api/admin',adm)
  pg.goto('http://localhost:8790/admin/index.html#kw');pg.wait_for_timeout(800)
  pg.fill('#em','owner@claimclub.io');pg.click('#send');pg.wait_for_timeout(400)
  pg.locator('#code').type('123456',delay=30);pg.wait_for_timeout(1200)
  pg.click('.nav[data-v=kw]');pg.wait_for_timeout(500);pg.screenshot(path='/tmp/kw1.png',full_page=True)
  pg.locator('input[data-k]').first.uncheck();pg.wait_for_timeout(200)
  pg.fill('#kwCid','1234567890');pg.locator('#kwCid').dispatch_event('change');pg.wait_for_timeout(200)
  bi=pg.locator('input[data-b]').first; bi.fill('1.75'); bi.dispatch_event('change')
  pg.click('#kwSave');pg.wait_for_timeout(400)
  print('saved', [c for c in calls if c['action']=='setSetting'][-1]['value'])
  pg.click('.seg button[data-t=qm]');pg.wait_for_timeout(300);pg.screenshot(path='/tmp/kw2.png',full_page=True)
  pg.locator('button[data-copy]').first.click();pg.wait_for_timeout(200)
  print('clip', pg.evaluate('navigator.clipboard.readText()')[:80].replace('\n',' | '))
  with pg.expect_download() as dl: pg.click('#kwDl')
  dl.value.save_as('/tmp/kw.csv')
  print('main has', 'Keyword Bidding' in pg.inner_text('#main'))
  print('errors', e); b.close()
