# Nov 21 2026: dashboard gating per tier, device-only mode. t_tierdash.py [width] [std|fast|pri]
import sys, json
from playwright.sync_api import sync_playwright
W = int(sys.argv[1]) if len(sys.argv) > 1 else 1280; T = sys.argv[2] if len(sys.argv) > 2 else 'std'
SESS = {'ids': ['apple', 'visa', 'googleplay', 'realpage', 'tyson'], 'signed': ['apple', 'visa', 'googleplay', 'realpage', 'tyson'], 'plan': T, 'paid': 'std' if T == 'std' else 'member', 'flow': 'g',
        'p': {'name': 'Ana Reyes', 'email': 'ana@gmail.com', 'phone': '5127436190', 'street': '12 Oak St', 'city': 'Austin', 'st': 'TX', 'zip': '78701'}}
with sync_playwright() as p:
  b = p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg = b.new_page(viewport={'width': W, 'height': 900}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
  pg.route(lambda u: 'standard=1' in u, lambda r: r.fulfill(status=200, content_type='application/json', body=json.dumps({'ids': ['apple', 'visa', 'equifax'], 'count': 3})))
  pg.route('**/api/config*', lambda r: r.fulfill(status=200, content_type='application/json', body=json.dumps({'cardConnect': True, 'bankConnect': False, 'offers': ['f']})))
  pg.goto('http://localhost:8790/d/start.html?v=1'); pg.evaluate("s=>{localStorage.clear();localStorage.setItem('claimclub_session',JSON.stringify(s))}", SESS)
  pg.goto('http://localhost:8790/dashboard'); pg.wait_for_timeout(1800); pg.screenshot(path=f'/tmp/td_{T}_claims.png', full_page=True)
  print(T, 'plan state', pg.evaluate("window.__dc&&[__dc.state.plan,__dc.state.stdIds]"), '| File/Upgrade buttons', pg.locator('section[aria-label="Your claims"] button:visible').all_inner_texts()[:12])
  pg.goto('http://localhost:8790/dashboard/settlements'); pg.wait_for_timeout(1500); pg.screenshot(path=f'/tmp/td_{T}_find.png', full_page=True)
  print('find lock:', pg.locator('text=Upgrade to').all_inner_texts()[:3])
  pg.goto('http://localhost:8790/dashboard/refunds'); pg.wait_for_timeout(1200); pg.screenshot(path=f'/tmp/td_{T}_ref.png')
  print('refund lock card:', pg.locator('button:visible', has_text='Priority').all_inner_texts()[:2], '| errs', errs[:3])
  b.close()
