from playwright.sync_api import sync_playwright
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome');pg=b.new_page(viewport={'width':1440,'height':900});e=[];pg.on('pageerror',lambda x:e.append(str(x)))
  pg.goto('http://localhost:8790/d/start.html');pg.wait_for_timeout(800)
  pg.evaluate("__dc.setState({a:{apple:'yes'},email:'t@example.com',plan:'6m',step:__dc.steps().indexOf('plans')})");pg.wait_for_timeout(400)
  t=pg.inner_text('body');import re
  print([l for l in t.split('\n') if re.search(r'\$|75%|Save',l)][:14])
  pg.screenshot(path='/tmp/pr_plans.png')
  pg.evaluate("__dc.setState({buying:'member',step:__dc.steps().indexOf('checkout')})");pg.wait_for_timeout(300)
  t=pg.inner_text('body');print([l for l in t.split('\n') if '$' in l or '75%' in l][:6])
  ex=pg.locator('input[autocomplete="cc-exp"]');ex.click();ex.type('1229',delay=40);print('exp',ex.input_value())
  pg.screenshot(path='/tmp/pr_co.png')
  pg.evaluate("__dc.setState({buying:'fee'})");pg.wait_for_timeout(200);t=pg.inner_text('body');print('fee',[l for l in t.split('\n') if '$' in l][:4])
  pg.evaluate("__dc.setState({step:__dc.steps().indexOf('details')})");pg.wait_for_timeout(300)
  d=pg.locator('input[autocomplete="bday"]');d.click();d.type('04171995',delay=40);print('dob',d.input_value())
  pg.goto('http://localhost:8790/d/index.html');pg.wait_for_timeout(600);pg.evaluate("document.querySelector('#pricing').scrollIntoView()");pg.wait_for_timeout(400);pg.screenshot(path='/tmp/pr_home.png')
  print(e);b.close()
