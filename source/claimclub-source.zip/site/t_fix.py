from playwright.sync_api import sync_playwright
import json
FAKE=open('/tmp/fake_supabase.js').read()
calls=[]
def plaid(r):
  b=json.loads(r.request.post_data); calls.append(b['action'])
  out={'status':{'enabled':True,'env':'sandbox','member':False,'items':[],'tx':[],'subs':[]},'link_token':{'link_token':'link-sandbox-1'}}.get(b['action'],{})
  r.fulfill(status=200,content_type='application/json',body=json.dumps(out))
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  ctx=b.new_context(viewport={'width':1440,'height':900});pg=ctx.new_page();e=[];pg.on('pageerror',lambda x:e.append(str(x)))
  ctx.route('**/supabase-js@2/**',lambda r:r.fulfill(status=200,content_type='application/javascript',body=FAKE))
  ctx.route('**/api/config',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'supabaseUrl':'https://x.supabase.co','supabaseAnonKey':'anon','testMode':True,'bankConnect':True,'cardConnect':True})))
  def mem(r):
    d=json.loads(r.request.post_data)
    if d['action']=='test': pg.evaluate("(()=>{const db=JSON.parse(localStorage.getItem('__fakedb'));const s=JSON.parse(localStorage.getItem('__fakesess'));db.memberships=db.memberships||[];db.memberships.push({user_id:s.user.id,kind:'member',plan:'1m',status:'test'});localStorage.setItem('__fakedb',JSON.stringify(db))})()")
    r.fulfill(status=200,content_type='application/json',body=json.dumps({'membership':None if d['action']=='link' else {'kind':'member','plan':'1m','status':'test'}}))
  ctx.route('**/api/membership',mem)
  ctx.route('**/api/plaid',plaid)
  ctx.route('https://cdn.plaid.com/**',lambda r:r.fulfill(status=200,content_type='application/javascript',body="window.Plaid={create:function(o){return{open:function(){window.__opened=o.token}}}};"))
  pg.goto('http://localhost:8790/d/index.html')
  # leftover session for an account that no longer exists, plus a fresh flow for a new email that chose Connect bank
  pg.evaluate('''localStorage.clear();localStorage.setItem('__fakedb',JSON.stringify({profiles:[],claims:[],memberships:[]}));
    localStorage.setItem('__fakesess',JSON.stringify({access_token:'tok',user:{id:'deleted-user',email:'old@example.com'}}));
    localStorage.setItem('claimclub_session',JSON.stringify({ids:['apple'],signed:[],plan:'1m',paid:'member',p:{name:'New Person',email:'new@example.com'}}));
    localStorage.setItem('claimclub_connect','1')''')
  pg.goto('http://localhost:8790/dashboard');pg.wait_for_timeout(1500)
  t=pg.inner_text('body'); print('asks to sign in', 'Log in to Claimclub' in t, 'email', pg.locator('input[type=email]').input_value())
  pg.click('text=Email me a code');pg.wait_for_timeout(300)
  c=pg.locator('input[autocomplete="one-time-code"]');c.click();c.type('123456',delay=20);pg.wait_for_timeout(2000)
  print('signed in as member', 'Members only' not in pg.inner_text('main'), 'plaid calls', calls, 'link opened', pg.evaluate('window.__opened'), 'flag cleared', pg.evaluate("localStorage.getItem('claimclub_connect')"))
  pg.screenshot(path='/tmp/fix1.png'); print('errors', e)
