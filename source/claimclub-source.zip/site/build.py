import re,json,os,shutil
P='/home/claude/cc/project/'
OUT='/tmp/site/out'
shutil.rmtree(OUT,ignore_errors=True); os.makedirs(OUT+'/d'); os.makedirs(OUT+'/m'); os.makedirs(OUT+'/assets')
bm=json.load(open('/tmp/blobmap.json'))
for b,f in bm.items():
    ext=os.path.splitext(f)[1]; shutil.copy('/home/claude/cc/'+f, f'{OUT}/assets/{b}{ext}')
ext={b:os.path.splitext(f)[1] for b,f in bm.items()}
shutil.copy('/tmp/site/runtime.js',OUT+'/runtime.js')
def page(src,out,title,fix=None,patch='',redirect=''):
    h=open(P+src).read()
    x=h.split('<x-dc>')[1].split('</x-dc>')[0]
    helm=x.split('<helmet>')[1].split('</helmet>')[0]
    body=x.split('</helmet>')[1]
    js=h.split('data-dc-script')[1].split('>',1)[1].rsplit('</script>',1)[0]
    if fix:
        for a,b in fix: 
            assert a in body,(src,a[:50]); body=body.replace(a,b,1)
    body=re.sub(r'/_blob/([a-f0-9]{32})',lambda m:'../assets/'+m.group(1)+ext[m.group(1)],body)
    js=re.sub(r'/_blob/([a-f0-9]{32})',lambda m:'../assets/'+m.group(1)+ext[m.group(1)],js)
    body=body.replace('href="FlowG2D.dc.html','href="start.html').replace('href="FlowG2.dc.html','href="start.html')
    html=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{title}</title>
<link rel="icon" href="/favicon.svg" type="image/svg+xml"><link rel="icon" href="/favicon.ico" sizes="32x32"><link rel="apple-touch-icon" href="/apple-touch-icon.png">
{redirect}{helm}<style>html,body{{margin:0}}sc-if,sc-for{{display:contents}}</style></head><body><template id="tpl">{body}</template><div id="root"></div>
<script src="../runtime.js"></script><script src="../live.js"></script><script>
{js}
bootDC(Component,{{}},{patch or 'null'});
</script></body></html>'''
    open(OUT+'/'+out,'w').write(html)
livevis="(c,v)=>{v.visStats=false;v.visTracker=true;return v}"
toM=lambda p:f"<script>if(innerWidth<820)location.replace('../m/{p}')</script>"
page('LandingG2.dc.html','d/index.html','Claimclub · You could be owed money',patch=livevis,redirect=toM('index.html'))
page('LandingG2M.dc.html','m/index.html','Claimclub · You could be owed money',patch=livevis)
appnav="(c,v)=>ccLive(c,v)"
page('FlowG2D.dc.html','d/start.html','Claimclub · Check what you are owed',fix=[('<div style="position: relative; width: 1280px; height: 800px;','<div style="position: relative; width: 100%; height: 100vh; min-height: 760px;')],patch=appnav,redirect=toM('start.html'))
page('FlowG2.dc.html','m/start.html','Claimclub · Check what you are owed',fix=[('<div style="position: relative; width: 390px; height: 844px;','<div style="position: relative; width: 100%; max-width: 520px; margin: 0 auto; height: 100dvh;')],patch=appnav)
page('AppG2.dc.html','d/app.html','Claimclub · Your claims',redirect=toM('app.html'))
page('AppG2M.dc.html','m/app.html','Claimclub · Your claims',patch="(c,v)=>{if(c.state.tour!==99)c.state.tour=99;return v}")
open(OUT+'/index.html','w').write("<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>Claimclub</title><link rel=icon href=/favicon.svg type=image/svg+xml><link rel=icon href=/favicon.ico sizes=32x32><link rel=apple-touch-icon href=/apple-touch-icon.png><script>location.replace(innerWidth<820?'m/index.html':'d/index.html')</script>")
json.dump({"trailingSlash":False},open(OUT+'/vercel.json','w'))
shutil.copy('/tmp/site/live.js',OUT+'/live.js');
for f in ['favicon.svg','favicon.ico','favicon-32.png','apple-touch-icon.png','icon-512.png']: shutil.copy('/tmp/site/'+f,OUT+'/'+f)
shutil.copytree('/tmp/site/api',OUT+'/api'); shutil.copy('/tmp/site/package.json.site',OUT+'/package.json')
print(os.listdir(OUT))
