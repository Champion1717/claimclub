import re,json,os,shutil
PIXEL=open('/tmp/site/pixel.html').read()
import re as _re
_H='|'.join(sorted(set(_re.findall(r"id: '([\w-]+)'[^}]*cat: 'health'",open('/home/claude/cc/src/data.js').read()))))
PIXEL=PIXEL.replace('__HEALTH__',_H)
HOVER=open('/tmp/site/hover.html').read()
# Android app (Trusted Web Activity) and install support: web app manifest plus a network-only service worker (site/pwa/).
PWA='<link rel="manifest" href="/manifest.webmanifest"><meta name="theme-color" content="#FFFFFF"><script>if("serviceWorker" in navigator)addEventListener("load",function(){navigator.serviceWorker.register("/sw.js").catch(function(){})})</script>'  # site-wide button hover CSS  # Meta Pixel, see pixel.html
P='/home/claude/cc/project/'
OUT='/tmp/site/out'
shutil.rmtree(OUT,ignore_errors=True); os.makedirs(OUT+'/d'); os.makedirs(OUT+'/m'); os.makedirs(OUT+'/assets')
bm=json.load(open('/tmp/blobmap.json'))
for b,f in bm.items():
    ext=os.path.splitext(f)[1]; shutil.copy('/home/claude/cc/'+f, f'{OUT}/assets/{b}{ext}')
ext={b:os.path.splitext(f)[1] for b,f in bm.items()}
shutil.copy('/tmp/site/runtime.js',OUT+'/runtime.js')
def page(src,out,title,fix=None,patch='',redirect='',meta=''):
    h=open(P+src).read()
    x=h.split('<x-dc>')[1].split('</x-dc>')[0]
    helm=x.split('<helmet>')[1].split('</helmet>')[0]
    body=x.split('</helmet>')[1]
    js=h.split('data-dc-script')[1].split('>',1)[1].rsplit('</script>',1)[0]
    if fix:
        for a,b in fix: 
            assert a in body,(src,a[:50]); body=body.replace(a,b,1)
    body=re.sub(r'/_blob/([a-f0-9]{32})',lambda m:'/assets/'+m.group(1)+ext[m.group(1)],body)
    js=re.sub(r'/_blob/([a-f0-9]{32})',lambda m:'/assets/'+m.group(1)+ext[m.group(1)],js)
    body=body.replace('href="DashA.dc.html','href="/dashboard').replace('href="FlowG2D.dc.html','href="/claim').replace('href="FlowG2.dc.html','href="/claim')
    for a,b in (('href="start.html','href="/claim'),('href="app.html','href="/login'),('https://claimclub.io/about.html','/about'),('"/d/start.html','"/claim'),("'/d/start.html","'/claim"),('href="/about.html','href="/about'),
                ('/legal/terms.html','/terms'),('/legal/privacy.html','/privacy'),('/legal/authorization.html','/authorization'),('https://claimclub.io/legal/','https://claimclub.io/legal/')):
        body=body.replace(a,b); js=js.replace(a,b)
    js=js.replace("'app.html?login=' + encodeURIComponent","'/login?email=' + encodeURIComponent")
    html=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{title}</title>
<link rel="icon" href="/favicon.svg" type="image/svg+xml"><link rel="icon" href="/favicon.ico" sizes="32x32"><link rel="apple-touch-icon" href="/apple-touch-icon.png">{PWA}
{meta}{redirect}{PIXEL}{helm}{HOVER}<style>html,body{{margin:0}}sc-if,sc-for{{display:contents}}</style></head><body><template id="tpl">{body}</template><div id="root"></div>
<script src="/runtime.js"></script><script src="/live.js"></script><script>
{js}
bootDC(Component,{{}},{patch or 'null'});
</script></body></html>'''
    open(OUT+'/'+out,'w').write(html)
SITE='https://www.claimclub.io'
def seo(path,title,desc,index=True,ld=''):
    # Search engines: canonical clean URL on www, description, social cards. Private pages get noindex.
    import html as _h
    t,d=_h.escape(title),_h.escape(desc)
    if not index: return '<meta name="robots" content="noindex, nofollow">\n'
    return (f'<meta name="description" content="{d}"><link rel="canonical" href="{SITE}{path}">'
            f'<meta property="og:type" content="website"><meta property="og:site_name" content="Claimclub"><meta property="og:title" content="{t}"><meta property="og:description" content="{d}">'
            f'<meta property="og:url" content="{SITE}{path}"><meta property="og:image" content="{SITE}/og.png"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">'
            f'<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="{t}"><meta name="twitter:description" content="{d}"><meta name="twitter:image" content="{SITE}/og.png">{ld}\n')
HOME_T='Claimclub · Find class action settlements you could be owed money from'
HOME_D="See which open class action settlements you qualify for in about a minute. Free to check. Claimclub prepares and files your claims, and every payout goes straight to you."
CLAIM_D="Answer a few quick yes or no questions to see which class action settlements you could claim money from. Free to check, no account needed."
LD=('<script type="application/ld+json">'+json.dumps({"@context":"https://schema.org","@graph":[
    {"@type":"Organization","@id":"https://www.claimclub.io/#org","name":"Claimclub","alternateName":["Claim Club","ClaimClub","claimclub.io"],"legalName":"DBC Workshop LLC",
     "url":"https://www.claimclub.io/","logo":{"@type":"ImageObject","url":"https://www.claimclub.io/icon-512m.png","width":512,"height":512},"image":"https://www.claimclub.io/og.png",
     "description":"Claimclub finds open class action settlements you qualify for and prepares and files your claims. Every payout goes straight to you.",
     "email":"support@mail.claimclub.io","address":{"@type":"PostalAddress","streetAddress":"408 Andrew Ave","addressLocality":"Encinitas","addressRegion":"CA","postalCode":"92024","addressCountry":"US"},
     "areaServed":"US","sameAs":["https://www.facebook.com/1512659508594888"]},
    {"@type":"WebSite","@id":"https://www.claimclub.io/#site","name":"Claimclub","alternateName":["Claim Club","claimclub.io"],"url":"https://www.claimclub.io/","inLanguage":"en-US","publisher":{"@id":"https://www.claimclub.io/#org"}}]},separators=(',',':'))+'</script>')
livevis="(c,v)=>{v.visStats=false;v.visTracker=true;return v}"
def sw(p, side, mn=820, live=True):
    # Clean URLs (/, /claim, /dashboard) are served by vercel.json rewrites that pick d/ or m/ from a cookie (cc_site / cc_app) or, on a first visit, the user agent.
    # This script checks the real window width and, if the other build fits better, sets the cookie and reloads the same clean URL. live=True also re-checks on resize/rotation.
    # If cookies are blocked it falls back once to the plain file path with ?v=1 (old file paths redirect to clean URLs unless v is present).
    other = 'm' if side == 'd' else 'd'
    ck = 'cc_app' if p == 'app.html' else 'cc_site'
    cond = f"innerWidth<{mn}" if side == 'd' else f"innerWidth>={mn}"
    js = (f"(function(){{function c(){{if(!({cond}))return;document.cookie='{ck}={other};path=/;max-age=31536000;samesite=lax';"
          f"var k='ccsw_{ck}';if(document.cookie.indexOf('{ck}={other}')<0||sessionStorage.getItem(k)==='{other}'){{location.replace('/{other}/{p}?v=1'+location.search.replace(/^\\?/,'&')+(/^\\/claim\\/([\\w-]+)/i.test(location.pathname)?'&claim='+RegExp.$1:'')+location.hash);return}}"
          f"try{{sessionStorage.setItem(k,'{other}')}}catch(e){{}}location.reload()}}"
          f"try{{if(sessionStorage.getItem('ccsw_{ck}')==='{side}')sessionStorage.removeItem('ccsw_{ck}')}}catch(e){{}}c();")
    if live: js += "var t;addEventListener('resize',function(){clearTimeout(t);t=setTimeout(c,250)});"
    return '<script>' + js + '})()</script>'
toM=lambda p:sw(p,'d')
page('LandingG2.dc.html','d/index.html',HOME_T,redirect=toM('index.html'),meta=seo('/',HOME_T,HOME_D,ld=LD))
page('LandingG2M.dc.html','m/index.html',HOME_T,redirect=sw('index.html','m'),meta=seo('/',HOME_T,HOME_D,ld=LD))
appnav="(c,v)=>ccLive(c,v)"
page('FlowG2D.dc.html','d/start.html','Claimclub · Check what you are owed',meta=seo('/claim','Claimclub · Check what you are owed',CLAIM_D),fix=[('<div style="position: relative; width: 1280px; height: 800px;','<div style="position: relative; width: 100%; height: 100vh; min-height: 760px;')],patch=appnav,redirect=sw('start.html','d',live=False))
page('FlowG2.dc.html','m/start.html','Claimclub · Check what you are owed',meta=seo('/claim','Claimclub · Check what you are owed',CLAIM_D),fix=[('<div style="position: relative; width: 390px; height: 844px;','<div style="position: relative; width: 100%; max-width: 520px; margin: 0 auto; height: 100dvh;')],patch=appnav,redirect=sw('start.html','m',live=False))
SUPA='<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.js"></script>'
page('DashA.dc.html','d/app.html','Claimclub · Your claims',meta=seo('/dashboard','','',index=False),redirect=sw('app.html','d',1100)+SUPA)
page('DashAM.dc.html','m/app.html','Claimclub · Your claims',meta=seo('/dashboard','','',index=False),redirect=sw('app.html','m',1100)+SUPA)
# Clean URLs. Static files win over rewrites on Vercel, so there is no root index.html.
MUA='.*(iPhone|iPod|Android.*Mobile|Windows Phone|BlackBerry).*'; TUA='.*(iPhone|iPod|iPad|Android|Mobile).*'
def pick(src, f, ck, ua):
    return [{"source":src,"has":[{"type":"cookie","key":ck,"value":"m"}],"destination":"/m/"+f},{"source":src,"has":[{"type":"cookie","key":ck,"value":"d"}],"destination":"/d/"+f},
            {"source":src,"has":[{"type":"header","key":"user-agent","value":ua}],"destination":"/m/"+f},{"source":src,"destination":"/d/"+f}]
rw=pick('/','index.html','cc_site',MUA)+pick('/claim','start.html','cc_site',MUA)+pick('/claim/:id','start.html','cc_site',MUA)+pick('/dashboard','app.html','cc_app',TUA)+pick('/dashboard/:section','app.html','cc_app',TUA)+pick('/login','app.html','cc_app',TUA)
rw+=[{"source":"/delete-account","destination":"/legal/delete-account.html"}]
rw+=[{"source":"/terms","destination":"/legal/terms.html"},{"source":"/privacy","destination":"/legal/privacy.html"},{"source":"/authorization","destination":"/legal/authorization.html"},{"source":"/security","destination":"/legal/security.html"},{"source":"/about","destination":"/about.html"},{"source":"/admin","destination":"/admin/index.html"}]
nov=[{"type":"query","key":"v"}]
rd=[{"source":s_,"destination":d_,"permanent":True,"missing":nov} for s_,d_ in [("/index.html","/"),("/d/index.html","/"),("/m/index.html","/"),("/d/start.html","/claim"),("/m/start.html","/claim"),("/start","/claim"),
     ("/d/app.html","/dashboard"),("/m/app.html","/dashboard"),("/app","/dashboard"),("/legal/terms.html","/terms"),("/legal/privacy.html","/privacy"),("/legal/authorization.html","/authorization"),("/legal/security.html","/security"),("/legal/delete-account.html","/delete-account"),("/about.html","/about"),("/admin/index.html","/admin")]]
NOIDX=[{"key":"X-Robots-Tag","value":"noindex, nofollow"}]
hd=[{"source":s_,"headers":NOIDX} for s_ in ["/dashboard","/dashboard/(.*)","/login","/admin","/admin/(.*)","/api/(.*)","/d/app.html","/m/app.html"]]
hd.insert(0,{"source":"/(.*)","headers":[{"key":"X-Content-Type-Options","value":"nosniff"},{"key":"Referrer-Policy","value":"strict-origin-when-cross-origin"},{"key":"X-Frame-Options","value":"SAMEORIGIN"},{"key":"Strict-Transport-Security","value":"max-age=63072000; includeSubDomains"}]})
hd+=[{"source":"/sw.js","headers":[{"key":"Cache-Control","value":"no-cache"},{"key":"Service-Worker-Allowed","value":"/"}]},
    {"source":"/manifest.webmanifest","headers":[{"key":"Content-Type","value":"application/manifest+json"}]},
    {"source":"/.well-known/assetlinks.json","headers":[{"key":"Content-Type","value":"application/json"},{"key":"Access-Control-Allow-Origin","value":"*"}]}]
hd+=[{"source":s_,"headers":[{"key":"Vary","value":"User-Agent, Cookie"}]} for s_ in ["/","/claim","/claim/(.*)"]]  # same URL serves d/ or m/ by device
# Case finder runs once a day (Vercel Cron, UTC); staff can also run it from /admin > New cases.
json.dump({"trailingSlash":False,"redirects":rd,"rewrites":rw,"headers":hd,"crons":[{"path":"/api/find-cases","schedule":"17 14 * * *"}],"functions":{"api/find-cases.js":{"maxDuration":60}}},open(OUT+'/vercel.json','w'),indent=1)
open(OUT+'/robots.txt','w').write("User-agent: *\nAllow: /\nDisallow: /api/\n\nSitemap: "+SITE+"/sitemap.xml\n")
import datetime as _dt
_today=_dt.date.today().isoformat()
_urls=[('/','1.0','weekly'),('/delete-account','0.2','yearly'),('/claim','0.9','weekly'),('/about','0.6','monthly'),('/terms','0.3','yearly'),('/privacy','0.3','yearly'),('/security','0.3','yearly'),('/authorization','0.3','yearly')]
open(OUT+'/sitemap.xml','w').write('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+''.join(f'  <url><loc>{SITE}{u}</loc><lastmod>{_today}</lastmod><changefreq>{c}</changefreq><priority>{p}</priority></url>\n' for u,p,c in _urls)+'</urlset>\n')
if os.path.exists('/tmp/site/og.png'): shutil.copy('/tmp/site/og.png',OUT+'/og.png')
shutil.copy('/tmp/site/live.js',OUT+'/live.js');
for f in ['favicon.svg','favicon.ico','favicon-32.png','apple-touch-icon.png','icon-512.png']: shutil.copy('/tmp/site/'+f,OUT+'/'+f)
for f in ['manifest.webmanifest','sw.js','offline.html','icon-192.png','icon-512m.png']: shutil.copy('/tmp/site/pwa/'+f,OUT+'/'+f)
if os.path.exists('/tmp/site/pwa/assetlinks.json'): os.makedirs(OUT+'/.well-known',exist_ok=True); shutil.copy('/tmp/site/pwa/assetlinks.json',OUT+'/.well-known/assetlinks.json')
shutil.copytree('/tmp/site/api',OUT+'/api'); shutil.copy('/home/claude/cc/data/filing_specs.json',OUT+'/api/_specs.json'); json.dump([{'id':d['id'],'co':d['co'],'title':d['title']} for d in json.load(open('/home/claude/cc/concepts/sets.json'))],open(OUT+'/api/_catalog.json','w'),separators=(',',':')); shutil.copy('/tmp/site/package.json.site',OUT+'/package.json')
print(os.listdir(OUT))

import subprocess
subprocess.run(['python3','/tmp/site/legal_src/build_legal.py'],check=True)

# Staff admin dashboard (/admin). Settlement names come from the member app's data.
import json as _json
_sets=_json.load(open('/home/claude/cc/concepts/sets.json'))
_S={d['id']:{'c':d['co'],'t':d['title'],'p':d.get('pay',''),'dl':d.get('dl') or '','w':d.get('who',''),'pr':d.get('proof','')} for d in _sets}
os.makedirs(OUT+'/admin',exist_ok=True)
open(OUT+'/admin/index.html','w').write(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'admin_src','admin.html')).read().replace('__SETS__',_json.dumps(_S,separators=(',',':'))).replace('</head>',HOVER+'</head>',1))
