from playwright.sync_api import sync_playwright
import sys
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  for w,h,pg_ in [(1440,900,'dasha'),(390,844,'dasham')]:
    t=pg_[-1]
    pg=b.new_page(viewport={'width':w,'height':h});e=[];pg.on('pageerror',lambda x:e.append(str(x)))
    pg.goto(f'http://localhost:8790/d/{pg_}.html');pg.wait_for_timeout(700)
    pg.locator('button.cname').first.click();pg.wait_for_timeout(400);pg.screenshot(path=f'/tmp/n_{t}_det.png')
    print(t,'sheet', pg.locator('[role=dialog]').count(), pg.locator('[role=dialog]').inner_text()[:160].replace('\n',' | '))
    pg.locator('[role=dialog] button:has-text("Close")').click();pg.wait_for_timeout(200)
    pg.locator('section[aria-label="Tracking"] button.cname').first.click();pg.wait_for_timeout(300);print(t,'track sheet', pg.locator('[role=dialog]').inner_text()[:90].replace('\n',' | '))
    pg.locator('[role=dialog] button:has-text("Close")').click();pg.wait_for_timeout(200)
    # make find box show: mark all ready as filed
    pg.evaluate("(()=>{const s=__dc.state.st, n={};Object.keys(s).forEach(k=>n[k]=s[k]==='ready'?'filed':s[k]);__dc.setState({st:n})})()");pg.wait_for_timeout(300)
    pg.locator('button:has-text("Browse all")').first.click();pg.wait_for_timeout(300)
    print(t,'browse ->', pg.locator('text=/\\d+ results/').first.inner_text())
    pg.evaluate("__dc.setState({view:'dash'})");pg.wait_for_timeout(300)
    pg.locator('button:has-text("Scan near me")').first.click();pg.wait_for_timeout(300)
    print(t,'near ->', pg.locator('text=/\\d+ results/').first.inner_text(), pg.evaluate("__dc.state.scope"));pg.screenshot(path=f'/tmp/n_{t}_near.png')
    pg.evaluate("__dc.setState({view:'info'})");pg.wait_for_timeout(300)
    pg.locator('[role=radio]:has-text("Venmo")').click();pg.wait_for_timeout(200)
    inp=pg.locator('input[aria-label="Email or phone on your Venmo account"]');inp.fill('bad');inp.dispatch_event('change');pg.locator('button:has-text("Save")').last.click();pg.wait_for_timeout(150)
    print(t,'err',pg.locator('[role=alert]').last.inner_text())
    inp.fill('(415) 555-0134');inp.dispatch_event('change');pg.locator('button:has-text("Save")').last.click();pg.wait_for_timeout(200)
    print(t,'venmo',pg.evaluate("JSON.stringify([__dc.state.payDef,__dc.state.payH])"))
    pg.locator('text=Default payout method').first.scroll_into_view_if_needed();pg.screenshot(path=f'/tmp/n_{t}_pay.png')
    pg.evaluate("__dc.setState({view:'dash'})");pg.wait_for_timeout(200);pg.locator('button.cname').first.click();pg.wait_for_timeout(300)
    print(t,'dest',[l for l in pg.locator('[role=dialog]').inner_text().split('\n') if 'Venmo' in l])
    print(t,'errors',e)
  b.close()
