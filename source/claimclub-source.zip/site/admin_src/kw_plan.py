"""Google Ads keyword plan for /admin > Keyword Bidding.
Volumes and CPCs: Ahrefs, US, pulled Nov 19 2026. Rerun after edits: python3 kw_plan.py (writes kw_plan.json, embedded by site/build.py).
Rules: no competitor names in ad text, only in keywords. Ad copy must stay honest (payouts come when each settlement pays out)."""
import json, os, re

URL = 'https://www.claimclub.io/claim'

# (keyword, monthly US volume, Ahrefs CPC in cents or None, match types)
E, P = ['exact'], ['phrase']
EP = ['exact', 'phrase']

CAMPAIGNS = [
  dict(id='comp', name='CC Search - Competitors', budget=25, floor=100, cap=250,
    note='People searching for another claim app or settlement site by name. Our ads never name them.',
    groups=[
      ('ClaimMoney', [('claimmoney', 8400, 50, EP), ('claimmoney.com', 4800, 60, E), ('claim money app', 70, None, EP)]),
      ('Settlemate', [('settlemate', 18000, 25, EP), ('settlemate app', None, None, EP)]),
      ('ClaimHunt', [('claimhunt', 1800, 60, EP), ('claim hunt app', 1700, 70, EP), ('claim hunt class action', 800, 80, EP)]),
      ('Sparrow', [('sparrow class action', 1100, 25, EP), ('usesparrow', 300, 20, E), ('sparrow settlement app', None, None, P)]),
      ('Claim Depot', [('claim depot', 900, 300, EP), ('claimdepot', 700, 250, E)]),
      ('Top Class Actions', [('top class actions', 2800, 3, EP), ('topclassactions', 3800, 50, E)]),
      ('ClassAction.org and OpenClassActions', [('classaction.org', 2400, 400, E), ('openclassactions', 1000, 300, E), ('open class actions', 600, 150, EP), ('classaction.com', 100, 35, E)]),
      ('Other claim apps', [('claimhood', 700, 100, EP), ('claimify', 250, 600, E), ('claimbee', 150, 200, EP), ('claimly', 100, None, E),
                            ('collect settlement app', 250, None, EP), ('payout claim class action', 2200, 45, P), ('catch settlement app', 40, None, P),
                            ('oweyou app', 60, None, E), ('class action buddy', 50, None, EP), ('corresi', 50, None, E)]),
    ],
    negatives=['login', 'log in', 'sign in', 'customer service', 'phone number', 'cancel', 'refund', 'careers', 'jobs', 'lawyer', 'attorney']),

  dict(id='set', name='CC Search - Settlement claims', budget=25, floor=100, cap=300,
    note='People already looking for settlements to claim. Closest match to what we sell.',
    groups=[
      ('Find settlements', [('class action settlements', 19000, 140, EP), ('class action settlement', 4200, 130, EP), ('open class action settlements', 5000, 350, EP),
                            ('current class action settlements', 600, 300, EP), ('class action settlements to join', 2300, 200, EP), ('class action lawsuits to join', 5700, 250, EP),
                            ('class action settlement claims', 1700, 250, EP), ('settlement class action', 2000, 140, P), ('class action lawsuit settlements', 1300, 180, P),
                            ('how to find class action settlements', 100, 80, P), ('open settlements', 1700, 400, E)]),
      ('Settlement apps', [('settlement app', 2500, 45, EP), ('class action settlement app', 100, 50, EP), ('settlement finder', 900, 80, EP), ('class action app', 20, None, P)]),
      ('No proof needed', [('class action settlements no proof of purchase', 6000, 45, EP), ('largest class action settlements no proof of purchase', 4300, 110, P),
                           ('no proof class action settlements', 1700, 120, EP), ('class action lawsuit no proof', 6800, 150, EP), ('no proof class action lawsuits', 4900, 90, P),
                           ('class action lawsuits no proof', 4700, 250, P), ('open class action lawsuits no proof', 1500, 180, P), ('open class action settlements no proof', 600, 120, P)]),
      ('Owed money', [('unclaimed money class action settlements', 3100, 70, EP), ('am i owed money', 300, 35, EP), ('money owed to me', 800, 40, P), ('unclaimed settlement money', 100, 50, P)]),
      ('Our open settlements', [('apple siri settlement', 1500, 45, EP), ('apple settlement claim', 2800, 20, P), ('apple intelligence settlement', 150, None, P),
                                ('atm class action claim form', 1300, 35, EP), ('visa mastercard atm settlement', 100, 110, P), ('atm fee settlement', 150, None, P),
                                ('google play settlement', 500, 80, EP), ('realpage settlement', 200, 130, P), ('goodrx settlement', 200, None, P), ('toyota airbag settlement', 350, 300, P)]),
    ],
    negatives=['lawyer', 'attorney', 'law firm', 'how to start', 'sue', 'reddit', 'news', 'stock', 'shareholder']),

  dict(id='qm', name='CC Search - Quick money (test)', budget=10, floor=50, cap=150,
    note='People who want money fast. Wider and cheaper, so bids start low. Ads must say payouts come when settlements pay out, never instant.',
    groups=[
      ('Free money', [('free money', 41000, 200, P), ('free money now', 1800, 250, P), ('get free money', 1700, 300, P), ('how to get free money', 8800, 250, P),
                      ('free money online', 2600, 200, P), ('free money apps', 3400, 200, P), ('apps that give you free money', 200, 300, P)]),
      ('Money fast', [('how to make money fast', 43000, 250, P), ('make money fast', 9100, 300, P), ('quick money', 4700, 400, P), ('ways to make quick money', 2300, 250, P),
                      ('get money fast', 2500, 450, P), ('how to get money fast', 15000, 350, P), ('need money now', 11000, 400, P), ('how to make 100 dollars fast', 800, 200, P),
                      ('easy money', 15000, 300, P), ('extra cash', 1400, 500, P)]),
      ('Unclaimed money', [('unclaimed money', 41000, 20, E), ('find unclaimed money', 1000, 50, E), ('unclaimed money search', 1800, 45, E)]),
    ],
    negatives=['loan', 'loans', 'payday', 'borrow', 'advance', 'credit card', 'casino', 'slots', 'spins', 'bonus', 'bet', 'betting', 'gambling', 'poker', 'lottery',
               'grant', 'grants', 'government', 'stimulus', 'ebt', 'snap', 'unemployment', 'social security', 'irs', 'tax refund', 'cash app code', 'code', 'hack',
               'generator', 'glitch', 'job', 'jobs', 'hiring', 'survey', 'surveys', 'crypto', 'bitcoin', 'invest', 'investing', 'stocks', 'game', 'games', 'roblox', 'robux',
               'church', 'prayer', 'spell', 'state of', 'treasury', 'missing money', 'property']),
]

# Negatives on every campaign.
SHARED_NEG = ['free lawyer', 'pro bono', 'class action lawyer', 'mesothelioma', 'asbestos', 'personal injury', 'car accident', 'workers comp', 'porn', 'xxx', 'scam']

ADS = {
  'comp': dict(h=['Find Settlements Owed to You', 'Claimclub: We File for You', 'Free Eligibility Check', '$2 for 7 Days, Then $49/Year', 'We File Your Claims for You',
                  'Hundreds of Open Settlements', 'No Lawyer Needed', 'Answer a Few Yes/No Questions', 'Track Every Claim in One App', 'You Keep 100% of Payouts',
                  'Apple, Visa, Google & More', 'Court-Approved Settlements', 'A Simpler Settlement App', 'See What You Could Be Owed', 'Cancel Anytime'],
               d=['Answer a few yes/no questions and see which open settlements you may qualify for.',
                  'We file eligible claims for you and track every payout in one simple dashboard.',
                  'Try Claimclub for $2 for 7 days, then $49 a year. Cancel anytime before it renews.',
                  'Payouts come from court-approved settlements, usually 2 to 6 months after the deadline.']),
  'set': dict(h=['Open Class Action Settlements', 'See Which Ones You Qualify For', 'We File Your Claims for You', 'Free Eligibility Check', 'No Proof Needed for Many',
                 '$2 for 7 Days, Then $49/Year', 'Apple, Visa, Google & More', 'Claimclub Settlement Finder', 'Answer a Few Yes/No Questions', 'Track Every Payout in One App',
                 'You Keep 100% of Payouts', 'New Settlements Every Week', 'Never Miss a Claim Deadline', 'Court-Approved Settlements', 'File Claims in Minutes'],
              d=['Answer a few yes/no questions and see which open class action settlements fit you.',
                 'We file eligible claims for you, remind you of deadlines and track each payout.',
                 'Many settlements need no proof of purchase. Check yours free in about 2 minutes.',
                 '$2 for a 7-day trial, then $49 a year. Cancel anytime. You keep 100% of payouts.']),
  'qm': dict(h=['Companies May Owe You Money', 'Check What You Could Be Owed', 'Real Settlement Payouts', 'Free Eligibility Check', 'Money From Settlements',
                'We File the Claims for You', 'Takes About 2 Minutes', 'No Lawyer Needed', '$2 for 7 Days, Then $49/Year', 'Apple, Visa, Google & More',
                'You Keep 100% of Payouts', 'Answer a Few Yes/No Questions', 'Court-Approved Settlements', 'See Your Matches Free', 'Claimclub'],
             d=['Companies settle lawsuits and pay customers. See which settlements you may qualify for.',
                'Answer a few yes/no questions. We file eligible claims for you and track each payout.',
                'Payouts come when each settlement pays, usually 2 to 6 months after the deadline.',
                '$2 for a 7-day trial, then $49 a year. Cancel anytime. You keep 100% of payouts.']),
}

def slug(s): return re.sub(r'[^a-z0-9]+', '-', s.lower()).strip('-')

def bid(cpc, c):
  base = cpc if cpc else c['floor']
  return max(c['floor'], min(c['cap'], int(round(base * 1.1 / 5.0) * 5)))

out = {'pulled': '2026-11-19', 'source': 'Ahrefs, United States', 'url': URL, 'shared_negatives': SHARED_NEG, 'campaigns': []}
seen = set()
for c in CAMPAIGNS:
  ad = ADS[c['id']]
  for h in ad['h']: assert len(h) <= 30, ('headline too long', h, len(h))
  for d in ad['d']: assert len(d) <= 90, ('description too long', d, len(d))
  assert len(ad['h']) == 15 and len(ad['d']) == 4
  for t in ad['h'] + ad['d']: assert '—' not in t
  cc = {'id': c['id'], 'name': c['name'], 'budget': c['budget'], 'note': c['note'], 'negatives': c['negatives'],
        'suffix': 'utm_source=google&utm_medium=cpc&utm_campaign=' + slug(c['name']) + '&utm_term={keyword}', 'ads': ad, 'groups': []}
  for gname, kws in c['groups']:
    g = {'name': gname, 'keywords': []}
    for kw, vol, cpc, matches in kws:
      for m in matches:
        k = c['id'] + ':' + m + ':' + kw
        assert k not in seen, k; seen.add(k)
        g['keywords'].append({'id': k, 'kw': kw, 'match': m, 'vol': vol, 'cpc': cpc, 'bid': bid(cpc, c)})
    cc['groups'].append(g)
  out['campaigns'].append(cc)

here = os.path.dirname(os.path.abspath(__file__))
json.dump(out, open(os.path.join(here, 'kw_plan.json'), 'w'), indent=1)
print(sum(len(g['keywords']) for c in out['campaigns'] for g in c['groups']), 'keywords')
