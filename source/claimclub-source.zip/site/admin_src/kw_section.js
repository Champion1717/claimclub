// ---------- keyword bidding ----------
const kwSyntax = (k) => k.match === 'exact' ? '[' + k.kw + ']' : k.match === 'phrase' ? '"' + k.kw + '"' : k.kw;
const money = (c) => c == null ? '' : '$' + (c / 100).toFixed(2);
function kwState() {
  const p = (me.settings && me.settings.kw_plan) || {};
  if (!cache.kw) cache.kw = { tab: 'comp', customer_id: p.customer_id || '', off: new Set(p.off || []), bids: Object.assign({}, p.bids || {}), budgets: Object.assign({}, p.budgets || {}), dirty: false };
  return cache.kw;
}
const kwBid = (st, k) => st.bids[k.id] != null ? st.bids[k.id] : k.bid;
const kwBudget = (st, c) => st.budgets[c.id] != null ? st.budgets[c.id] : c.budget;
function kwCsv(st) {
  const H = ['Campaign', 'Campaign Type', 'Networks', 'Budget', 'Budget type', 'Bid Strategy Type', 'Campaign Status', 'Languages', 'Location', 'Final URL suffix', 'Ad Group', 'Max CPC', 'Ad Group Status', 'Keyword', 'Criterion Type', 'Status', 'Ad type']
    .concat([...Array(15)].map((_, i) => 'Headline ' + (i + 1)), [...Array(4)].map((_, i) => 'Description ' + (i + 1)), ['Path 1', 'Path 2', 'Final URL']);
  const rows = [H];
  const row = (o) => rows.push(H.map((h) => o[h] == null ? '' : String(o[h])));
  KW.campaigns.forEach((c) => {
    const groups = c.groups.filter((g) => g.keywords.some((k) => !st.off.has(k.id)));
    if (!groups.length) return;
    row({ Campaign: c.name, 'Campaign Type': 'Search', Networks: 'Google search', Budget: kwBudget(st, c).toFixed(2), 'Budget type': 'Daily', 'Bid Strategy Type': 'Manual CPC', 'Campaign Status': 'Paused', Languages: 'en', 'Final URL suffix': c.suffix });
    row({ Campaign: c.name, Location: 'United States' });
    KW.shared_negatives.concat(c.negatives).forEach((n) => row({ Campaign: c.name, Keyword: n, 'Criterion Type': 'Negative Phrase' }));
    groups.forEach((g) => {
      const on = g.keywords.filter((k) => !st.off.has(k.id));
      const top = Math.max(...on.map((k) => kwBid(st, k)));
      row({ Campaign: c.name, 'Ad Group': g.name, 'Max CPC': (top / 100).toFixed(2), 'Ad Group Status': 'Enabled' });
      on.forEach((k) => row({ Campaign: c.name, 'Ad Group': g.name, Keyword: k.kw, 'Criterion Type': k.match === 'exact' ? 'Exact' : k.match === 'phrase' ? 'Phrase' : 'Broad', 'Max CPC': (kwBid(st, k) / 100).toFixed(2), Status: 'Enabled' }));
      const a = { Campaign: c.name, 'Ad Group': g.name, 'Ad type': 'Responsive search ad', 'Path 1': 'settlements', 'Path 2': 'check', 'Final URL': KW.url, Status: 'Enabled' };
      c.ads.h.forEach((h, i) => { a['Headline ' + (i + 1)] = h; }); c.ads.d.forEach((d, i) => { a['Description ' + (i + 1)] = d; });
      row(a);
    });
  });
  return rows.map((r) => r.map((v) => /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v).join(',')).join('\r\n');
}
async function kw() {
  if (!me.settings || !('kw_plan' in me.settings)) { try { me.settings = (await api('settings')).settings; } catch (e) { return fail(e); } }
  const st = kwState();
  const c = KW.campaigns.find((x) => x.id === st.tab) || KW.campaigns[0];
  const all = KW.campaigns.flatMap((x) => x.groups.flatMap((g) => g.keywords));
  const onAll = all.filter((k) => !st.off.has(k.id));
  const uniqVol = (list) => { const m = {}; list.forEach((k) => { m[k.kw] = k.vol || 0; }); return Object.values(m).reduce((a, b) => a + b, 0); };
  const budgetAll = KW.campaigns.reduce((a, x) => a + kwBudget(st, x), 0);
  const cid = st.customer_id, linked = /^\d{3}-\d{3}-\d{4}$/.test(cid);
  const T = (k, v, h) => '<div class="tile"><div class="k">' + k + '</div><div class="v">' + v + '</div>' + (h ? '<div class="h">' + h + '</div>' : '') + '</div>';
  const tabs = '<div class="seg" role="tablist">' + KW.campaigns.map((x) => { const n = x.groups.reduce((a, g) => a + g.keywords.filter((k) => !st.off.has(k.id)).length, 0); return '<button role="tab" aria-selected="' + (x.id === c.id) + '" class="' + (x.id === c.id ? 'on' : '') + '" data-t="' + x.id + '">' + esc(x.name.replace('CC Search - ', '')) + ' <span class="muted">' + n + '</span></button>'; }).join('') + '</div>';
  const ad = c.ads;
  const preview = '<div style="border-radius:14px;box-shadow:0 0 0 1px #E3EAE6;padding:14px 16px;max-width:620px;font-family:Arial,sans-serif">'
    + '<div class="small" style="color:#202124"><b>Sponsored</b></div><div class="small" style="color:#202124;margin:2px 0 4px">claimclub.io/settlements/check</div>'
    + '<div style="color:#1A0DAB;font-size:19px;line-height:1.3">' + esc(ad.h[0]) + ' | ' + esc(ad.h[1]) + ' | ' + esc(ad.h[2]) + '</div>'
    + '<div style="color:#4D5156;font-size:14px;line-height:1.5;margin-top:4px">' + esc(ad.d[0]) + ' ' + esc(ad.d[1]) + '</div></div>';
  const lines = (list, max) => '<ol style="margin:8px 0 0;padding-left:22px;display:flex;flex-direction:column;gap:4px">' + list.map((t) => '<li class="small"><b>' + esc(t) + '</b> <span class="muted">' + t.length + '/' + max + '</span></li>').join('') + '</ol>';
  const groups = c.groups.map((g, gi) => {
    const on = g.keywords.filter((k) => !st.off.has(k.id)).length;
    return '<div class="card"><div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:6px"><h2 style="margin:0">' + esc(g.name) + ' <span class="small muted">' + on + ' of ' + g.keywords.length + ' on · ' + uniqVol(g.keywords).toLocaleString() + ' searches/mo</span></h2>'
      + '<button class="btn soft" data-copy="' + gi + '">' + ico('M8 4h10a2 2 0 0 1 2 2v12 M4 8h10a2 2 0 0 1 2 2v10H6a2 2 0 0 1-2-2z', 15) + 'Copy keywords</button></div>'
      + '<table><thead><tr><th style="width:44px">On</th><th>Keyword</th><th style="text-align:right">Searches/mo</th><th style="text-align:right">Avg CPC</th><th style="text-align:right">Your max CPC</th></tr></thead><tbody>'
      + g.keywords.map((k) => { const off = st.off.has(k.id); return '<tr' + (off ? ' style="opacity:.45"' : '') + '><td><input type="checkbox" data-k="' + esc(k.id) + '"' + (off ? '' : ' checked') + ' aria-label="Bid on ' + esc(kwSyntax(k)) + '" style="width:18px;height:18px;accent-color:#12805C"></td>'
        + '<td><b>' + esc(kwSyntax(k)) + '</b> <span class="pill ' + (k.match === 'exact' ? 'p-filed' : 'p-ready') + '">' + (k.match === 'exact' ? 'Exact' : 'Phrase') + '</span></td>'
        + '<td style="text-align:right">' + (k.vol == null ? '<span class="muted">n/a</span>' : k.vol.toLocaleString()) + '</td><td style="text-align:right" class="muted">' + (k.cpc == null ? 'n/a' : money(k.cpc)) + '</td>'
        + '<td style="text-align:right"><span class="row" style="justify-content:flex-end;gap:4px"><span class="muted">$</span><input class="inp" data-b="' + esc(k.id) + '" inputmode="decimal" value="' + (kwBid(st, k) / 100).toFixed(2) + '" aria-label="Max CPC for ' + esc(k.kw) + '" style="width:78px;height:32px;text-align:right"></span></td></tr>'; }).join('')
      + '</tbody></table></div>';
  }).join('');
  main('<h1>Keyword Bidding</h1><div class="sub">Google Search ads for the claim flow. Search volume and average CPC from ' + esc(KW.source) + ', pulled ' + fmtDay(KW.pulled + 'T12:00:00') + '.</div>'
    + '<div class="card"><div class="row" style="justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:14px"><div style="max-width:600px"><h2 style="margin-bottom:6px">Google Ads account</h2>'
    + '<div class="small muted" style="line-height:1.55">The account Lunis used for testing. Enter its Customer ID (top right in Google Ads, like 123-456-7890), then download the upload file and import it with Google Ads Editor: Account > Import > From file, review, then Post. Campaigns upload paused, so nothing spends until you turn them on.</div></div>'
    + '<div class="row" style="gap:8px"><input id="kwCid" class="inp" placeholder="123-456-7890" value="' + esc(cid) + '" aria-label="Google Ads Customer ID" style="width:160px"><span class="pill ' + (linked ? 'p-approved' : 'p-ready') + '">' + (linked ? 'Saved' : 'Not set') + '</span></div></div></div>'
    + '<div class="tiles">' + T('Keywords on', onAll.length, 'of ' + all.length + ' (exact and phrase counted apart)') + T('Searches a month', uniqVol(onAll).toLocaleString(), 'US, keywords that are on') + T('Daily budget', '$' + budgetAll.toFixed(0), 'All 3 campaigns, $' + (budgetAll * 30.4).toFixed(0) + ' a month at most') + T('Landing page', '/claim', 'With UTM tags per campaign') + '</div>'
    + '<div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:14px">' + tabs
    + '<span class="row" style="gap:8px"><span id="kwMsg" class="small muted" role="status">' + (st.dirty ? 'Unsaved changes' : '') + '</span><button id="kwSave" class="btn ' + (st.dirty ? 'mint' : 'soft') + '">Save</button><button id="kwDl" class="btn dark">' + ico('M12 3v12 M7 10l5 5 5-5 M5 21h14', 15) + 'Download upload file</button></span></div>'
    + '<div class="grid2"><div>' + groups + '</div><div>'
    + '<div class="card"><h2 style="margin-bottom:6px">' + esc(c.name) + '</h2><div class="small muted" style="line-height:1.55;margin-bottom:12px">' + esc(c.note) + '</div>'
    + '<label class="small" style="font-weight:800;display:flex;flex-direction:column;gap:6px">Daily budget<span class="row" style="gap:4px"><span class="muted">$</span><input id="kwBud" class="inp" inputmode="decimal" value="' + kwBudget(st, c).toFixed(0) + '" style="width:100px"></span></label>'
    + '<div class="small muted" style="margin-top:10px">Manual CPC, Google Search only (no Display or partners), United States, English.</div></div>'
    + '<div class="card"><h2>Ad preview</h2>' + preview + '<div class="small muted" style="margin-top:10px">Google mixes these 15 headlines and 4 descriptions. No competitor names appear in the ads.</div>'
    + '<div class="small" style="font-weight:800;margin-top:12px">Headlines</div>' + lines(ad.h, 30) + '<div class="small" style="font-weight:800;margin-top:12px">Descriptions</div>' + lines(ad.d, 90) + '</div>'
    + '<div class="card"><h2>Negative keywords</h2><div class="small muted" style="margin-bottom:8px">Searches with these words never show our ads (phrase match).</div><div style="display:flex;flex-wrap:wrap;gap:6px">'
    + KW.shared_negatives.concat(c.negatives).map((n) => '<span class="pill p-ready">' + esc(n) + '</span>').join('') + '</div></div>'
    + '</div></div>');
  const dirty = () => { st.dirty = true; const m = $('#kwMsg'); if (m) m.textContent = 'Unsaved changes'; const b = $('#kwSave'); if (b) b.className = 'btn mint'; };
  document.querySelectorAll('.seg button[data-t]').forEach((b) => { b.onclick = () => { st.tab = b.dataset.t; kw(); }; });
  document.querySelectorAll('input[data-k]').forEach((x) => { x.onchange = () => { if (x.checked) st.off.delete(x.dataset.k); else st.off.add(x.dataset.k); st.dirty = true; kw(); }; });
  document.querySelectorAll('input[data-b]').forEach((x) => { x.onchange = () => { const v = Math.round(parseFloat(x.value.replace(/[^0-9.]/g, '')) * 100); if (v > 0 && v <= 5000) { st.bids[x.dataset.b] = v; x.value = (v / 100).toFixed(2); dirty(); } else { const k = all.find((y) => y.id === x.dataset.b); x.value = (kwBid(st, k) / 100).toFixed(2); } }; });
  $('#kwBud').onchange = () => { const v = parseFloat($('#kwBud').value.replace(/[^0-9.]/g, '')); if (v >= 1 && v <= 1000) { st.budgets[c.id] = Math.round(v); dirty(); kw(); } else $('#kwBud').value = kwBudget(st, c).toFixed(0); };
  $('#kwCid').onchange = () => { st.customer_id = $('#kwCid').value.replace(/\D/g, '').replace(/^(\d{3})(\d{3})(\d{4})$/, '$1-$2-$3'); dirty(); kw(); };
  document.querySelectorAll('button[data-copy]').forEach((b) => { b.onclick = async () => { const g = c.groups[+b.dataset.copy]; const txt = g.keywords.filter((k) => !st.off.has(k.id)).map(kwSyntax).join('\n'); try { await navigator.clipboard.writeText(txt); b.lastChild.textContent = 'Copied'; } catch (e) { b.lastChild.textContent = 'Copy failed'; } setTimeout(() => { b.lastChild.textContent = 'Copy keywords'; }, 1600); }; });
  $('#kwDl').onclick = () => { const blob = new Blob(['﻿' + kwCsv(st)], { type: 'text/csv;charset=utf-8' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'claimclub-google-ads-' + new Date().toISOString().slice(0, 10) + '.csv'; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500); };
  $('#kwSave').onclick = async () => {
    const m = $('#kwMsg'); m.textContent = 'Saving...'; m.className = 'small muted';
    try { const r = await api('setSetting', { key: 'kw_plan', value: { customer_id: st.customer_id, off: [...st.off], bids: st.bids, budgets: st.budgets } }); me.settings = r.settings; st.dirty = false; kw(); const m2 = $('#kwMsg'); if (m2) m2.textContent = 'Saved'; }
    catch (e) { m.textContent = e.message; m.className = 'small err'; }
  };
}
