# Filing from the member app: signature step, proof upload, "Action needed" reply. /api/claim is faked here.
from playwright.sync_api import sync_playwright
import json, sys
FAKE=open('/tmp/fake_supabase.js').read()
W=int(sys.argv[1]) if len(sys.argv)>1 else 1440
calls=[]; signed={}
def claim(r):
  b=json.loads(r.request.post_data); a=b['action']; calls.append((a, {k:v for k,v in b.items() if k!='action'}))
  if a=='state': out={'signed':signed,'files':[]}
  elif a=='file':
    sid=b['settlement_id']
    if sid not in signed and not (b.get('signature') and b['signature'].get('agree') and ' ' in b['signature'].get('name','')):
      return r.fulfill(status=409,content_type='application/json',body=json.dumps({'error':'Type your full name to sign','needSign':True}))
    signed[sid]='2026-11-15T18:00:00Z'; out={'claim':{'settlement_id':sid,'status':'requested','answers':b.get('answers',{})},'signedNow':True}
  elif a=='attach': out={'file':{'id':7,'settlement_id':b['settlement_id'],'name':b['name'],'size':b['size'],'mime':b['mime']}}
  elif a=='reply': out={'claim':{'status':'requested'}}
  else: out={}
  r.fulfill(status=200,content_type='application/json',body=json.dumps(out))
with sync_playwright() as p:
  br=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  ctx=br.new_context(viewport={'width':W,'height':900});pg=ctx.new_page();e=[];pg.on('pageerror',lambda x:e.append(str(x)))
  ctx.route('**/supabase-js@2/**',lambda r:r.fulfill(status=200,content_type='application/javascript',body=FAKE))
  ctx.route('**/api/config',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'supabaseUrl':'https://x.supabase.co','supabaseAnonKey':'anon','testMode':True})))
  ctx.route('**/api/membership',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'membership':None if json.loads(r.request.post_data)['action']=='link' else {'kind':'member','plan':'1m','status':'test'}})))
  ctx.route('**/api/plaid',lambda r:r.fulfill(status=200,content_type='application/json',body='{"enabled":false}'))
  ctx.route('**/api/claim',claim)
  pg.goto('http://localhost:8790/d/index.html');pg.evaluate('''localStorage.clear();localStorage.setItem('claimclub_session',JSON.stringify({ids:['visa','kroger','cvs'],signed:[],plan:'1m',paid:'member',p:{name:'Maria Lopez',email:'maria@example.com',st:'WA'}}))''')
  pg.goto('http://localhost:8790/d/app.html');pg.wait_for_timeout(1000)
  pg.click('text=Email me a code');pg.wait_for_timeout(300);c=pg.locator('input[autocomplete="one-time-code"]');c.click();c.type('123456',delay=20);pg.wait_for_timeout(2000)
  pg.goto('http://localhost:8790/dashboard/claims');pg.wait_for_timeout(1800)
  # 1. no-proof claim: straight to the sign step
  pg.locator('button[aria-label="File the Visa & Mastercard claim"] >> visible=true').first.click() if pg.locator('button[aria-label="File the Visa & Mastercard claim"] >> visible=true').count() else pg.locator('button:has-text("File") >> visible=true').nth(0).click()
  pg.wait_for_timeout(500); pg.screenshot(path='/tmp/fl_1.png')
  dlg=pg.locator('[role=dialog] >> visible=true').first; print('sheet', dlg.get_attribute('aria-label'), '| step text', 'STEP 1 OF 1' in pg.inner_text('body') or 'STEP 1 OF 2' in pg.inner_text('body'))
  pg.fill('input[aria-label="Type your full legal name to sign"] >> visible=true','Maria Lopez')
  pg.click('button:has-text("I agree to sign electronically") >> visible=true'); pg.wait_for_timeout(200)
  pg.click('button:has-text("Sign and submit") >> visible=true'); pg.wait_for_timeout(900)
  print('filed call', [x for x in calls if x[0]=='file'][-1:])
  print('toast', 'Filing request sent' in pg.inner_text('body'))
  # 2. Notice ID claim: details + upload + sign
  pg.wait_for_timeout(4500)
  btn=pg.locator('button[aria-label^="File the Kroger"] >> visible=true')
  (btn.first if btn.count() else pg.locator('button:has-text("File") >> visible=true').first).click(); pg.wait_for_timeout(500)
  print('details step', 'Notice ID or claim number' in pg.inner_text('body'))
  pg.locator('[role=dialog] input[type=text] >> visible=true').first.fill('ABC1234567')
  pg.set_input_files('[role=dialog] input[type=file]', files=[{'name':'notice.pdf','mimeType':'application/pdf','buffer':b'%PDF-1.4 test'}]); pg.wait_for_timeout(700)
  print('file listed', 'notice.pdf' in pg.inner_text('[role=dialog]'), 'uploaded path', pg.evaluate('window.__uploads'))
  pg.screenshot(path='/tmp/fl_2.png')
  pg.click('[role=dialog] button:has-text("Continue")'); pg.wait_for_timeout(300)
  pg.fill('input[aria-label="Type your full legal name to sign"] >> visible=true','Maria Lopez')
  pg.click('button:has-text("I agree to sign electronically") >> visible=true')
  pg.screenshot(path='/tmp/fl_3.png')
  pg.click('button:has-text("Sign and submit") >> visible=true'); pg.wait_for_timeout(900)
  f=[x for x in calls if x[0]=='file'][-1][1]; print('kroger answers', f.get('answers'), 'sig', f.get('signature'))
  # 3. Action needed reply: staff set needs_info in the database, member reloads
  pg.evaluate("(()=>{const db=JSON.parse(localStorage.getItem('__fakedb'));db.claims.forEach(c=>{if(c.settlement_id==='cvs'){c.status='needs_info';c.admin_note='Please send the email CVS sent you about the data breach.'}});localStorage.setItem('__fakedb',JSON.stringify(db))})()")
  pg.reload(); pg.wait_for_timeout(2200)
  print('db cvs', pg.evaluate("JSON.parse(localStorage.getItem('__fakedb')).claims.filter(c=>c.settlement_id==='cvs').map(c=>c.status)"))
  pg.screenshot(path='/tmp/fl_r.png')
  rb=pg.locator('button:has-text("Reply") >> visible=true'); print('reply buttons', rb.count()); rb.first.click(); pg.wait_for_timeout(400)
  print('ask shown', 'about the data breach' in pg.inner_text('[role=dialog]'))
  pg.fill('textarea[aria-label="Your answer"]','Attached the email they sent me in March.')
  pg.screenshot(path='/tmp/fl_4.png')
  pg.click('[role=dialog] button:has-text("Send reply")'); pg.wait_for_timeout(700)
  print('reply call', [x for x in calls if x[0]=='reply'], 'toast', 'Reply sent' in pg.inner_text('body'))
  print('errors', e)
