# New claim-flow order (Nov 15): questions, estimate, email, fee or membership, payment, perks (members), details, sign, dashboard.
from playwright.sync_api import sync_playwright
import sys
FAKE = open('/tmp/site/fake_stripejs.js').read()
W = int(sys.argv[1]) if len(sys.argv) > 1 else 390
path = '/m/start.html?v=1' if W < 820 else '/d/start.html?v=1'
with sync_playwright() as p:
  b = p.chromium.launch(executable_path='/usr/bin/google-chrome')
  for kind in ('fee', 'member'):
    pg = b.new_page(viewport={'width': W, 'height': 844 if W < 820 else 900}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.route('https://js.stripe.com/**', lambda r: r.fulfill(status=200, content_type='text/javascript', body=FAKE))
    pg.goto('http://localhost:8790' + path); pg.wait_for_function('window.__dc'); pg.wait_for_timeout(300)
    seen = []
    S = lambda: pg.evaluate("window.__dc&&__dc.stepName?__dc.stepName():'(left)'")
    print(kind, 'steps:', pg.evaluate('__dc.steps().join(" > ")'))
    # answer the 7 questions: Yes to all
    for i in range(12):
      n = S()
      if not n.startswith('q'): break
      seen.append(n); pg.evaluate("__dc.answerYN?__dc.answerYN(true):null") if pg.evaluate("!!__dc.answerYN") else pg.locator('button', has_text='Yes').first.click(); pg.wait_for_timeout(250)
    seen.append(S())
    # estimate -> email
    while S() not in ('email',): 
      pg.evaluate('__dc.go(1)'); pg.wait_for_timeout(150); seen.append(S())
    pg.evaluate("__dc.setState({email:'ana@gmail.com'})"); pg.evaluate('__dc.go(1)'); pg.wait_for_timeout(300); seen.append(S())
    if kind == 'member':
      pg.locator('button', has_text='Or join').first.click(); pg.wait_for_timeout(300); seen.append(S())
      pg.locator('button', has_text='Start getting paid').first.click()
    else:
      pg.locator('button', has_text='Pay filing fee').first.click()
    pg.wait_for_selector('.ccp .ccp-body:not(.loading)'); pg.click('.ccp-pay'); pg.wait_for_timeout(5200)
    seen.append(S())
    if kind == 'member':
      for i in range(3):
        btns = pg.locator('button:visible', has_text='Next')
        if S() != 'perks': break
        (btns.first.click() if btns.count() else pg.evaluate('__dc.toSign()')); pg.wait_for_timeout(300)
      seen.append(S())
    print(kind, 'back button on details:', pg.locator('button[aria-label="Back"]:visible').count())
    pg.screenshot(path=f'/tmp/order_{kind}_{W}_details.png')
    pg.evaluate('__dc.go(1)'); pg.wait_for_timeout(300); seen.append(S())
    pg.screenshot(path=f'/tmp/order_{kind}_{W}_auth.png')
    # sign everything in one go
    pg.evaluate("__dc.setState({saOpen:true,saConsent:true,saSigned:true})"); pg.wait_for_timeout(200)
    lab = pg.locator('button:visible', has_text='Sign all')
    if lab.count(): lab.last.click()
    pg.wait_for_timeout(1800); seen.append(S() + ' ' + pg.url.replace('http://localhost:8790', ''))
    print(kind, ' > '.join(seen), '| errs', errs)
    pg.close()
  b.close()
