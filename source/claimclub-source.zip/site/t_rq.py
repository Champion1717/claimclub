from playwright.sync_api import sync_playwright
import json
FAKE=open('/tmp/fake_supabase.js').read()
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  ctx=b.new_context(viewport={'width':1440,'height':900});pg=ctx.new_page();e=[];pg.on('pageerror',lambda x:e.append(str(x)));pg.on('console',lambda m:print('CONSOLE',m.text[:200]))
  calls=[]
  ctx.route('**/supabase-js@2/**',lambda r:r.fulfill(status=200,content_type='application/javascript',body=FAKE))
  ctx.route('**/api/config',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'supabaseUrl':'https://x.supabase.co','supabaseAnonKey':'anon','testMode':True,'cardConnect':True})))
  def mem(r):
    calls.append(r.request.post_data);d=json.loads(r.request.post_data)
    body={'membership':None} if d['action']=='link' else {'membership':{'kind':d.get('kind'),'plan':d.get('plan'),'status':'test'}}
    r.fulfill(status=200,content_type='application/json',body=json.dumps(body))
  ctx.route('**/api/membership',mem)
  pg.goto('http://localhost:8790/d/index.html');pg.evaluate('''localStorage.clear();localStorage.setItem('claimclub_session',JSON.stringify({ids:['apple','visa','googleplay','cvs'],signed:['apple'],bank:false,plan:'3m',paid:'member',p:{name:'Maria Lopez',email:'maria.lopez@example.com',phone:'',street:'88 Pine St',city:'Seattle',st:'WA',zip:'98101',dob:''}}))''')
  pg.goto('http://localhost:8790/d/app.html');pg.wait_for_timeout(900);pg.screenshot(path='/tmp/db_signin.png')
  print('signin visible',pg.locator('text=Log in to Claimclub').count(),'email prefilled',pg.locator('input[type=email]').input_value())
  pg.click('text=Email me a code');pg.wait_for_timeout(300);pg.screenshot(path='/tmp/db_code.png')
  c=pg.locator('input[autocomplete="one-time-code"]');c.click();c.type('111111',delay=30);pg.wait_for_timeout(400);print('bad code err',pg.locator('[role=alert]').inner_text())
  c.fill('');c.type('123456',delay=30);pg.wait_for_timeout(1500)
  print('after login', pg.locator('text=Log in to Claimclub').count(), [l for l in pg.inner_text('body').split('\n') if 'Hi ' in l][:1])
  pg.evaluate("(()=>{const db=JSON.parse(localStorage.getItem('__fakedb'));const s=JSON.parse(localStorage.getItem('__fakesess'));db.memberships.push({user_id:s.user.id,kind:'member',plan:'3m',status:'test',started_at:new Date().toISOString()});localStorage.setItem('__fakedb',JSON.stringify(db))})()")
  pg.goto('http://localhost:8790/dashboard/refunds');pg.wait_for_timeout(1800)
  pg.locator('text=+ Add a charge yourself >> visible=true').first.click();pg.wait_for_timeout(400);pg.fill('input[placeholder="Who charged you"]','City Fitness');pg.fill('input[placeholder="$0.00"]','39.99');pg.fill('.popCard textarea','Kept billing after I canceled');pg.locator('.popCard button:has-text("Ask for it back")').click();pg.wait_for_timeout(800);pg.screenshot(path='/tmp/rq_dbg.png');pg.wait_for_timeout(1000)
  db=pg.evaluate("JSON.parse(localStorage.getItem('__fakedb'))");print('refund rows',[(r.get('company'),r.get('amount'),r.get('status')) for r in db.get('refund_requests',[])])
  pg.reload();pg.wait_for_timeout(1800);print('after reload', 'City Fitness' in pg.inner_text('body'), e[:3])
  pg.screenshot(path='/tmp/h_db_ref.png')
