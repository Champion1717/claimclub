from playwright.sync_api import sync_playwright
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  pg=b.new_page(viewport={'width':1440,'height':900});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
  pg.goto('http://localhost:8790/d/index.html');pg.wait_for_timeout(900)
  pg.screenshot(path='/tmp/site/h_top.png')
  pg.evaluate("document.querySelector('#settlements').scrollIntoView()");pg.wait_for_timeout(800)
  pg.click('[data-snext]');pg.wait_for_timeout(900);pg.click('[data-snext]');pg.wait_for_timeout(900)
  print('scrollLeft',pg.evaluate("document.querySelector('[data-shelf]').scrollLeft"),'prev disabled',pg.evaluate("document.querySelector('[data-sprev]').disabled"),'thumb',pg.evaluate("document.querySelector('[data-sthumb]').style.left"))
  pg.screenshot(path='/tmp/site/h_shelf.png')
  # drag thumb to end
  bb=pg.locator('[data-sthumb]').bounding_box();pg.mouse.move(bb['x']+5,bb['y']+3);pg.mouse.down();pg.mouse.move(bb['x']+2000,bb['y']+3,steps=8);pg.mouse.up();pg.wait_for_timeout(300)
  print('after drag',pg.evaluate("const s=document.querySelector('[data-shelf]');[s.scrollLeft,s.scrollWidth-s.clientWidth]"),'next disabled',pg.evaluate("document.querySelector('[data-snext]').disabled"))
  print('icon',pg.evaluate("[...document.querySelectorAll('link[rel*=icon]')].map(l=>l.href)"),errs)
  m=b.new_page(viewport={'width':390,'height':844});m.goto('http://localhost:8790/m/index.html');m.wait_for_timeout(900);m.screenshot(path='/tmp/site/h_m.png')
  b.close()
