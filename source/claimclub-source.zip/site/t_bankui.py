from playwright.sync_api import sync_playwright
import json, time
FAKE=open('/tmp/fake_supabase.js').read()
def plaid(r):
  b=json.loads(r.request.post_data)
  if b['action']=='link_token': time.sleep(0.9)
  if b['action']=='exchange': time.sleep(1.5)
  r.fulfill(status=200,content_type='application/json',body=json.dumps({'link_token':'link-sandbox-1','ok':True}))
PL="window.Plaid={create:function(o){window.__o=o;return{open:function(){var f=document.createElement('iframe');f.id='plaid-link-iframe-1';f.style.cssText='position:fixed;left:50%;top:50%;width:400px;height:600px;margin:-300px 0 0 -200px;border:0;background:#fff;border-radius:16px;box-shadow:0 20px 60px rgba(0,0,0,.25);z-index:9999';document.body.appendChild(f);window.__opened=1}}}};"
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  for w,h,path in [(1440,900,'/d/start.html?v=1'),(390,844,'/m/start.html?v=1')]:
    ctx=b.new_context(viewport={'width':w,'height':h});pg=ctx.new_page();e=[];pg.on('pageerror',lambda x:e.append(str(x)))
    ctx.route('**/supabase-js@2/**',lambda r:r.fulfill(status=200,content_type='application/javascript',body=FAKE))
    ctx.route('**/api/config*',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'supabaseUrl':'https://x.supabase.co','supabaseAnonKey':'anon','bankConnect':True,'cardConnect':True})))
    ctx.route('**/api/plaid',plaid)
    ctx.route('https://cdn.plaid.com/**',lambda r:r.fulfill(status=200,content_type='application/javascript',body=PL))
    pg.goto('http://localhost:8790/d/index.html')
    pg.evaluate("""localStorage.clear();localStorage.setItem('__fakedb',JSON.stringify({profiles:[],claims:[],memberships:[]}));localStorage.setItem('__fakesess',JSON.stringify({access_token:'tok',user:{id:'u1',email:'ana@gmail.com'}}))""")
    pg.goto('http://localhost:8790'+path); pg.wait_for_function('window.__dc')
    pg.evaluate("__dc.setState({bankOn:true,plaidOn:true,email:'ana@gmail.com',paid:'fee'});setTimeout(()=>__dc.setState({step:__dc.steps().indexOf('bank')}),50)"); pg.wait_for_timeout(500)
    pg.screenshot(path=f'/tmp/bank_{w}_a.png')
    pg.locator('button:visible', has_text='Connect bank account').first.click(); pg.wait_for_timeout(250)
    pg.screenshot(path=f'/tmp/bank_{w}_b.png'); print(w,'button now:', pg.locator('button[aria-busy]:visible').first.inner_text())
    pg.wait_for_function('window.__opened'); pg.wait_for_timeout(400); pg.screenshot(path=f'/tmp/bank_{w}_c.png')
    t0=time.time(); ms=pg.evaluate("(()=>{const of=window.fetch;window.fetch=function(u,o){return /api\/plaid/.test(u)?new Promise(()=>{}):of(u,o)};const a=performance.now();window.__o.onSuccess('public-x',{institution:{name:'Chase',institution_id:'ins_3'}});return document.getElementById('ccCover')?Math.round(performance.now()-a):-1})()"); print(w,'loader shown within', ms, 'ms of Plaid finishing'); pg.wait_for_timeout(150); pg.screenshot(path=f'/tmp/bank_{w}_d.png')
    print(w,'cover text:',pg.inner_text('#ccCover'),'errors',e)
    ctx.close()
  b.close()
