from playwright.sync_api import sync_playwright
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  for n in ['dasha','dashb','dashc']:
    pg=b.new_page(viewport={'width':1440,'height':900});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto(f'http://localhost:8790/d/{n}.html');pg.wait_for_timeout(700)
    pg.screenshot(path=f'/tmp/{n}_0.png')
    btn=pg.locator('button:has-text("File")').first
    btn.click();pg.wait_for_timeout(300);pg.screenshot(path=f'/tmp/{n}_1.png')
    pg.wait_for_timeout(1100);pg.screenshot(path=f'/tmp/{n}_2.png')
    print(n,errs,pg.locator('[role=status]').count(),pg.locator('[role=status]').inner_text() if pg.locator('[role=status]').count() else '')
  b.close()
