# Pricing test (Nov 16 2026): t_ab.py [width] [a|b] runs flow A (fee and member) or flow B (trial) end to end.
# Based on t_order.py. Claim-flow order (Nov 15, later). Member: questions > estimate > email > choice > perks (3) > plans > payment > details > email code > sign > dashboard.
# Fee: ... > choice > fee receipt > payment > details > email code > sign > dashboard. Stubs ccAuth (code 123456) and fakes Stripe.js.
from playwright.sync_api import sync_playwright
import sys
FAKE = open('/tmp/site/fake_stripejs.js').read()
W = int(sys.argv[1]) if len(sys.argv) > 1 else 390
F = sys.argv[2] if len(sys.argv) > 2 else 'a'
path = ('/m/start.html?v=1' if W < 820 else '/d/start.html?v=1') + '&flow=' + F
STUB = "window.ccAuth={sent:[],send:function(e){this.sent.push(e);return Promise.resolve({})},verify:function(e,c){return Promise.resolve({ok:c==='123456'})}}"
with sync_playwright() as p:
  b = p.chromium.launch(executable_path='/usr/bin/google-chrome')
  for kind in (('fee', 'member') if F == 'a' else ('trial',)):
    pg = b.new_page(viewport={'width': W, 'height': 844 if W < 820 else 900}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.route('https://js.stripe.com/**', lambda r: r.fulfill(status=200, content_type='text/javascript', body=FAKE))
    pg.goto('http://localhost:8790' + path); pg.wait_for_function('window.__dc'); pg.wait_for_timeout(300); pg.evaluate(STUB)
    S = lambda: pg.evaluate("window.__dc&&__dc.stepName?__dc.stepName():'(left)'")
    seen = []
    def note():
      n = S()
      if not seen or seen[-1] != n: seen.append(n)
    for i in range(12):
      note()
      if not S().startswith('q'): break
      pg.locator('button:visible', has_text='Yes').first.click(); pg.wait_for_timeout(200)
    while S() != 'email': pg.evaluate('__dc.go(1)'); pg.wait_for_timeout(150); note()
    pg.evaluate("__dc.setState({email:'ana@gmail.com'})"); pg.evaluate('__dc.go(1)'); pg.wait_for_timeout(300); note()
    if kind == 'member':
      pg.screenshot(path=f'/tmp/ab_{W}_choice.png')
      pg.locator('button:visible', has_text='Join and file free').last.click(); pg.wait_for_timeout(300); note()
      pg.locator('button:visible', has_text='Start getting paid').first.click()
    elif kind == 'trial':
      print('flow', pg.evaluate('__dc.state.flow'), 'plan', pg.evaluate('__dc.state.plan'), 'step', S())
      pg.screenshot(path=f'/tmp/ab_{W}_trial.png')
      pg.locator('button:visible', has_text='Start my').last.click()
      pg.wait_for_selector('.ccp .ccp-body:not(.loading)'); pg.wait_for_timeout(400); pg.screenshot(path=f'/tmp/ab_{W}_sheet.png')
      print('checkout body:', pg.evaluate("fetch('/last').then(r=>r.json())"))
    else:
      pg.locator('button:visible', has_text='49.99 once').first.click()
    pg.wait_for_selector('.ccp .ccp-body:not(.loading)'); pg.click('.ccp-pay'); pg.wait_for_timeout(5200); note()
    # fill details
    pg.evaluate("__dc.setState({p:Object.assign({},__dc.state.p,{first:'Ana',last:'Reyes',street:'12 Oak St',city:'Austin',zip:'78701',phone:'5127436190'}),st:'TX'})"); pg.wait_for_timeout(200)
    pg.locator('button:visible', has_text='Continue').last.click(); pg.wait_for_timeout(400); note()
    print(kind, 'so far:', ' > '.join(seen), '| detErr', pg.evaluate('JSON.stringify(__dc.state.detTried)'), 'code sent to:', pg.evaluate('window.ccAuth.sent'))
    pg.screenshot(path=f'/tmp/ab_{W}_{kind}_code.png')
    pg.fill('input[autocomplete="one-time-code"]', '111111'); pg.wait_for_timeout(500)
    print(kind, 'wrong code:', pg.locator('[role=alert]:visible').first.inner_text() if pg.locator('[role=alert]:visible').count() else None, S())
    pg.fill('input[autocomplete="one-time-code"]', '123456'); pg.wait_for_timeout(700); note()
    pg.evaluate("__dc.setState({saOpen:true,saConsent:true,saSigned:true})"); pg.wait_for_timeout(200)
    lab = pg.locator('button:visible', has_text='Sign all')
    if lab.count(): lab.last.click()
    pg.wait_for_timeout(1800); note()
    print(kind, ' > '.join(seen), '| url', pg.url.replace('http://localhost:8790', ''), '| errs', errs)
    pg.close()
  b.close()
