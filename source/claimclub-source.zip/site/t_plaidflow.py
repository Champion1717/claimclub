# Plaid in the claim flow (Nov 15): with card connections on, "Connect bank account" calls window.ccPlaid; without it, the old dashboard handoff.
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
  b = p.chromium.launch(executable_path='/usr/bin/google-chrome'); pg = b.new_page(viewport={'width': 390, 'height': 844})
  pg.goto('http://localhost:8790/m/start.html?v=1'); pg.wait_for_function('window.__dc')
  pg.evaluate("() => { window.__calls=[]; window.ccPlaid=function(c){window.__calls.push(c.stepName());c.afterBank()} }")
  pg.evaluate("__dc.setState({bankOn:true,plaidOn:true,email:'ana@gmail.com',paid:'fee'});setTimeout(()=>__dc.setState({step:__dc.steps().indexOf('bank')}),50)"); pg.wait_for_timeout(400)
  print('step', pg.evaluate('__dc.stepName()'))
  pg.screenshot(path='/tmp/plaidflow.png')
  pg.locator('button:visible', has_text='Connect').first.click(); pg.wait_for_timeout(1500)
  print('ccPlaid called from', pg.evaluate('window.__calls'), '| url', pg.url.replace('http://localhost:8790',''))
  b.close()
