# Test link (Nov 15): /claim?test=<key> skips payment when the server accepts the key; a wrong key changes nothing.
from playwright.sync_api import sync_playwright
STUB = "() => { window.__mem=[]; window.ccAuth.send=function(){return Promise.resolve({})}; var v=window.ccAuth.verify; window.ccAuth.verify=function(e,c){window.__mem.push({kind:sessionStorage.getItem('cc_test_kind'),plan:sessionStorage.getItem('cc_test_plan'),key:sessionStorage.getItem('cc_test')});return Promise.resolve({ok:true})} }"
with sync_playwright() as p:
  b = p.chromium.launch(executable_path='/usr/bin/google-chrome')
  for key, kind in [('mock-test-key-123456', 'member'), ('mock-test-key-123456', 'fee'), ('wrong-key', 'fee')]:
    pg = b.new_page(viewport={'width': 390, 'height': 844}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
    sheet = []
    pg.route('https://js.stripe.com/**', lambda r: (sheet.append(1), r.abort()))
    pg.goto('http://localhost:8790/m/start.html?v=1&flow=a&test=' + key); pg.wait_for_function('window.__dc'); pg.wait_for_timeout(700); pg.evaluate(STUB)
    badge = pg.locator('#ccTestBadge').count()
    pg.evaluate("() => { const a={}; __dc.quiz().forEach((q,i)=>{a[q.key]=q.opts[0][0]}); __dc.setState({email:'tester@gmail.com',a:a,step:__dc.steps().indexOf('pay')}) }"); pg.wait_for_timeout(300)
    if kind == 'member':
      pg.locator('button:visible', has_text='Join and file free').last.click(); pg.wait_for_timeout(300)
      pg.locator('button:visible', has_text='Start getting paid').first.click()
    else:
      pg.locator('button:visible', has_text='49.99 once').first.click()
    pg.wait_for_timeout(4500)
    st = pg.evaluate("__dc.stepName()+' paid='+__dc.state.paid")
    sheet_open = pg.locator('.ccp').count()
    print(key, kind, '| badge', badge, '| after pay:', st, '| Stripe loaded (real payment path)', len(sheet) > 0, '| errs', errs)
    if 'details' in st:
      pg.screenshot(path=f'/tmp/testlink_{kind}.png')
    pg.close()
  b.close()
