from playwright.sync_api import sync_playwright
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  for w,h in [(834,1194),(1024,768),(912,1368),(1440,900)]:
    pg=b.new_page(viewport={'width':w,'height':h});pg.goto('http://localhost:8790/d/index.html');pg.wait_for_timeout(1800)
    r=pg.evaluate("(()=>{const t=document.querySelector('.herotext').getBoundingClientRect(),v=document.querySelector('.vis-stats').getBoundingClientRect();return [Math.round(t.top),Math.round(v.top),Math.round(v.left),Math.round(v.right),document.documentElement.scrollWidth]})()")
    print(w,h,'text top/vis top/left/right/scrollW',r);pg.screenshot(path=f'/tmp/tab_{w}.png');pg.close()
  b.close()
