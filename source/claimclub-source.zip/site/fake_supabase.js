(function(){
  var DB=JSON.parse(localStorage.getItem('__fakedb')||'{"profiles":[],"claims":[],"memberships":[]}');
  function save(){localStorage.setItem('__fakedb',JSON.stringify(DB))}
  var session=JSON.parse(localStorage.getItem('__fakesess')||'null');
  function Q(t){this.t=t;this.f=[];this.op='select';this.payload=null;this.single=false}
  Q.prototype.select=function(){if(this.op==='select')this.op='select';this.ret=true;return this};
  Q.prototype.eq=function(k,v){this.f.push([k,v]);return this};
  Q.prototype.maybeSingle=function(){this.single=true;return this};
  Q.prototype.insert=function(r){this.op='insert';this.payload=[].concat(r);return this};
  Q.prototype.update=function(r){this.op='update';this.payload=r;return this};
  Q.prototype.upsert=function(r,o){this.op='upsert';this.payload=[].concat(r);this.conf=(o&&o.onConflict||'').split(',');return this};
  Q.prototype.then=function(res,rej){var t=DB[this.t],me=this,out;
    var match=function(r){return me.f.every(function(f){return r[f[0]]===f[1]})};
    if(this.op==='select'){out=t.filter(match)}
    else if(this.op==='insert'){out=this.payload.map(function(r){r=Object.assign({id:Math.random()},r);t.push(r);return r})}
    else if(this.op==='update'){out=t.filter(match);out.forEach(function(r){Object.assign(r,me.payload)})}
    else if(this.op==='upsert'){out=this.payload.map(function(r){var ex=t.find(function(x){return me.conf.every(function(k){return x[k]===r[k]})});if(ex){Object.assign(ex,r);return ex}t.push(r);return r})}
    save();var data=this.single?(out[0]||null):out;return Promise.resolve({data:data,error:null}).then(res,rej)};
  window.supabase={createClient:function(){return{
    auth:{getSession:function(){return Promise.resolve({data:{session:session}})},
      signInWithOtp:function(o){window.__otpTo=o.email;return Promise.resolve({error:null})},
      verifyOtp:function(o){if(o.token!=='123456')return Promise.resolve({data:{},error:{message:'bad'}});var u=DB.profiles.find(function(p){return p.email===o.email});if(!u){u={id:'u'+Date.now(),email:o.email,created_at:new Date().toISOString()};DB.profiles.push(u);save()}session={access_token:'tok',user:{id:u.id,email:o.email}};localStorage.setItem('__fakesess',JSON.stringify(session));return Promise.resolve({data:{session:session},error:null})},
      onAuthStateChange:function(){},getUser:function(){return Promise.resolve({data:{user:session&&session.user}})},
      signOut:function(){session=null;localStorage.removeItem('__fakesess');return Promise.resolve({})}},
    from:function(t){return new Q(t)}}}};
})();
