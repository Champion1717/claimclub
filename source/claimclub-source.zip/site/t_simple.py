import sys, json
sys.argv=[sys.argv[0]]+sys.argv[1:]
W=int(sys.argv[1]) if len(sys.argv)>1 else 1440
src=open('/tmp/t_plaid2.py').read()
head=src[:src.index("  pg.goto('http://localhost:8790/dashboard/refunds')")]
head=head.replace("W=int(sys.argv[1]) if len(sys.argv)>1 else 1440","W=%d"%W).replace("'height':900","'height':%d"%(844 if W<800 else 900))
body='''
  P='/tmp/sx_%d_'%W
  pg.goto('http://localhost:8790/dashboard');pg.wait_for_timeout(1800);pg.screenshot(path=P+'0claims.png')
  pg.get_by_role("button",name="Finish",exact=True).first.click();pg.wait_for_timeout(600);pg.screenshot(path=P+'1info.png');print('url info',pg.url)
  pg.keyboard.press('Escape');pg.wait_for_timeout(300);print('closed',pg.url)
  pg.locator('[aria-label="Account menu"] >> visible=true').first.click();pg.wait_for_timeout(300);pg.screenshot(path=P+'2menu.png')
  pg.locator('button:has-text("Settings") >> visible=true').first.click();pg.wait_for_timeout(500);pg.screenshot(path=P+'3settings.png');print('url set',pg.url)
  pg.keyboard.press('Escape');pg.wait_for_timeout(300)
  pg.locator('button:has-text("Visa") >> visible=true').first.click();pg.wait_for_timeout(500);pg.screenshot(path=P+'4det.png');pg.keyboard.press('Escape')
  pg.goto('http://localhost:8790/dashboard');pg.wait_for_timeout(1500)
  pg.locator('.nxBtn >> visible=true').first.click();pg.wait_for_timeout(600);pg.screenshot(path=P+'5file.png')
  pg.goto('http://localhost:8790/dashboard/settlements');pg.wait_for_timeout(1500);pg.screenshot(path=P+'6find.png')
  pg.goto('http://localhost:8790/dashboard/refunds');pg.wait_for_timeout(1500)
  pg.get_by_role('button',name='Connect a card',exact=True).first.click();pg.wait_for_timeout(1500)
  pg.screenshot(path=P+'7ref.png')
  pg.locator('button:has-text("First Platypus") >> visible=true').first.click();pg.wait_for_timeout(500);pg.screenshot(path=P+'8cards.png')
  pg.keyboard.press('Escape');pg.wait_for_timeout(300)
  pg.locator('text=+ Add a charge yourself >> visible=true').first.click();pg.wait_for_timeout(400)
  pg.fill('input[placeholder="Who charged you"]','Spirit Airlines');pg.fill('textarea','Seat fee I did not agree to');pg.screenshot(path=P+'9add.png')
  pg.locator('button:has-text("Ask for it back")').click();pg.wait_for_timeout(900);print('pop closed', pg.locator('.popCard').count()==0)
  pg.goto('http://localhost:8790/dashboard/subscriptions');pg.wait_for_timeout(1800);pg.screenshot(path=P+'10subs.png')
  print('errors',e[:3])
'''
exec(compile(head+body,'t','exec'))
