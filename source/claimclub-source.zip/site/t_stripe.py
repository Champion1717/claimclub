from playwright.sync_api import sync_playwright
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  for vw,path in [((1280,800),'/d/start.html'),((390,844),'/m/start.html')]:
    pg=b.new_page(viewport={'width':vw[0],'height':vw[1]});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://localhost:8790'+path);pg.wait_for_timeout(500)
    pg.evaluate("()=>{const c=__dc;c.setState({email:'ana@gmail.com',plan:'3m',step:c.steps().indexOf('plans')})}")
    pg.wait_for_timeout(300)
    pg.evaluate("()=>ccLive(__dc,{}).subscribe()")
    pg.wait_for_timeout(1200);pg.wait_for_function("window.__dc")
    print(path,'after return step:',pg.evaluate("__dc.stepName()"),pg.evaluate("__dc.state.payState"))
    pg.wait_for_timeout(2000)
    print(path,'final step:',pg.evaluate("__dc.stepName()"),'paid:',pg.evaluate("__dc.state.paid"),'plan:',pg.evaluate("__dc.state.plan"),'email:',pg.evaluate("__dc.state.email"),'url:',pg.url,'errs',errs)
    pg.screenshot(path='/tmp/site/st_'+vw[0].__str__()+'.png')
  import urllib.request;print(urllib.request.urlopen('http://localhost:8790/last').read().decode())
  b.close()
