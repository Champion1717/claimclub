import re
# Nov 21 2026: offer G (T3 plan page). Nov 22: details come after payment (or after picking Standard). t_tiers.py [width] [std|fast|pri]
import sys, json
from playwright.sync_api import sync_playwright
W = int(sys.argv[1]) if len(sys.argv) > 1 else 390
T = sys.argv[2] if len(sys.argv) > 2 else 'fast'
path = ('/m/start.html?v=1' if W < 820 else '/d/start.html?v=1') + '&flow=g'
FAKE = open('/tmp/site/fake_stripejs.js').read()
STUB = "window.ccAuth={sent:[],send:function(e){this.sent.push(e);return Promise.resolve({})},verify:function(e,c){return Promise.resolve({ok:c==='123456'})}}"
signs = []; cks = []
with sync_playwright() as p:
  b = p.chromium.launch(executable_path='/usr/bin/google-chrome')
  pg = b.new_page(viewport={'width': W, 'height': 844 if W < 820 else 900}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
  pg.route('https://js.stripe.com/**', lambda r: r.fulfill(status=200, content_type='text/javascript', body=FAKE))
  pg.route(lambda u: 'standard=1' in u, lambda r: r.fulfill(status=200, content_type='application/json', body=json.dumps({'ids': ['apple', 'visa', 'equifax'], 'count': 3})))
  def sign(r): signs.append(json.loads(r.request.post_data)); r.fulfill(status=200, content_type='application/json', body='{"ok":true}')
  pg.route('**/api/sign', sign)
  pg.on('request', lambda r: cks.append(r.post_data) if '/api/checkout' in r.url else None)
  pg.goto('http://localhost:8790' + path); pg.wait_for_function('window.__dc'); pg.wait_for_timeout(300); pg.evaluate(STUB)
  S = lambda: pg.evaluate("window.__dc&&__dc.stepName?__dc.stepName():'(left)'")
  seen = []
  def note():
    n = S()
    if not seen or seen[-1] != n: seen.append(n)
  for i in range(12):
    note()
    if not S().startswith('q'): break
    pg.locator('button:visible', has_text='Yes').first.click(); pg.wait_for_timeout(200)
  while S() != 'email': pg.evaluate('__dc.go(1)'); pg.wait_for_timeout(150); note()
  pg.evaluate("__dc.setState({email:'ana@gmail.com'})"); pg.evaluate('__dc.go(1)'); pg.wait_for_timeout(300); note()
  pg.screenshot(path=f'/tmp/tg_{W}_page.png', full_page=True)
  name = {'std': 'Standard', 'fast': 'Fast', 'pri': 'Priority'}[T]
  pg.locator('[role=radio]:visible', has_text=name).first.click(); pg.wait_for_timeout(200)
  if T == 'std': pg.locator('[role=checkbox]:visible').first.click(); pg.wait_for_timeout(200)
  pg.screenshot(path=f'/tmp/tg_{W}_{T}.png')
  pg.locator('button:visible', has_text=re.compile('^(Start|Continue with)')).last.click(); pg.wait_for_timeout(600)
  if T != 'std':
    pg.wait_for_selector('.ccp .ccp-body:not(.loading)'); pg.wait_for_timeout(300); pg.click('.ccp-pay'); pg.wait_for_timeout(200); print('no tick, signs so far', len(signs), '| error', pg.locator('.ccp-err').inner_text()); pg.check('.ccp-ag'); pg.screenshot(path=f'/tmp/tg_{W}_{T}_sheet.png'); pg.click('.ccp-pay'); pg.wait_for_timeout(5200)
  note(); print('signs before details', len(signs))
  pg.evaluate("__dc.setState({p:Object.assign({},__dc.state.p,{first:'Ana',last:'Reyes',street:'12 Oak St',city:'Austin',zip:'78701',phone:'5127436190',dob:'04/02/1990'}),st:'TX'})"); pg.wait_for_timeout(200)
  pg.locator('button:visible', has_text='Continue').last.click(); pg.wait_for_timeout(800); note()
  print('step', S(), '| code sent to', pg.evaluate('window.ccAuth.sent'), '| cc_std', pg.evaluate("sessionStorage.getItem('cc_std')"))
  print(' > '.join(seen), '| errs', errs)
  print('checkout bodies:', [json.loads(x).get('plan') for x in cks if x])
  for s in signs: print('sign:', s['method'], len(s['records']))
  b.close()
