import re
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome')
  pg=b.new_page(viewport={'width':1440,'height':900});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
  pg.goto('http://localhost:8790/d/index.html');pg.wait_for_timeout(900)
  heads=pg.evaluate("[...document.querySelectorAll('[data-shelf] a')].map(a=>a.innerText.split('\\n').filter(x=>/Up to|Automatic|Cash share/.test(x))[0])")
  print('tiles',len(heads),'cash share',sum(1 for h in heads if h and 'Cash share' in h), heads[:6])
  print('count line',pg.locator('text=/nationwide/').first.inner_text()[:80])
  pg.goto('http://localhost:8790/d/start.html?offer=goodrx');pg.wait_for_timeout(900)
  pg.get_by_role('button',name='Yes').first.click();pg.wait_for_timeout(900)
  print('picked total',pg.evaluate("__dc.renderVals().pickedTotal"))
  pg.get_by_role('button',name='Continue with 1 claim').click();pg.wait_for_timeout(3400)
  v=pg.evaluate("(()=>{const r=__dc.renderVals();return [__dc.stepName(),r.totalNum,r.amountWords,r.totalLabel,r.hasFigure]})()");print(v)
  pg.screenshot(path='/tmp/fig_check.png')
  pg.goto('http://localhost:8790/d/start.html?offer=visa');pg.wait_for_timeout(900);pg.get_by_role('button',name='Yes').first.click();pg.wait_for_timeout(900)
  print('visa total',pg.evaluate("__dc.renderVals().pickedTotal"))
  print('errs',errs);b.close()
