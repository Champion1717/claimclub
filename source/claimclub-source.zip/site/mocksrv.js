const http=require('http'),fs=require('fs'),path=require('path');
const root='/tmp/site/out';let last=null;
http.createServer((req,res)=>{const u=new URL(req.url,'http://x');
 if(u.pathname==='/api/checkout'){let d='';req.on('data',c=>d+=c);req.on('end',()=>{last=JSON.parse(d);res.end(JSON.stringify({url:'/fakestripe?kind='+last.kind+'&back='+last.path}))});return}
 if(u.pathname==='/fakestripe'){res.writeHead(302,{Location:u.searchParams.get('back')+'?paid='+u.searchParams.get('kind')+'&sid=cs_test_abc'});return res.end()}
 if(u.pathname==='/api/session'){return res.end(JSON.stringify({paid:true}))}
 if(u.pathname==='/last'){return res.end(JSON.stringify(last))}
 const f=path.join(root,u.pathname);fs.readFile(f,(e,b)=>{if(e){res.statusCode=404;return res.end()}res.setHeader('Content-Type',f.endsWith('.js')?'text/javascript':f.endsWith('.html')?'text/html':f.endsWith('.svg')?'image/svg+xml':f.endsWith('.png')?'image/png':'');res.end(b)})}).listen(8790);
