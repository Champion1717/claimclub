const http=require('http'),fs=require('fs'),path=require('path');
const root='/tmp/site/out';let last=null;
http.createServer((req,res)=>{const u=new URL(req.url,'http://x');
 if(u.pathname==='/api/checkout'){let d='';req.on('data',c=>d+=c);req.on('end',()=>{last=JSON.parse(d);res.end(JSON.stringify(last.ui==='elements'?{clientSecret:'cs_test_abc_secret_x',publishableKey:'pk_test_x'}:{url:'/fakestripe?kind='+last.kind+'&back='+last.path}))});return}
 if(u.pathname==='/fakestripe'){res.writeHead(302,{Location:u.searchParams.get('back')+'?paid='+u.searchParams.get('kind')+'&sid=cs_test_abc'});return res.end()}
 if(u.pathname==='/api/account-exists'){let d='';req.on('data',c=>d+=c);req.on('end',()=>{const e=(JSON.parse(d||'{}').email||'');res.setHeader('Content-Type','application/json');res.end(JSON.stringify({exists:/^member/.test(e)}))});return}
 // emulate vercel.json redirects and rewrites
 {let vc={};try{vc=JSON.parse(fs.readFileSync(path.join(root,'vercel.json'),'utf8'))}catch(e){}
  const ck=Object.fromEntries((req.headers.cookie||'').split(/;\s*/).filter(Boolean).map(x=>x.split('=')));
  const conds=(r)=>(r.has||[]).every(h=>h.type==='cookie'?ck[h.key]===h.value:h.type==='header'?new RegExp('^'+h.value+'$').test(req.headers[h.key]||''):h.type==='query'?u.searchParams.has(h.key):true)&&(r.missing||[]).every(h=>h.type==='query'?!u.searchParams.has(h.key):true);
  const match=(src)=>{const re=new RegExp('^'+src.replace(/:[a-z]+\*?/g,'[^/]+')+'$');return re.test(u.pathname)};
  for(const r of vc.redirects||[]){if(match(r.source)&&conds(r)){res.writeHead(308,{Location:r.destination+u.search});return res.end()}}
  const isFile=(()=>{try{return fs.statSync(path.join(root,u.pathname)).isFile()}catch(e){return false}})();
  if(!isFile)for(const r of vc.rewrites||[]){if(match(r.source)&&conds(r)){u.pathname=r.destination;break}}}
 if(u.pathname==='/api/config'&&u.searchParams.get('test')!==null){res.setHeader('Content-Type','application/json');return res.end(JSON.stringify({testKey:u.searchParams.get('test')==='mock-test-key-123456'}))}
 if(u.pathname==='/api/session'){return res.end(JSON.stringify({paid:true}))}
 if(u.pathname==='/last'){return res.end(JSON.stringify(last))}
 const f=path.join(root,u.pathname);fs.readFile(f,(e,b)=>{if(e){res.statusCode=404;return res.end()}res.setHeader('Content-Type',f.endsWith('.js')?'text/javascript':f.endsWith('.html')?'text/html':f.endsWith('.svg')?'image/svg+xml':f.endsWith('.png')?'image/png':'');res.end(b)})}).listen(8790);
