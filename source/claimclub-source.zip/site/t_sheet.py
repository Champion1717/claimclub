# In-page payment sheet test (Nov 15 2026): fake Stripe.js, fee and membership, phone and desktop.
# Usage: python3 t_sheet.py   (needs node /tmp/site/mocksrv.js on 8790). Screenshots in /tmp/sheet_*.png
from playwright.sync_api import sync_playwright
FAKE = open('/tmp/site/fake_stripejs.js').read()
with sync_playwright() as p:
  b = p.chromium.launch(executable_path='/usr/bin/google-chrome')
  for vw, path in [((390, 844), '/m/start.html?v=1'), ((1440, 900), '/d/start.html?v=1')]:
    for kind in ('fee', 'member'):
      pg = b.new_page(viewport={'width': vw[0], 'height': vw[1]}); errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
      pg.route('https://js.stripe.com/**', lambda r: r.fulfill(status=200, content_type='text/javascript', body=FAKE))
      pg.goto('http://localhost:8790' + path); pg.wait_for_function('window.__dc'); pg.wait_for_timeout(400)
      pg.evaluate("""k=>{const c=__dc;const ids=c.matched().length?null:1;c.setState({email:'ana@gmail.com',plan:'1m',a:{x1:'apple',x2:'visa',x3:'googleplay',x4:'cvs',x5:'amazon',x6:'netflix'},step:c.steps().indexOf(k==='fee'?'pay':'plans')})}""", kind)
      pg.wait_for_timeout(500)
      tag = f'{vw[0]}_{kind}'
      pg.screenshot(path=f'/tmp/sheet_{tag}_page.png')
      btn = pg.locator('button', has_text='File my' if kind == 'fee' else 'Start getting paid').first
      btn.click(); pg.wait_for_selector('.ccp .ccp-body:not(.loading)', timeout=5000); pg.wait_for_timeout(450)
      pg.screenshot(path=f'/tmp/sheet_{tag}_open.png')
      # pay with the card button
      pg.click('.ccp-pay'); pg.wait_for_timeout(2600)
      st = pg.evaluate("window.__dc&&__dc.stepName?__dc.stepName()+' paid='+__dc.state.paid:'left flow'")
      print(tag, 'url', pg.url.replace('http://localhost:8790',''), st, 'sheet gone', pg.locator('.ccp').count() == 0,
            'confirm', pg.evaluate('JSON.stringify(window.__confirm)'), 'errs', errs)
      pg.close()
  # closing the sheet returns to the page; a declined card shows the error
  pg = b.new_page(viewport={'width': 390, 'height': 844}); pg.route('https://js.stripe.com/**', lambda r: r.fulfill(status=200, content_type='text/javascript', body=FAKE))
  pg.goto('http://localhost:8790/m/start.html?v=1'); pg.wait_for_function('window.__dc')
  pg.evaluate("__dc.setState({email:'ana@gmail.com',step:__dc.steps().indexOf('pay')})"); pg.wait_for_timeout(300)
  pg.locator('button', has_text='File my').first.click(); pg.wait_for_selector('.ccp .ccp-body:not(.loading)')
  pg.evaluate('window.__failPay=true'); pg.click('.ccp-pay'); pg.wait_for_timeout(700)
  print('declined:', pg.inner_text('.ccp-err'), '| button:', pg.inner_text('.ccp-pay'))
  pg.screenshot(path='/tmp/sheet_declined.png')
  pg.keyboard.press('Escape'); pg.wait_for_timeout(400)
  print('after close: sheet', pg.locator('.ccp').count(), 'step', pg.evaluate('__dc.stepName()'))
  pg.close()
  # Stripe.js blocked: falls back to the hosted page and comes back paid
  pg = b.new_page(viewport={'width': 390, 'height': 844}); pg.route('https://js.stripe.com/**', lambda r: r.abort())
  pg.goto('http://localhost:8790/m/start.html?v=1'); pg.wait_for_function('window.__dc')
  pg.evaluate("__dc.setState({email:'ana@gmail.com',step:__dc.steps().indexOf('pay')})"); pg.wait_for_timeout(300)
  pg.locator('button', has_text='File my').first.click(); pg.wait_for_timeout(3500)
  print('fallback: url', pg.url, pg.evaluate("window.__dc&&__dc.stepName?__dc.stepName()+' paid='+__dc.state.paid:'left flow'"), 'last', pg.evaluate("fetch('/last').then(r=>r.text())"))
  b.close()
