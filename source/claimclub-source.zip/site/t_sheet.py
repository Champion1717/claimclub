from playwright.sync_api import sync_playwright
import sys
W,H,page,tag=(390,844,'dasham','m') if len(sys.argv)>1 else (1440,900,'dasha','d')
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome');pg=b.new_page(viewport={'width':W,'height':H});e=[];pg.on('pageerror',lambda x:e.append(str(x)))
  pg.goto(f'http://localhost:8790/d/{page}.html');pg.wait_for_timeout(600);pg.screenshot(path=f'/tmp/{tag}s0.png')
  pg.click('button[aria-label="File the Google Play claim"]');pg.wait_for_timeout(400)
  dlg=pg.locator('[role=dialog]');print('dialog',dlg.count())
  dlg.locator('button:has-text("Yes")').nth(0).click();dlg.locator('button:has-text("Yes")').nth(1).click();pg.wait_for_timeout(150)
  pg.screenshot(path=f'/tmp/{tag}s1.png');dlg.locator('button:has-text("Continue")').click();pg.wait_for_timeout(200)
  dlg.locator('button:has-text("Continue")').click();pg.wait_for_timeout(100);print('still step2',dlg.inner_text().count('STEP 2'))
  inp=dlg.locator('input');inp.fill('henry@example.com');inp.dispatch_event('change');dlg.locator('button:has-text("$50 to $200")').click();pg.wait_for_timeout(150)
  pg.screenshot(path=f'/tmp/{tag}s2.png');dlg.locator('button:has-text("Continue")').click();pg.wait_for_timeout(200)
  pg.screenshot(path=f'/tmp/{tag}s3.png')
  dlg.locator('button:has-text("Direct deposit")').click();pg.wait_for_timeout(150);pg.screenshot(path=f'/tmp/{tag}s3.png');dlg.locator('button:has-text("Connect bank")').click();dlg.locator('button:has-text("I declare")').click();pg.wait_for_timeout(150)
  pg.screenshot(path=f'/tmp/{tag}s3b.png');dlg.locator('button:has-text("Submit claim")').click();pg.wait_for_timeout(1300)
  print('dialog gone',pg.locator('[role=dialog]').count()==0,'toast',pg.locator('[role=status]').inner_text()[:40]);pg.screenshot(path=f'/tmp/{tag}s4.png')
  # apple + No path
  pg.click('button[aria-label="File the Apple claim"]');pg.wait_for_timeout(300);dlg.locator('button:has-text("No")').first.click();pg.wait_for_timeout(150);pg.screenshot(path=f'/tmp/{tag}s5.png')
  dlg.locator('button:has-text("Remove claim")').click();pg.wait_for_timeout(200);print('apple gone',pg.locator('button[aria-label="File the Apple claim"]').count()==0)
  # settings
  pg.locator('button:has-text("Settings")').first.click();pg.wait_for_timeout(300);pg.screenshot(path=f'/tmp/{tag}set.png')
  pg.locator('button:has-text("Small")').click();pg.wait_for_timeout(200);pg.screenshot(path=f'/tmp/{tag}setS.png')
  pg.locator('button:has-text("Dashboard"), button:has-text("Claims")').first.click();pg.wait_for_timeout(300);pg.screenshot(path=f'/tmp/{tag}small.png')
  pg.locator('button:has-text("Settings")').first.click();pg.locator('button:has-text("Large")').click();pg.locator('button:has-text("Dashboard"), button:has-text("Claims")').first.click();pg.wait_for_timeout(300);pg.screenshot(path=f'/tmp/{tag}large.png')
  print(e);b.close()
