from playwright.sync_api import sync_playwright
import json
FAKE=open('/tmp/fake_supabase.js').read(); calls=[]
def mem(r):
  d=json.loads(r.request.post_data); calls.append(d['action'])
  if d['action']=='portal': return r.fulfill(status=200,content_type='application/json',body=json.dumps({'url':'http://localhost:8790/portal-test'}))
  r.fulfill(status=200,content_type='application/json',body=json.dumps({'membership':{'kind':'member','plan':'1m','status':'past_due'}}))
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/google-chrome'); ctx=b.new_context(viewport={'width':1440,'height':900}); pg=ctx.new_page(); e=[]; pg.on('pageerror',lambda x:e.append(str(x)))
  ctx.route('**/supabase-js@2/**',lambda r:r.fulfill(status=200,content_type='application/javascript',body=FAKE))
  ctx.route('**/api/config',lambda r:r.fulfill(status=200,content_type='application/json',body=json.dumps({'supabaseUrl':'https://x.supabase.co','supabaseAnonKey':'anon','testMode':False})))
  ctx.route('**/api/membership',mem); ctx.route('**/api/plaid',lambda r:r.fulfill(status=200,content_type='application/json',body='{"enabled":false}'))
  ctx.route('**/api/claim',lambda r:r.fulfill(status=200,content_type='application/json',body='{"signed":{},"files":[]}'))
  ctx.route('**/portal-test',lambda r:r.fulfill(status=200,content_type='text/html',body='<h1>Stripe portal</h1>'))
  pg.goto('http://localhost:8790/d/index.html');pg.evaluate('''localStorage.clear();localStorage.setItem('claimclub_session',JSON.stringify({ids:['visa'],signed:[],plan:'1m',paid:'member',linkedTo:'maria@example.com',p:{name:'Maria Lopez',email:'maria@example.com'}}))''')
  pg.goto('http://localhost:8790/d/app.html');pg.wait_for_timeout(900)
  pg.click('text=Email me a code');pg.wait_for_timeout(300);c=pg.locator('input[autocomplete="one-time-code"]');c.click();c.type('123456',delay=20);pg.wait_for_timeout(1500)
  pg.evaluate("(()=>{const db=JSON.parse(localStorage.getItem('__fakedb'));const s=JSON.parse(localStorage.getItem('__fakesess'));db.memberships=[{user_id:s.user.id,kind:'member',plan:'1m',status:'past_due'}];localStorage.setItem('__fakedb',JSON.stringify(db))})()")
  pg.goto('http://localhost:8790/dashboard');pg.wait_for_timeout(1800); pg.screenshot(path='/tmp/pd.png')
  t=pg.inner_text('main'); print('todo shown', 'payment did not go through' in t, 'locked', pg.locator('text=Members only >> visible=true').count()>0)
  pg.click('button:has-text("Update card") >> visible=true'); pg.wait_for_timeout(800); print('portal', pg.url, calls[-1], 'errors', e)
