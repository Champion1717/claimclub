// Meta Conversions API test (Nov 16 2026): webhook sends Purchase on the $2 trial checkout and Subscribe once on the first $49,
// nothing for flow A, nothing without a token, nothing for GPC. Fakes Stripe, Supabase and the Graph API. Run: node t_meta.js
const path = require('path'), Module = require('module');
const sent = [], subs = { sub_1: { id: 'sub_1', current_period_end: 1795400000, metadata: { plan: '1y', fbp: 'fb.1.1.2', ip: '1.2.3.4', ua: 'UA', source_url: 'https://www.claimclub.io/claim' } } };
let EVENT;
const fakeStripe = () => ({
  webhooks: { constructEvent: () => EVENT },
  subscriptions: { retrieve: async (id) => subs[id], update: async (id, u) => { Object.assign(subs[id].metadata, u.metadata); return subs[id]; } },
});
const q = () => { const o = { select: () => o, eq: () => o, ilike: () => o, maybeSingle: async () => ({ data: null }), upsert: async () => ({}), update: () => o, insert: async () => ({}), then: (r) => r({}) }; return o; };
const origLoad = Module._load;
Module._load = function (req, parent, isMain) {
  if (req === 'stripe') return fakeStripe;
  if (req === './_db' || req.endsWith('/_db')) return { db: () => ({ from: q }), renewsAt: () => new Date().toISOString() };
  if (req === './_email' || req.endsWith('/_email')) return { sendNotice: async () => {} };
  return origLoad.apply(this, arguments);
};
global.fetch = async (url, o) => { sent.push({ url, body: JSON.parse(o.body) }); return { ok: true, json: async () => ({ events_received: 1 }) }; };
const hook = require(path.join(__dirname, 'api/webhook.js'));
const call = async (ev) => { EVENT = ev; const req = new (require('stream').Readable)({ read() { this.push(null); } }); req.method = 'POST'; req.headers = {}; const res = { statusCode: 200, setHeader() {}, end() {} }; await hook(req, res); };
(async () => {
  process.env.STRIPE_SECRET_KEY = 'sk_test_x'; process.env.META_CAPI_TOKEN = 'tok';
  const sess = (md, id) => ({ type: 'checkout.session.completed', data: { object: { id, mode: 'subscription', created: 1763300000, amount_total: 200, customer_details: { email: 'Ana@Gmail.com ' }, subscription: 'sub_1', metadata: md } } });
  await call(sess({ kind: 'member', plan: '1y', flow: 'b', fbp: 'fb.1.1.2', ip: '1.2.3.4', ua: 'UA', source_url: 'https://www.claimclub.io/claim' }, 'cs_b'));
  await call(sess({ kind: 'member', plan: '1m', flow: 'a' }, 'cs_a'));
  await call(sess({ kind: 'member', plan: '1y', flow: 'b', gpc: '1' }, 'cs_gpc'));
  const inv = (id, reason, amt) => ({ type: 'invoice.paid', data: { object: { id, billing_reason: reason, amount_paid: amt, subscription: 'sub_1', customer_email: 'ana@gmail.com', status_transitions: { paid_at: 1763900000 } } } });
  await call(inv('in_create', 'subscription_create', 200));   // the $2 invoice at signup: not a Subscribe
  await call(inv('in_day7', 'subscription_cycle', 4900));     // first $49: Subscribe
  await call(inv('in_year2', 'subscription_cycle', 4900));    // year 2: not sent again
  delete process.env.META_CAPI_TOKEN; await call(sess({ kind: 'member', plan: '1y', flow: 'b' }, 'cs_notoken'));
  const ev = sent.map((s) => { const d = s.body.data[0]; return [d.event_name, d.event_id, d.custom_data.value, d.custom_data.predicted_ltv, !!(d.user_data.em && d.user_data.em[0].length === 64), d.user_data.client_ip_address || '', s.url.includes('/v26.0/1486613173392815/events')]; });
  console.log(JSON.stringify(ev));
  const ok = ev.length === 2 && ev[0][0] === 'Purchase' && ev[0][1] === 'cs_b' && ev[0][2] === 2 && ev[0][4] && ev[1][0] === 'Subscribe' && ev[1][1] === 'in_day7' && ev[1][2] === 49 && subs.sub_1.metadata.meta_subscribe_sent === '1';
  const em = sent[0].body.data[0].user_data.em[0], want = require('crypto').createHash('sha256').update('ana@gmail.com').digest('hex');
  console.log(ok && em === want ? 'PASS' : 'FAIL');
})();
