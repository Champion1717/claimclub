// (fake_db has no .or(), so the paths that pass the gate stop later; only the gate is checked)
// Server refuses a required-notice claim without its codes (node /tmp/site/t_notice_srv.js).
const assert = require('assert'), API = '/tmp/site/api/';
const fake = require('/tmp/site/fake_db.js');
const SPECS = require('/tmp/site/out/api/_specs.json'), byId = Object.fromEntries(SPECS.map((s) => [s.id, s]));
require.cache[require.resolve(API + '_db')] = { exports: { db: fake.db, userFrom: async () => ({ id: 'u1', email: 'maria@example.com' }), readJson: async (req) => req.body, send: (res, code, body) => { res.code = code; res.body = body; } } };
require.cache[require.resolve(API + '_email')] = { exports: { sendClaimEmail: async () => ({ sent: true }) } };
require.cache[require.resolve(API + '_spec')] = { exports: { getSpec: async (id) => byId[id] || null, getSpecs: async () => byId } };
fake.T.claims = []; fake.T.authorizations = []; fake.T.profiles = [{ id: 'u1', email: 'maria@example.com' }];
const h = require(API + 'claim.js');
const call = async (body) => { const res = { setHeader() {}, end() {} }; await h({ method: 'POST', headers: {}, body }, res); return res; };
(async () => {
  const base = { action: 'file', settlement_id: 'equifax', title: 'Equifax', co: 'Equifax', signature: { name: 'Maria Lopez', agree: true } };
  let r = await call(Object.assign({}, base, { answers: { q_0: 'yes', n_got: 'no' } }));
  assert.equal(r.code, 400); assert(r.body.needNotice); assert.deepEqual(r.body.missing, ['Claim Number', 'PIN']);
  r = await call(Object.assign({}, base, { answers: { n_got: 'yes', n_claim_number: 'EQ12345678' } }));
  assert.equal(r.code, 400); assert.deepEqual(r.body.missing, ['PIN']);
  r = await call(Object.assign({}, base, { answers: { n_got: 'yes', n_claim_number: 'EQ12345678', n_notice_pin: 'A1B2C3' } }));
  assert(!(r.body || {}).needNotice, 'codes given: passes the notice check');
  r = await call({ action: 'file', settlement_id: 'apple', title: 'Apple', co: 'Apple', signature: { name: 'Maria Lopez', agree: true }, answers: { n_got: 'no' } });
  assert(!(r.body || {}).needNotice, 'optional notice: no notice check');
  console.log('notice server tests passed');
})().catch((e) => { console.error(e); process.exit(1); });
